import json, re, hashlib, datetime, pathlib, subprocess
root=pathlib.Path('/workspace/xk-website')
out=pathlib.Path('/tmp/xk-task013/spec-audit.json')
spec=(root/'docs/task/task013.md').read_text()
rows=[]
for line in spec.splitlines():
    if re.match(r'^\| V13-',line):
        cells=[x.strip() for x in line.strip().strip('|').split('|')]
        rows.append(cells)
local={
'V13-L01': ['以scripts/run-with-evidence.py記錄npm ci及真實退出碼；保存Node/npm、lockfileVersion與前後package/lock Git差異。','npm ci exit 0，無非預期lockfile變更。'],
'V13-L02': ['分開保存npx tsc --noEmit與npm run lint的命令、時間、受測SHA/tree、stdout/stderr及真實exit。','兩命令各自exit 0，ESLint零警告，不以Vercel忽略型別/品質選項替代。'],
'V13-L03': ['在Pages旗標未啟用的一般模式執行npm run build，保存實際route/Next/Tailwind/font輸出與exit；新啟npm run start -- --hostname 127.0.0.1 --port 3030，保存PID/啟停與server log。','一般build exit 0；一般production server新啟可用；不把Pages .next直接交給next start。'],
'V13-L04': ['保存curl -sS -D /tmp/xk-v13-headers.txt -o /tmp/xk-v13-home.html http://127.0.0.1:3030/的真實exit與HTTP；對9公開routes、未知route/unknown portfolio slug/dev/privacy/sitemap逐一記錄headers/body；檢查根路徑assets與exact metadata。','9公開routes 200；未知route、unknown portfolio slug、/dev/design-system、draft /privacy、/sitemap.xml 404；robots.txt可取且無Sitemap；根路徑無Pages prefix。'],
'V13-L05': ['先停止一般server，再npm run build:pages並保存exit；依實際Base Path掛載靜態server；保存9公開routes、404.html、.nojekyll與CSS/JS/font/icon GET；掃描out的dev/privacy草案HTML/payload/text並保留validator log。','Pages build exit 0，9頁與引用資源正確；.nojekyll、404保留；dev與Privacy draft未輸出；一般模式/Pages不互相污染。'],
'V13-L06': ['9公開routes ×320/375/768/1440/1920px：保存每case版本/URL/viewport、overflow/clipping檢查、有效連結與錨點；手機選單開關、Escape回trigger、焦點離開關閉、route/outside/breakpoint、Skip Link、Reduced Motion、Console/Runtime/Network及CSS/JS/font/icon結果。一般production與Pages各保留實際範圍，不能以舊45case結果代填。','現有頁與互動正常，無溢出/裁切、失效連結/資源與未處理runtime error；保留Task012 disclosure與focus改善。'],
'V13-L07': ['保存9公開routes與手機選單展開態axe WCAG2/2.1 A/AA JSON、程序exit、人工鍵盤/名稱/heading/對比檢查；對axe incomplete另做決定；檢查Task012已合併修復未回退。','無新增WCAG2/2.1 A/AA違規與必要人工問題；保留Task012 WCAG2.2 AA改善，不能把自動工具當完整認證。']}
external={
'V13-A01': ['僅在使用者指定Team/Project後經受支援API或Dashboard唯讀盤點。保存非機密Owner/Team/Project ID/name、GitHub repo/App權限、production branch、root、preset、Node、install/build/output現值與差異、方案限制。','資源屬正確Owner/Team；repo=xk2022/xk-website、main、root .、Next.js、Node24.x、npm ci、npm run build、default output；不重建平行Project。'],
'V13-A02': ['記錄當次授權來源/時間/操作者權限與建立/link/啟用main autodeploy的實際副作用；在按Create/Import/Link前確認是否立即production；保留Pages workflow/source現值。','所執行寫入與立即Production副作用均在本輪授權內；Pages發布條件不改；不可事後才補production gate。'],
'V13-A03': ['保存各scope的Env名稱、用途、是否公開、Owner/更新方式；不讀出或記錄值。核對XK_PAGES_EXPORT與XK_PAGES_BASE_PATH未套入Vercel、XK_DESIGN_SYSTEM_PREVIEW及XK_PRIVACY_PREVIEW未開放；檢查diff/log/artifact/screenshot無secret，核對fork/不可信PR secrets限制。','目前無自訂env需要；Preview/Production均不得以XK_PRIVACY_PREVIEW=1公開draft，design-system預設關閉；不新增NEXT_PUBLIC_SITE_URL/API_BASE_URL等未讀變數或token。'],
'V13-P01': ['取得本次feature精確SHA的Preview Deployment ID/實際URL/environment/createdTime與Build/Deployment logs、Ready狀態；紀錄平台版本、字體取得/警告/修復重驗。','真正Vercel Preview完成，SHA等於受測feature，不用Pages artifact/舊Preview替代。'],
'V13-P02': ['URL必須由本次Deployment取得；保存curl -sS -L --max-redirs 5 -D <暫存headers> -o <暫存body> "$xk_preview_url"並以write-out記HTTP/final URL與真實exit；9路由/資源/預期404、browser手機/跨頁/錨點/console/network；保存本次Preview Desktop及Mobile實際截圖、URL/SHA/viewport/PNG尺寸/人工檢視。受保護Preview分開記401/403及授權檢視程序，不輸出bypass秘密。','實際Preview內容可依授權驗證，真實頁與assets正常，未知/dev/privacy/sitemap 404；不因保護而任意關閉protection或冒稱公開200。'],
'V13-P03': ['保存實際response/head HTML：逐頁title/description、noindex,nofollow、canonical/OG品牌host與path、zh-TW、Twitter text summary、最小WebSite JSON-LD、robots/sitemap保護；browser驗沒有新增假表單/收件/追蹤功能。','品牌Canonical/OG=https://xplorekaleidoscope.com+實際path；無/xk-website、Preview host/query/fragment；索引與Privacy/Contact保護保持。'],
'V13-C01': ['從當次Task013 PR exact head取得quality/pages-build SUCCESS及deploy SKIPPED的真實run/job/artifact/時間；記錄實際Review狀態及處理結果，將CI與Preview分列；確認final CI artifact對應final source。','本次PR head與本機受測來源、Preview版本吻合，CI成功不代替Review/部署；未發生階段PENDING。PR18不能冒充Task013 PR。'],
'V13-R01': ['發佈動作前保存本輪Production授權、審查與精確main SHA、品質/Preview結果、允許9頁內容/Contact/Privacy/noindex狀態、前版Ready ID/可回復性與操作者權限、可能autodeploy副作用。首次無前版必須明列限制/停止與修復方式，不能捏造前版。','只有gate具體完成且授權涵蓋才發佈；無授權PENDING，實際權限障礙BLOCKED；不能在main link立即部署後才聲稱提前gate。'],
'V13-R02': ['經授權觸發/promote對應main的production，保存實際environment、Deployment ID/URL/SHA/time、Build/Deployment成功logs；另存main Pages quality/pages-build/deploy run/job與URL/時間。','Vercel production Ready且對應受審main；Pages main部署是另一件事件。'],
'V13-R03': ['對實際Vercel Production URL重做全部9routes/預期404/robots/metadata/noindex的headers/body/finalURL/exit、引用CSS/JS/font/icon；browser保存手機/跨頁/錨點/Console/Runtime/Network與實際URL/SHA截圖或等效可追溯證據。','Production訪客路徑及資源正常，根路徑不含Pages prefix，draft/dev/sitemap不公開；Ready與公開smoke分開判定。'],
'V13-R04': ['保存真正前版Ready Deployment ID/SHA/URL與環境；依當時方案/平台確認rollback功能、操作者權限、啟動條件、逐步操作與回復後V13-R03+Pages驗證。初次無前版明列事實與停止後續發佈/修復forward限制。','提供可操作且符合實際權限的rollback計畫，無前版不假造ID；計畫不等於演練。'],
'V13-O01': ['僅有必要且本輪另有明確rollback授權時，執行後保存environment/Deployment ID/SHA/URL/時間、HTTP/resources與Pages regression。未演練保留PENDING並說明。','真正rollback後對應可回復SHA並重驗；Task013 merge/deploy授權不自動涵蓋生產切回演練。'],
'V13-O02': ['只在真實診斷需要時固定工具/CPU/network/cache、比較cold/warm或額外browser/真機/Lighthouse，保留raw outputs與退出碼；未執行PENDING。','不捏造CWV/INP/score，診斷不替代Task011完整量測。'],
'V13-N01': ['本次只做適用性判定與範圍紀錄；DNS/domain SSL/www由Task014；API/DB/forms delivery未建，不測假功能。','本次不新增或更動DNS/backend。父代理在正式矩陣可於附理由後將本項狀態判N/A；本次唯讀audit按交接要求仍保留PENDING。']}
matrix=[]
for test_id, app, procedure, status in rows:
    detail=(local if test_id in local else external)[test_id]
    applicability='Required' if app.startswith('Required') else 'Optional' if app.startswith('Optional') else 'Not Applicable'
    matrix.append({'test_id':test_id,'applicability':applicability,'applicability_reason':app.split('：',1)[-1],'spec_procedure':procedure,'planned_procedure':detail[0],'expected_result':detail[1],'necessary_local_evidence':detail[0] if test_id in local else ('當次精確source與保護規則核對，無本機測試可替代遠端證據。' if test_id!='V13-N01' else '範圍/適用性紀錄。'),'necessary_external_evidence':detail[0] if test_id in external and test_id!='V13-N01' else '本項非Vercel部署證據；遠端要求另見A/P/C/R各項。','actual_result':'未實測；本次僅唯讀來源與規格分析。','exit_code':None,'status':'PENDING','evidence':[],'notes':('Optional未執行不得改N/A。' if applicability=='Optional' else 'Not Applicable為適用性，與未執行狀態分開。' if applicability=='Not Applicable' else '歷史報告結果不可沿用。')})
files=['docs/task/task013.md','AGENTS.md','docs/subagent-workflow.md','next.config.ts','package.json','package-lock.json','.nvmrc','.github/workflows/ci.yml','.gitignore','scripts/build-github-pages.mjs','src/app/layout.tsx','src/app/robots.ts','src/app/privacy/page.tsx','src/app/dev/design-system/page.tsx','src/app/portfolio/[slug]/page.tsx','src/config/site.ts','src/config/seo.ts','src/config/privacy.ts','src/config/contact.ts','src/config/navigation.ts','src/config/portfolio.ts','src/lib/privacy-publication.ts','src/lib/seo.ts','src/components/layout/site-footer.tsx','src/components/layout/mobile-navigation.tsx','src/app/globals.css']
identities={f:{'sha256':hashlib.sha256((root/f).read_bytes()).hexdigest(),'bytes':(root/f).stat().st_size} for f in files}
get=lambda *args:subprocess.check_output(['git',*args],cwd=root,text=True).strip()
audit={
'audit_type':'有限唯讀規格/來源audit；非網站測試、非Vercel inventory、非deploy驗收',
'generated_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
'scope_constraints':['不修改repo','不Git mutation','不build/server/browser/npm install','不讀token或env值','不探測未知管理登入session','不另派agent','未實測全部PENDING'],
'spec_full_read':{'path':'docs/task/task013.md','sections':[str(i) for i in range(1,17)],'section_11_test_id_count':len(matrix),'spec_file_identity':identities['docs/task/task013.md']},
'static_observation_context':{'repo':'xk2022/xk-website','worktree_branch':get('branch','--show-current'),'worktree_head':get('rev-parse','HEAD'),'local_main':get('rev-parse','main'),'status_porcelain':get('status','--short'),'note':'此head為未合併PR18品牌copy分支。Task013須從當次最新已合併main建feature/website-vercel-deployment；不得自行把PR18當Task013 base或整合。父代理決定PR18後重新freeze。'},
'static_findings':[
{'area':'next.config.ts','observation':'XK_PAGES_EXPORT === 1才設output export/basePath/trailingSlash/images unoptimized；預設一般模式沒有export/basePath/output override，保留Tailwind Turbopack CSS loader。','implication':'既有雙模式符合Task013提案，無需為Vercel常規部署改寫。實際平台相容性與字體build仍PENDING。'},
{'area':'package/lock/Node','observation':'scripts build=next build、start=next start、build:pages=node scripts/build-github-pages.mjs；engines 24.x、.nvmrc 24；Next16.4.6、React19.3.1、Tailwind/Turbopack4.3.3；package-lock v3。','implication':'Vercel install用npm ci、build npm run build，output由Next preset；平台當時Node/Next支援必須查官方文件與真logs，不因規格快照無故升降級。'},
{'area':'CI/Pages','observation':'PR/push main/workflow_dispatch；quality→pages-build→deploy。deploy只非PR且main，OIDC/pages寫入只限deploy；quality .next artifact是診斷，Pages out artifact獨立；Base Path來自configure-pages。','implication':'不新增Vercel Actions/Token/--prebuilt，不變更現有Pages source、workflow、artifact、條件。fresh PR exact-head與main各查run。'},
{'area':'Privacy','observation':'status draft/version draft-1/controller/effectiveDate/rightsContact null；server-only publication gate；普通production無XK_PRIVACY_PREVIEW則notFound；Pages子程序強制XK_PRIVACY_PREVIEW=0且刪除draft HTML/payload。Footer只顯示待確認文字。','implication':'Vercel Preview與Production均不可設XK_PRIVACY_PREVIEW=1；它不是認證，不得用Preview環境名當開放理由。'},
{'area':'Design-system','observation':'Pages先notFound避免connection；一般模式await connection，再於production且未明確preview旗標時notFound。','implication':'Vercel兩scope預設不啟XK_DESIGN_SYSTEM_PREVIEW；實際HTTP必須驗404。'},
{'area':'SEO','observation':'siteConfig.url固定https://xplorekaleidoscope.com；metadata helpers逐頁noindex/nofollow、品牌canonical/OG、text-only Twitter summary；zh-TW與最小WebSite JSON-LD；robots允許公開HTML但排除draft/dev，無Sitemap宣告；無sitemap route。','implication':'不加NEXT_PUBLIC_SITE_URL、不強制Preview canonical、不開索引；Production同樣保護模式。'},
{'area':'contact/portfolio','observation':'verifiedContactChannels空；9公開routes的Portfolio三個slug固定，dynamicParams=false+notFound；planned routes不代表已實作。','implication':'不新增form/email/API/DB/Live links或宣稱9頁等於完整商業MVP。'},
{'area':'gitignore','observation':'.env*、.vercel、node_modules、.next、out、build、npm debug、*.pem皆已ignore。','implication':'無需為目前任務新增ignore；仍需檢查git tracked/staged/untracked，ignore不保證已追蹤機密不存在。'},
{'area':'Tailwind/docs','observation':'globals.css只明列task011/task012報告及artifact排除；新Task013報告可能被Tailwind自動掃描。','implication':'報告落地後比對final CI artifact/CSS。若新內容可產生utilities，僅新增相應報告/證據排除；此audit沒有build證據，不能宣稱已發生或已修復。'}],
'public_route_inventory':[
{'route':'/','source':'src/app/page.tsx'}, {'route':'/about','source':'src/app/about/page.tsx'}, {'route':'/services','source':'src/app/services/page.tsx'}, {'route':'/solutions','source':'src/app/solutions/page.tsx'}, {'route':'/portfolio','source':'src/app/portfolio/page.tsx'}, {'route':'/portfolio/corporate-website','source':'src/app/portfolio/[slug]/page.tsx + src/config/portfolio.ts'}, {'route':'/portfolio/enterprise-management','source':'src/app/portfolio/[slug]/page.tsx + src/config/portfolio.ts'}, {'route':'/portfolio/integration-hub','source':'src/app/portfolio/[slug]/page.tsx + src/config/portfolio.ts'}, {'route':'/contact','source':'src/app/contact/page.tsx'}],
'protected_and_auxiliary_routes':{'ordinary_production_expected_404':['/privacy','/dev/design-system','/sitemap.xml','/unknown-route','/portfolio/unknown-slug'],'ordinary_expected_available':['/robots.txt','/icon.svg'],'pages_must_not_emit':['draft privacy HTML/payload/text','dev HTML/payload/text'],'note':'全部為source推導的expected，未作本次HTTP驗證。'},
'actual_env_reads':[
{'name':'XK_PAGES_EXPORT','readers':['next.config.ts:3','src/app/robots.ts:9','src/app/dev/design-system/page.tsx:87','src/app/privacy/page.tsx:12','src/lib/privacy-publication.ts:34'],'usage':'字串1才啟用Pages export/protection分支；build:pages子程序設1。','vercel_proposal':'Preview/Production不啟用；無必要自訂。'},
{'name':'XK_PAGES_BASE_PATH','readers':['next.config.ts:9','src/app/robots.ts:9','scripts/build-github-pages.mjs:8'],'usage':'Pages prefix預設/xk-website，CI用平台真實base_path。','vercel_proposal':'Preview/Production不設定，不複製Pages值。'},
{'name':'XK_DESIGN_SYSTEM_PREVIEW','readers':['src/app/dev/design-system/page.tsx:92'],'usage':'production請求只有明確字串1才繞過該dev notFound，Pages永不開放。','vercel_proposal':'Preview/Production都不啟用。'},
{'name':'XK_PRIVACY_PREVIEW','readers':['src/lib/privacy-publication.ts:35'],'usage':'僅隔離loopback本機production審閱草案；build:pages強制0。','vercel_proposal':'公開Preview/Production都不得設1；Task013舊Env表未列，必須補入本次inventory。'},
{'name':'NODE_ENV','readers':['src/app/dev/design-system/page.tsx:92','src/lib/privacy-publication.ts:35'],'usage':'Next production/dev guard。','vercel_proposal':'由平台標準管理，不自訂繞過。'}],
'not_read_env':['NEXT_PUBLIC_SITE_URL','NEXT_PUBLIC_API_BASE_URL','VERCEL_URL','VERCEL_ENV','any custom API/database secret'],
'minimum_configuration_proposal':{
'ownership':'由已指定Team/Project開始，先inventory；目前未取得外部實況，不猜Project name/ID/URL。',
'project':{'repository':'xk2022/xk-website','frameworkPreset':'Next.js','rootDirectory':'.','productionBranch':'main','node':'24.x（需現行平台選項/log確認）','installCommand':'npm ci','buildCommand':'npm run build','outputDirectory':'preset default，無override','customEnvironmentVariables':'none required'},
'git_integration':'用平台Git integration且App僅必要repo權限；在link/import前先確認是否立即部署main，授權必須包含實際副作用。',
'preview':'本次受測feature exactSHA，受保護時僅已授權程序存取；不關閉protection來取得200。',
'production':'先review/main gate再已授權promotion/部署；若平台方案無所需暫停/保護，不先連main再想像gate。',
'preserve':['GitHub Pages source/workflow與URL','npm run build:pages與條件export','品牌canonical/noindex/nofollow','draft/dev404','Contact無收件','DNS/Domain不動'],
'repo_changes':['必須新增真實docs/reports/task013-implementation.md','README.md與docs/implementation-notes.md只追加實際操作/歷史','僅真實產生的Preview Desktop/Mobile截圖、非機密設定/log與Production證據'],
'vercel_json':'不需要且不預設新增；只有實際平台設定需版本管理的明確需求才提出最小差異。',
'dependencies_and_pipelines':'不需npm新dependency、Vercel CLI website dependency、Token或另一條Actions發佈管線。'},
'program_fix_decision':{'required_now':False,'basis':'所檢視的config、scripts、routes、guards已具普通Next與Pages雙模式；本次沒有實際部署/測試失敗可支持程式修復。','conditional_only':['實際Vercel Node/Next/Tailwind/font log若不相容，先保留FAIL及最小可審差異，依已安裝Next文件修正。','新report/evidence若實際擴大CSS，做必要source排除並驗final artifact。'],'not_a_pass':'僅source審查結論，不代表Vercel可部署已實測。'},
'rollback_boundaries':{
'plan_before_first_external_mutation':['記錄既有Project/Integration/Env scope/build/root/Node/productionBranch現值與最小差異，不含值。','inventory現有production/最近Ready Deployment的ID/SHA/URL、plan/角色可否Instant Rollback與操作者。','確認initial import/link是否立刻production；在該動作前完成授權與gate。'],
'candidate_trigger':['production路由或關鍵資源失敗','Privacy/dev意外公開','錯誤SHA/設定被promotion','阻礙訪客導覽/Runtime/安全內容保護的回歸'],
'operation_when_previous_ready_exists':['停止進一步自動promotion，保存失敗ID/SHA/log/HTTP證據。','由已授權操作者在當前平台支援介面選擇已記錄前版Ready production，核對ID/SHA/environment後執行rollback；本次audit未核對現行平台功能，需正式執行前查官方文件與方案。','確認alias/實際productionURL指向目標ID與SHA，再重做V13-R03，並檢查獨立Pages仍正常；保留時間與限制。'],
'first_deployment_limitation':'若Project無可用前版，不存在可宣稱的instant rollback；明列previousReady=null、Owner/操作限制、先停止後續Production與受審fix-forward方案。停止future autodeploy不代表收回已公開deployment，也不代表Pages URL自動取代Vercel；任何額外撤除/保護/alias變更依具體授權執行。',
'never_do_without_scope':['實際生產rollback演練','刪除正常前版','改DNS/custom domain或假稱Pages已接回Vercel流量','關閉deployment protection','轉Team/付費方案'],
'rehearsal_status':'PENDING','note':'計畫與可回復性驗收不等於已rollback；O01 Optional且需必要性/另授權。'},
'known_source_and_planning_conflicts':[
{'topic':'規格撰寫輪與現在正式執行','source':'task013開頭/第12/13節仍寫本輪只規格、不建報告/不部署。','resolution':'該文是歷史規格撰寫輪界線；父代理提供的本輪明確Task013執行及CI後merge/deploy授權優先。不要據此停止已授權工作，也不擴張到未知Team/DNS/rollback。'},
{'topic':'研究base/路由','source':'Task013 pinned e2a8f5a、當時只Home/About/Services；current main97886ab；工作樹copy4b876cc未合併。','resolution':'新Task013從當次最新已合併main；重盤9routes；PR18不擅自整合。'},
{'topic':'root/monorepo','source':'舊hosting planning建議frontend/website、文件repo作應用repo。','resolution':'已合併架構獨立xk2022/xk-website root .優先。舊Project建議名不是已授權Owner/ID。'},
{'topic':'install/output','source':'舊hosting與bootstrap notes為npm install，其他規劃可能建議靜態output。','resolution':'Task013鎖定npm ci、一般npm run build、Next preset default；不指定out/.next/standalone或使用Pages artifact。'},
{'topic':'Env/backend','source':'舊planning NEXT_PUBLIC_SITE_URL/API_BASE_URL、Spring Boot/VPS/DB/Docker。','resolution':'目前未讀這些變數且無Backend需求，不新增無效Env或資源。'},
{'topic':'Vercel與既有Pages','source':'舊planning Vercel作P0，Task003 owner選Pages，舊指南legacy Jekyll/403為當時快照。','resolution':'Task013兩平台共存；實查當次Pages source/run，不沿用legacy障礙或舊PASS。'},
{'topic':'Privacy新增gate','source':'Task013 Env表只列design-system，Task009後已新增XK_PRIVACY_PREVIEW。','resolution':'Preview/Production一律不以該flag公開草案；法律核准仍獨立BLOCKED歷史事項，Task013不代核准。'},
{'topic':'品牌/經營文案','source':'Task012歷史來源報告記錄文件repo2026-11-19中文名/Logo03核准與正職並行，但網站暫定標示及main仍舊一人全職。PR18已有owner2026-11-20中立技術文案更正，尚open。','resolution':'本次使用者最新中立文案優先；父代理處理PR18決策；Task013不自行品牌/Logo同步，也不重新加入人數/任職/創辦人敘述。這些歷史來源不是本次fresh source驗收。'},
{'topic':'商業MVP/案例/索引','source':'規劃完整MVP、表單、Analytics、API、完成案例、DNS/SSL與90+等目標。','resolution':'只發布實際9頁資訊；三案PLANNED、Contact空管道、Privacy draft404、noindex保留；Task014/010/011各自獨立。'},
{'topic':'來源新鮮度','source':'品牌copy報告記main9d0ed1282a6cf07bbaccdbf47f0220c37038080e；舊task pinned95ef1275；本audit僅讀repo與已有source snapshot。','resolution':'父代理正式source inventory需fresh核對指定業務檔/commit/blob；不把歷史8/8或copy source檢查當Task013 fresh核對。'}],
'acceptance_matrix':matrix,
'evidence_and_delivery_requirements':{'unique_ids':[r['test_id'] for r in matrix],'all_current_status':'PENDING','each_test_fields':['Test ID','Test Item/Applicability','Command/Procedure','Environment/Version/Time/URL/BasePath/Viewport','Expected Result','Actual Result','Exit Code','Status','Evidence','Notes/Failure/Retest'],'prerequisite_report':'本機相容性與可審設定提案在Task013 PR前完成，納入同PR。','required_remote_screenshots':'本次Preview Desktop/Mobile真網站截圖、非機密設定與成功log；Production後補真Browser/HTTP證據。','stage_separation':['Local','Feature commit/push','PR CI','Review','Authorized merge','main CI/Pages','Vercel Preview','Vercel Production Ready','Production public smoke','Rollback plan/rehearsal'],'failure_rule':'保留原FAIL/外部原因/時間/受測版本與retest；必要PENDING/FAIL/BLOCKED不得完整通過；未試不假稱BLOCKED或N/A。'},
'file_identities':identities
}
assert len(matrix)==21
assert len(set(r['test_id'] for r in matrix))==21
assert all(r['status']=='PENDING' for r in matrix)
out.write_text(json.dumps(audit,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'output':str(out),'bytes':out.stat().st_size,'matrix_count':len(matrix),'statuses':sorted(set(r['status'] for r in matrix)),'program_fix_required_now':False},ensure_ascii=False))
