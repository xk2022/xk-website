import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { pathToFileURL } from 'node:url';
const root = '/workspace/xk-website';
const output = process.argv[2];
if (!output || !path.resolve(output).startsWith('/tmp/xk-task013/')) throw new Error('Output must be inside /tmp/xk-task013');
const files = ['src/config/seo.ts', 'src/config/site.ts'];
const sourceFiles = Object.fromEntries(files.map(file => [file, crypto.createHash('sha256').update(fs.readFileSync(path.join(root, file))).digest('hex')]));
// Native Node 24 TypeScript stripping; separate export from actual source, no HTML-derived expectations.
const { seoPages, seoProtectionPolicy } = await import(pathToFileURL(path.join(root, files[0])).href);
const { siteConfig } = await import(pathToFileURL(path.join(root, files[1])).href);
fs.writeFileSync(output, JSON.stringify({ exportedAt: new Date().toISOString(), sourceFiles, seoPages, seoProtectionPolicy, siteConfig }, null, 2) + '\n');
