from pathlib import Path
import subprocess,json,hashlib,base64,datetime,concurrent.futures
out=Path('/tmp/xk-task013/documentation');out.mkdir(parents=True,exist_ok=True)
repo='xk2022/xplore-kaleidoscope';ref='9d0ed1282a6cf07bbaccdbf47f0220c37038080e'
paths=['doc/00_initGPT/05_Xplore Kaleidoscope 正式建置技術決策如下.md','doc/01_business-plan/week-02/07_domain-hosting_網域、DNS、主機與部署架構規劃.md','doc/01_business-plan/week-02/08_website-architecture_官方網站 Next.js 技術架構設計.md','doc/01_business-plan/week-02/09_website-mvp_官方網站 MVP 開發規格.md','doc/01_business-plan/week-02/01_brand-identity_品牌視覺識別規範.md']
def api(path):
 start=datetime.datetime.now(datetime.timezone.utc).isoformat();raw=subprocess.check_output(['gh','api',f'repos/{repo}/contents/{path}?ref={ref}']);d=json.loads(raw);dest=out/path;dest.parent.mkdir(parents=True,exist_ok=True)
 if isinstance(d,list):
  dest=out/(path.replace('/','__')+'.listing.json');dest.write_bytes(raw);return {'path':path,'kind':'directory_listing','at':start,'entries':[{k:x.get(k) for k in ['path','sha','type','size']} for x in d],'evidence':str(dest)}
 b=base64.b64decode(d['content']);dest.write_bytes(b);actual=hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest();assert actual==d['sha'];return {'path':path,'kind':'complete_file','commit':ref,'at':start,'bytes':len(b),'blobSha':actual,'sha256':hashlib.sha256(b).hexdigest(),'url':d['html_url'],'evidence':str(dest)}
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as ex: rows=list(ex.map(api,paths+['doc/01_business-plan/week-03','doc/decisions']))
(out/'manifest-initial.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2)+'\n');print(json.dumps(rows,ensure_ascii=False,indent=2))
