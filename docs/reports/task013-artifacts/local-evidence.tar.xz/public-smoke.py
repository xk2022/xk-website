import datetime,hashlib,json,re,urllib.request,urllib.error
from pathlib import Path
from html.parser import HTMLParser
from urllib.parse import urljoin,urlsplit,unquote
ROOT=Path('/workspace/xk-website');DIR=Path('/tmp/xk-task013/public');BASE='https://xk2022.github.io/xk-website/'
class Page(HTMLParser):
 def __init__(self):super().__init__();self.meta=[];self.links=[];self.scripts=[];self.anchors=[];self.ids=[];self.title='';self.inTitle=False;self.lang=None
 def handle_starttag(self,t,a):
  a=dict(a)
  if t=='html':self.lang=a.get('lang')
  if t=='meta':self.meta.append(a)
  if t=='link':self.links.append(a)
  if t=='script':self.scripts.append(a)
  if t=='a':self.anchors.append(a)
  if a.get('id'):self.ids.append(a['id'])
  if t=='title':self.inTitle=True
 def handle_endtag(self,t):
  if t=='title':self.inTitle=False
 def handle_data(self,d):
  if self.inTitle:self.title+=d

def run():
 DIR.mkdir(exist_ok=False);rows=[];pages={};assets=set()
 def get(url,name,expected=200,save=True):
  try:
   with urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'XK-Task013-verification','Cache-Control':'no-cache'}),timeout=30) as r: status=r.status;body=r.read();final=r.url;headers={k:r.headers.get(k)for k in ['Content-Type','ETag','Last-Modified','Cache-Control','Age']}
  except urllib.error.HTTPError as r:status=r.code;body=r.read();final=r.url;headers={k:r.headers.get(k)for k in ['Content-Type','ETag','Last-Modified','Cache-Control','Age']}
  row={'url':url,'finalUrl':final,'status':status,'bytes':len(body),'sha256':hashlib.sha256(body).hexdigest(),'headers':headers};rows.append(row)
  if save:(DIR/(name+'.body')).write_bytes(body)
  assert status==expected,(url,status,expected)
  return body
 registry=json.loads(Path('/tmp/xk-task013/seo.json').read_text());registry=[p for p in registry if p['availability']=='public'];assert len(registry)==9
 for spec in registry:
  suffix=spec['path'].strip('/')+'/' if spec['path']!='/' else '';url=urljoin(BASE,suffix);body=get(url,suffix.strip('/').replace('/','--')or'home');p=Page();p.feed(body.decode());assert p.lang=='zh-TW';assert p.title==spec['title']
  def one(k,v):
   matches=[m for m in p.meta if m.get(k)==v];assert len(matches)==1;(m,)=matches;return m['content']
  for key,value in [('description',spec['description']),('twitter:title',spec['title']),('twitter:description',spec['description']),('twitter:card','summary')]:assert one('name',key)==value
  assert set(re.split(r'[,\s]+',one('name','robots')))=={'noindex','nofollow'}
  for key,value in [('og:title',spec['title']),('og:description',spec['description']),('og:locale','zh_TW'),('og:type','website')]:assert one('property',key)==value
  canon=[a['href']for a in p.links if a.get('rel')=='canonical'];assert len(canon)==1
  for raw in canon+[one('property','og:url')]:
   u=urlsplit(raw);assert u.scheme=='https'and u.netloc=='xplorekaleidoscope.com'and u.path.rstrip('/')==spec['path'].rstrip('/')and not u.query and not u.fragment
  for a in p.links:
   if a.get('rel')in['stylesheet','icon']:assets.add(urljoin(BASE,a['href']))
  for a in p.scripts:
   if a.get('src'):assets.add(urljoin(BASE,a['src']))
  assert not any(urlsplit(a.get('href','')).path.rstrip('/').endswith('/privacy')for a in p.anchors)
  pages[spec['path']]=p
 for path,p in pages.items():
  for a in p.anchors:
   u=urlsplit(urljoin(BASE,a.get('href','')))
   if u.netloc!='xk2022.github.io':continue
   assert u.path.startswith('/xk-website/');target=u.path.removeprefix('/xk-website').rstrip('/')or'/';assert target in pages,target
   if u.fragment:assert unquote(u.fragment)in pages[target].ids
 for url in sorted(assets):
  assert urlsplit(url).netloc=='xk2022.github.io'and urlsplit(url).path.startswith('/xk-website/');data=get(url,'asset-'+hashlib.sha256(url.encode()).hexdigest()[:12],save=False);local=ROOT/'out'/urlsplit(url).path.removeprefix('/xk-website/');assert data==local.read_bytes(),url
  if url.endswith('.css'):
   font=re.search(r'url\(["\x27]?([^\)"\x27]+\.woff2)["\x27]?\)',data.decode())
   if font:
    f=urljoin(url,font.group(1));body=get(f,'font',save=False);assert body==(ROOT/'out'/urlsplit(f).path.removeprefix('/xk-website/')).read_bytes()
 robots=get(urljoin(BASE,'robots.txt'),'robots').decode();assert 'Sitemap:'not in robots and 'Disallow: /xk-website/privacy'in robots and 'Allow: /xk-website/'in robots
 for path in ['privacy/','dev/design-system/','portfolio/unknown-task013-project/','unknown-task013-route/','sitemap.xml']:get(urljoin(BASE,path),'404-'+path.strip('/').replace('/','--'),404)
 result={'status':'PASS','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'base':BASE,'publicRoutes':9,'metadata':9,'protected404':5,'observedResources':len(assets),'httpResponses':rows,'boundary':'Actual Pages public HTTP smoke only; not Vercel, DNS or legal/indexing approval'};(DIR/'result.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'status':'PASS','routes':9,'resources':len(assets),'requests':len(rows)}))
if __name__=='__main__':run()
