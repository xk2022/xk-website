import collections,datetime,hashlib,itertools,json,math,re
from pathlib import Path
from urllib.parse import urlsplit
P=Path('/tmp/xk-task013');raw=json.loads((P/'fresh-contrast-nodes-pages.json').read_text());assert raw['collectionComplete'] and raw['counts']['exactlyOneMatch']==336
# Conservative bounds evaluated against actual observed layers/opaque ancestors.
def composite(f,a,b):return [x*a+y*(1-a)for x,y in zip(f,b)]
def lum(c):return sum(k*(x/255/12.92 if x/255<=.04045 else((x/255+.055)/1.055)**2.4)for k,x in zip([.2126,.7152,.0722],c))
def ratio(a,b):x,y=sorted([lum(a),lum(b)]);return(y+.05)/(x+.05)
light=[min(a,b)for a,b in zip(composite([25,184,213],.12,[245,247,251]),composite([49,87,213],.07,[255]*3))]
darks=[]
for layers in set(itertools.permutations([(49,87,213,.09),(49,87,213,.09),(25,184,213,.12)])):
 c=[16,26,51]
 for *fg,a in layers:c=composite(fg,a,c)
 darks.append(c)
dark=[max(c[i]for c in darks)for i in range(3)]
def color(s):
 if s.startswith('rgb'):v=[float(x)for x in re.findall(r'[\d.]+',s)];return v[:3],v[3]if len(v)>3 else 1
 m=re.fullmatch(r'oklab\(([-.\deE]+) ([-.\deE]+) ([-.\deE]+) / ([-.\deE]+)\)',s);assert m,s;L,a,b,alpha=map(float,m.groups());l=(L+.3963377774*a+.2158037573*b)**3;m0=(L-.1055613458*a-.0638541728*b)**3;s0=(L-.0894841775*a-1.291485548*b)**3
 linear=[4.0767416621*l-3.3077115913*m0+.2309699292*s0,-1.2684380046*l+2.6097574011*m0-.3413193965*s0,-.0041960863*l-.7034186147*m0+1.707614701*s0]
 return[255*max(0,min(1,12.92*v if v<=.0031308 else1(v)))for v in linear],alpha
def else1(v):return 1.055*v**(1/2.4)-.055
def normalized_html(s):
 def href(m):
  p=urlsplit(m.group(2));path=p.path.removeprefix('/xk-website');path=path.rstrip('/')or'/';return 'href='+m.group(1)+path+('?' + p.query if p.query else'')+('#'+p.fragment if p.fragment else'')+m.group(1)
 return re.sub(r'href=([\"\x27])([^\"\x27]*)\1',href,s)
rows=[];counts=collections.Counter();minratio=99
for f in raw['files']:
 for t in f['rows']:
  assert t['matchCount']==1;n=t['nodes'][0];c=n['current'];assert normalized_html(n['actualHtml'])==normalized_html(t['rawHtml']),(f['raw'],t['target']);assert all(a['opacity']=='1'and a['filter']=='none'and a['mixBlendMode']=='normal'for a in n['ancestry']);bg=next(a['backgroundColor']for a in n['ancestry']if a['backgroundColor']not in['rgba(0, 0, 0, 0)','transparent']);fg,alpha=color(c['color']);kind='dark bounded compositing'if bg=='rgb(16, 26, 51)'else'light bounded compositing';assert bg in ['rgb(16, 26, 51)','rgb(245, 247, 251)','rgb(255, 255, 255)'];bound=dark if kind.startswith('dark')else light
  if kind.startswith('light'):assert alpha==1 and fg in [[16,26,51],[23,32,51],[49,87,213]]
  measured=ratio(composite(fg,alpha,bound),bound);assert measured>=4.5,(f['raw'],t['target'],measured);minratio=min(minratio,measured)
  overlap=any(x.get('data',{}).get('messageKey')=='bgOverlap'for x in t['checks']);fully=overlap and n['panelGeometryContainsEntireNode']and n['sampledCoveredByDisclosureCount']==9
  decision='N/A in this covered state; same actual foreground/layer model also passes conservative bound'if fully else'PASS conservative bound for visible text, including exposed portions of partially covered nodes'
  if overlap:assert n['expandedDisclosurePanel']['backgroundColor']=='rgb(255, 255, 255)'and n['expandedDisclosurePanel']['opacity']=='1'
  counts['fullyCovered'if fully else'partiallyCovered'if overlap else'gradient']+=1
  rows.append({'raw':f['raw'],'rawSha256':f['rawSha256'],'target':t['target'],'actualForeground':c['color'],'nearestOpaqueBackground':bg,'family':kind,'conservativeRatio':measured,'requiredRatioConservative':4.5,'decision':decision,'panelFullyContainsNode':n['panelGeometryContainsEntireNode'],'sampledCoveredPoints':n['sampledCoveredByDisclosureCount'],'status':'N/A'if fully else'PASS'})
assert len(rows)==336 and counts=={'gradient':290,'fullyCovered':41,'partiallyCovered':5}
# Root reviewed the actual headings/names inventory, real keyboard style observations and seven screenshot views.
review={'status':'PASS','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Task013 basic LOCAL regression only, no WCAG certification','frozenFingerprint':raw['sourceBefore']['fingerprint'],'contrast':{'cases':27,'targets':336,'minimumConservativeRatio':minratio,'lightLowerBoundRgb':light,'darkUpperBoundRgb':dark,'counts':dict(counts),'method':'Use current actual computed foreground/alpha/opaque ancestor and CSS gradient maximum alpha; compare href-only normal/Pages DOM bridge and byte-identical three stylesheets. Per-channel dark maximum over all layer orders. Masks only reduce decoration opacity. Alpha converted from actual Oklab to sRGB. Closed-state visible counterparts and partially exposed text use the same conservative bound. Fully opaque menu covers entire node for 41 observations; no blanket incomplete waiver. Nine-point tests supplement panel geometry, do not prove every glyph.','rows':rows},'semantics':{'routesReviewed':9,'observations':'One h1 each; subordinate section/article headings follow context, landmark/nav names identify primary/breadcrumb/footer/service/mobile navigation, action names match destinations. No unapproved form or public Privacy link.'},'layout':{'normalCases':45,'pagesCases':18,'candidates':0,'observations':'All measured viewports fit document/body width; root viewed actual Home/About desktop and mobile full-page screenshots, no overlap/clipped content observed.'},'focus':{'journeys':36,'screenshotsReviewed':['focus-visual/skip-focus.png','focus-visual/main-link-focus.png','focus-visual/menu-focus.png'],'observations':'Actual skip, main CTA and expanded menu first link have visible blue outline/ring; real Tab/ShiftTab and Escape/focus-leave checks passed. Review collected style/hit-test data; no full WCAG2.2 repeat claim.'},'screenshots':{'desktopViewedFrom':'normal/retest/screenshots','mobileViewedFrom':'normal/initial/screenshots','mobileBridge':'Home/About 375 initial/retest PNG bytes identical, source unchanged; original actual visual inspection retained, not relabelled as a second view.','files':[]}}
for p in sorted((P/'normal/retest/screenshots').glob('*.png')):
 b=p.read_bytes();review['screenshots']['files'].append({'file':str(p),'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b),'manualDecision':'PASS within shown local viewport/full-page scope'})
(P/'manual-adjudication.json').write_text(json.dumps(review,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'status':'PASS','targets':336,'counts':dict(counts),'minimumConservativeRatio':minratio}))
