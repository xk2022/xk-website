'use strict';
// Root-executed style/occlusion evidence only. This does not run axe or infer contrast PASS.
const fs = require('node:fs'), path = require('node:path'), crypto = require('node:crypto'), assert = require('node:assert/strict');
const { chromium } = require('/tmp/xk-browser-check/node_modules/playwright-core');
const run = path.resolve(process.argv[2] || ''), output = path.resolve(process.argv[3] || '');
const base = new URL(process.argv[4] || 'http://127.0.0.1:3031/xk-website/');
assert.ok(run.startsWith('/tmp/xk-task013/') && output.startsWith('/tmp/xk-task013/'));
assert.equal(base.origin, 'http://127.0.0.1:3031'); assert.equal(base.pathname, '/xk-website/');
assert.ok(!fs.existsSync(output), 'Choose a new output filename; preserve prior evidence');
const sha = bytes => crypto.createHash('sha256').update(bytes).digest('hex');
const source = JSON.parse(fs.readFileSync('/tmp/xk-task013/source.json'));
function checkSource() { for (const [file, expected] of Object.entries(source.files)) assert.equal(sha(fs.readFileSync(path.join('/workspace/xk-website', file))), expected, 'Frozen source ' + file); return { fingerprint: source.fingerprint, filesChecked: Object.keys(source.files).length }; }
function bridgeSelector(selector) {
  // Bridge only actual href path spelling between normal and Pages. Preserve original selector and HTML.
  let bridged = selector.replace(/\[href=(["'])(\/[^"']*)\1\]/g, (_, quote, value) => {
    const u = new URL(value, 'http://normal.invalid'); let suffix = u.pathname.slice(1);
    if (suffix && !path.posix.extname(suffix) && !suffix.endsWith('/')) suffix += '/';
    return '[href=' + quote + base.pathname + suffix + u.search + u.hash + quote + ']';
  });
  // Normal links may have no terminal slash; Pages Link output does.
  const suffix = bridged.match(/\[href\$=(["'])([^"']+)\1\]/);
  return suffix && !suffix[2].endsWith('/') ? [bridged, bridged.replace(suffix[0], '[href$=' + suffix[1] + suffix[2] + '/' + suffix[1] + ']')] : [bridged];
}
const result = { status: 'PENDING', collectionComplete: false, manualReviewStatus: 'PENDING', meaning: 'Fresh Pages DOM/CSS styles mapped to each normal/retest incomplete target. Contrast, layer compositing and covered/uncovered decisions remain manual.', startedAt: new Date().toISOString(), rawRun: run, observedBase: base.href, expected: { cases: 27, selectors: 336 }, files: [] };
const save = () => fs.writeFileSync(output, JSON.stringify(result, null, 2) + '\n');
(async () => {
  let browser;
  try {
    result.sourceBefore = checkSource();
    const files = fs.readdirSync(path.join(run, 'axe')).filter(name => name.endsWith('.json')).sort(); assert.equal(files.length, 27, 'Final full normal raw axe files');
    browser = await chromium.launch({ executablePath: '/usr/bin/chromium', headless: true, args: ['--no-sandbox'] }); result.browser = browser.version();
    for (const filename of files) {
      const file = path.join(run, 'axe', filename), bytes = fs.readFileSync(file), raw = JSON.parse(bytes), width = Number(filename.match(/-(\d+)-(closed|expanded)\.json$/)?.[1]);
      const targets = raw.incomplete.flatMap(rule => rule.nodes.map(node => ({ rule: rule.id, target: node.target, rawHtml: node.html, checks: node.any.concat(node.all, node.none).map(check => ({ id: check.id, data: check.data })), effectiveSelectors: node.target.length === 1 && typeof node.target[0] === 'string' ? bridgeSelector(node.target[0]) : [] })));
      assert.ok([375, 1440].includes(width)); const normal = new URL(raw.url); assert.equal(normal.origin, 'http://127.0.0.1:3030');
      const route = normal.pathname.replace(/\/$/, '') || '/', url = new URL(route === '/' ? '' : route.slice(1) + '/', base);
      const context = await browser.newContext({ viewport: { width, height: 1000 } });
      try {
        const page = await context.newPage(); await page.goto(url.href, { waitUntil: 'networkidle', timeout: 25000 }); await page.evaluate(() => document.fonts.ready);
        if (filename.endsWith('-expanded.json')) { await page.getByRole('button', { name: '開啟導覽', exact: true }).click(); await page.getByRole('navigation', { name: '手機導覽', exact: true }).waitFor(); }
        const rows = await page.evaluate(targets => {
          const description = node => ({ tag: node.tagName, id: node.id, className: node.getAttribute('class') });
          const computed = node => { const s = getComputedStyle(node), r = node.getBoundingClientRect(); return { element: description(node), color: s.color, backgroundColor: s.backgroundColor, backgroundImage: s.backgroundImage, opacity: s.opacity, fontSize: s.fontSize, fontWeight: s.fontWeight, filter: s.filter, backdropFilter: s.backdropFilter, mixBlendMode: s.mixBlendMode, backgroundBlendMode: s.backgroundBlendMode, textShadow: s.textShadow, position: s.position, zIndex: s.zIndex, isolation: s.isolation, transform: s.transform, maskImage: s.maskImage, rect: { left: r.left, top: r.top, right: r.right, bottom: r.bottom, width: r.width, height: r.height } }; };
          const decoration = node => /brand-pattern-(gradient|grid|kaleidoscope|shapes)/.test(node.getAttribute('class') || '');
          return targets.map(target => {
            if (!target.effectiveSelectors.length) return { ...target, collectionError: 'Nested selector requires explicit root handling' };
            const nodes = [...new Set(target.effectiveSelectors.flatMap(selector => [...document.querySelectorAll(selector)]))];
            return { ...target, matchCount: nodes.length, nodes: nodes.map(node => {
              const ancestry = [], siblingDecorations = [];
              for (let parent = node; parent; parent = parent.parentElement) {
                ancestry.push(computed(parent));
                for (const sibling of parent.parentElement?.children || []) if (sibling !== parent && decoration(sibling)) siblingDecorations.push({ besideAncestor: description(parent), decoration: computed(sibling) });
              }
              const trigger = document.querySelector('header button[aria-expanded="true"][aria-controls]'), panel = trigger && document.getElementById(trigger.getAttribute('aria-controls'));
              const panelStyle = panel ? computed(panel) : null, r = node.getBoundingClientRect(), visible = { left: Math.max(0, r.left), top: Math.max(0, r.top), right: Math.min(innerWidth, r.right), bottom: Math.min(innerHeight, r.bottom) }, hitTests = [];
              if (visible.right > visible.left && visible.bottom > visible.top) for (const fy of [1/6, 1/2, 5/6]) for (const fx of [1/6, 1/2, 5/6]) {
                const x = visible.left + (visible.right - visible.left) * fx, y = visible.top + (visible.bottom - visible.top) * fy, hit = document.elementFromPoint(x, y);
                const own = !!hit && (hit === node || node.contains(hit)), ancestorHit = !!hit && hit !== node && hit.contains(node), coveredByDisclosure = !!hit && !!panel && (hit === panel || panel.contains(hit));
                hitTests.push({ x, y, own, ancestorHit, coveredByDisclosure, hit: hit ? computed(hit) : null });
              }
              const pr = panel?.getBoundingClientRect();
              return { text: node.textContent.trim(), actualHtml: node.outerHTML, current: computed(node), ancestry, siblingDecorations, expandedDisclosurePanel: panelStyle, viewport: { width: innerWidth, height: innerHeight, scrollX, scrollY }, visibleIntersection: visible, hitTests, sampledCoveredByDisclosureCount: hitTests.filter(hit => hit.coveredByDisclosure).length, sampledOwnedCount: hitTests.filter(hit => hit.own).length, panelGeometryContainsEntireNode: !!pr && pr.left <= r.left && pr.right >= r.right && pr.top <= r.top && pr.bottom >= r.bottom, visibilityDecision: 'PENDING', note: 'Nine sampled hit points do not prove every painted glyph. Offscreen nodes have zero samples; no coverage/contrast verdict is inferred. Root must compare exact raw/actual HTML after href-only bridge, panel opacity, geometry and partially visible glyphs.' };
            }) };
          });
        }, targets);
        result.files.push({ raw: filename, rawSha256: sha(bytes), rawUrl: raw.url, actualUrl: page.url(), width, state: filename.endsWith('-expanded.json') ? 'expanded' : 'closed', actualStylesheets: await page.locator('link[rel="stylesheet"]').evaluateAll(nodes => nodes.map(node => node.href)), selectors: rows.length, rows }); save();
      } finally { await context.close(); }
    }
    result.counts = { cases: result.files.length, selectors: result.files.reduce((n, file) => n + file.rows.length, 0), exactlyOneMatch: result.files.reduce((n, file) => n + file.rows.filter(row => row.matchCount === 1).length, 0), ambiguousOrMissing: result.files.flatMap(file => file.rows.filter(row => row.matchCount !== 1).map(row => ({ raw: file.raw, target: row.target, effectiveSelectors: row.effectiveSelectors, matchCount: row.matchCount }))) };
    assert.equal(result.counts.cases, 27); assert.equal(result.counts.selectors, 336); result.collectionComplete = true;
    result.sourceAfter = checkSource(); result.finishedAt = new Date().toISOString();
  } catch (error) { result.collectionComplete = false; result.error = { message: error.message, stack: error.stack }; process.exitCode = 1; }
  finally { await browser?.close(); save(); }
})();
