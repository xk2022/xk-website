from pathlib import Path
from html.parser import HTMLParser
from urllib.request import Request,urlopen
import datetime,hashlib,json,concurrent.futures
class Text(HTMLParser):
 def __init__(self):super().__init__();self.skip=0;self.main=0;self.parts=[];self.all=[]
 def handle_starttag(self,tag,attrs):
  if tag in ['script','style','noscript']:self.skip+=1
  if tag=='main':self.main+=1
  if tag in ['h1','h2','h3','h4','p','li','tr','br','pre']:self.handle_data('\n')
 def handle_endtag(self,tag):
  if tag in ['script','style','noscript']:self.skip=max(0,self.skip-1)
  if tag=='main':self.main=max(0,self.main-1)
  if tag in ['h1','h2','h3','h4','p','li','tr','pre']:self.handle_data('\n')
 def handle_data(self,data):
  if not self.skip:
   self.all.append(data)
   if self.main:self.parts.append(data)
urls={'nextjs':'https://vercel.com/docs/frameworks/full-stack/nextjs','git-deployments':'https://vercel.com/docs/deployments/git','env':'https://vercel.com/docs/environment-variables','instant-rollback':'https://vercel.com/docs/instant-rollback','node-versions':'https://vercel.com/docs/functions/runtimes/node-js/node-js-versions','protection':'https://vercel.com/docs/deployment-protection','hobby-plan':'https://vercel.com/docs/plans/hobby','build-config':'https://vercel.com/docs/builds/configure-a-build','prebuilt':'https://vercel.com/docs/cli/deploy'}
out=Path('/tmp/xk-task013/official');out.mkdir(parents=True,exist_ok=True)
def get(pair):
 name,url=pair;at=datetime.datetime.now(datetime.timezone.utc).isoformat()
 try:
  req=Request(url,headers={'User-Agent':'Task013-source-audit/1.0','Accept':'text/html'})
  with urlopen(req,timeout=45) as r:
   b=r.read();meta={'name':name,'requestedUrl':url,'finalUrl':r.url,'status':r.status,'retrievedAtUtc':at,'responseDate':r.headers.get('Date'),'lastModified':r.headers.get('Last-Modified'),'contentType':r.headers.get('Content-Type'),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
  (out/(name+'.html')).write_bytes(b);p=Text();p.feed(b.decode('utf-8'));s=''.join(p.parts or p.all);s='\n'.join(x.strip() for x in s.splitlines() if x.strip());(out/(name+'.txt')).write_text(s);meta['textBytes']=len(s.encode());meta['textEvidence']=str(out/(name+'.txt'));return meta
 except Exception as e:return {'name':name,'requestedUrl':url,'retrievedAtUtc':at,'error':str(e)}
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as ex:rows=list(ex.map(get,urls.items()))
(out/'http-manifest.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2)+'\n');print(json.dumps(rows,ensure_ascii=False,indent=2))
