import argparse,datetime,gzip,hashlib,json,pathlib,re,subprocess,sys
parser=argparse.ArgumentParser();parser.add_argument('--visual',type=pathlib.Path,default=pathlib.Path('/tmp/xk-domain-fix/visual-review.json'));parser.add_argument('--seal',action='store_true');args=parser.parse_args()
root=pathlib.Path('/workspace/xk-website');temp=pathlib.Path('/tmp/xk-domain-fix');artifacts=root/'docs/reports/custom-domain-assets-artifacts';screenshots=root/'docs/screenshots/custom-domain-assets'
sha=lambda b:hashlib.sha256(b).hexdigest();now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat();read=lambda p:json.loads(p.read_text())
if args.seal:
 mp=artifacts/'manifest.json';d=read(mp)
 for name,compressed in [('package-evidence.receipt.json',False),('package-evidence.log',True)]:
  p=temp/name;raw=p.read_bytes();r=read(p) if not compressed else None
  if r:assert r['exitCode']==0 and r['finishedAt']
  dest=artifacts/(('commands/' if r else '')+name+('.gz' if compressed else ''));assert not dest.exists();archive=gzip.compress(raw,compresslevel=9,mtime=0) if compressed else raw;dest.write_bytes(archive)
  row={'sourcePath':str(p),'logicalPath':name,'archivePath':dest.relative_to(root).as_posix(),'category':'command-receipt' if r else 'evidence','compression':'gzip' if compressed else 'identity','rawBytes':len(raw),'rawSha256':sha(raw),'archiveBytes':len(archive),'archiveSha256':sha(archive)}
  if r:row.update(exitCode=r['exitCode'],receiptStatus=r['status'],observationMethod=r['observationMethod'])
  d['files'].append(row)
 cp=artifacts/'changed-files.json';c=read(cp);mismatch=[f['path'] for f in c['files'] if (sha((root/f['path']).read_bytes()) if (root/f['path']).is_file() else None)!=f['sha256']];assert not mismatch,('Files changed after packaging',mismatch)
 for f in d['files']:
  raw=(root/f['archivePath']).read_bytes();assert sha(raw)==f['archiveSha256'];original=gzip.decompress(raw) if f['compression']=='gzip' else raw;assert sha(original)==f['rawSha256'] and len(original)==f['rawBytes']
 assert len({f['archivePath'] for f in d['files']})==len(d['files'])
 actual={p.relative_to(root).as_posix() for p in artifacts.rglob('*') if p.is_file()};accounted={f['archivePath'] for f in d['files']};assert actual-accounted=={(artifacts/'manifest.json').relative_to(root).as_posix(),cp.relative_to(root).as_posix()}
 d['verification']['rawAndArchiveSha256RoundTrips']=len(d['files']);d['verification']['changedFilesHashMismatches']=[];d['verification']['sealedAt']=now();d['toolExecutionStatus']['package-evidence.py']='Packaging executed with run-with-evidence.py; actual exit 0 receipt archived. --seal verifies all copied bytes and appends that already completed receipt.'
 d['totals'].update(files=len(d['files']),commandReceipts=sum(f['category']=='command-receipt' for f in d['files']),gzipFiles=sum(f['compression']=='gzip' for f in d['files']),rawBytes=sum(f['rawBytes'] for f in d['files']),archiveBytes=sum(f['archiveBytes'] for f in d['files']));d['totals']['savedBytes']=d['totals']['rawBytes']-d['totals']['archiveBytes'];d['totals']['reductionPercent']=round(d['totals']['savedBytes']/d['totals']['rawBytes']*100,2)
 mp.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'status':'SEALED','manifest':str(mp),'manifestSha256':sha(mp.read_bytes()),'totals':d['totals']}));sys.exit(0)
source=read(temp/'source.json');normal=read(temp/'normal-final/result.json');pages=read(temp/'pages-final/result.json');visual=read(args.visual)
for mode,result in [('normal',normal),('pages',pages)]:
 receipt=read(temp/('browser-'+mode+'.json'));assert receipt['exitCode']==0 and receipt['finishedAt'];assert result['status']=='PASS';assert result['counters']['actualTests']==75 and result['counters']['actualRoutes']==15;assert result['counters']['actualResponsiveDefault']==30 and result['counters']['actualResponsive']==32;assert len(result['resourceHashes'])==8
assert visual.get('status',visual.get('result','')).startswith('PASS'), 'Human visual review must be completed first'
assert not artifacts.exists() and not screenshots.exists(), 'Refuse overwrite of an existing evidence package'
required=['npm-ci.json','npm-ci.log','tsc.json','tsc.log','lint.json','lint.log','build.json','build.log','build-pages.json','build-pages.log','deployment-contract.json','deployment-contract.log','deployment-contract-result.json','smoke-normal.json','smoke-normal.log','smoke-normal-result.json','smoke-pages.json','smoke-pages.log','smoke-pages-result.json','browser-normal.json','browser-normal.log','browser-pages.json','browser-pages.log','preflight-live.cjs','preflight-live.json','preflight-live.log','preflight-live.receipt.json','browser.cjs','check-deployment.py','check-artifact.py','source.json','seo.json','showcases.json','tool-preparation.json','tool-syntax.receipt.json','tool-syntax.log']
inputs=[(temp/p,p) for p in required]+[(temp/'normal-final/result.json','browser-normal-result.json'),(temp/'pages-final/result.json','browser-pages-result.json'),(args.visual,'visual-review.json'),(temp/'package-evidence.py','package-evidence.py')]
for p,name in [(pathlib.Path('/tmp/xk-custom-domain-tool-checks-20261123.json'),'fixtures/tool-checks-115.json'),(pathlib.Path('/tmp/xk-custom-domain-cli-negative-20261123.json'),'fixtures/cli-negative.json')]:inputs.append((p,name))
# Explicitly preserve this batch's additional failure/retest receipts and logs, without sweeping other temporary trees.
selected={p.resolve() for p,_ in inputs}
for p in sorted(temp.glob('*')):
 if not p.is_file() or p.resolve() in selected or p.name.startswith('package-evidence'):continue
 if p.suffix in {'.json','.log'} and any(t in p.name for t in ['retest','failure','failed','negative','lint-packaged','local-artifact']):inputs.append((p,p.name));selected.add(p.resolve())
assert all(p.is_file() for p,_ in inputs)
assert len({n for _,n in inputs})==len(inputs)
# Do not archive credentials, signed access URLs or arbitrary temporary files.
secret=re.compile(rb'https?://[^\s"<>]+(?:[?&](?:x-amz-signature|x-goog-signature|access_token|token|signature|sig)=)|gh[pousr]_[A-Za-z0-9]{20,}',re.I)
for p,_ in inputs:assert not secret.search(p.read_bytes()),'Potential credential/signed URL in '+str(p)
artifacts.mkdir(parents=True);screenshots.mkdir(parents=True);files=[]
for p,name in inputs:
 raw=p.read_bytes();value=read(p) if p.suffix=='.json' else None;receipt=isinstance(value,dict) and 'exitCode' in value and 'command' in value
 if receipt:assert value['exitCode'] is not None and value.get('finishedAt'),'Unfinished command '+str(p)
 mapped=('commands/'+name) if receipt else name
 compress=p.suffix!='.json' or len(raw)>24576 or name.endswith('-result.json') or name.startswith('fixtures/tool-')
 dest=artifacts/(mapped+('.gz' if compress else ''));dest.parent.mkdir(parents=True,exist_ok=True);assert not dest.exists();arch=gzip.compress(raw,compresslevel=9,mtime=0) if compress else raw;dest.write_bytes(arch)
 row={'sourcePath':str(p),'logicalPath':name,'archivePath':dest.relative_to(root).as_posix(),'category':'command-receipt' if receipt else 'tool' if p.suffix in {'.cjs','.py'} else 'fixture' if name.startswith('fixtures/') else 'evidence','compression':'gzip' if compress else 'identity','rawBytes':len(raw),'rawSha256':sha(raw),'archiveBytes':len(arch),'archiveSha256':sha(arch)}
 if receipt:row.update(exitCode=value['exitCode'],receiptStatus=value.get('status'),observationMethod=value.get('observationMethod'))
 files.append(row)
for name in ['home-1440.png','portfolio-375.png']:
 p=temp/'pages-final'/name;raw=p.read_bytes();dest=screenshots/name;dest.write_bytes(raw);files.append({'sourcePath':str(p),'logicalPath':'screenshots/'+name,'archivePath':dest.relative_to(root).as_posix(),'category':'screenshot','compression':'identity','rawBytes':len(raw),'rawSha256':sha(raw),'archiveBytes':len(raw),'archiveSha256':sha(raw)})
changes=[]
for line in subprocess.check_output(['git','diff','--name-status',source['base']],cwd=root,text=True).splitlines():
 parts=line.split('\t');changes.append((parts[-1],parts[0],'git diff --name-status '+source['base']))
for path in subprocess.check_output(['git','ls-files','--others','--exclude-standard'],cwd=root,text=True).splitlines():changes.append((path,'UNTRACKED','git ls-files --others --exclude-standard'))
changed=[];exclude=('docs/reports/custom-domain-assets-artifacts/','docs/screenshots/custom-domain-assets/')
for name,status,method in changes:
 if name.startswith(exclude):continue
 p=root/name;raw=p.read_bytes() if p.is_file() else None;changed.append({'path':name,'status':status,'method':method,'bytes':len(raw) if raw is not None else None,'sha256':sha(raw) if raw is not None else None})
changedfile={'capturedAt':now(),'base':source['base'],'headAtCapture':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'files':changed,'scope':'This batch Git diff and untracked files, excluding generated evidence itself. Root owns subsequent commits and remote acceptance.'};cp=artifacts/'changed-files.json';cp.write_text(json.dumps(changedfile,ensure_ascii=False,indent=2)+'\n')
mismatch=[name for name,h in source['files'].items() if not (root/name).is_file() or sha((root/name).read_bytes())!=h];assert not mismatch,mismatch
for row in files:
 raw=(root/row['archivePath']).read_bytes();assert sha(raw)==row['archiveSha256'];unpacked=gzip.decompress(raw) if row['compression']=='gzip' else raw;assert sha(unpacked)==row['rawSha256'] and len(unpacked)==row['rawBytes']
manifest={'schemaVersion':1,'task':'Custom domain root assets fix','createdAt':now(),'timezone':'Asia/Taipei','source':{'base':source['base'],'fingerprint':source['fingerprint'],'fingerprintFiles':len(source['files']),'currentMismatches':mismatch,'snapshot':'source.json'},'changedFiles':{'path':'changed-files.json','count':len(changed),'rawSha256':sha(cp.read_bytes()),'archiveSha256':sha(cp.read_bytes())},'environments':{'normal':'http://127.0.0.1:3170/','pages':'http://127.0.0.1:3171/','live':'https://www.xplorekaleidoscope.com/'},'toolExecutionStatus':{'browser.cjs':'Normal and Pages executed; exact 75-test receipts and raw results archived. No post-deploy live suite claimed.','check-deployment.py':'Executed; nine positive/negative deployment contract cases, OS exit 0 receipt archived.','check-artifact.py':'NOT_EXECUTED: archived for future actual CI artifact comparison; no PASS inferred.','package-evidence.py':'Packaging only; actual OS exit belongs to separately sealed command receipt.'},'mappingNotes':['logicalPath maps report references to archivePath. Recover exact raw bytes using gzip -dc for gzip entries.','Command receipts are preserved verbatim under commands/, including any nonzero outcomes supplied. Expected-negative CLI actualExitCode is original fixture evidence, not a fabricated OS runner receipt.','Only this batch and two explicit current fixture files are included. Old evidence batches, source PNG bulk and duplicate normal-mode screenshots are excluded.','Two original Pages full-page PNGs are byte-identical copies used by the independent human visual record.','Manifest omits its own hash to avoid self-reference; changed-files snapshot is separately hashed.'],'limitations':['This is deployment-path regression: no full axe/AT/WCAG or performance audit was run.','Contact form submission is N/A because there is no approved form or receiving channel. Existing keyboard/navigation/disclosure checks remain required.','The 115 fixture checks and CLI negative retain their original actual/result fields; the supplied files have no separate run-with-evidence.py OS receipt. No receipt is invented.','Preflight exit 0 means successful diagnostic collection. Its CSS/JS/image/favicon 404-vs-200 results record the original defect, not post-fix website acceptance.','CI artifact comparison, main deployment and post-deploy live checks remain owned by Root and are not inferred from local evidence.'],'securityReview':{'selectedTextInputs':len(inputs),'potentialSecretMatches':0,'selection':'Explicit current-batch evidence paths; no signed URLs or unrelated temporary trees.'},'verification':{'rawAndArchiveSha256RoundTrips':len(files),'sourceFingerprintFilesMatch':len(source['files']),'screenshotCount':2,'uncompressedExecutableTools':0},'totals':{'files':len(files),'commandReceipts':sum(f['category']=='command-receipt' for f in files),'gzipFiles':sum(f['compression']=='gzip' for f in files),'rawBytes':sum(f['rawBytes'] for f in files),'archiveBytes':sum(f['archiveBytes'] for f in files)},'files':files}
manifest['totals']['savedBytes']=manifest['totals']['rawBytes']-manifest['totals']['archiveBytes'];manifest['totals']['reductionPercent']=round(manifest['totals']['savedBytes']/manifest['totals']['rawBytes']*100,2)
(artifacts/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'status':'PACKAGED','manifest':str(artifacts/'manifest.json'),'totals':manifest['totals'],'sourceFingerprint':source['fingerprint'],'sourceFiles':len(source['files'])}))
