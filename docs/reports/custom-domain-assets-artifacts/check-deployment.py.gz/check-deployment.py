import json
import os
from pathlib import Path
import subprocess

root = Path('/workspace/xk-website')
rows = []
code = '''import assert from 'node:assert/strict';
import config from './next.config.ts';
import {siteConfig} from './src/config/site.ts';
assert.equal(siteConfig.url,'https://www.xplorekaleidoscope.com');
assert.equal(config.basePath,''); assert.equal(config.assetPrefix,'');
assert.equal(config.output,'export'); assert.equal(config.images.unoptimized,true);
console.log('ROOT_EXPORT_CONTRACT_PASS');'''
for supplied in [None, '', '/xk-website', 'https://www.xplorekaleidoscope.com/', '/https://www.xplorekaleidoscope.com/', '/', ' ', '/other']:
    env = dict(os.environ, XK_PAGES_EXPORT='1')
    env.pop('XK_PAGES_BASE_PATH', None)
    if supplied is not None:
        env['XK_PAGES_BASE_PATH'] = supplied
    command = ['node', '--input-type=module', '-e', code]
    result = subprocess.run(command, cwd=root, env=env, capture_output=True, text=True)
    expected = 0 if supplied in [None, ''] else 1
    assert result.returncode == expected, (supplied, result.returncode, result.stderr)
    assert ('ROOT_EXPORT_CONTRACT_PASS' in result.stdout) if expected == 0 else ('require an empty XK_PAGES_BASE_PATH' in result.stderr)
    rows.append({'test': 'next-config', 'basePathInput': supplied, 'expectedExitCode': expected, 'actualExitCode': result.returncode, 'stdout': result.stdout, 'stderr': result.stderr})
env = dict(os.environ, XK_PAGES_BASE_PATH='/xk-website')
result = subprocess.run(['node', 'scripts/build-github-pages.mjs'], cwd=root, env=env, capture_output=True, text=True)
assert result.returncode == 1 and 'require an empty XK_PAGES_BASE_PATH' in result.stderr
assert 'Creating an optimized production build' not in result.stdout
rows.append({'test': 'actual-pages-builder-rejects-legacy-before-build', 'expectedExitCode': 1, 'actualExitCode': result.returncode, 'stdout': result.stdout, 'stderr': result.stderr})
result = {'status': 'PASS', 'cases': len(rows), 'rows': rows}
Path('/tmp/xk-domain-fix/deployment-contract-result.json').write_text(json.dumps(result, indent=2) + '\n')
print({'status': result['status'], 'cases': result['cases']})
