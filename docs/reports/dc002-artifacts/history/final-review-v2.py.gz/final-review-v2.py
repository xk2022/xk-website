import hashlib,json,pathlib,re,subprocess,gzip,datetime
from urllib.parse import unquote
root=pathlib.Path.cwd();e=root/'docs/reports/dc002-artifacts';checks=[]
def check(name,condition,actual):
 checks.append({'testId':name,'status':'PASS' if condition else 'FAIL','expected':True,'actual':actual})
s=json.loads((e/'source-delivery.json').read_text());changed=[p for p,h in s['files'].items() if hashlib.sha256((root/p).read_bytes()).hexdigest()!=h];check('SOURCE-FREEZE',not changed,{'files':len(s['files']),'changed':changed,'sha256':s['sha256']})
base='eeb04b3ae89e2740ae104b92399be2a450511f37';tracked=subprocess.check_output(['git','diff','HEAD','--name-only'],text=True).splitlines();allowed={'AGENTS.md','README.md','docs/98_decisions/implementation-notes.md','docs/README.md','docs/task/README.md','package.json','src/app/globals.css'};check('TRACKED-SCOPE',set(tracked)==allowed,tracked)
manifest=json.loads(subprocess.check_output(['git','show',base+':package.json'],text=True));current=json.loads((root/'package.json').read_text());check('PACKAGE-SCRIPTS-ONLY',{k:v for k,v in current.items() if k!='scripts'}=={k:v for k,v in manifest.items() if k!='scripts'},'Only scripts may change')
old=subprocess.check_output(['git','show',base+':src/app/globals.css'],text=True);new=(root/'src/app/globals.css').read_text();clean=re.sub(r'\n/\* Pure DC-002 contracts and evidence contain no rendered utility classes\. \*/\n(?:@source not "[^"\n]+";\n)+','',new);check('NO-PRESENTATION-CSS-CHANGE',old==clean,'Only bounded @source not block removed for exact comparison')
docs=['AGENTS.md','README.md','docs/README.md','docs/task/README.md','docs/task/dc002.md','docs/03_engineering/design-collection-core.md','docs/reports/dc002-implementation.md','docs/98_decisions/implementation-notes.md','docs/reports/dc002-artifacts/README.md'];broken=[];format_errors=[];count=0
for name in docs:
 text=(root/name).read_text();fenced=False;visible=[]
 for n,line in enumerate(text.splitlines(),1):
  if line.startswith(('```','~~~')):fenced=not fenced;continue
  if not fenced:visible.append(line)
  if line.rstrip()!=line:format_errors.append([name,n,'trailing whitespace'])
  if re.match(r'^(<<<<<<<|=======|>>>>>>>)',line):format_errors.append([name,n,'conflict marker'])
 if fenced:format_errors.append([name,'unclosed fence'])
 for url in re.findall(r'(?<!!)\[[^\]]+\]\(([^)]+)\)','\n'.join(visible)):
  url=url.strip('<>')
  if re.match(r'^[a-zA-Z][a-zA-Z0-9+.-]*:',url) or url.startswith('/'):continue
  path,_,anchor=url.partition('#');target=((root/name).parent/unquote(path)).resolve() if path else root/name;count+=1
  if not target.exists():broken.append([name,url,'missing path']);continue
  if anchor and target.is_file() and target.suffix=='.md':
   t=target.read_text();explicit=re.findall(r'<a\s+id="([^"]+)"',t);headings=[re.sub(r'[^\w\- ]','',h.strip().lower()).replace(' ','-') for h in re.findall(r'^#{1,6}\s+(.+)$',t,re.M)]
   if unquote(anchor) not in explicit+headings:broken.append([name,url,'missing anchor'])
check('MARKDOWN-AND-LINKS',not broken and not format_errors,{'checkedLinks':count,'broken':broken,'format':format_errors})
files=[root/p for p in subprocess.check_output(['git','ls-files','--others','--exclude-standard'],text=True).splitlines()]+[root/p for p in tracked];secret=[]
pattern=re.compile(rb'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----|github_pat_[A-Za-z0-9_]{20,}|gh[pousr]_[A-Za-z0-9_]{20,}|[?&](?:X-Amz-Signature|sig|access_token)=',re.I)
for f in files:
 if f.is_file():
  data=gzip.decompress(f.read_bytes()) if f.suffix=='.gz' else f.read_bytes()
  if pattern.search(data):secret.append(str(f.relative_to(root)))
check('NO-SECRETS',not secret,secret)
invalid=[str(f.relative_to(root)) for f in files if any(p in {'.next','out','node_modules','.git'} or p.startswith('.env') for p in f.relative_to(root).parts)];check('NO-BUILD-OR-TEMP-SUBMISSIONS',not invalid,invalid)
errors=[];receipts=0
for f in e.rglob('*.json'):
 d=json.loads(f.read_text())
 if isinstance(d,dict) and d.get('logSha256'):
  receipts+=1;n=pathlib.Path(d['logFile']).name;possibles=[f.parent/(n+'.gz'),f.parent/('contracts-'+n+'.gz')];log=next((x for x in possibles if x.exists()),None)
  if not log or hashlib.sha256(gzip.decompress(log.read_bytes())).hexdigest()!=d['logSha256']:errors.append(str(f.relative_to(e)))
check('RAW-RECEIPT-LOG-INTEGRITY',not errors,{'receipts':receipts,'errors':errors})
r={'status':'FAIL' if any(x['status']=='FAIL' for x in checks) else 'PASS','testedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'base':base,'checks':checks};pathlib.Path('/tmp/xk-dc002/final-review-v2-result.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2));raise SystemExit(0 if r['status']=='PASS' else 1)
