import argparse, collections, hashlib, json, pathlib, re
from datetime import datetime, timezone
parser=argparse.ArgumentParser()
parser.add_argument('--site-dir',required=True)
parser.add_argument('--reference',required=True)
parser.add_argument('--output',required=True)
a=parser.parse_args();output=pathlib.Path(a.output)
if output.exists(): parser.error('Refusing to overwrite evidence')
base=json.loads(pathlib.Path(a.reference).read_text());root=pathlib.Path(a.site_dir)
extensions={'.css','.js','.woff','.woff2','.ttf','.svg','.webp','.png','.ico','.jpg','.jpeg'}
actual={str(f.relative_to(root)):hashlib.sha256(f.read_bytes()).hexdigest() for f in root.rglob('*') if f.is_file() and f.suffix in extensions}
def normalize(path):
 return re.sub(r'^_next/static/[^/]+/(_(?:ssgManifest|clientMiddlewareManifest|buildManifest)\.js)$',r'_next/static/BUILD_ID/\1',path)
def manifest(data):
 return collections.Counter((normalize(path),digest) for path,digest in data.items())
expected=manifest(base);observed=manifest(actual);passed=expected==observed
record={'status':'PASS' if passed else 'FAIL','testedAt':datetime.now(timezone.utc).isoformat(),'procedure':'Compare all CSS/JS/fonts/images byte SHA-256; only three Next build-ID manifest directories are normalized, not contents.','reference':a.reference,'siteDir':str(root),'expectedCount':len(base),'actualCount':len(actual),'unchangedAtSamePath':sum(actual.get(p)==h for p,h in base.items()),'expectedOnly':[{'path':p,'sha256':h,'count':n} for (p,h),n in (expected-observed).items()],'actualOnly':[{'path':p,'sha256':h,'count':n} for (p,h),n in (observed-expected).items()],'actualAssets':actual}
output.write_text(json.dumps(record,indent=2)+'\n');print(json.dumps({k:v for k,v in record.items() if k!='actualAssets'}));raise SystemExit(0 if passed else 1)
