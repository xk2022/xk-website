#!/usr/bin/env python3
"""Compare DC registry anchor declarations with actual published HTML IDs."""

import argparse
from collections import Counter
from datetime import datetime, timezone
import hashlib
from html.parser import HTMLParser
import json
from pathlib import Path
import platform
import shlex
import subprocess
import sys
from urllib.error import HTTPError, URLError
from urllib.parse import urljoin, urlsplit
from urllib.request import Request, urlopen


class IdParser(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.ids = Counter()

    def handle_starttag(self, tag, attrs):
        for name, value in attrs:
            if name == "id" and value is not None:
                self.ids[value] += 1

    handle_startendtag = handle_starttag


def stamp():
    return datetime.now(timezone.utc).isoformat()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo", default="/workspace/xk-website")
    parser.add_argument("--base-url", required=True)
    parser.add_argument("--mode", choices=("normal", "pages"), required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--timeout", type=float, default=15)
    args = parser.parse_args()
    if args.output.exists():
        parser.error("Output already exists; use a new evidence filename.")
    base = urlsplit(args.base_url)
    if base.scheme not in ("http", "https") or not base.netloc or base.query or base.fragment:
        parser.error("base-url must be an HTTP(S) preview URL without query or fragment")
    repo = Path(args.repo).resolve()
    source_code = """
import { designCollectionRegistry } from './src/config/design-collection.ts';
import { getPublishedDesignRoutes } from './src/lib/design-collection/routes.ts';
process.stdout.write(JSON.stringify({registry:designCollectionRegistry,
  routes:getPublishedDesignRoutes(),node:process.version}));
"""
    native_command = ["node", "--import", "./scripts/register-test-aliases.mjs", "--input-type=module", "-e", source_code]
    report = {
        "startedAt": stamp(), "suite": "DC-002 declared-anchor HTTP contracts",
        "command": shlex.join([sys.executable, *sys.argv]),
        "environment": {"mode": args.mode, "baseUrl": args.base_url,
                        "python": platform.python_version(), "platform": platform.platform(), "repo": str(repo)},
        "nativeCommand": native_command,
        "sourceSha256": {}, "results": [],
        "limitation": "Checks registry-declared fragment IDs in HTTP HTML only; not browser rendering, interaction, focus or a full route smoke.",
    }
    for name in ("src/config/design-collection.ts", "src/lib/design-collection/routes.ts", "scripts/register-test-aliases.mjs"):
        path = repo / name
        report["sourceSha256"][name] = hashlib.sha256(path.read_bytes()).hexdigest() if path.is_file() else None
    try:
        native = subprocess.run(native_command, cwd=repo, capture_output=True, text=True, timeout=45, check=False)
        report["nativeExitCode"] = native.returncode
        report["nativeStderr"] = native.stderr
        if native.returncode != 0:
            raise RuntimeError("Native registry export failed")
        snapshot = json.loads(native.stdout)
        registry, routes = snapshot["registry"], snapshot["routes"]
        report["environment"]["node"] = snapshot["node"]
        expected_simple = {"home", "about", "services", "solutions", "portfolio", "contact", "quotation"}
        actual_simple = {route["pageKey"] for route in routes if route["slug"] is None}
        technical = [route for route in routes if route["pageKey"] == "technical-project"]
        brands = [route for route in routes if route["pageKey"] == "brand-showcase"]
        inventory_ok = (len(routes) == 16 and actual_simple == expected_simple and len(technical) == 3
                        and len(brands) == 6 and len({r["presentationPath"] for r in routes}) == 16
                        and all(r["styleId"] == "modern" and r["availability"] == "public" for r in routes))
        report["results"].append({"testId": "DC-ANCHOR-INVENTORY", "status": "PASS" if inventory_ok else "FAIL",
            "expected": {"publishedRoutes": 16, "simplePageKeys": sorted(expected_simple), "technicalSlugs": 3, "brandSlugs": 6},
            "actual": {"publishedRoutes": len(routes), "simplePageKeys": sorted(actual_simple),
                       "technicalSlugs": [r["slug"] for r in technical], "brandSlugs": [r["slug"] for r in brands]}})
        for index, route in enumerate(routes, 1):
            style, page = route["styleId"], route["pageKey"]
            expected = registry["anchors"].get(style, {}).get(page, [])
            target = urljoin(args.base_url.rstrip("/") + "/", route["presentationPath"].lstrip("/"))
            result = {"testId": f"DC-ANCHOR-{index:02d}", "status": "FAIL", "route": route,
                      "url": target, "expected": {"httpStatus": 200, "ids": expected, "eachIdCount": 1},
                      "actual": {"httpStatus": None, "missingIds": list(expected), "duplicateIds": []}}
            try:
                if not expected or len(expected) != len(set(expected)):
                    raise ValueError("Published route must declare a nonempty, unique anchor list")
                request = Request(target, headers={"User-Agent": "XK-DC002-Anchor-Contract/1.0"})
                with urlopen(request, timeout=args.timeout) as response:
                    content_type = response.headers.get("Content-Type", "")
                    body = response.read().decode(response.headers.get_content_charset() or "utf-8", errors="replace")
                    parsed = IdParser()
                    parsed.feed(body)
                    parsed.close()
                    final_url = response.geturl()
                    final = urlsplit(final_url)
                    requested = urlsplit(target)
                    missing = [anchor for anchor in expected if parsed.ids[anchor] == 0]
                    duplicate = [anchor for anchor in expected if parsed.ids[anchor] > 1]
                    same_route = (final.scheme, final.netloc, final.path.rstrip("/")) == (requested.scheme, requested.netloc, requested.path.rstrip("/"))
                    result["actual"] = {"httpStatus": response.status, "finalUrl": final_url,
                        "contentType": content_type, "sameRoute": same_route, "missingIds": missing,
                        "duplicateIds": duplicate, "declaredIdCounts": {anchor: parsed.ids[anchor] for anchor in expected}}
                    if response.status == 200 and "text/html" in content_type.lower() and same_route and not missing and not duplicate:
                        result["status"] = "PASS"
            except (HTTPError, URLError, OSError, ValueError) as error:
                result["actual"]["error"] = str(error)
                if isinstance(error, HTTPError):
                    result["actual"]["httpStatus"] = error.code
            report["results"].append(result)
        for style in registry["styles"]:
            if style["status"] == "planned":
                report["results"].append({"testId": f"DC-ANCHOR-NA-{style['id'].upper()}", "status": "N/A",
                    "route": {"styleId": style["id"]}, "expected": {"publishedRoutes": 0},
                    "actual": {"publishedRoutes": sum(r["styleId"] == style["id"] for r in routes),
                               "declaredAnchors": registry["anchors"].get(style["id"], {})},
                    "reason": "Planned style has no implemented published page; an empty anchor map is not HTTP verification and no planned URL was requested."})
    except (OSError, ValueError, KeyError, TypeError, RuntimeError, subprocess.SubprocessError) as error:
        report["results"].append({"testId": "DC-ANCHOR-EXPORT", "status": "FAIL",
                                  "expected": "Native registry and route export succeeds", "actual": str(error)})
    counts = Counter(row["status"] for row in report["results"])
    report["counts"] = dict(counts)
    report["status"] = "FAIL" if counts["FAIL"] else "PASS"
    report["finishedAt"] = stamp()
    report["completionMarker"] = "DC002_ANCHOR_CONTRACT_COMPLETE"
    args.output.parent.mkdir(parents=True, exist_ok=True)
    temporary = args.output.with_suffix(args.output.suffix + ".tmp")
    temporary.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    temporary.replace(args.output)
    print(json.dumps({"status": report["status"], "counts": report["counts"], "output": str(args.output)}, ensure_ascii=False))
    return 1 if report["status"] == "FAIL" else 0


if __name__ == "__main__":
    raise SystemExit(main())
