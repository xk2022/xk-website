from pathlib import Path
from datetime import datetime, timezone
from importlib.metadata import version
import sys, json, hashlib
sys.path.insert(0,'/tmp/xk-estimator-tools')
import fitz, zxingcpp
from PIL import Image

source=Path('/tmp/xk-dc005-full/pages-final/quotation-modern-worstcase-a4.pdf')
doc=fitz.open(source)
assert len(doc)==1
page=doc[0]
pix=page.get_pixmap(dpi=150,alpha=False)
image=Image.frombytes('RGB',[pix.width,pix.height],pix.samples)
decoded=sorted(item.text for item in zxingcpp.read_barcodes(image,formats=zxingcpp.BarcodeFormat.QRCode))
expected=sorted(['https://www.xplorekaleidoscope.com/','https://www.xplorekaleidoscope.com/portfolio/'])
assert decoded==expected
result={'testId':'DC007-PDF-TOOL-DEPENDENCY-FIXTURE','status':'PASS','recordedAt':datetime.now(timezone.utc).isoformat(),'scope':'Read and rasterize one historical DC005 fixture solely to exercise actual fitz/Pillow/zxing decoding. This is NOT a fresh DC007 website PDF, current-page acceptance or a manual Logo review.','fixture':{'path':str(source),'sha256':hashlib.sha256(source.read_bytes()).hexdigest()},'tools':{'PyMuPDF':version('PyMuPDF'),'Pillow':version('Pillow'),'zxing-cpp':version('zxing-cpp')},'actual':{'pages':len(doc),'pagePt':[page.rect.width,page.rect.height],'dpi':150,'pixels':[pix.width,pix.height],'decodedUrls':decoded},'browserLaunched':False}
Path('/tmp/xk-dc007/pdf/preflight.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print('DC007_PDF_DEPENDENCY_FIXTURE_COMPLETE PASS')
