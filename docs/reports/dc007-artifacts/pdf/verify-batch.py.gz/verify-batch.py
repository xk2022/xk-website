from pathlib import Path
import argparse, subprocess, sys, json, hashlib
from datetime import datetime, timezone

parser=argparse.ArgumentParser()
parser.add_argument('--capture', required=True)
parser.add_argument('--out', required=True)
args=parser.parse_args()
capture_path=Path(args.capture).resolve()
capture=json.loads(capture_path.read_text())
out=Path(args.out).resolve()
out.mkdir(parents=True, exist_ok=False)
assert capture['status']=='CAPTURED_PHYSICAL_AND_MANUAL_PENDING'
expected=[('modern','worstcase'),('heritage','worstcase'),('luxury','worstcase'),('modern','from')]
assert [(c['style'],c['scenario']) for c in capture['cases']]==expected
sha=lambda path:hashlib.sha256(Path(path).read_bytes()).hexdigest()
tool=Path(__file__).with_name('verify-pdf.py')
result={'testId':'DC007-PDF-PHYSICAL-BATCH','startedAt':datetime.now(timezone.utc).isoformat(),'mode':capture['mode'],'capture':{'path':str(capture_path),'sha256':sha(capture_path)},'source':capture['source'],'catalog':capture['catalog'],'verifier':{'path':str(tool),'sha256':sha(tool)},'cases':[],'manualVisibility':'PENDING_ACTUAL_RENDER_VIEWS','status':'PENDING'}
for item in capture['cases']:
    pdf=Path(item['pdf']['path'])
    assert sha(pdf)==item['pdf']['sha256'],'Captured PDF bytes changed'
    case_out=out/(item['style']+'-'+item['scenario'])
    cmd=[sys.executable,str(tool),str(pdf),'--out',str(case_out),'--mode',capture['mode'],'--catalog',capture['catalog']['path'],'--expected-catalog-sha',capture['catalog']['sha256'],'--style',item['style'],'--scenario',item['scenario']]
    executed=subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
    log=out/(item['style']+'-'+item['scenario']+'.log')
    log.write_text(executed.stdout)
    row={'style':item['style'],'scenario':item['scenario'],'command':cmd,'returnCode':executed.returncode,'observedBy':'subprocess.run.wait','log':str(log),'logSha256':sha(log),'pdf':item['pdf'],'result':str(case_out/'verification.json')}
    if (case_out/'verification.json').is_file():
        actual=json.loads((case_out/'verification.json').read_text())
        row.update(automatedResult=actual['automatedResult'],failureCount=actual['failureCount'],testCount=len(actual['tests']),renders=actual['renders'])
    else: row['automatedResult']='FAIL_NO_VERIFICATION_RESULT'
    result['cases'].append(row)
    (out/'batch.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
failed=[c for c in result['cases'] if c['returnCode']!=0 or c['automatedResult']!='PASS']
result['status']='FAIL' if failed else 'AUTOMATED_PASS_MANUAL_PENDING'
result['finishedAt']=datetime.now(timezone.utc).isoformat()
result['counts']={'cases':len(result['cases']),'worstcase':3,'fromSupplement':1,'failures':len(failed)}
(out/'batch.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print('DC007_PDF_PHYSICAL_BATCH_COMPLETE',result['status'],str(out/'batch.json'))
sys.exit(1 if failed else 0)
