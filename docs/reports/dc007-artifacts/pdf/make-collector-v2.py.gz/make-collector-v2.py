from pathlib import Path
import hashlib,json,difflib
root=Path('/tmp/xk-dc007/pdf'); old=root/'collect.cjs'; new=root/'collect-v2.cjs'
assert not new.exists()
s=old.read_text();oldsha=hashlib.sha256(old.read_bytes()).hexdigest();assert oldsha=='498d35758ae857cc5c1719a402b5b8b1193a4fdd32c50f9687aafcd21b409e16'
def replace(a,b):
 global s
 assert s.count(a)==1,(a,s.count(a));s=s.replace(a,b)
replace("const executable='/usr/bin/chromium';", "const executable='/usr/bin/chromium';\n// V2 only: reuse the release QA passive exact-request monitor; no request routing/cache override.\nconst monitorPath='/tmp/xk-dc007/monitor.cjs',monitor=require(monitorPath);\nconst monitorDependencies=[monitorPath,'/tmp/xk-dc007/neutral-query-contract-v5.cjs'];")
replace("checkSource();assert.equal(catalog.builds.length,9);assert.equal(catalog.addons.length,17);", "checkSource();assert.equal(catalog.builds.length,9);assert.equal(catalog.addons.length,17);\nconst fixturePath=path.resolve(option('--fixture')||'/tmp/xk-dc007/fixture.json'),fixtureBytes=fs.readFileSync(fixturePath),fixture=JSON.parse(fixtureBytes);\nassert.equal(fixture.routes.length,49);const publishedPaths=fixture.routes.map(r=>r.path);assert.equal(new Set(publishedPaths).size,49);assert(publishedPaths.every(p=>typeof p==='string'&&p.startsWith('/')&&!p.includes('?')&&!p.includes('#')));\nconst dependencyEvidence=monitorDependencies.map(p=>({path:p,sha256:hash(fs.readFileSync(p))}));")
replace("tool:{path:__filename,sha256:hash(fs.readFileSync(__filename))}", "tool:{path:__filename,sha256:hash(fs.readFileSync(__filename)),version:2,previousCollector:{path:'/tmp/xk-dc007/pdf/collect.cjs',sha256:'498d35758ae857cc5c1719a402b5b8b1193a4fdd32c50f9687aafcd21b409e16'},dependencies:dependencyEvidence}")
replace("catalog:{path:catalogPath,sha256:hash(catalogBytes)},environment:", "catalog:{path:catalogPath,sha256:hash(catalogBytes)},fixture:{path:fixturePath,sha256:hash(fixtureBytes),approvedPublishedPathCount:publishedPaths.length},environment:")
replace("scope:'Four fresh app PDFs per mode:", "networkCorrection:'V1 FAIL is immutable. V2 removes context.route and reuses the release passive monitor: exact approved-route Pages HEAD/fetch ERR_ABORTED requires an actual same-route/referrer RSC tree GET 2xx companion; a null HEAD response stays unknown, never asserted 200. All other resource/console/runtime/privacy errors remain strict.',scope:'Four fresh app PDFs per mode:")
replace("const context=await browser.newContext({viewport:out.environment.viewport,deviceScaleFactor:1,reducedMotion:'reduce',timezoneId:'Asia/Taipei'});let closing=false;", "const context=await browser.newContext({viewport:out.environment.viewport,deviceScaleFactor:1,reducedMotion:'reduce',timezoneId:'Asia/Taipei'});let finishMonitor;\n   row.networkErrors=row.resourceErrors;row.runtimeErrors=row.pageErrors;row.privacyLeaks=row.unsafeRequests;row.expected404=[];row.expected404Console=[];row.expectedPrefetchCancellations=[];\n   const strictNetworkGuard=()=>{assert.deepEqual(row.unsafeRequests,[]);assert.deepEqual(row.pageErrors,[]);assert.deepEqual(row.consoleErrors,[]);assert.deepEqual(row.resourceErrors,[]);};")
a="""    await context.route('**/*',async route=>{const url=new URL(route.request().url());if(url.origin===base.origin||['data:','blob:'].includes(url.protocol))return route.continue();row.unsafeRequests.push({url:url.href,method:route.request().method()});await route.abort('blockedbyclient');});
    await context.addInitScript(()=>{document.addEventListener('click',event=>{const a=event.target instanceof Element?event.target.closest('a[href^="mailto:"]'):null;if(a){event.preventDefault();window.__dc007MailPrevented=(window.__dc007MailPrevented||0)+1;}},true);});
    const page=await context.newPage();page.setDefaultTimeout(30000);
    page.on('request',r=>row.requests.push({url:r.url(),method:r.method(),resourceType:r.resourceType()}));
    page.on('requestfailed',r=>row.resourceErrors.push({url:r.url(),error:r.failure()?.errorText,phase:closing?'context-closing':'active'}));
    page.on('response',r=>{if(r.status()>=400)row.resourceErrors.push({url:r.url(),status:r.status(),phase:closing?'context-closing':'active'});});
    page.on('console',message=>{if(message.type()==='error')row.consoleErrors.push(message.text());});page.on('pageerror',error=>row.pageErrors.push(error.message));"""
replace(a,"""    finishMonitor=await monitor(context,{base,mode,out:row,publishedPaths});
    const page=await context.newPage();page.setDefaultTimeout(30000);""")
replace("row.mailPrevented=await page.evaluate(()=>window.__dc007MailPrevented||0);", "row.mailPrevented=await page.evaluate(()=>(window.__dc006Mail||[]).length);")
replace("    assert.equal(row.mailPrevented,0);assert.deepEqual(row.unsafeRequests,[]);assert.deepEqual(row.pageErrors,[]);assert.deepEqual(row.consoleErrors,[]);assert.deepEqual(row.resourceErrors.filter(e=>e.phase==='active'),[]);", "    await finishMonitor();assert.equal(row.mailPrevented,0);strictNetworkGuard();")
replace("   finally{closing=true;await context.close();save();}", """   finally{
    await context.close();
    // Drain late requestfailed observations too: closing never becomes a broad exemption.
    if(finishMonitor)try{await finishMonitor();strictNetworkGuard();}catch(error){if(row.status!=='FAIL'){row.status='FAIL';row.error=error.stack;out.errors.push({style:spec.style,scenario:spec.scenario,error:error.stack,phase:'final network observation'});}}
    save();
   }""")
replace("  checkSource();assert.equal(out.cases.length,4);", "  checkSource();for(const entry of dependencyEvidence)assert.equal(hash(fs.readFileSync(entry.path)),entry.sha256,'Monitor dependency changed');assert.equal(hash(fs.readFileSync(fixturePath)),hash(fixtureBytes),'Fixture changed');assert.equal(out.cases.length,4);")
new.write_text(s)
diff=''.join(difflib.unified_diff(old.read_text().splitlines(True),s.splitlines(True),fromfile=str(old),tofile=str(new)))
(root/'collect-v1-v2.diff').write_text(diff)
# Preserve what V1 can actually prove, with exact ambiguity and missing-success-response limits.
capture=root/'pages-v1/capture.json';d=json.loads(capture.read_text());findings=[]
for c in d['cases']:
 failures=[]
 for e in c['resourceErrors']:
  matches=[r for r in c['requests'] if r['url']==e['url']]
  failures.append({'failure':e,'sameURLRequests':matches,'methodTypeEvidence':'URL_CORRELATION_ONLY_UNAMBIGUOUS_HEAD_FETCH' if len(matches)==1 and matches[0]['method']=='HEAD' and matches[0]['resourceType']=='fetch' else 'AMBIGUOUS_URL_ONLY_NO_FAILED_REQUEST_ID','actualOriginalHeadStatus':'UNKNOWN_NOT_RECORDED','actualRSCCompanionStatus':'UNKNOWN_NOT_RECORDED'})
 findings.append({'style':c['style'],'scenario':c['scenario'],'originalStatus':c['status'],'consoleErrors':c['consoleErrors'],'runtimeErrors':c['pageErrors'],'unsafeRequests':c['unsafeRequests'],'failures':failures})
files=[old,capture,root/'pages-capture-v1.json',root/'pages-capture-v1.log']+[Path(c['pdf']['path']) for c in d['cases']]
report={'testId':'DC007-PDF-PAGES-V1-NETWORK-REVIEW','originalStatus':'FAIL','originalResultChanged':False,'evidence':[{'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in files],'summary':{'caseCount':4,'failureCount':31,'uniqueURLHeadFetchCandidates':29,'ambiguousFailedRequestIdentityCount':2,'consoleErrorCount':0,'runtimeErrorCount':0,'httpErrorCount':sum('status'in e for c in d['cases'] for e in c['resourceErrors'])},'cases':findings,'limits':['V1 requestfailed only saved URL/error/phase; request identity, failed method/type and response headers were not saved.','29 failures correlate by URL to exactly one HEAD/fetch request. Two quotation URLs have both GET/document and HEAD/fetch and cannot be assigned rigorously.','V1 did not store successful RSC responses. No historical response status is inferred or filled in.','Four generated PDFs are not a passing collector run; original OS exit1 and status FAIL remain.']}
(root/'pages-v1-network-review.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
bridge={'testId':'DC007-PDF-COLLECTOR-V1-V2-BRIDGE','scope':'Tool-only network observation correction; App and physical checker untouched. No fresh collection executed by this preparation.','originalCollector':{'path':str(old),'sha256':oldsha},'newCollector':{'path':str(new),'sha256':hashlib.sha256(new.read_bytes()).hexdigest()},'diff':{'path':str(root/'collect-v1-v2.diff'),'sha256':hashlib.sha256(diff.encode()).hexdigest()},'originalEvidence':report['evidence'],'review':{'path':str(root/'pages-v1-network-review.json'),'sha256':hashlib.sha256((root/'pages-v1-network-review.json').read_bytes()).hexdigest()},'monitorDependencies':[{'path':str(p),'sha256':hashlib.sha256(Path(p).read_bytes()).hexdigest()} for p in ['/tmp/xk-dc007/monitor.cjs','/tmp/xk-dc007/neutral-query-contract-v5.cjs']],'freshFixture':{'path':'/tmp/xk-dc007/fixture.json','sha256':hashlib.sha256(Path('/tmp/xk-dc007/fixture.json').read_bytes()).hexdigest()},'v2Proof':'Pending actual fresh Pages capture; no prior RSC200 backfill. Passive monitor does not context.route or alter HTTP cache. Expected cancellations require the inherited exact headers/approved route/real companion evidence.'}
(root/'collector-version-bridge.json').write_text(json.dumps(bridge,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'newCollector':bridge['newCollector'],'v1Summary':report['summary'],'changedApp':False,'collectorExecuted':False}))
