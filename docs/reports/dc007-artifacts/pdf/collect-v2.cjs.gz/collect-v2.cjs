'use strict';
// Adapted from the exercised estimator print-only/DC005 business PDF flow.
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict'),crypto=require('node:crypto');
const playwrightPath='/tmp/xk-browser-check/node_modules/playwright-core';
const executable='/usr/bin/chromium';
// V2 only: reuse the release QA passive exact-request monitor; no request routing/cache override.
const monitorPath='/tmp/xk-dc007/monitor.cjs',monitor=require(monitorPath);
const monitorDependencies=[monitorPath,'/tmp/xk-dc007/neutral-query-contract-v5.cjs'];
const hash=b=>crypto.createHash('sha256').update(b).digest('hex');
const args=process.argv.slice(2),option=name=>{const i=args.indexOf(name);return i<0?null:args[i+1];};
if(args.includes('--preflight')){
  const {chromium}=require(playwrightPath);assert(chromium&&fs.existsSync(executable));
  console.log(JSON.stringify({testId:'DC007-PDF-COLLECTOR-DEPENDENCIES',status:'PASS',node:process.version,playwright:require(playwrightPath+'/package.json').version,executable,browserLaunched:false,scope:'Module and executable availability only; no site/PDF acceptance'}));process.exit(0);
}
const base=new URL(option('--base')),mode=option('--mode'),outDir=path.resolve(option('--out')),repo=path.resolve(option('--repo'));
assert(['normal','pages'].includes(mode));assert(['127.0.0.1','localhost'].includes(base.hostname)&&base.protocol==='http:'&&base.pathname==='/'&&!base.search&&!base.hash);
assert.equal(base.port,mode==='normal'?'3280':'3281','Root-managed DC007 ports');
assert(!fs.existsSync(outDir),'Do not overwrite evidence');fs.mkdirSync(outDir,{recursive:true});
const catalogPath=path.resolve(option('--catalog')),sourcePath=path.resolve(option('--source'));
const catalogBytes=fs.readFileSync(catalogPath),catalog=JSON.parse(catalogBytes),sourceBytes=fs.readFileSync(sourcePath),source=JSON.parse(sourceBytes);
assert(Array.isArray(source.files)&&/^[a-f0-9]{64}$/.test(source.sha256)&&source.base,'Root freeze schema files/sha256/base required');
const checkSource=()=>{for(const entry of source.files){assert(typeof entry.path==='string'&&!path.isAbsolute(entry.path)&&!entry.path.split('/').includes('..'));assert.equal(hash(fs.readFileSync(path.join(repo,entry.path))),entry.sha256,'Freeze mismatch: '+entry.path);}};
checkSource();assert.equal(catalog.builds.length,9);assert.equal(catalog.addons.length,17);
const fixturePath=path.resolve(option('--fixture')||'/tmp/xk-dc007/fixture.json'),fixtureBytes=fs.readFileSync(fixturePath),fixture=JSON.parse(fixtureBytes);
assert.equal(fixture.routes.length,49);const publishedPaths=fixture.routes.map(r=>r.path);assert.equal(new Set(publishedPaths).size,49);assert(publishedPaths.every(p=>typeof p==='string'&&p.startsWith('/')&&!p.includes('?')&&!p.includes('#')));
const dependencyEvidence=monitorDependencies.map(p=>({path:p,sha256:hash(fs.readFileSync(p))}));
const addonIds=catalog.addons.filter(a=>a.applicableBuildIds.includes('shop')).map(a=>a.id);assert.equal(addonIds.length,17);
assert.deepEqual(catalog.builds.find(b=>b.id==='app').price,{kind:'from',min:80000});
const CUSTOMER='測試客戶'.repeat(10),PROJECT='測試專案'.repeat(15);assert.equal([...CUSTOMER].length,40);assert.equal([...PROJECT].length,60);
const cases=[...['modern','heritage','luxury'].map(style=>({style,scenario:'worstcase',serviceId:'website',buildId:'shop',addonIds})),{style:'modern',scenario:'from',serviceId:catalog.builds.find(b=>b.id==='app').serviceId,buildId:'app',addonIds:[]}];
// The actual catalog, rather than a guessed service ID, supplies APP's parent.
cases[3].serviceId=catalog.builds.find(b=>b.id==='app').serviceId;
const out={testId:'DC007-ACTUAL-PDF-CAPTURE',mode,baseURL:base.href,startedAt:new Date().toISOString(),status:'PENDING',tool:{path:__filename,sha256:hash(fs.readFileSync(__filename)),version:2,previousCollector:{path:'/tmp/xk-dc007/pdf/collect.cjs',sha256:'498d35758ae857cc5c1719a402b5b8b1193a4fdd32c50f9687aafcd21b409e16'},dependencies:dependencyEvidence},source:{path:sourcePath,sha256:hash(sourceBytes),rootFingerprint:source.sha256,base:source.base},catalog:{path:catalogPath,sha256:hash(catalogBytes)},fixture:{path:fixturePath,sha256:hash(fixtureBytes),approvedPublishedPathCount:publishedPaths.length},environment:{node:process.version,viewport:{width:1440,height:1000},deviceScaleFactor:1,reducedMotion:'reduce',timezone:'Asia/Taipei'},networkCorrection:'V1 FAIL is immutable. V2 removes context.route and reuses the release passive monitor: exact approved-route Pages HEAD/fetch ERR_ABORTED requires an actual same-route/referrer RSC tree GET 2xx companion; a null HEAD response stays unknown, never asserted 200. All other resource/console/runtime/privacy errors remain strict.',scope:'Four fresh app PDFs per mode: three SHOP+17 maximum cases and one Modern APP from supplement. No mail send, site mutation, forced page fit, output crop, PDF rescaling or content deletion. Physical bounds, QR and manual visibility require separate verification.',cases:[],errors:[]};
const save=()=>fs.writeFileSync(path.join(outDir,'capture.json'),JSON.stringify(out,null,2)+'\n');
async function bounded(promise,label,ms=30000){let timer;try{return await Promise.race([promise,new Promise((_,reject)=>{timer=setTimeout(()=>reject(new Error(label+' exceeded '+ms+'ms')),ms);})]);}finally{clearTimeout(timer);}}
let browser;
(async()=>{
 try{
  const {chromium}=require(playwrightPath);browser=await chromium.launch({executablePath:executable,headless:true,args:['--no-sandbox','--disable-dev-shm-usage']});out.environment.browser=browser.version();
  for(const spec of cases){
   const row={...spec,status:'PENDING',startedAt:new Date().toISOString(),requests:[],resourceErrors:[],consoleErrors:[],pageErrors:[],unsafeRequests:[],mailPrevented:0};out.cases.push(row);save();
   const context=await browser.newContext({viewport:out.environment.viewport,deviceScaleFactor:1,reducedMotion:'reduce',timezoneId:'Asia/Taipei'});let finishMonitor;
   row.networkErrors=row.resourceErrors;row.runtimeErrors=row.pageErrors;row.privacyLeaks=row.unsafeRequests;row.expected404=[];row.expected404Console=[];row.expectedPrefetchCancellations=[];
   const strictNetworkGuard=()=>{assert.deepEqual(row.unsafeRequests,[]);assert.deepEqual(row.pageErrors,[]);assert.deepEqual(row.consoleErrors,[]);assert.deepEqual(row.resourceErrors,[]);};
   try{
    finishMonitor=await monitor(context,{base,mode,out:row,publishedPaths});
    const page=await context.newPage();page.setDefaultTimeout(30000);
    const prefix=spec.style==='modern'?'':'design-collection/'+spec.style+'/';const url=new URL(prefix+'quotation/',base);
    const response=await page.goto(url.href,{waitUntil:'networkidle'});assert.equal(response.status(),200);assert.equal(new URL(page.url()).search,'');
    await page.locator('#quotation-estimator[data-quotation-ready="true"]').waitFor();
    await page.getByRole('button',{name:'重設方案',exact:true}).click();await page.locator('#quotation-service-'+spec.serviceId).check();await page.locator('#quotation-build-'+spec.buildId).check();
    for(const id of spec.addonIds)await page.locator('#quotation-addon-'+id).check();
    await page.locator('#quotation-customer').fill(CUSTOMER);await page.locator('#quotation-project').fill(PROJECT);
    assert.equal(await page.locator('#quotation-customer').inputValue(),CUSTOMER);assert.equal(await page.locator('#quotation-project').inputValue(),PROJECT);
    row.totals={};for(const kind of ['base','extras','one-time','annual']){const node=page.locator('[data-total-kind="'+kind+'"]');row.totals[kind]={status:await node.getAttribute('data-total-status'),text:await node.locator('dd').innerText()};}
    if(spec.scenario==='worstcase'){assert.equal(row.totals['one-time'].status,'pending');assert.equal(row.totals.annual.status,'pending');}else{assert.equal(row.totals['one-time'].status,'from');assert(row.totals['one-time'].text.includes('NT$80,000 起（上限待評估）'));assert(row.totals.annual.text.includes('未選擇年度項目'));}
    const storage=await page.evaluate(()=>({selection:localStorage.getItem('xk:quotation:v1'),url:location.href}));assert(!storage.selection.includes(CUSTOMER)&&!storage.selection.includes(PROJECT));assert(!storage.url.includes(encodeURIComponent(CUSTOMER))&&!storage.url.includes(encodeURIComponent(PROJECT)));row.storage={selection:JSON.parse(storage.selection),piiPresent:false};
    await page.bringToFront();await page.emulateMedia({media:'print',reducedMotion:'reduce'});await bounded(page.evaluate(()=>document.fonts.ready.then(()=>document.fonts.status)),'print fonts');
    const paper=page.locator('[data-a4-sheet="true"]');await paper.waitFor({state:'visible'});assert.equal(await paper.count(),1);
    const text=await paper.innerText();assert(text.includes(CUSTOMER)&&text.includes(PROJECT));assert(text.includes(spec.scenario==='worstcase'?'18 項':'1 項'));
    assert.equal(await paper.locator('[data-summary-addon][data-selected="true"]').count(),spec.addonIds.length);
    const expectedImages=['/brand/source/xk-logo-horizontal.svg','/images/quotation/website-qr.svg','/images/quotation/portfolio-qr.svg'];
    row.images=[];for(const image of await paper.locator('img').all()){await image.scrollIntoViewIfNeeded();row.images.push(await bounded(image.evaluate(async e=>{await e.decode();const r=e.getBoundingClientRect(),s=getComputedStyle(e);return{src:e.getAttribute('src'),complete:e.complete,naturalWidth:e.naturalWidth,naturalHeight:e.naturalHeight,display:s.display,visibility:s.visibility,bbox:{x:r.x,y:r.y,width:r.width,height:r.height}};}),'print image decode'));}
    assert.equal(row.images.length,3);assert.deepEqual(row.images.map(i=>i.src),expectedImages);assert(row.images.every(i=>i.complete&&i.naturalWidth>0&&i.bbox.width>0&&i.bbox.height>0&&i.display!=='none'&&i.visibility!=='hidden'));
    assert.equal(await page.locator('[data-design-switcher]:visible').count(),0);await page.evaluate(()=>scrollTo(0,0));await bounded(page.evaluate(()=>document.fonts.ready),'final fonts');
    row.paperDOM=await paper.evaluate(e=>{const r=e.getBoundingClientRect(),s=getComputedStyle(e);return{bbox:{x:r.x,y:r.y,width:r.width,height:r.height},scrollWidth:e.scrollWidth,scrollHeight:e.scrollHeight,background:s.backgroundColor,color:s.color};});assert.equal(row.paperDOM.background,'rgb(255, 255, 255)');
    const file=path.join(outDir,spec.style+'-'+spec.scenario+'.pdf');assert(!fs.existsSync(file));await bounded(page.pdf({path:file,printBackground:true,preferCSSPageSize:true}),'actual Chromium printToPDF');const bytes=fs.readFileSync(file);assert.equal(bytes.subarray(0,5).toString(),'%PDF-');assert(bytes.length>1000);
    row.pdf={path:file,sha256:hash(bytes),bytes:bytes.length,options:{printBackground:true,preferCSSPageSize:true}};row.mailPrevented=await page.evaluate(()=>(window.__dc006Mail||[]).length);
    await finishMonitor();assert.equal(row.mailPrevented,0);strictNetworkGuard();
    assert(!row.requests.some(r=>r.url.includes(encodeURIComponent(CUSTOMER))||r.url.includes(encodeURIComponent(PROJECT))),'Personal fields in requests');
    row.status='CAPTURED_PHYSICAL_AND_MANUAL_PENDING';row.finishedAt=new Date().toISOString();
   }catch(error){row.status='FAIL';row.error=error.stack;out.errors.push({style:spec.style,scenario:spec.scenario,error:error.stack});}
   finally{
    await context.close();
    // Drain late requestfailed observations too: closing never becomes a broad exemption.
    if(finishMonitor)try{await finishMonitor();strictNetworkGuard();}catch(error){if(row.status!=='FAIL'){row.status='FAIL';row.error=error.stack;out.errors.push({style:spec.style,scenario:spec.scenario,error:error.stack,phase:'final network observation'});}}
    save();
   }
  }
  checkSource();for(const entry of dependencyEvidence)assert.equal(hash(fs.readFileSync(entry.path)),entry.sha256,'Monitor dependency changed');assert.equal(hash(fs.readFileSync(fixturePath)),hash(fixtureBytes),'Fixture changed');assert.equal(out.cases.length,4);assert(out.cases.every(r=>r.status==='CAPTURED_PHYSICAL_AND_MANUAL_PENDING'));out.status='CAPTURED_PHYSICAL_AND_MANUAL_PENDING';
 }catch(error){out.status='FAIL';out.errors.push({error:error.stack});process.exitCode=1;}
 finally{if(browser)await browser.close();out.finishedAt=new Date().toISOString();save();console.log('DC007_PDF_CAPTURE_COMPLETE',out.status,JSON.stringify({mode,cases:out.cases.length,pdfs:out.cases.filter(c=>c.pdf).length,out:path.join(outDir,'capture.json')}));if(out.status==='FAIL')process.exitCode=1;}
})();
