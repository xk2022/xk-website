import gzip,hashlib,json,importlib.util
from pathlib import Path
p=Path('/tmp/xk-dc007-r01');r=Path('/workspace/xk-website');dest=r/'docs/reports/dc007-artifacts/r01-delivery'
spec=importlib.util.spec_from_file_location('r01_archive_guard',p/'archive-r01.py');guard=importlib.util.module_from_spec(spec);spec.loader.exec_module(guard)
files=[p/n for n in ['final-lint.json','final-lint.log','final-delivery-integrity.json','final-delivery-integrity-command.json','final-delivery-integrity.log','archive-r01-process-v2.json']]+[Path('/tmp/xk-dc007-r01-archive-execution-summary.json'),Path(__file__)]
source=[(f,f.read_bytes())for f in files]
for f,b in source:assert guard.secret_reason(b.decode())is None,f
assert not dest.exists();dest.mkdir();rows=[]
for f,b in source:
 name=f.name+'.gz';encoded=gzip.compress(b,compresslevel=6,mtime=0);(dest/name).write_bytes(encoded);assert gzip.decompress((dest/name).read_bytes())==b
 rows.append({'sourcePath':str(f),'path':name,'encoding':'gzip','rawBytes':len(b),'rawSha256':hashlib.sha256(b).hexdigest(),'encodedBytes':len(encoded),'encodedSha256':hashlib.sha256(encoded).hexdigest()})
out={'testId':'R01-POST-ARCHIVE-DELIVERY-APPENDIX','integrity':'PASS','scope':'Completed final lint,44-check delivery integrity and actual archive completion receipts after immutable main archive. Main3383-record manifest remains unchanged. No QA/performance/remoteCI/deployment status inferred.','files':rows}
(dest/'manifest.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'integrity':'PASS','files':len(rows),'encodedBytes':sum(x['encodedBytes']for x in rows),'manifestSha256':hashlib.sha256((dest/'manifest.json').read_bytes()).hexdigest()}))
