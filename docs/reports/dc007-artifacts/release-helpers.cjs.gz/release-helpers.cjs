'use strict';
// Helpers operate on the actual document; the route/content oracle is the frozen DTO.
exports.contentParity=async function(page,route,fixture){
 const opened=[];for(const d of await page.locator('main:visible details').all())if(!await d.evaluate(e=>e.open)){await d.locator(':scope > summary').click();opened.push(d);}
 try{const text=await page.locator('main:visible').innerText(),norm=s=>String(s).replace(/\s+/g,'').toLowerCase();const required=[],facts=fixture.publicFacts,p=facts.portfolio;
 if(route.pageKey==='home')required.push(facts.home.hero.title,...facts.home.hero.serviceLabels);
 if(route.pageKey==='services')required.push(...facts.services.categories.map(r=>r.title),...facts.services.plans.map(r=>r.title),'依需求報價');
 if(route.pageKey==='contact')required.push(facts.contact.inquiry.title,...facts.contact.page.process.steps.map(r=>r.title),'system.xk2022@gmail.com');
 if(route.pageKey==='technical-project'){const r=p.projects.find(r=>r.slug===route.slug);required.push(r.title,r.summary,'規劃中');}
 if(route.pageKey==='brand-showcase'){const r=p.websiteShowcases.find(r=>r.id===route.slug);required.push(r.title,r.detail.context,...r.detail.limitations);}
 for(const value of required)if(!norm(text).includes(norm(value)))throw Error('Missing approved public content '+JSON.stringify(value));
 const cards=await page.locator('main:visible [data-showcase-id]').evaluateAll(es=>es.map(e=>({id:e.getAttribute('data-showcase-id'),state:e.getAttribute('data-showcase-state'),presentation:e.getAttribute('data-showcase-presentation'),images:[...e.querySelectorAll('img')].map(i=>i.getAttribute('src')),hrefs:[...e.querySelectorAll('a[href]')].map(a=>a.getAttribute('href'))})));
 if(route.pageKey==='home'||route.pageKey==='portfolio'){const ids=cards.filter(r=>p.settings.brandOrder.includes(r.id)).map(r=>r.id),expected=route.pageKey==='home'?p.settings.featuredIds:p.settings.brandOrder;if(JSON.stringify(ids)!==JSON.stringify(expected))throw Error('Showcase DOM order changed '+JSON.stringify({ids,expected}));for(const card of cards){const r=p.websiteShowcases.find(r=>r.id===card.id);if(!r)throw Error('Unknown showcase');if(r.href&&!card.hrefs.includes(r.href))throw Error('Missing real showcase source '+r.id);if(r.image&&!card.images.includes(r.image.src))throw Error('Missing real preview '+r.id);if(!r.href&&card.hrefs.some(h=>/^https?:/.test(h)&&!/(?:template|colorlib|html5up|bootstrapmade|templatemo)/i.test(h)))throw Error('Unexpected reference external link '+r.id);if(!r.image&&card.images.length)throw Error('Reference-only has preview '+r.id);}}
 return{approvedFacts:required.length,showcaseCards:cards,source:'fresh fixture DTO; visible public text and real href/image/order, not sourceRefs'};
 }finally{for(const d of opened)if(await d.evaluate(e=>e.open))await d.locator(':scope > summary').click();}
};
