from pathlib import Path
import subprocess,json,hashlib,datetime,re
r=Path('/tmp/xk-dc007-build');base='ee4b4709a9f8daa755e2595a46c158b3c92d8229';out=Path('/tmp/xk-dc007/source.json')
paths=sorted({p for cmd in [['git','ls-files','-z'],['git','ls-files','--others','--exclude-standard','-z']] for p in subprocess.check_output(cmd,cwd=r).decode().split('\0') if p and (p.startswith(('src/','public/','scripts/')) or p in ['package.json','package-lock.json','next.config.ts','.github/workflows/ci.yml','.nvmrc','eslint.config.mjs','tsconfig.json']) and (r/p).is_file() and '__pycache__' not in p})
rows=[]
for p in paths:
 b=(r/p).read_bytes();old=subprocess.run(['git','show',base+':'+p],cwd=r,capture_output=True)
 rows.append({'path':p,'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b),'baseSha256':hashlib.sha256(old.stdout).hexdigest() if old.returncode==0 else None})
changes=[x['path'] for x in rows if x['sha256']!=x['baseSha256']];assert changes==['src/app/globals.css'],changes
strip=lambda t:re.sub(r'^@source not .*\n','',t,flags=re.M)
assert strip((r/'src/app/globals.css').read_text())==strip(subprocess.check_output(['git','show',base+':src/app/globals.css'],cwd=r,text=True))
fp=hashlib.sha256(json.dumps([(x['path'],x['sha256']) for x in rows],separators=(',',':')).encode()).hexdigest()
data={'testId':'DC7-SOURCE-INITIAL-FREEZE','status':'PASS','createdAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'base':base,'sha256':fp,'files':rows,'changes':changes,'scope':'Only narrow evidence/document Tailwind exclusions before release acceptance. No layout/business/price/dependency/deploy change. Actual output identity remains an artifact assertion, not inferred from this fingerprint. Full fresh DC007 required acceptance and physical PDFs follow.'}
out.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'files':len(rows),'sha256':fp,'changes':changes}))
