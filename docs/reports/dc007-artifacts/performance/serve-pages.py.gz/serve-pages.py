#!/usr/bin/env python3
"""Loopback-only controlled transport model, not a GitHub Pages CDN emulator."""
import argparse, gzip, hashlib, http.server, mimetypes
from pathlib import Path
from email.utils import formatdate
from urllib.parse import unquote, urlsplit

ap=argparse.ArgumentParser();ap.add_argument('--root',type=Path,required=True);ap.add_argument('--port',type=int,default=3281);args=ap.parse_args()
root=args.root.resolve();entries={}
for path in root.rglob('*'):
 if not path.is_file(): continue
 data=path.read_bytes();kind=mimetypes.guess_type(path.name)[0] or 'application/octet-stream'
 zipped=gzip.compress(data,compresslevel=6,mtime=0) if path.suffix in {'.html','.css','.js','.txt','.json','.svg','.xml'} else None
 entries['/'+path.relative_to(root).as_posix()]={'data':data,'gzip':zipped,'type':kind,'mtime':formatdate(path.stat().st_mtime,usegmt=True)}
class Handler(http.server.BaseHTTPRequestHandler):
 protocol_version='HTTP/1.1'
 def do_HEAD(self): self.send_content(False)
 def do_GET(self): self.send_content(True)
 def send_content(self,body):
  request=urlsplit(self.path)
  path=unquote(request.path)
  if '..' in path.split('/'):
   self.send_error(400);return
  key=path+'index.html' if path.endswith('/') else path
  if key not in entries and key+'/index.html' in entries:
   self.send_response(301);self.send_header('Location',request.path+'/' + ('?'+request.query if request.query else ''));self.send_header('Content-Length','0');self.end_headers();return
  code=200 if key in entries else 404;e=entries.get(key) or entries.get('/404.html')
  if not e:
   self.send_error(404);return
  zipped=e['gzip'] is not None and 'gzip' in self.headers.get('Accept-Encoding','').lower();data=e['gzip'] if zipped else e['data'];tag='"'+hashlib.sha256(data).hexdigest()+'"'
  if code==200 and self.headers.get('If-None-Match')==tag: code=304
  self.send_response(code);self.send_header('Content-Type',e['type']);self.send_header('ETag',tag);self.send_header('Last-Modified',e['mtime']);self.send_header('Vary','Accept-Encoding');self.send_header('Cache-Control','public, max-age=600' if path.startswith('/_next/static/') else 'no-cache')
  if zipped: self.send_header('Content-Encoding','gzip')
  self.send_header('Content-Length',str(len(data) if code!=304 else 0));self.end_headers()
  if body and code!=304: self.wfile.write(data)
print({'model':'controlled local gzip6; hashed assets max-age600; HTML no-cache','root':str(root),'port':args.port,'files':len(entries)},flush=True)
http.server.ThreadingHTTPServer(('127.0.0.1',args.port),Handler).serve_forever()
