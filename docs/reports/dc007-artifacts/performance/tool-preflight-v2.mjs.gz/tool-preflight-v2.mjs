import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import crypto from 'node:crypto';
import assert from 'node:assert/strict';
import {initializeConfig} from '/tmp/xk-task011/tools/node_modules/lighthouse/core/config/config.js';
const root='/tmp/xk-dc007/performance';
const sha=b=>crypto.createHash('sha256').update(b).digest('hex');
assert.equal(JSON.parse(fs.readFileSync(path.join(root,'chromium-version.receipt.json'))).exitCode,0);
const versions={node:process.version,chromiumCli:fs.readFileSync(path.join(root,'chromium-version.log'),'utf8').trim(),lighthouse:JSON.parse(fs.readFileSync('/tmp/xk-task011/tools/node_modules/lighthouse/package.json')).version,playwright:JSON.parse(fs.readFileSync('/tmp/xk-browser-check/node_modules/playwright-core/package.json')).version};
assert.equal(versions.lighthouse,'13.6.0');
const profiles={};
for(const name of ['mobile','desktop']){
 const file=path.join(root,'profiles','lighthouse-'+name+'.json');const config=JSON.parse(fs.readFileSync(file));
 const {resolvedConfig}=await initializeConfig('navigation',config,{configPath:file});
 const s=resolvedConfig.settings;
 assert.equal(s.screenEmulation.deviceScaleFactor,1);assert.equal(s.disableStorageReset,false);
 if(name==='mobile'){
  assert.equal(s.screenEmulation.width,375);assert.equal(s.screenEmulation.height,812);assert.equal(s.throttlingMethod,'devtools');assert.equal(s.throttling.cpuSlowdownMultiplier,4);
  assert.equal(s.throttling.requestLatencyMs,150);assert.equal(Math.floor(s.throttling.downloadThroughputKbps*1024/8),200000);assert.equal(Math.floor(s.throttling.uploadThroughputKbps*1024/8),93750);
 }else{assert.equal(s.screenEmulation.width,1440);assert.equal(s.screenEmulation.height,1000);assert.equal(s.throttlingMethod,'provided');}
 profiles[name]={file,sha256:sha(fs.readFileSync(file)),actualResolvedSettings:s};
}
const disk=fs.statfsSync(root);
const result={status:'PASS',scope:'Static installed-tool/version/configuration preflight only. No Chromium session, server, website request or timing sample launched.',observedAt:new Date().toISOString(),versions,profiles,hardware:{platform:process.platform,arch:process.arch,logicalCpus:os.cpus().length,cgroupCpuMax:fs.readFileSync('/sys/fs/cgroup/cpu.max','utf8').trim(),cgroupMemoryMax:fs.readFileSync('/sys/fs/cgroup/memory.max','utf8').trim(),availableTempBytes:disk.bavail*disk.bsize,limitation:'Virtual host workload, power state and physical CPU frequency cannot be fully controlled. Root must reserve no QA/build/PDF/AT overlap.'},browserRuntimePreflight:'PENDING exclusive CPU window',formalSamples:'PENDING Root3281/code/transport handoff',dependenciesChanged:false,retainedFailure:'tool-preflight.receipt.json Exit1: Node execFileSync Chromium--version reported EPERM despite process status0/stdout; replaced the synchronous metadata subprocess with the separately observed direct version command. No browser session was attempted.'};
fs.writeFileSync(path.join(root,'tool-preflight.json'),JSON.stringify(result,null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify({status:result.status,versions,profileConfigsValidated:true,formalSamplingStarted:false}));
