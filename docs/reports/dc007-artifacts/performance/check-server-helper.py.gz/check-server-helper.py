from pathlib import Path
from unittest.mock import patch
import gzip,hashlib,http.server,io,json,runpy,sys,tempfile
root=Path('/tmp/xk-dc007/performance');cases=[]
with tempfile.TemporaryDirectory(prefix='dc007-transport-fixtures-') as tmp:
 fixture=Path(tmp)
 for name,body in {'index.html':b'<h1>root fixture</h1>','404.html':b'<h1>404 fixture</h1>','about/index.html':b'<h1>About fixture</h1>','about/__next._tree.txt':b'RSC fixture bytes','_next/static/test.js':b'console.log(1)'}.items():
  p=fixture/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(body)
 saved=sys.argv;sys.argv=[str(root/'serve-pages.py'),'--root',str(fixture),'--port','3281']
 try:
  with patch.object(http.server,'ThreadingHTTPServer') as server:
   namespace=runpy.run_path(str(root/'serve-pages.py'));server.assert_called_once();assert server.call_args.args[0]==('127.0.0.1',3281)
 finally:sys.argv=saved
 Handler=namespace['Handler']
 def request(method,url,headers=None):
  obj=Handler.__new__(Handler);obj.path=url;obj.headers=headers or {};obj.wfile=io.BytesIO();result={'headers':{}}
  obj.send_response=lambda status:result.update(status=status)
  obj.send_header=lambda key,value:result['headers'].update({key:value})
  obj.end_headers=lambda:None
  obj.send_error=lambda status:result.update(status=status)
  (obj.do_HEAD if method=='HEAD' else obj.do_GET)();result['body']=obj.wfile.getvalue();return result
 def check(name,want,actual):cases.append({'case':name,'expected':want,'actual':actual,'status':'PASS' if want==actual else 'FAIL'})
 response=request('GET','/',{'Accept-Encoding':'gzip'});check('Root GET real200 and gzip6body', [200,b'<h1>root fixture</h1>'],[response['status'],gzip.decompress(response['body'])]);check('HTML no-cache','no-cache',response['headers']['Cache-Control']);check('HTML type','text/html',response['headers']['Content-Type'])
 head=request('HEAD','/',{'Accept-Encoding':'gzip'});check('HEAD200 no body but GET representation length',[200,b'',str(len(response['body']))],[head['status'],head['body'],head['headers']['Content-Length']])
 redirect=request('GET','/about?source=qa');check('Directory301 preserves query',[301,'/about/?source=qa'],[redirect['status'],redirect['headers']['Location']])
 rsc=request('GET','/about/__next._tree.txt?source=qa&_rsc=one');check('RSC URL query ignored only in file lookup',[200,b'RSC fixture bytes','text/plain'],[rsc['status'],rsc['body'],rsc['headers']['Content-Type']])
 bad=request('GET','/not-a-page');check('Unknown real404 with root app404 and correcttype',[404,b'<h1>404 fixture</h1>','text/html'],[bad['status'],bad['body'],bad['headers']['Content-Type']])
 cached=request('GET','/_next/static/test.js',{'Accept-Encoding':'gzip'});check('Hashed root static max-age600','public, max-age=600',cached['headers']['Cache-Control']);check('Static gzip header','gzip',cached['headers']['Content-Encoding']);check('Variant Vary','Accept-Encoding',cached['headers']['Vary'])
 conditional=request('GET','/_next/static/test.js',{'Accept-Encoding':'gzip','If-None-Match':cached['headers']['ETag']});check('ETag304 emptybody',[304,b'','0'],[conditional['status'],conditional['body'],conditional['headers']['Content-Length']])
 invalid=request('GET','/%2e%2e/private');check('Traversal rejected400',400,invalid['status'])
passed=all(case['status']=='PASS' for case in cases);proof={'status':'PASS' if passed else 'FAIL','scope':'In-memory handler fixtures; mocked server constructor means no port/socket or website server was launched. Root must still inspect real3281 responses at startup.','cases':cases,'caseCount':len(cases),'serverSha256':hashlib.sha256((root/'serve-pages.py').read_bytes()).hexdigest(),'cli':'python3 /tmp/xk-dc007/performance/serve-pages.py --root <actualPagesOut> --port3281'}
with (root/'server-helper-check.json').open('x') as out:json.dump(proof,out,indent=2,default=lambda value:value.decode() if isinstance(value,bytes) else str(value));out.write('\n')
print(json.dumps({'status':proof['status'],'caseCount':len(cases),'serverSha256':proof['serverSha256'],'realServerStarted':False}));raise SystemExit(0 if passed else 1)
