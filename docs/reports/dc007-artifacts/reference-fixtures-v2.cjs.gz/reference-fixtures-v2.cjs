'use strict';
const assert=require('node:assert/strict'),{checkReferenceOnly}=require('./release-helpers-v2.cjs');
const creative={id:'demo-002',availability:'reference-only',href:null,image:null,attribution:{href:'https://startbootstrap.com/theme/creative'}},gadget={id:'demo-003',availability:'reference-only',href:null,image:null,attribution:{href:'https://templatemag.com/'}};
const card=r=>({state:'reference-only',images:[],hrefs:[r.attribution.href]}),rows=[
 ['approved-Creative-exact-attribution',true,card(creative),creative],['approved-Gadget-exact-attribution',true,card(gadget),gadget],
 ['same-publisher-wrong-path',false,{...card(creative),hrefs:['https://startbootstrap.com/theme/agency']},creative],
 ['paused-live-demo',false,{...card(creative),hrefs:['https://xk2022.github.io/single-demo002/']},creative],
 ['extra-live-demo',false,{...card(creative),hrefs:[creative.attribution.href,'https://xk2022.github.io/single-demo002/']},creative],
 ['preview-image',false,{...card(gadget),images:['/images/showcases/demo-003.webp']},gadget],
 ['missing-attribution',false,{...card(gadget),hrefs:[]},gadget],
 ['mailto-link',false,{...card(gadget),hrefs:['mailto:example@example.invalid']},gadget],
 ['unexpected-internal-link',false,{...card(gadget),hrefs:[gadget.attribution.href,'/portfolio']},gadget],
 ['incorrect-available-state',false,{...card(gadget),state:'available'},gadget]
];
const results=rows.map(([id,accept,c,r])=>{let accepted=true,error=null;try{checkReferenceOnly(c,r);}catch(e){accepted=false;error:e.message;}assert.equal(accepted,accept,id);return{id,expectedAccepted:accept,actualAccepted:accepted,status:'PASS',card:c,oracle:r,error};});console.log(JSON.stringify({testId:'DC007-EXACT-REFERENCE-ATTRIBUTION-FIXTURES',status:'PASS',cases:10,positive:2,negative:8,results},null,2));
