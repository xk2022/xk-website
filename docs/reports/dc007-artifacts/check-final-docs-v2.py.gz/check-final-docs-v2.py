from pathlib import Path
import hashlib,json,gzip,re,subprocess,urllib.parse,datetime
r=Path('/tmp/xk-dc007-build');s=Path('/tmp/xk-dc007');checks=[]
def ck(name,ok,actual):checks.append({'testId':name,'status':'PASS' if ok else 'FAIL','actual':actual})
def sha(b):return hashlib.sha256(b).hexdigest()
freeze=json.loads((s/'source.json').read_text());bad=[x['path'] for x in freeze['files'] if sha((r/x['path']).read_bytes())!=x['sha256']]
ck('DC7-FINAL-218-SOURCE-BYTES',len(freeze['files'])==218 and not bad,{'fingerprint':freeze['sha256'],'mismatches':bad})
unchanged=['package.json','package-lock.json','next.config.ts','.github/workflows/ci.yml','scripts/build-github-pages.mjs']
ck('DC7-FINAL-PRESERVE-DEPLOY-LOCK',all((r/p).read_bytes()==subprocess.check_output(['git','show',freeze['base']+':'+p],cwd=r) for p in unchanged),unchanged)
man=json.loads((r/'docs/reports/dc007-artifacts/manifest.json').read_text());bad=[]
for item in man['files']:
 b=(r/'docs/reports/dc007-artifacts'/item['path']).read_bytes();decoded=gzip.decompress(b) if item['encoding']=='gzip' else b
 if sha(b)!=item['sha256'] or sha(decoded)!=item['decodedSha256'] or len(b)!=item['bytes'] or len(decoded)!=item['originalBytes']:bad.append(item['path'])
ck('DC7-FINAL-ARCHIVE-MANIFEST',not bad,{'files':len(man['files']),'mismatches':bad})
visual=json.loads((r/'docs/screenshots/design-collection/dc007/visual-index.json').read_text());reviews=json.loads((r/'docs/screenshots/design-collection/dc007/visual-review.json').read_text());bad=[]
for x in visual['images']:
 if sha((r/'docs/screenshots/design-collection/dc007'/x['path']).read_bytes())!=x['sha256']:bad.append(x['path'])
ck('DC7-FINAL-47-ACTUAL-IMAGES',len(visual['images'])==47 and len(reviews['images'])==47 and {x['path'] for x in visual['images']}=={x['filename'] for x in reviews['images']} and not bad,{'images':len(visual['images']),'mismatches':bad})
changed=subprocess.check_output(['git','diff','--name-only',freeze['base']],cwd=r,text=True).splitlines();new=subprocess.check_output(['git','ls-files','--others','--exclude-standard'],cwd=r,text=True).splitlines();paths=sorted(set(changed+new));md=[p for p in paths if p.endswith('.md')];links=[];errors=[]
def anchors(text):
 slugs=set(re.findall(r'<a\s+(?:id|name)=[\"\']([^\"\']+)',text));seen={}
 for head in re.findall(r'^#{1,6}\s+(.+?)\s*#*$',text,re.M):
  head=re.sub(r'!?\[([^\]]+)\]\([^)]*\)',r'\1',head);head=re.sub(r'<[^>]+>','',head);slug=re.sub(r'[^\w\-\s]','',head.lower());slug=re.sub(r'\s','-',slug);n=seen.get(slug,0);seen[slug]=n+1;slugs.add(slug+('-'+str(n) if n else ''))
 return slugs
for name in md:
 p=r/name;text=p.read_text();ck('MD-FORMAT-'+name,not re.search(r'[ \t]+$',text,re.M) and text.endswith('\n') and not text.endswith('\n\n'),name)
 ck('MD-FENCES-'+name,len(re.findall(r'^```',text,re.M))%2==0,name)
 active=re.sub(r'^```[^\n]*\n.*?^```[^\n]*$', '',text,flags=re.S|re.M)
 for raw in re.findall(r'!?\[[^\]]*\]\(([^\n)]+)\)',active):
  target=raw.strip().strip('<>');url=urllib.parse.urlsplit(target)
  if url.scheme or target.startswith('//'):continue
  dest=(p.parent/urllib.parse.unquote(url.path)).resolve() if url.path else p.resolve();ok=dest.exists()
  if ok and url.fragment and dest.is_file() and dest.suffix=='.md':ok=urllib.parse.unquote(url.fragment) in anchors(dest.read_text())
  row={'source':name,'target':target,'existsAndAnchor':ok};links.append(row)
  if not ok:errors.append(row)
ck('DC7-FINAL-LOCAL-MARKDOWN-LINKS',not errors,{'documents':len(md),'links':len(links),'errors':errors})
forbidden=[p for p in paths if any(seg in ['.next','out','node_modules','.env','.env.local','__pycache__'] for seg in p.split('/'))]
ck('DC7-FINAL-NO-GENERATED-OR-ENV-FILES',not forbidden,forbidden)
secret=[]
for name in paths:
 p=r/name
 if p.suffix.lower() in ['.png','.pdf']:continue
 raw=p.read_bytes();raw=gzip.decompress(raw) if p.suffix=='.gz' else raw
 if re.search(rb'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----|gh[pousr]_[A-Za-z0-9]{35,}|github_pat_[A-Za-z0-9_]{60,}',raw):secret.append(name)
ck('DC7-FINAL-SECRET-PATTERN-CHECK',not secret,secret)
diff=subprocess.run(['git','diff','--check'],cwd=r,capture_output=True,text=True);ck('DC7-FINAL-DIFF-CHECK',diff.returncode==0,diff.stdout+diff.stderr)
receipts=['npm-ci','typegen','typescript','lint','test','build-normal','build-pages-v3','http-normal-command','http-pages-command','artifact-local-command','pdf/normal-capture-v1','pdf/normal-physical-v1','pdf/pages-capture-v2','pdf/pages-physical-v2','pdf/cross-page-print-v2','lint-final']
bad=[]
for key in receipts:
 d=json.loads((s/(key+'.json')).read_text())
 if d.get('exitCode')!=0 or d.get('terminationReason')!='completed':bad.append(key)
ck('DC7-FINAL-EXPECTED-TRUE-EXITS',not bad,{'receipts':receipts,'bad':bad})
for mode,n in [('normal',4),('pages',1)]:
 d=json.loads((s/f'{mode}-final/result.json').read_text());c=d['counters'];ck('DC7-FINAL-RAW-SUITE-COUNTS-'+mode,c['tests']==531 and c['layouts']==245 and c['axeScans']==119 and c['switcherIdentityCases']==96 and c['selectedBusinessAssertions']==39 and c['printMediaCases']==3 and c['violations']==0 and c['incompleteNodes']==384 and c['failures']==n,c)
result={'testId':'DC7-FINAL-DOCS-SOURCE-EVIDENCE','status':'FAIL' if any(x['status']=='FAIL' for x in checks) else 'PASS','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'sourceFingerprint':freeze['sha256'],'checks':checks,'counts':{'checks':len(checks),'failed':sum(x['status']=='FAIL' for x in checks)},'changedFiles':paths,'markdownLinks':links,'scope':'Documentation/attachment/source/receipt consistency only. Preserves browser/performance FAIL and HumanAT BLOCKED; not release acceptance or new App test/remote claim.'}
(s/'final-doc-check-v2-result.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'status':result['status'],'counts':result['counts'],'failures':[x for x in checks if x['status']=='FAIL']},ensure_ascii=False));raise SystemExit(0 if result['status']=='PASS' else 1)
