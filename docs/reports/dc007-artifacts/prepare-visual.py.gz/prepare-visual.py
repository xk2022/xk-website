from pathlib import Path
import json,hashlib,shutil
from PIL import Image,ImageDraw
s=Path('/tmp/xk-dc007');r=Path('/tmp/xk-dc007-build');d=r/'docs/screenshots/design-collection/dc007';d.mkdir(parents=True,exist_ok=True);v=s/'visual-previews';v.mkdir(exist_ok=True)
a=json.loads((s/'pages-final/result.json').read_text());assert len(a['screenshots'])==47;rows=[]
for row in a['screenshots']:
 p=Path(row['path']);b=p.read_bytes();assert hashlib.sha256(b).hexdigest()==row['sha256'];shutil.copyfile(p,d/p.name)
 im=Image.open(p).convert('RGB');w,h=im.size;mobile=w<768;mainw=375 if mobile else 960;overw=80 if mobile else 200
 overview=im.copy();overview.thumbnail((overw,3200));crops=[]
 for y,length in [(0,1400 if mobile else 1100),(max(0,h//2-450),1000),(max(0,h-750),750)]:
  q=im.crop((0,y,w,min(h,y+length)));q.resize((mainw,round(q.height*mainw/w))).save(v/(p.stem+f'-crop{len(crops)}.png'));q=q.resize((mainw,round(q.height*mainw/w)));crops.append(q)
 height=max(overview.height+50,sum(x.height for x in crops)+100);canvas=Image.new('RGB',(overw+mainw+25,height),'#e7e9ee');draw=ImageDraw.Draw(canvas);draw.text((4,4),p.name,fill='black');canvas.paste(overview,(4,32));yy=32
 for q in crops:canvas.paste(q,(overw+15,yy));yy+=q.height+20
 dst=v/p.name;canvas.save(dst)
 rows.append({**row,'originalPath':row['path'],'path':p.name,'mode':'Pages static export','widthPixels':w,'heightPixels':h,'previewPath':str(dst),'reviewScope':'Whole-page composition overview plus original top/middle/footer crops; not a claim to read every glyph at thumbnail scale. Raw original retained. HTTP/DTO checks cover content facts; axe/geometry/nativezoom cover separate criteria.'})
(d/'visual-index.json').write_text(json.dumps({'sourceFingerprint':a['source']['data']['sha256'],'mode':'Pages','images':rows},ensure_ascii=False,indent=2)+'\n');print(json.dumps({'screenshots':len(rows),'bytes':sum((d/x['path']).stat().st_size for x in rows)}))
