# 原始 Modern Home：FCP 後 JS 與 TBT

來源：base `ee4b4709a9f8daa755e2595a46c158b3c92d8229`，source fingerprint SHA256 `661f6cd2ac68add9e0887849819b8568f647b867ee72b8fa85ecf27beb39f16c`；manifest file SHA256 `374151b8c4a42b0bc2546c6fa6baccca75bb54b3c474814e1f0601e7a85fe6e9`。只讀原始 r1/r2/r3；沒有重跑。

| run | FCP ms | TTI ms | report/recomputed TBT ms | ReactDOM EvaluateScript start–end ms | chunk task TBT ms | style-dominant task TBT ms | JS-dominant task TBT ms |
|---|---:|---:|---:|---|---:|---:|---:|
| r1 | 2037.639 | 7751.916 | 1552.949/1552.949 | 2036.797–2310.525 | 229.206 | 1323.743 | 229.206 |
| r2 | 1889.860 | 7558.040 | 1814.294/1814.294 | 2063.571–2267.793 | 155.716 | 1658.578 | 155.716 |
| r3 | 1857.614 | 11465.599 | 965.657/965.657 | 1873.160–2059.844 | 143.673 | 814.693 | 143.673 |

結論：共享 chunk 並非完全在 FCP 前。r1 只在 FCP 前 0.842ms 開始，主要執行在 FCP 後；r2/r3 均在 FCP 後開始。r1 的 247.1ms 是 Lighthouse task 分類的 scriptEvaluation self-time，原始 EvaluateScript inclusive duration 是 273.728ms，所屬 RunTask 是 280.074ms，視 FCP/TTI 裁切後才得 TBT。不能把整頁 ~600ms Script Evaluation 當 TBT。

實際算法：`max(0, min(task.end, TTI) - max(task.start, FCP) - 50ms)`，先與 FCP/TTI 交集，再扣50ms。trace 的 ts/dur 以微秒記錄；表格以主 frame 實際 navigationStart 為原點換算毫秒；只取 FCP 的 pid/tid 主 thread RunTask；使用 Lighthouse 的重疊修正。逐 task、Layout/UpdateLayoutTree、原始 ts、分類交叉與精準檔案 hash 見 JSON。

字體 batch 後是否還需 JS：原始資料證明 JS 主導 long task 本身有可量測的 post-FCP blocking；但整體主要仍是 style/layout task。這使 JS 成為可獨立量測的後續候選，不能證明字體修正後一定仍超標，也不能從這批 pre-change trace 預報節省量。應先由同 profile 的 font-after 結果判斷剩餘 TBT，再決定是否處理共享 runtime。

界限：主分類分桶為 whole-task TBT，不能解讀成 CSS/JS 的精確因果節省量；未以 source map 臆測任何 hook、hydration 或自訂 component 為原因；未讀新 build 或改 App。
