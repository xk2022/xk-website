# DC007-R01 動畫與第三方執行來源唯讀盤點

日期：2026-11-27。範圍：`/workspace/xk-website/src`、`package.json` 與既有 `/tmp/xk-dc007/performance/cold`。已讀根 AGENTS 與 `docs/03_engineering/subagent-workflow.md`；依分工未變更 App、未用 Git、未建置、未啟 server/browser、未安裝依賴、未重跑 Lighthouse。此文件是 source/既有 trace 診斷，不是新的效能驗收 PASS。

## 結論

1. `src` 未見持續自我排程的 JS 動畫、`setInterval` / `setTimeout`、scroll/resize 逐幀 handler、Observer 或 Web Animations API。唯一 `requestAnimationFrame` 是風格切換器在同源連結點擊後的一次位置通知，會取消前次工作，沒有遞迴（`src/components/design-collection/shared/style-switcher-client.tsx:12–33`）。因此沒有可證明應移除的 perpetual animation。
2. 未見訪客載入第三方 analytics/tag-manager/runtime script。18 份既有 cold DevTools logs 的 732 筆 `Network.requestWillBeSent` 全部是 `127.0.0.1:3281`。這只覆蓋原樣本，不等於完整 49 頁／所有操作的普遍證明。
3. `next/font/google` 在 root 宣告 Inter、Noto Sans TC；原樣本字體請求實際是同源 `/_next/static/media/*.woff2`。Google 字體 API import 不等於訪客對 Google 發請求；建置時下載不在本次 runtime 證據範圍。
4. trace 的 `AnimationFrame` 是瀏覽器 frame pipeline 記錄，不能直接當作 App 的 JS rAF callback。18 份 trace 都沒有名為 `RequestAnimationFrame` / `FireAnimationFrame` 的記錄；有界 CSS 色彩轉場出現在 Heritage/Luxury Quotation，不是持續動畫。

## JS effects / 事件清冊

| 來源與行號 | 實際工作 | 循環／清理判斷 |
| --- | --- | --- |
| `src/components/design-collection/shared/style-switcher-client.tsx:12–41` | `useSyncExternalStore` 訂閱 hashchange、popstate、自訂 location event、Navigation API currententrychange、document click；同源連結 click 後 rAF 通知 | 單次 rAF；再次 click 取消待執行工作；unsubscribe 移除全部 listener 並取消 frame。沒有 scroll/resize |
| `src/components/layout/mobile-navigation.tsx:20–55` | open 時訂閱 keydown/pointerdown；另訂閱 64rem matchMedia change 以關閉選單 | 事件驅動；兩個 effect 都有 remove；沒有 resize polling |
| `src/components/design-collection/heritage/heritage-navigation.tsx:15–49` | keydown/pointerdown/click/focusin 與 matchMedia change，操作原生 details | mount 訂閱、unmount 清理；事件先檢查是否 open；無 frame/timer loop |
| `src/components/design-collection/luxury/luxury-navigation.tsx:15–48` | 同上，保留 switcher 區域的 pointer/focus 次序 | mount 訂閱、unmount 清理；無 frame/timer loop |
| `src/components/sections/quotation/quotation-estimator.tsx:89–133` | styleId effect 設定 print scope；pagehide/pageshow 清除個資與復原 scope | 有 cleanup；React setters 位於事件/cleanup；effect 不依賴其所更新的 state，未形成 effect feedback loop |
| `src/components/sections/quotation/quotation-estimator.tsx:182–195` | 使用者列印時 await document.fonts.ready 再 window.print | 使用者動作的一次 async 工作，沒有字體 polling |
| `src/components/sections/contact/contact-inquiry-form.tsx:32–65` | styleId effect 訂閱 pagehide/pageshow 並清個資；errors/draft 更新時聚焦摘要 | listener 有 cleanup；focus effect 沒有設定其依賴 state，未見 feedback loop |
| `src/lib/quotation/storage.ts:47–81` | getSnapshot 讀 localStorage、相同 raw 回傳快取；subscribe storage event；選項改動時通知 | 事件驅動；unsubscribe 清理，無 polling。儲存/個資契約應保留 |

搜尋涵蓋 `useEffect/useLayoutEffect/useSyncExternalStore`、rAF/timers、addEventListener、scrollTo/scrollIntoView、Resize/Intersection/MutationObserver、animate、fetch/axios/sendBeacon/WebSocket/EventSource、script/iframe，以及 CSS keyframes/infinite。`scroll-mt-*` 是靜態錨點偏移 class，不是 JS scroll listener。`src` 只有上述 rAF 位置通知，沒有 matchMedia 以外的 resize 工作。

## CSS 與套件實際來源

| 來源 | 實際角色 |
| --- | --- |
| `src/app/globals.css:1–3` | 匯入 Tailwind、`tw-animate-css`、shadcn CSS；`tw-animate-css` 是 package.json:35 的 devDependency，屬 CSS 動畫工具來源，不是外部 JS animation runtime |
| `src/app/globals.css:244,299–305` | 轉場 token 與 prefers-reduced-motion override；沒有 src 自訂 @keyframes / infinite 宣告 |
| `src/components/ui/button.tsx:3,11` | Radix Slot 用於按鈕組合；CSS 僅 background-color/color/border-color/box-shadow 轉場。不能由 radix dependency 名稱推論有 animation loop |
| `src/components/ui/card.tsx:24` | border-color/box-shadow 的 hover/focus 有界轉場 |
| `src/components/sections/home-solutions.tsx:29`、`src/components/layout/site-header.tsx:43`、`site-footer.tsx:12` | hover/focus 顏色轉場，均有 motion-reduce class |
| `src/design-systems/heritage/heritage.css:88,239–241` | 按鈕 160ms background/border 色彩轉場，減少動態模式停用 |
| `src/design-systems/luxury/luxury.css:84,246–249` | 按鈕 token 時長色彩轉場，減少動態模式停用 |
| `package.json:17–24,35` | Next/React/ReactDOM、Lucide、Radix、CVA/cn；沒有 GSAP、Framer Motion、Lottie、AOS、Lenis 或 analytics SDK 宣告。Lucide 實際為 React SVG icon import |

src 沒有使用 `animate-*` 類別，未見明確啟用 tw-animate-css keyframe utility。這不足以直接移除其 import/依賴；本輪也沒有檢查產物 selector/use sites，不能宣稱可節省多少 CSS 或 JS。

## Runtime script / font / 外部 URL

- `src/app/layout.tsx:2,10–23`：唯一全站字體來源為 next/font 的 Inter 與 Noto Sans TC，display swap；Noto 設 variable weight、preload false。保留三風格既定字體，不建議用系統字體替換來掩蓋效能門檻。
- `src/app/layout.tsx:41–45`：唯一顯式 script 是 inline `application/ld+json`（網站結構資料），不是可執行 analytics；不可為清 script 而移除 SEO。
- `src/lib/seo.ts:60` 的 schema.org 是 JSON-LD context 字串，並非 App fetch 來源。
- `src/config/website-showcases.ts:107,144,180,216,252,289,326–393` 的外部 URL 是展示/來源/授權連結設定。未見 iframe 或外部 script embed；使用者開啟目的站的請求不應混為本頁 runtime analytics。
- `src/config/quotation.ts:100,296` 的 analytics 只是服務目錄品項，未伴隨 analytics SDK 或 tracking 呼叫。
- `src/config/privacy.ts:72` 已正確區分建置下載與訪客字體請求；盤點結果與此敘述相符。

## 既有 trace 交叉證據

只解析既有檔案，沒有啟動新的工具測量。來源：`/tmp/xk-dc007/performance/cold/{modern,heritage,luxury}-{home,quotation}-mobile-r{1,2,3}-0.{trace,devtoolslog}.json`。

| 樣本組（每組三次） | Animation 記錄／每次 | b 開始與 e 結束／每次 | properties |
| --- | --- | --- | --- |
| 三風格 Home | 0 | 0 / 0 | 無 |
| Modern Quotation | 0 | 0 / 0 | 無 |
| Heritage Quotation | 7（含中間記錄） | 2 / 2 | background-color、color |
| Luxury Quotation | 4（含中間記錄） | 1 / 1 | color |

這些 Quotation trace 的 Animation `nodeName` 指向共用 `type-button ... transition-[background-color,color,border-color,box-shadow]` 按鈕，開始項 `endData.state` 為 finished。Luxury r1 含 `unsupportedProperties: ["color"]`，顯示色彩轉場不能合成；不能單靠這筆短事件指認整體 TBT 因果。六個 r1 trace 各有 3 筆 TimerFire，但 `src` 沒有 timer 排程，未追呼叫棧，故不將它們歸因 App／持續動畫。瀏覽器 AnimationFrame pipeline 計數不等於 callback 次數。

18 份 devtoolslog 共 732 筆 requestWillBeSent，唯一 netloc 為 `127.0.0.1:3281`；沒有第三方 hostname。這是測試 server 樣本的正向證據，並非公開正式站所有路由的完整網路稽核。

## 低風險建議（不改三風格視覺／功能／SEO）

1. **本輪不做 animation 或 analytics 刪除變更。** 沒有找到可移除的持續動畫或第三方 analytics；刪掉 JSON-LD、字體、必要頁面生命周期清除與導航 listener 反而沒有本次證據支持。
2. 在既有 QA 後續輸出同源/跨源 hostname 與 Animation 起訖/屬性摘要，作為診斷紀錄；不增加 App runtime instrumentation、依賴或外部請求。這能防止把瀏覽器 frame pipeline 誤判為 App 動畫。
3. 如另輪有必要優化事件負擔，可研究 switcher click rAF 僅處理同文件 hash 的可行性；須先用現有 hash/history/新分頁/無 Navigation API case 證明行為等價。**目前沒有成本或收益量測，不列為 R01 必做修復，不預估 TBT 改善。**
4. `tw-animate-css` 可列後續產物使用確認候選；在證明產物無用 selector 前維持 import/lockfile。這是待查 CSS 範圍，不是已找到第三方 runtime blocker。

限制：沒有執行 production output inspection、bundle/hydration 分析、新 browser/LH、互動後長時 idle profile、正式公開站資源驗證或全部 49 頁 network matrix；既有 trace 的版本歸屬沿用原 receipts，不在本子題重新認定。靜態找不到 API 並非數學證明框架/第三方套件永無 timer；本結論限 App src 與指定既有樣本。此清冊沒有提供 DC-007 TBT FAIL 的單一根因，也沒有宣稱解鎖發布。
