# DC-007-R01 真人輔助科技交接

日期：2026-11-27 UTC。狀態：BLOCKED，沒有真人讀屏驗收證據。

沿用原 DC-007 真人驗收交接及三系列流程；R01 新受測原始碼 manifest 為 source-after.json。原自動 axe、AX tree、鍵盤或 AI 視覺檢視不能代替真人讀屏。

新增須覆核的影響範圍：原生 screen-only content-visibility:auto 的首頁後續區塊、試算操作區與 Footer。請實際使用讀屏逐區閱讀、landmark／heading／link 導覽、Tab／Shift+Tab、錨點與返回；確認離屏內容仍可讀取，取得焦點時完整呈現，試算選項改變後的 live 結果宣告正常。確認字型未載入、載入後及列印不遺失語意／內容。

紀錄實際版本、OS、Browser、讀屏產品與版本、操作、預期／實際、PASS／FAIL／BLOCKED、問題與證據。功能分支沒有部署；須在本機受控預覽核對，未獲另外授權前不公開發布或變更 DNS。此交接不是已執行結果。
