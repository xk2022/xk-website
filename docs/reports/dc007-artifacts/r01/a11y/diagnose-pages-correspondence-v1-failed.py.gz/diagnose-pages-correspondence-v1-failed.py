"""Strict offline Pages/Normal paint-input diagnostic. This never adjudicates contrast."""
from pathlib import Path
import argparse, copy, hashlib, json, re
from urllib.parse import urlsplit
from datetime import datetime, timezone

ALIASES={
 '.underline-offset-4.mt-4[href$="about/"]':'.underline-offset-4.mt-4[href$="about"]',
 '.mb-8 > .hover\\:text-secondary.rounded-sm[href$="portfolio/"]':'.mb-8 > .hover\\:text-secondary.rounded-sm[href$="portfolio"]',
 '.hover\\:text-secondary.rounded-sm[href$="portfolio/#website-cases"]':'.hover\\:text-secondary.rounded-sm[href$="portfolio#website-cases"]',
 '.mt-3.underline-offset-4[href$="services/#service-plans"]':'.mt-3.underline-offset-4[href$="services#service-plans"]',
 '.mt-3.hover\\:underline[href$="services/#service-plans"]':'.mt-3.hover\\:underline[href$="services#service-plans"]'}
def differences(a,b,p=''):
 if type(a)!=type(b):return[{'pointer':p,'normal':a,'pages':b}]
 if isinstance(a,dict):return[q for k in sorted(a.keys()|b.keys())for q in([{'pointer':p+'/'+k,'normal':a.get(k),'pages':b.get(k)}]if k not in a or k not in b else differences(a[k],b[k],p+'/'+k))]
 if isinstance(a,list):return[{'pointer':p+'/length','normal':len(a),'pages':len(b)}]if len(a)!=len(b)else[q for i,(x,y)in enumerate(zip(a,b))for q in differences(x,y,p+'/'+str(i))]
 return []if a==b else[{'pointer':p,'normal':a,'pages':b}]
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
parser=argparse.ArgumentParser();parser.add_argument('--projection',required=True);parser.add_argument('--output',required=True);args=parser.parse_args()
path=Path(args.output);assert not path.exists()
R=Path('/tmp/xk-dc007-r01/a11y');N=json.loads((R/'normal-contrast-projection.json').read_text());P=json.loads(Path(args.projection).read_text());F=json.loads((R/'normal-contrast-final-v2.json').read_text());routes={x['path']:x for x in json.loads(Path('/workspace/xk-website/scripts/fixtures/design-collection-contract.json').read_text())['routes']}
assert len(P['axeCompletion']['records'])==119
assert P['source']['sha256']==sha('/tmp/xk-dc007-r01/source-after-v2.json')
assert len(P['manualStyles'])==len(N['manualStyles'])
rows=[]
for gi,(ng,pg)in enumerate(zip(N['manualStyles'],P['manualStyles'])):
 assert (ng['route'],ng['width'],ng['state'])==(pg['route'],pg['width'],pg['state'])
 assert len(ng['nodes'])==len(pg['nodes'])
 for ni,(nn,pn)in enumerate(zip(ng['nodes'],pg['nodes'])):
  canonical=[ALIASES.get(t,t)for t in pn['target']];assert canonical==nn['target']
  adjusted=copy.deepcopy(pn);adjusted['target']=canonical;adjusted['computed']['target']=canonical
  href=None
  if nn['html']!=pn['html']:
   nh=re.findall(r'\bhref="([^"]*)"',nn['html']);ph=re.findall(r'\bhref="([^"]*)"',pn['html']);assert len(nh)==len(ph)==1
   a,b=urlsplit(nh[0]),urlsplit(ph[0]);assert not a.scheme and not a.netloc and not a.query and not b.query and a.path!='/' and b.path==a.path+'/' and a.fragment==b.fragment and a.path in routes
   assert not a.fragment or a.fragment in routes[a.path]['anchors']
   assert nn['html'].replace('href="'+nh[0]+'"','href="'+ph[0]+'"',1)==pn['html']
   adjusted['html']=nn['html'];href={'normal':nh[0],'pages':ph[0],'declaredPath':a.path,'declaredHash':a.fragment or None}
  assert pn['target']==canonical or href
  ds=differences(nn,adjusted)
  prior=next(r for r in F['rows']if r['freshProjectionPointer']==f'/manualStyles/{gi}/nodes/{ni}')
  rows.append({'testId':f'R01-PAGES-CONTRAST-{len(rows)+1:03d}','normalRowTestId':prior['testId'],'projectionPointer':f'/manualStyles/{gi}/nodes/{ni}','route':pg['route'],'width':pg['width'],'state':pg['state'],'target':pn['target'],'normalTarget':canonical,'singleDeclaredSlashDifference':href,'selectorAliased':pn['target']!=canonical,'differences':ds,'status':'DIFFERENCE_REQUIRES_SCOPED_REVIEW'if ds else'EXACT_FORMAL_COMPUTED_INPUT_CORRESPONDENCE_NOT_ADJUDICATED'})
out={'testId':'R01-PAGES-STRICT-FORMAL-CORRESPONDENCE-DIAGNOSTIC','status':'DIAGNOSTIC_ONLY_NOT_CONTRAST_PASS','createdAt':datetime.now(timezone.utc).isoformat(),'pagesProjection':{'path':args.projection,'sha256':sha(args.projection)},'normalProjection':{'path':str(R/'normal-contrast-projection.json'),'sha256':sha(R/'normal-contrast-projection.json')},'normalFinal':{'path':str(R/'normal-contrast-final-v2.json'),'sha256':sha(R/'normal-contrast-final-v2.json')},'counts':{'rows':len(rows),'exact':sum(not r['differences']for r in rows),'different':sum(bool(r['differences'])for r in rows),'singleDeclaredHrefSlashes':sum(bool(r['singleDeclaredSlashDifference'])for r in rows),'selectorAliases':sum(r['selectorAliased']for r in rows)},'rows':rows}
path.write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'status':out['status'],'counts':out['counts'],'output':str(path)}))
