"""Offline final correspondence; original suites, projections and failures stay immutable."""
from pathlib import Path
from datetime import datetime, timezone
import collections, copy, gzip, hashlib, json

R = Path('/tmp/xk-dc007-r01/a11y')
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
read = lambda p: json.loads(Path(p).read_text())
ref = lambda p: {'path': str(p), 'sha256': sha(p)}
partial_path = R / 'normal-contrast-correspondence.json'
activation_path = R / 'home-cta-activation-v2/evidence.json'
P, F = read(partial_path), read(activation_path)
O = read('/tmp/xk-dc007/a11y/capture-normal-v2/evidence.json')
B = read('/tmp/xk-dc007-r01/source-after.json')
V = read('/tmp/xk-dc007-r01/source-after-v2.json')
assert P['counts'] == {'PASS_EXACT_FRESH_PAINT_SOURCE_BRIDGE': 375, 'PENDING_FRESH_CV_ACTIVATION': 9}
assert F['oldPendingMap'] == ref(partial_path)
assert F['source']['sha256'] == sha('/tmp/xk-dc007-r01/source-after-v2.json')
assert read(R/'home-cta-activation-v2-command.json')['exitCode'] == 0
assert read(R/'home-cta-activation-command.json')['exitCode'] == 1
bm, vm = ({x['path']: x for x in d['files']} for d in [B,V])
assert bm.keys() == vm.keys() and len(vm) == 337
changed = sorted(k for k in bm if bm[k] != vm[k])
assert changed == ['src/app/globals.css', 'src/components/sections/quotation/quotation-estimator.tsx', 'src/components/sections/quotation/quotation-summary.tsx']
css = Path('/workspace/xk-website/src/app/globals.css').read_bytes()
extra = b'  #quotation-estimator > section.quotation-preview-section,\n'
assert css.count(extra) == 1
assert hashlib.sha256(css).hexdigest() == vm['src/app/globals.css']['sha256']
assert hashlib.sha256(css.replace(extra,b'',1)).hexdigest() == bm['src/app/globals.css']['sha256']
source = {
 'testId':'R01-FINAL-NONQUOTATION-SOURCE-BRIDGE', 'status':'PASS_EXACT_SCOPED_SOURCE_DELTA',
 'before':ref('/tmp/xk-dc007-r01/source-after.json'), 'after':ref('/tmp/xk-dc007-r01/source-after-v2.json'),
 'beforeRuntimeFingerprint': B['sha256'], 'afterRuntimeFingerprint': V['sha256'],
 'fileCounts': {'before':337,'after':337,'unchanged':334,'changed':3,'added':0,'deleted':0},
 'changed':[{'path':k,'before':bm[k],'after':vm[k]}for k in changed],
 'exactCssAddition':extra.decode(), 'removingOnlyThisLineRestoresBeforeBytesSha256':bm['src/app/globals.css']['sha256'],
 'boundary':'Only the Quotation estimator preview selector joins the pre-existing screen-only content-visibility rule. All other CSS bytes and all334 unchanged tracked source entries, including Home/fonts/header/style switcher/footer, retain their prior source. Quotation component changes require their separate fresh affected-area evidence.',
 'independentCheck':ref(R/'source-v2-independent-check.json')}
source_path = R/'source-v2-nonquotation-bridge.json'
source_path.write_text(json.dumps(source,ensure_ascii=False,indent=2)+'\n')

old_class='_0bjUvq_variable U63m2q_variable antialiased'
new_class='_0bjUvq_variable Obekhq_variable antialiased'
def paint(v):
 if isinstance(v,list): return [paint(x)for x in v]
 if isinstance(v,dict):
  d={k:paint(x)for k,x in v.items()if k!='rect'}
  if d.get('tag')=='HTML'and d.get('className')==new_class: d['className']=old_class
  return d
 return v
def local_box(item,surface):
 r,s=item['rect'],surface['rect']
 return {'x':r['x']-s['x'],'y':r['y']-s['y'],'width':r['width'],'height':r['height']}

rows=copy.deepcopy(P['rows']); resolved=[]
for gi,g in enumerate(F['groups']):
 og=next(x for x in O['groups']if(x['route'],x['width'],x['state'])==('/',g['width'],g['state']))
 assert len(g['actual']['nodes'])==3
 assert g['menuExpanded']==('true'if g['state']=='actual-mobile-menu-expanded'else'false')
 for ni,n in enumerate(g['actual']['nodes']):
  on=next(x for x in og['actual']['nodes']if x['target']==n['target'])
  visibility=next(x for x in g['visibility']if x['target']==n['target'])
  assert visibility['visible']and visibility['intersectsViewport']
  assert n['resolution']==on['resolution'] and n['text']==on['text']and n['html']==on['html']
  assert paint(n['element'])==paint(on['element'])
  assert paint(n['ancestors'])==paint(on['ancestors'])
  assert paint(n['decorations'])==paint(on['decorations'])
  oi=next(i for i,a in enumerate(on['ancestors'])if a['style']['backgroundColor'].startswith('rgb('))
  fi=next(i for i,a in enumerate(n['ancestors'])if a['style']['backgroundColor'].startswith('rgb('))
  assert oi==fi==3
  os,fs=on['ancestors'][oi],n['ancestors'][fi]
  for a,b in zip(on['ancestors'][:oi+1],n['ancestors'][:fi+1]):assert local_box(a,os)==local_box(b,fs)
  for a,b in zip(on['decorations'],n['decorations']):assert local_box(a,os)==local_box(b,fs)
  assert n['panelCoverageRatio']==0
  assert len(n['hitTests'])==9 and all(h['inViewport']and h['stack'][0]['targetContains']and not h['stack'][0]['panelContains']for h in n['hitTests'])
  row=next(x for x in rows if(x['route'],x['width'],x['state'],x['target'])==('/',g['width'],g['state'],n['target']))
  assert row['status']=='PENDING_FRESH_CV_ACTIVATION'
  assert row['formulaReference']['provedMinimum']>=row['formulaReference']['threshold']
  row['status']='PASS_FRESH_SCROLL_ACTIVATION_PAINT_SOURCE_BRIDGE'
  row['activationProof']={
   'evidence':ref(activation_path),'pointer':f'/groups/{gi}/actual/nodes/{ni}',
   'visibilityPointer':f'/groups/{gi}/visibility/{ni}', 'actualVisibility':visibility,
   'elementAncestorPseudoDecorationPaintMatch':True,'opaqueSurface':fs,
   'targetAndRelevantLayerLocalGeometryMatch':True,
   'absoluteDocumentPlacement':'Changed by real scroll/CV preceding-section estimates. Not a formula input; actual local glyph/opaque/decorative geometry is exact.',
   'actualPanelCoverageRatio':0,'nineViewportHitProbesTopmostTarget':True,
   'menuState':'Expanded aria state preserved but header/menu moved offscreen during actual CTA scroll. This does not assert simultaneous menu visibility. Prior conservative shadow interval includes zero.',
   'formulaApplicability':'Same foreground, nearest opaque surface, gradient/pseudo/effect inputs and local paint stratum; prior whole-gradient alpha-interval lower bound remains valid after activation. No formula recalculation.'}
  resolved.append(row['testId'])
assert len(resolved)==9
counts=dict(collections.Counter(r['status']for r in rows))
assert counts=={'PASS_EXACT_FRESH_PAINT_SOURCE_BRIDGE':375,'PASS_FRESH_SCROLL_ACTIVATION_PAINT_SOURCE_BRIDGE':9}
for s in F['screenshots']:assert sha(s['path'])==s['sha256']
quote_path='/tmp/xk-dc007-r01/qa/normal-quotation-axe-retained-v2/result.json'
Q=read(quote_path)
assert len(Q['axe'])==18 and not Q['incomplete']
assert all(not a.get('violations')for a in Q['axe'])
report={
 'testId':'R01-NORMAL-FINAL-SCOPED-CONTRAST-BRIDGE-V2',
 'status':'SCOPED_384_CORRESPONDENCES_RESOLVED', 'createdAt':datetime.now(timezone.utc).isoformat(),
 'partial375AndOriginalNinePending':ref(partial_path), 'sourceBridge':ref(source_path),
 'counts':counts,'pending':0,'resolvedNine':resolved,
 'formalOriginal':P['formalOriginal'],
 'freshActivation':ref(activation_path),'activationCommand':ref(R/'home-cta-activation-v2-command.json'),
 'retainedFailedAttempt':{'receipt':ref(R/'home-cta-activation-command.json'),'actualExit':1,'reason':'Initial section-only scroll could not establish every desktop CTA target viewport intersection during CV reflow. Retest uses real per-target scrolling; no CSS override or suite rewrite.'},
 'screenshots':F['screenshots'],
 'imageReview':{'375':'All three CTA text targets visibly painted on the light radial surface; no menu overlay.','1440':'All three CTA text targets visibly painted on the light radial surface; no overlay.','menu375':'Byte-identical PNG to375 default after scroll; aria-expanded remains true while menu is offscreen. No simultaneous visible-menu claim.'},
 'quotationSeparateOwnerEvidence':{**ref(quote_path),'axeScans':18,'violations':0,'incomplete':0,'boundary':'Separate fresh affected-area result inspected offline; not produced by this collector and not included in the384 bridge count.'},
 'scope':'Only384 originally incomplete target-specific color contrast correspondences.375 use prior fresh R01 computed/paint evidence plus exact non-Quotation final-source bridge;9 additionally prove final-source actual CV activation. Original formal Exit1 and384 incomplete remain unchanged. Not a fresh full-suite axe run, full WCAG certification, keyboard/human AT or Pages-mode acceptance.',
 'browser':'Focused browser closed in collector finally before notification to Root. No browser launched during subsequent exclusive performance.',
 'rows':rows}
out=R/'normal-contrast-final-v2.json'
out.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
(R/'normal-contrast-final-v2.md').write_text('''# R01 Normal 最終來源的限定對比覆核

384 個原 incomplete targets 的限定對照已收斂：375 項沿用本輪 fresh computed／paint correspondence，並以 be6→9d18 的精確來源差異橋接；另9 個 Home CTA targets 已在最終來源實際捲動啟用、可見且落在viewport內。這是人工公式／實際paint輸入的限定判讀，不把原正式 Exit1、119 axe／0 violations／384 incomplete 改寫為 suite PASS。

三組補採是375預設、1440預設與375 menu expanded，各驗 eyebrow、#contact-title、內文三項。每項前景、最近opaque surface、ancestor／pseudo／gradient effects與相對幾何均符合既有公式；9個viewport probes的最上層皆為被測target，panel coverage皆0。menu維持aria-expanded=true，但實際scroll時header／menu已在畫面外；未聲稱menu仍同時可見。既有shadow公式涵蓋alpha=0，保守下界仍適用。最低引用值為4.793215544810599，對應門檻4.5；沒有重算384公式。

source-after be6與最終source-after-v2 9d18皆337檔：334完全相同、僅globals.css及兩個Quotation components變動、無增刪。globals唯一新增Quotation preview selector移除後逐byte還原be6 SHA；其他paint CSS完全相同。Quotation變動由另owner fresh18 axe、0violation／0incomplete結果涵蓋，不混入384筆數。

初版section-only scroll真Exit1保留；v2以真實逐target scroll加兩次RAF得到9項啟用，真Exit0。3張原PNG、原始JSON與兩次OS回執完整保留。375menu圖與375default圖SHA相同，符合scroll後menu在viewport外的實況。

逐項原testID、threshold／既有公式SHA與ratio、source bridge、fresh visibility／paint pointers均見normal-contrast-final-v2.json。normal-contrast-correspondence.json仍保留當時375已橋接／9待補的歷史狀態。此結論限Normal色彩對比，未宣稱Pages、完整WCAG、真人讀屏或正式整套功能驗收通過。全部browser已關閉；離線整理未占用性能時窗。
''')
for p in [source_path,out,activation_path]:
 compressed=Path(str(p)+'.gz');compressed.write_bytes(gzip.compress(p.read_bytes(),mtime=0));assert gzip.decompress(compressed.read_bytes())==p.read_bytes()
print(json.dumps({'status':report['status'],'counts':counts,'pending':0,'changedFiles':changed,'report':ref(out)},ensure_ascii=False))
