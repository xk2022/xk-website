"""Target-specific final Pages correspondence; requires fresh actual menu/CTA paint."""
from pathlib import Path
from datetime import datetime,timezone
import argparse,copy,gzip,hashlib,json,collections

R=Path('/tmp/xk-dc007-r01/a11y');read=lambda p:json.loads(Path(p).read_text());sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();ref=lambda p:{'path':str(p),'sha256':sha(p)}
parser=argparse.ArgumentParser();parser.add_argument('--diagnostic',required=True);parser.add_argument('--paint',required=True);parser.add_argument('--output',required=True);args=parser.parse_args();out=Path(args.output);assert not out.exists()
D=read(args.diagnostic);P=read(D['pagesProjection']['path']);N=read(D['normalProjection']['path']);F=read(D['normalFinal']['path']);E=read(args.paint);NM=read(R/'fresh-normal-paint/evidence.json');NA=read(R/'home-cta-activation-v2/evidence.json')
assert D['pagesProjection']==ref(D['pagesProjection']['path'])and D['normalFinal']==ref(D['normalFinal']['path'])
assert E['status']=='LIMITED_PAINT_CAPTURE_COMPLETE_NOT_ADJUDICATED'and E['projection']==D['pagesProjection']and E['normalFinal']==D['normalFinal']
assert P['source']==E['source']and P['source']['sha256']==sha('/tmp/xk-dc007-r01/source-after-v2.json')
assert len(P['axeCompletion']['records'])==119 and len(D['rows'])==len(F['rows'])==384
assert sum(len(a['violations'])for a in P['axeCompletion']['records'])==0
assert sum(rule['nodes']for a in P['incomplete']for rule in a['rules'])==384
assert not P['manualEvidenceErrors']
rows=[];hover=0;menus=0;activated=0;geometryDeltas=[]
def paint(v):
 if isinstance(v,list):return[paint(x)for x in v]
 if isinstance(v,dict):return{k:paint(x)for k,x in v.items()if k not in('rect','originalChecks')}
 return v
def local(item,surface):
 a,b=item['rect'],surface['rect'];return{'x':a['x']-b['x'],'y':a['y']-b['y'],'width':a['width'],'height':a['height']}
for dr in D['rows']:
 row=copy.deepcopy(dr);prior=next(r for r in F['rows']if r['testId']==dr['normalRowTestId']);gi,ni=map(int,[dr['projectionPointer'].split('/')[2],dr['projectionPointer'].split('/')[4]]);pn=P['manualStyles'][gi]['nodes'][ni];nn=N['manualStyles'][gi]['nodes'][ni]
 assert prior['status'].startswith('PASS_')
 diagnostic=[]
 if dr['differences']:
  assert(dr['route'],dr['width'],dr['state'])==('/portfolio',375,'default-fullpage')
  assert len(dr['differences'])==3
  box=pn['computed']['ancestors'][0]['rect']
  for delta in dr['differences']:
   parts=delta['pointer'].split('/');assert parts[:4]==['','related','0','computed']and parts[4]=='hitTests'and int(parts[5])in(1,4,7)and parts[6:]==['stack','0','background']
   assert{delta['normal'],delta['pages']}=={'rgb(245, 247, 251)','rgb(255, 255, 255)'}
   hit=pn['related'][0]['computed']['hitTests'][int(parts[5])];top=hit['stack'][0]
   assert not(box['x']<=hit['x']<=box['x']+box['width']and box['y']<=hit['y']<=box['y']+box['height'])
   assert top['tag']=='A'and not top['targetContains']and not top['panelContains']and'hover:bg-surface'in top['className'].split()
   diagnostic.append({**delta,'reason':'Different-link hover diagnostic point lies outside this tested glyph box. Own-target input and every other compared field are exact; not used by the glyph contrast formula.'})
  hover+=1
 row['nonFormulaDiagnosticDeltas']=diagnostic
 row['formulaReference']=prior['formulaReference'];row['formulaReference']['recomputed']=False
 row['normalFinalStatus']=prior['status'];row['status']='PASS_FRESH_PAGES_FORMAL_INPUT_AND_SOURCE_BRIDGE'
 if any(c['data']['messageKey']=='bgOverlap'for c in pn['checks']):
  mg=next(g for g in E['menus']if(g['route'],g['width'],g['state'])==(dr['route'],dr['width'],dr['state']));ng=next(g for g in NM['groups']if(g['route'],g['width'],g['state'])==(dr['route'],dr['width'],dr['state']))
  assert mg['actual']['panel']==ng['actual']['panel']
  for state in['closed','actual']:
   assert mg[state]['viewport']==ng[state]['viewport']
   fresh=next(x for x in mg[state]['nodes']if x['target']==pn['target']);old=next(x for x in ng[state]['nodes']if x['target']==nn['target']);freshCopy=copy.deepcopy(fresh)
   freshCopy['html']=old['html'];assert fresh['html']==pn['html']and old['html']==nn['html']
   opaque=next(i for i,a in enumerate(fresh['ancestors'])if a['style']['backgroundColor'].startswith('rgb('))
   for i,(a,b)in enumerate(zip(freshCopy['ancestors'],old['ancestors'])):
    if a['tag']in('BODY','HTML'):
     assert i>opaque and a['style']['backgroundImage']=='none'and a['style']['opacity']=='1'
     if a['rect']!=b['rect']:geometryDeltas.append({'row':row['testId'],'state':state,'tag':a['tag'],'normal':b['rect'],'pages':a['rect']})
     a['rect']=b['rect']
   assert freshCopy==old,'Unreviewed fresh menu paint/geometry/input delta'
  actual=next(x for x in mg['actual']['nodes']if x['target']==pn['target']);assert actual['panelCoverageRatio']==1 and len(actual['hitTests'])==9 and all(h['inViewport']and h['stack'][0]['panelContains']for h in actual['hitTests'])
  row['freshPagesMenuProof']={'evidence':ref(args.paint),'menuGroup':E['menus'].index(mg),'closedOpenExactRelevantPaintAndGeometry':True,'coverageRatio':1,'topmostPanelHitProbes':9};menus+=1
  row['status']='PASS_FRESH_PAGES_OPAQUE_MENU_AND_CLOSED_PAINT_BRIDGE'
 if prior.get('activationProof'):
  ag=next(g for g in E['activations']if(g['width'],g['state'])==(dr['width'],dr['state']));ng=next(g for g in NA['groups']if(g['width'],g['state'])==(dr['width'],dr['state']));fresh=next(x for x in ag['actual']['nodes']if x['target']==pn['target']);old=next(x for x in ng['actual']['nodes']if x['target']==nn['target']);v=next(v for v in ag['visibility']if v['target']==pn['target'])
  assert fresh['resolution']==old['resolution']=='FOUND' and fresh['html']==old['html']and fresh['text']==old['text']
  assert paint(fresh['element'])==paint(old['element'])and paint(fresh['ancestors'])==paint(old['ancestors'])and paint(fresh['decorations'])==paint(old['decorations'])
  oi=next(i for i,a in enumerate(old['ancestors'])if a['style']['backgroundColor'].startswith('rgb('));fi=next(i for i,a in enumerate(fresh['ancestors'])if a['style']['backgroundColor'].startswith('rgb('));assert oi==fi==3;os,fs=old['ancestors'][oi],fresh['ancestors'][fi]
  for a,b in zip(old['ancestors'][:oi+1],fresh['ancestors'][:fi+1]):assert local(a,os)==local(b,fs)
  for a,b in zip(old['decorations'],fresh['decorations']):assert local(a,os)==local(b,fs)
  assert v['visible']and v['intersectsViewport']and fresh['panelCoverageRatio']==0
  assert len(fresh['hitTests'])==9 and all(h['inViewport']and h['stack'][0]['targetContains']and not h['stack'][0]['panelContains']for h in fresh['hitTests'])
  assert ag['menuExpanded']==ng['menuExpanded'];row['freshPagesActivation']={'evidence':ref(args.paint),'group':E['activations'].index(ag),'visibility':v,'exactRelevantPaintAndLocalGeometry':True,'actualPanelCoverageRatio':0,'menuBoundary':'When aria-expanded=true, actual scroll moves menu outside viewport; no simultaneous-visible-menu claim. Conservative shadow formula includes zero.'};row['status']='PASS_FRESH_PAGES_CV_ACTIVATION_PAINT_BRIDGE';activated+=1
 row.pop('differences',None);rows.append(row)
assert menus==30 and activated==9
for c in E['css']:assert sha(c['snapshot'])==c['sha256']and c['status']==200
for s in E['screenshots']:assert sha(s['path'])==s['sha256']
counts=dict(collections.Counter(r['status']for r in rows))
report={'testId':'R01-PAGES-FINAL-384-SCOPED-CONTRAST-BRIDGE','status':'SCOPED_384_PAGES_CORRESPONDENCES_RESOLVED_PENDING_FINAL_RAW_LINK','createdAt':datetime.now(timezone.utc).isoformat(),'pagesProjection':D['pagesProjection'],'diagnostic':ref(args.diagnostic),'normalFinal':D['normalFinal'],'freshPaint':ref(args.paint),'source':P['source'],'counts':counts,'freshMenuClosedOpenPairs':menus,'freshCVActivatedTargets':activated,'nonFormulaHoverDeltaRows':hover,'outerDocumentBoundsDeltas':geometryDeltas,'runtimeCSS':E['css'],'screenshots':E['screenshots'],'originalPolicy':'Pages119 formal axe scans retain0violations/384incomplete. Original NormalExit1/384incomplete unchanged. This target-specific color-contrast bridge is not overall suite success/fullWCAG/humanAT or release acceptance. No384formula recalculation or31state recapture.','sourcePolicy':'Fresh Pages pins final9d18 source. Normal375 formal/focused inputs are bridged across exact non-Quotation3file boundary;9 activated inputs also have final9d18 actual Normal proof. Pages own computed inputs and limited actual paint are checked, not inferred from fingerprint alone. Fresh Pages compiledCSS is snapshotted; uncaptured finalNormal compiledCSS byte identity is not asserted.','finalRawLink':'PENDING: reproject the finished Pagesraw with project-r01-contrast.py --compare and record actualOSexit/fullrawSHA. Completed119projection must remain byte-identical.','rows':rows}
out.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');Path(str(out)+'.gz').write_bytes(gzip.compress(out.read_bytes(),mtime=0));print(json.dumps({'status':report['status'],'counts':counts,'freshMenuClosedOpenPairs':menus,'freshCVActivatedTargets':activated,'nonFormulaHoverDeltaRows':hover,'output':str(out)}))
