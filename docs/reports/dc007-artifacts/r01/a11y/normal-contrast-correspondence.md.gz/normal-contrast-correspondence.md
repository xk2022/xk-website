# R01 normal fresh 對比：375 已橋接，9 待 CV 啟用

375／384 可作限定 fresh paint/source 對照，9 rows 保留 PENDING_FRESH_CV_ACTIVATION。原正式531／245 layouts／119axe／0violations／384incomplete／真Exit1與八項business FAIL不回寫。

原已證公式只在本輪glyph paint／threshold／opaque surface等實際輸入對應後引用，未重算384。唯一生成字體metadata變化為Noto root variable class U63m2q→Obekhq。source proof顯示globals除精確CV與source-exclusions新增外其餘paint bytes不變。六個Portfolio rows的related-gradient大範圍診斷點碰到不同link hover底色：各三點在被測glyph box之外，own-target paint／geometry／hit不變；這些非公式輸入的差異逐點保留，沒有假稱整份computed資料字面相同。

四組fresh小型補採驗三菜單closed/open、About conic及Home radial/grid。對已繪製的sample，除最近opaque surface外MAIN／BODY／HTML整體估高另記，glyph／opaque-surface／menu幾何與effects仍精確對照。

九項pending為HomeCTA三個targets（eyebrow、#contact-title、.max-w-2xl），在375 default／375 menu／1440 default。Fresh probe實際見content-visibility:auto skipped，不能只靠computed color相同判已繪製PASS。Root normal已停，全部browser關閉；獨占perf後再以Pages同source/output bridge，僅捲入HomeCTA的375／1440及menu狀態補visibility／paint／geometry／PNG即可，不跑axe/fullsuite。

逐row原testID、fresh JSON pointer、公式引用、六項診斷差異與九項pending在normal-contrast-correspondence.json。normal-projection-command.json與fresh-normal-paint-command.json皆為限定證據程序Exit0，不代表正式suite或完整WCAG／真人AT通過。
