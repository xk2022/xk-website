"""Project completed fresh axe evidence without adjudicating or assuming 384 nodes."""
import argparse,hashlib,json
from pathlib import Path
from datetime import datetime,timezone

def project(raw,expected):
    axe=raw['axe'];tests=[t for t in raw['tests']if t['testId'].startswith('AXE-')]
    assert raw.get('axePlan',{}).get('scans')==expected and len(axe)==len(tests)==expected,'Formal axe plan/records are not yet complete'
    assert all(t['status']in('PASS','FAIL')for t in tests),'A formal AXE test is still pending'
    assert len({(a['route'],a['width'],a['state'])for a in axe})==expected,'Duplicate formal axe identity'
    return{'schemaVersion':1,'testId':'DC007-R01-FRESH-COMPLETED-AXE-PROJECTION','mode':raw['mode'],'baseURL':raw['baseURL'],'source':raw['source'],'inputs':raw['inputs'],'tools':raw['tools'],'axePlan':raw['axePlan'],'axeCompletion':{'expectedScans':expected,'records':axe,'formalTests':tests},'manualStyles':raw['manualStyles'],'incomplete':raw['incomplete'],'manualEvidenceErrors':raw.get('manualEvidenceErrors',[]),'closedContrastEvidence':raw.get('closedContrastEvidence',[])}

parser=argparse.ArgumentParser();parser.add_argument('--input',required=True);parser.add_argument('--output');parser.add_argument('--compare');parser.add_argument('--expected-scans',type=int,default=119);args=parser.parse_args()
path=Path(args.input);raw=json.loads(path.read_text());projection=project(raw,args.expected_scans);encoded=(json.dumps(projection,ensure_ascii=False,sort_keys=True,separators=(',',':'))+'\n').encode();digest=hashlib.sha256(encoded).hexdigest()
if args.compare:
    assert raw.get('finishedAt') and raw['status']not in('PENDING','RUNNING'),'A running raw cannot be called final'
    assert Path(args.compare).read_bytes()==encoded,'Final projection differs; earlier target adjudication cannot be inherited'
    print(json.dumps({'status':'PASS_FINAL_PROJECTION_IDENTITY_ONLY','projectionSha256':digest,'finalRawStatus':raw['status'],'finishedAt':raw['finishedAt'],'finalRawSha256':hashlib.sha256(path.read_bytes()).hexdigest(),'contrastAdjudication':'Separate per-target evidence is required; this tool does not mark contrast PASS.'}))
else:
    assert args.output;output=Path(args.output);assert not output.exists(),'Preserve the first projection';output.write_bytes(encoded)
    meta={'status':'FROZEN_COMPLETED_AXE_EVIDENCE_NOT_ADJUDICATED','createdAt':datetime.now(timezone.utc).isoformat(),'tool':{'path':__file__,'sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()},'rawPath':str(path),'rawStatusAtRead':raw['status'],'rawFinishedAtAtRead':raw.get('finishedAt'),'runningWholeFileShaUsed':False,'projection':{'path':str(output),'sha256':digest,'bytes':len(encoded)},'completedAxeRecords':len(projection['axeCompletion']['records']),'violations':sum(len(a['violations'])for a in projection['axeCompletion']['records']),'manualGroups':len(projection['manualStyles']),'manualTargets':sum(len(g['nodes'])for g in projection['manualStyles']),'policy':'Fresh count and target identity are authoritative, not the old384. Completed-record projection is not a contrast or whole-suite PASS. Reproject finished raw for final linkage.'}
    Path(str(output)+'.meta.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2)+'\n');print(json.dumps(meta,ensure_ascii=False))
