# R01 Normal 最終來源的限定對比覆核

384 個原 incomplete targets 的限定對照已收斂：375 項沿用本輪 fresh computed／paint correspondence，並以 be6→9d18 的精確來源差異橋接；另9 個 Home CTA targets 已在最終來源實際捲動啟用、可見且落在viewport內。這是人工公式／實際paint輸入的限定判讀，不把原正式 Exit1、119 axe／0 violations／384 incomplete 改寫為 suite PASS。

三組補採是375預設、1440預設與375 menu expanded，各驗 eyebrow、#contact-title、內文三項。每項前景、最近opaque surface、ancestor／pseudo／gradient effects與相對幾何均符合既有公式；9個viewport probes的最上層皆為被測target，panel coverage皆0。menu維持aria-expanded=true，但實際scroll時header／menu已在畫面外；未聲稱menu仍同時可見。既有shadow公式涵蓋alpha=0，保守下界仍適用。最低引用值為4.793215544810599，對應門檻4.5；沒有重算384公式。

source-after be6與最終source-after-v2 9d18皆337檔：334完全相同、僅globals.css及兩個Quotation components變動、無增刪。globals唯一新增Quotation preview selector移除後逐byte還原be6 SHA；其他paint CSS完全相同。Quotation變動由另owner fresh18 axe、0violation／0incomplete結果涵蓋，不混入384筆數。

初版section-only scroll真Exit1保留；v2以真實逐target scroll加兩次RAF得到9項啟用，真Exit0。3張原PNG、原始JSON與兩次OS回執完整保留。375menu圖與375default圖SHA相同，符合scroll後menu在viewport外的實況。

逐項原testID、threshold／既有公式SHA與ratio、source bridge、fresh visibility／paint pointers均見normal-contrast-final-v2.json。normal-contrast-correspondence.json仍保留當時375已橋接／9待補的歷史狀態。此結論限Normal色彩對比，未宣稱Pages、完整WCAG、真人讀屏或正式整套功能驗收通過。全部browser已關閉；離線整理未占用性能時窗。
