"""R01 correspondence only: inherited math is gated by current evidence, CV stays pending."""
from pathlib import Path
from datetime import datetime,timezone
import json,hashlib,collections,copy,gzip
R=Path('/tmp/xk-dc007-r01/a11y');sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
P=json.loads((R/'normal-contrast-projection.json').read_text());N=json.loads(Path('/tmp/xk-dc007/normal-final/result.json').read_text());A=json.loads(Path('/tmp/xk-dc007/a11y/adjudication-normal-v2.json').read_text());OE=json.loads(Path('/tmp/xk-dc007/a11y/capture-normal-v2/evidence.json').read_text());F=json.loads((R/'fresh-normal-paint/evidence.json').read_text());prep=json.loads((R/'contrast-preparation.json').read_text())
oldClass='_0bjUvq_variable U63m2q_variable antialiased';newClass='_0bjUvq_variable Obekhq_variable antialiased'
def norm(v,outer=False):
 if isinstance(v,list):return[norm(x,outer)for x in v]
 if isinstance(v,dict):
  d={k:norm(x,outer)for k,x in v.items()}
  if d.get('tag')=='HTML'and d.get('className')==newClass:d['className']=oldClass
  if outer and d.get('tag')in('MAIN','BODY','HTML')and'rect'in d:d['rect']={'role':'outer-document-estimated-bounds-outside-nearest-opaque-surface'}
  return d
 return v
assert P['source']['sha256']==prep['sourceAfter']['sha256']==sha(prep['sourceAfter']['path']);assert F['status']=='CAPTURE_COMPLETE_NOT_ADJUDICATED'and F['input']['sha256']==sha(R/'normal-contrast-projection.json')
for d in prep['sourcePaintDelta']:assert sha(Path('/workspace/xk-website')/d['path'])==d['afterSha256']
skipped={tuple(n['target'])for g in F['groups']for n in g['renderState']if not n['visible']};assert len(skipped)==3
samples=[];outerDeltas=[]
for g in F['groups']:
 og=next(x for x in OE['groups']if(x['route'],x['width'],x['state'])==(g['route'],g['width'],g['state']))
 for state in ['actual']+(['closed']if'closed'in g else[]):
  for on,fn in zip(og[state]['nodes'],g[state]['nodes']):
   if g['route']=='/'and tuple(fn['target'])in skipped:continue
   opaque=next(i for i,a in enumerate(fn['ancestors'])if a['style']['backgroundColor'].startswith('rgb('))
   for i,a in enumerate(fn['ancestors']):
    if a['tag']in('MAIN','BODY','HTML'):assert i>opaque and a['style']['backgroundImage']=='none'and a['style']['opacity']=='1'
   assert norm(on,True)==norm(fn,True),(g['route'],state,fn['target'])
   for aa,bb in zip(on['ancestors'],fn['ancestors']):
    if aa['tag']in('MAIN','BODY','HTML')and aa['rect']!=bb['rect']:outerDeltas.append({'route':g['route'],'target':fn['target'],'ancestor':aa['tag'],'old':aa['rect'],'fresh':bb['rect']})
   samples.append({'route':g['route'],'state':g['state'],'captureState':state,'target':fn['target'],'actualPaintEffectsAndTargetSurfaceMenuGeometryMatch':True})
 for n in g['renderState']:
  if tuple(n['target'])not in skipped:assert n['visible'] and all(a['contentVisibility']=='visible'and a['contain']=='none'for a in n['ancestors'])
 if'closed'in g:assert g['actual']['panel']==og['actual']['panel']
base={}
for gi,g in enumerate(N['manualStyles']):
 for ni,n in enumerate(g['nodes']):base[(g['route'],g['width'],g['state'],tuple(n['target']))]=(gi,ni,n)
priorRows={r['sourceManualPointer']:r for r in A['rows']};rows=[];hoverRows=0
for gi,g in enumerate(P['manualStyles']):
 for ni,n in enumerate(g['nodes']):
  key=(g['route'],g['width'],g['state'],tuple(n['target']));assert key in base;oi,oj,on=base[key];a,b=norm(on),norm(n);diagnostics=[]
  if a!=b:
   assert(g['route'],g['width'],g['state'])==('/portfolio',375,'default-fullpage')
   rect=b['computed']['ancestors'][0]['rect']
   for ri,(ar,br)in enumerate(zip(a['related'],b['related'])):
    for hi,(ah,bh)in enumerate(zip(ar['computed']['hitTests'],br['computed']['hitTests'])):
     if ah==bh:continue
     assert hi in(1,4,7)and ah['x']==bh['x']and ah['y']==bh['y']and ah['inViewport']==bh['inViewport']==True
     assert not(rect['x']<=bh['x']<=rect['x']+rect['width']and rect['y']<=bh['y']<=rect['y']+rect['height']),'Related diagnostic point intersects tested glyph box'
     ao,bo=ah['stack'][0],bh['stack'][0];assert ao['tag']==bo['tag']=='A'and not ao['targetContains']and not bo['targetContains']and not ao['panelContains']and not bo['panelContains']
     assert 'bg-background'in bo['className'].split()and'hover:bg-surface'in bo['className'].split()and {ao['background'],bo['background']}=={'rgb(245, 247, 251)','rgb(255, 255, 255)'}
     expected=copy.deepcopy(ah);expected['stack'][0]['background']=bo['background'];assert expected==bh
     diagnostics.append({'pointer':f'/related/{ri}/computed/hitTests/{hi}/stack/0/background','old':ao['background'],'fresh':bo['background'],'reason':'Observed hover/background diagnostic on a different link outside this tested glyph box. Target own paint/geometry/hit data and actual related gradient colors/ancestors are unchanged; this diagnostic is not an input of the proven glyph contrast formula.'});ah['stack'][0]['background']=bo['background']
   assert a==b,'Other actual paint/threshold/geometry/related input changed';assert len(diagnostics)==3;hoverRows+=1
  prior=priorRows[f'/manualStyles/{oi}/nodes/{oj}'];pending=g['route']=='/'and tuple(n['target'])in skipped
  rows.append({'testId':f'R01-NORMAL-CONTRAST-{len(rows)+1:03d}','sourceTestId':prior['sourceTestId'],'freshProjectionPointer':f'/manualStyles/{gi}/nodes/{ni}','route':g['route'],'width':g['width'],'state':g['state'],'target':n['target'],'glyphPaintAndThresholdInputMatch':True,'nonFormulaDiagnosticDeltas':diagnostics,'formulaReference':{'path':'/tmp/xk-dc007/a11y/adjudication-normal-v2.json','sha256':sha('/tmp/xk-dc007/a11y/adjudication-normal-v2.json'),'rowTestId':prior['testId'],'threshold':prior['requiredRatio'],'provedMinimum':prior['paint']['minimumContrast'],'recomputed':False},'status':'PENDING_FRESH_CV_ACTIVATION'if pending else'PASS_EXACT_FRESH_PAINT_SOURCE_BRIDGE'})
counts=collections.Counter(r['status']for r in rows);assert counts=={'PASS_EXACT_FRESH_PAINT_SOURCE_BRIDGE':375,'PENDING_FRESH_CV_ACTIVATION':9}and hoverRows==6
report={'testId':'R01-NORMAL-FRESH-CONTRAST-CORRESPONDENCE','status':'PARTIAL_375_BRIDGED_9_CV_ACTIVATION_PENDING','createdAt':datetime.now(timezone.utc).isoformat(),'freshProjection':{'path':str(R/'normal-contrast-projection.json'),'sha256':sha(R/'normal-contrast-projection.json')},'formalOriginal':{'path':'/tmp/xk-dc007-r01/qa/normal-native-cv-final/result.json','actualExit':1,'tests':531,'layouts':245,'axeScans':119,'violations':0,'incomplete':384,'eightBusinessFailures':'Separate owner; never rewritten here'},'sourceProof':{'path':str(R/'contrast-preparation.json'),'sha256':sha(R/'contrast-preparation.json'),'freshSourceAfterSha256':prep['sourceAfter']['sha256'],'paintRulesExactAfterExplicitCVAndSourceExclusions':True,'fontVariableClassChange':{'old':oldClass,'fresh':newClass}},'focusedFresh':{'path':str(R/'fresh-normal-paint/evidence.json'),'sha256':sha(R/'fresh-normal-paint/evidence.json'),'actualGroups':4,'actualTargets':67,'closedTargets':54,'matchedEligibleCaptureNodes':len(samples),'comparisons':samples,'outerBoundsDeltas':outerDeltas,'boundsPolicy':'Only MAIN/BODY/HTML overall estimated boxes strictly above nearest opaque glyph surface are excluded from numeric compositing, with explicit plain paint checks. No target/opaque surface/menu geometry or effects are discarded.'},'counts':dict(counts),'cvSkippedTargets':[list(t)for t in sorted(skipped)],'pendingRows':[r['testId']for r in rows if r['status']=='PENDING_FRESH_CV_ACTIVATION'],'nonFormulaDiagnosticDifferenceRows':hoverRows,'next':'After Root releases exclusive performance: scroll-activate HomeCTA at375/1440/menu, record CVvisibility, glyph/opaque paint/effects/geometry and PNGs; Pages may supply same-source/output evidence. No browser before release.','scope':'Target-specific contrast only; original Exit1/384incomplete preserved. No384-formula recalculation. Not fullWCAG/humanAT.','rows':rows}
(R/'normal-contrast-correspondence.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
(R/'normal-contrast-correspondence.md').write_text('''# R01 normal fresh 對比：375 已橋接，9 待 CV 啟用

375／384 可作限定 fresh paint/source 對照，9 rows 保留 PENDING_FRESH_CV_ACTIVATION。原正式531／245 layouts／119axe／0violations／384incomplete／真Exit1與八項business FAIL不回寫。

原已證公式只在本輪glyph paint／threshold／opaque surface等實際輸入對應後引用，未重算384。唯一生成字體metadata變化為Noto root variable class U63m2q→Obekhq。source proof顯示globals除精確CV與source-exclusions新增外其餘paint bytes不變。六個Portfolio rows的related-gradient大範圍診斷點碰到不同link hover底色：各三點在被測glyph box之外，own-target paint／geometry／hit不變；這些非公式輸入的差異逐點保留，沒有假稱整份computed資料字面相同。

四組fresh小型補採驗三菜單closed/open、About conic及Home radial/grid。對已繪製的sample，除最近opaque surface外MAIN／BODY／HTML整體估高另記，glyph／opaque-surface／menu幾何與effects仍精確對照。

九項pending為HomeCTA三個targets（eyebrow、#contact-title、.max-w-2xl），在375 default／375 menu／1440 default。Fresh probe實際見content-visibility:auto skipped，不能只靠computed color相同判已繪製PASS。Root normal已停，全部browser關閉；獨占perf後再以Pages同source/output bridge，僅捲入HomeCTA的375／1440及menu狀態補visibility／paint／geometry／PNG即可，不跑axe/fullsuite。

逐row原testID、fresh JSON pointer、公式引用、六項診斷差異與九項pending在normal-contrast-correspondence.json。normal-projection-command.json與fresh-normal-paint-command.json皆為限定證據程序Exit0，不代表正式suite或完整WCAG／真人AT通過。
''')
for rel in ['normal-contrast-projection.json','fresh-normal-paint/evidence.json','normal-contrast-correspondence.json']:
 p=R/rel;Path(str(p)+'.gz').write_bytes(gzip.compress(p.read_bytes(),mtime=0))
print(json.dumps({'status':report['status'],'counts':dict(counts),'pendingRows':report['pendingRows'],'nonFormulaDiagnosticRows':hoverRows,'matchedEligibleCaptureNodes':len(samples)},ensure_ascii=False))
