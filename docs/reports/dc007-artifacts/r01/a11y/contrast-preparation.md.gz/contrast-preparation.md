# DC007-R01：fresh 對比證據準備

**僅準備，尚未判 R01 PASS。** 正式 normal 531 suite 仍在跑，準備時 axe records 為 0；不取整份持續變動 raw 的 SHA 作 freeze，也不假設新的 incomplete 一定仍是 384。

已核對 before／after source：globals.css 僅六條精確 source exclusions 與一段 screen-only `content-visibility:auto`／`contain-intrinsic-block-size`；刪除這些明列新增後，其餘 CSS bytes 與舊正式基準相同。Heritage／Luxury Home 只加 Boolean `data-deferred-sections`；其餘 component bytes 相同。native font core／preload 的字體實際載入與幾何仍以本輪 fresh 資料為準，不能拿這份 source 差異當新測試通過。

最小流程：

1. 119 筆正式 AXE 記錄與其 test records 均完成後，用 `project-r01-contrast.py` 固定獨立投影；target 數量及新增／移除 identity 以新資料為準。
2. 逐 `(route,width,state,target)` 對應舊 row，核 fresh text／threshold／foreground-alpha／font size-weight／實際 opaque ancestor／gradient-grid-mask／opacity-filter-blend-pseudo。只有實際計算輸入與 source paint projection 一致才沿用已證公式，不重算同一公式；不是因「來源沒有改色票」就繼承 PASS。
3. 將 root document 高度／CV estimated geometry 與 paint signature 分開，但不直接忽略 CV：目標需確實處於已繪製狀態。若 skipped／0 box／新增 containment 或座標使遮擋不同，只在主 QA 結束後補該 target/state，必要時實際捲入與兩個 animation frames，再記 actual paint／visible geometry。選單 overlap 一律使用本輪 panel opacity／bounds／shadow／9 點 hit，不套舊覆蓋率。
4. 若 formal manualStyles 未包含完整 effects／pseudo／CV 可見性，source 差異可支撐原有漆層不變，但新增 render gate 仍需最小 focused probe。優先僅三個選單 closed/open＋有差異的 representative paint stratum，無須重跑 axe 或 31-state 整套捕捉。
5. 完整 suite 結束後重新投影比對及記最終 raw SHA。保留原 exit／incomplete；數學條件未滿足則 MANUAL_PENDING，真實不達標才記 FAIL，範圍不等於完整 WCAG／真人 AT。

投影準備 CLI（由 Root 選正式收據執行時機）：

```sh
python /tmp/xk-dc007-r01/a11y/project-r01-contrast.py --input /tmp/xk-dc007-r01/qa/normal-native-cv-final/result.json --output /tmp/xk-dc007-r01/a11y/normal-contrast-projection.json
```

後續 47 張 fresh 圖可逐張支援視覺覆核；CV 讓畫面延遲繪製，須核實圖中內容確實出現，不能只數檔名、沿用舊圖或把估算留白當內容。當前未開 browser、未改 repo／舊 raw，未產生 R01 對比 PASS。
