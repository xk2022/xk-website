# R01 Pages：384 個原 contrast incomplete 的限定對照

完成119筆正式axe後固定投影。Pages仍為0 violations／384 incomplete；本文件不把它們改為0，也不解除主suite的network／其他失敗。

384筆formal computed輸入，在獨立清冊驗證的27個站內合法網址尾斜線及20個selector suffix映射後，與Normal逐項完全相同，無其他computed差異。沿用原Normal已證對比公式，不重算384份數學。最終source9d18固定；Normal first-source be6到final9d18的限定334檔不變／3檔Quotation邊界另有逐byte證明。

fresh實際補採只做3個mobile menu closed/open×10targets、HomeCTA3targets×375預設／1440預設／375展開menu三種狀態。30對menu底下字元的actual opaque coverage皆1、9點皆topmost panel，closed paint與Normal精確相同；9個CTA實際scroll啟用CV、visible與viewport intersection皆true，前景／ancestor／pseudo／gradient及最近opaque面局部幾何相同，9點皆target在最上層。CTA捲動後header／menu在viewport外，未宣稱menu仍同時可見；原保守shadow bound包括0。全部9張實際PNG已逐張開圖觀察。

分類為345項formal-input/source橋接、30項fresh opaque-menu及closed-paint、9項freshCVactivation，共384項；0未知。限定collector與bridge各有真OS Exit0，9PNG／3份fresh Pages CSS／JSON／SHA保留。只記錄Pages實際編譯CSS，未捏造未封存Normal bundle的逐byte一致。

主要證據：pages-contrast-projection.json、pages-correspondence-diagnostic.json、fresh-pages-retained-paint-v1/evidence.json、pages-contrast-final.json、pages-contrast-visual-review.json。最初診斷工具誤讀repository catalog為49route fixture的KeyError／Exit1保留；v2改讀已固定fixture且驗SHA，真Exit0，沒有更動App或放寬computed／contrast規則。

正式Pagesraw仍須完成後以project-r01-contrast.py --compare銜接最終整檔SHA／真OSexit；該projection identity只是證據銜接，不是網路、整套browser、fullWCAG、真人讀屏或完整release acceptance。全部focused browser已關閉。

正式原件完成後補記：531／245 layouts／119axe／39business／96directions／3print／47raw圖，530PASS＋1strict-network FAIL，真Exit1；0violations／384incomplete不變。final projection --compare 真Exit0，固定投影SHA `897c397221e0ee80185c6fae2586534737fc1d9c7aa4f04b72b0c281ba01c6de`，最終rawSHA `bc9e801d8ae4061f44ca8a89805f9a55f25fe3a55376e6e02e37a3efac53fa7d`。pages-contrast-closure.json補逐target正式TestID／axe pointer與最後回執，限定contrast成立，不解除74筆原network error records或整套FAIL。
