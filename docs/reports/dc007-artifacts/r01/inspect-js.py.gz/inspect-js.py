import json,pathlib,re,gzip,hashlib,statistics,urllib.parse
from html.parser import HTMLParser
repo=pathlib.Path('/workspace/xk-website');root=pathlib.Path('/tmp/xk-dc007-r01');perf=pathlib.Path('/tmp/xk-dc007/performance');site=pathlib.Path('/tmp/xk-dc007-build/out');nxt=pathlib.Path('/tmp/xk-dc007-build/.next/server/app')
hash=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
source=json.loads(pathlib.Path('/tmp/xk-dc007/source.json').read_text());files=[r for r in source['files'] if r['path'].startswith(('src/','public/')) or r['path'] in ['package.json','package-lock.json','next.config.ts']];mismatch=[{'path':r['path'],'expected':r['sha256'],'actual':hash(repo/r['path']) if (repo/r['path']).exists() else None} for r in files if not (repo/r['path']).exists() or hash(repo/r['path'])!=r['sha256']]
class P(HTMLParser):
 def __init__(self):super().__init__();self.scripts=[];self.prefetch=[];self.links=0
 def handle_starttag(self,t,a):
  a=dict(a)
  if t=='script' and a.get('src'):self.scripts.append(a['src'])
  if t=='a' and a.get('href','').startswith('/'):self.links+=1
  if t=='link' and a.get('rel') in ['preload','modulepreload','prefetch']:self.prefetch.append(a)
route_specs=[('modern-home','/','(modern)/page'),('modern-contact','/contact','(modern)/contact/page'),('modern-quotation','/quotation','(modern)/quotation/page'),('heritage-home','/design-collection/heritage','(collection)/design-collection/[style]/page'),('luxury-home','/design-collection/luxury','(collection)/design-collection/[style]/page'),('heritage-contact','/design-collection/heritage/contact','(collection)/design-collection/[style]/contact/page'),('luxury-contact','/design-collection/luxury/contact','(collection)/design-collection/[style]/contact/page'),('heritage-quotation','/design-collection/heritage/quotation','(collection)/design-collection/[style]/quotation/page'),('luxury-quotation','/design-collection/luxury/quotation','(collection)/design-collection/[style]/quotation/page')]
routes=[]
for name,url,manifest_name in route_specs:
 html=site/url.lstrip('/')/'index.html';p=P();p.feed(html.read_text());scripts=[]
 for src in dict.fromkeys(p.scripts):
  f=site/src.lstrip('/');scripts.append({'path':src,'bytes':f.stat().st_size,'gzip6Bytes':len(gzip.compress(f.read_bytes(),compresslevel=6,mtime=0)),'sha256':hash(f)})
 mf=nxt/(manifest_name+'_client-reference-manifest.js');text=mf.read_text();m=json.loads(text.split(' = ',2)[-1].strip().rstrip(';'));own={k:v for k,v in m['clientModules'].items() if '/src/' in k and not k.endswith('.css')}
 routes.append({'name':name,'path':url,'htmlBytes':html.stat().st_size,'htmlGzip6Bytes':len(gzip.compress(html.read_bytes(),compresslevel=6,mtime=0)),'scripts':scripts,'scriptBytes':sum(r['bytes'] for r in scripts),'scriptGzip6Bytes':sum(r['gzip6Bytes'] for r in scripts),'initialScriptCount':len(scripts),'clientModules':own,'internalLinkCount':p.links,'manifest':str(mf),'manifestSha256':hash(mf)})
reports=[]
for p in sorted((perf/'cold').glob('*.report.json')):
 x=json.loads(p.read_text());a=x['audits'];net=a['network-requests']['details']['items'];categories=a['mainthread-work-breakdown']['details']['items'];boot=a['bootup-time']['details'].get('items',[])
 reports.append({'run':p.stem.replace('.report',''),'path':str(p),'sha256':hash(p),'lcpMs':a['largest-contentful-paint']['numericValue'],'tbtMs':a['total-blocking-time']['numericValue'],'mainThread':categories,'bootup':boot,'network':{'scripts':[{'path':urllib.parse.urlsplit(r['url']).path,'transfer':r['transferSize'],'resourceBytes':r['resourceSize']} for r in net if r.get('resourceType')=='Script'],'allTransfer':sum(r['transferSize'] for r in net),'fontTransfer':sum(r['transferSize'] for r in net if r.get('resourceType')=='Font'),'scriptTransfer':sum(r['transferSize'] for r in net if r.get('resourceType')=='Script'),'allRequests':len(net),'foreignOrigins':sorted({urllib.parse.urlsplit(r['url']).netloc for r in net if urllib.parse.urlsplit(r['url']).netloc not in ['127.0.0.1:3281','']})},'unusedJS':a.get('unused-javascript',{}).get('details',{}).get('items',[])})
chunks=[]
for p in sorted((site/'_next/static/chunks').glob('*.js')):
 t=p.read_text();marks={k:mark in t for k,mark in {'contact':'contact-inquiry-name','quotation':'quotation-build-','switcher':'data-design-switcher-target','heritage-menu':'htg-mobile-navigation','luxury-menu':'lx-mobile-menu','modern-menu':'開啟導覽','react-dom':'react-dom-client','next-router':'next-router-prefetch'}.items()};chunks.append({'path':p.name,'bytes':p.stat().st_size,'gzip6Bytes':len(gzip.compress(p.read_bytes(),compresslevel=6,mtime=0)),'sha256':hash(p),'stringSignatures':marks})
out={'scope':'READ_ONLY source/output/previous actual traces; no builds/server/browser/Git/network. Chunk signatures indicate code presence, not callstack attribution. Manifest chunks lists are transitive prerequisites, not duplicate file copies.','expectedHeadProvidedByRoot':'3b2eb50','sourceBridge':{'baselineManifest':'/tmp/xk-dc007/source.json','checkedFiles':len(files),'mismatches':mismatch},'routes':routes,'chunks':chunks,'coldReports':reports};p=root/'js-evidence.json';p.write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n');print('source',len(files),'mismatch',len(mismatch));print('routes',[(r['name'],r['initialScriptCount'],r['scriptGzip6Bytes'],[k.split('/src/')[-1] for k in r['clientModules']]) for r in routes]);print('signatures',[(c['path'],c['bytes'],[k for k,v in c['stringSignatures'].items() if v]) for c in chunks]);print('reports',len(reports));
for label in ['modern-home','modern-quotation','heritage-home','heritage-quotation','luxury-home','luxury-quotation']:
 r=[r for r in reports if r['run'].startswith(label)];print(label,'JStransfer',r[0]['network']['scriptTransfer'],'fonts',r[0]['network']['fontTransfer'],'threadmedians',[(g['group'],round(statistics.median(next((v['duration'] for v in q['mainThread'] if v['group']==g['group']),0) for q in r),1)) for g in r[0]['mainThread']])
