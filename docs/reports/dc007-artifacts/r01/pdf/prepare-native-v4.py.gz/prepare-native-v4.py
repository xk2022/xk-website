from pathlib import Path
import shutil,hashlib,json,difflib,datetime,subprocess
r=Path('/tmp/xk-dc007-r01/pdf');sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();old=r/'collect.cjs';new=r/'collect-native-v4.cjs';helperSource=Path('/tmp/xk-dc007-r01/qa/font-native-readiness-v4.cjs');helper=r/'font-native-readiness-v4.cjs';assert not new.exists()and not helper.exists();assert sha(old)=='26c53aa4152be2e6fe8fdf87c177ad1f13154703798f38c8fa0252346cadada3';shutil.copyfile(helperSource,helper);assert sha(helper)==sha(helperSource)
s=old.read_text()
def rep(a,b):
 global s
 assert s.count(a)==1,(a,s.count(a));s=s.replace(a,b)
rep("path.join(__dirname,'font-readiness.cjs')","path.join(__dirname,'font-native-readiness-v4.cjs')")
rep("version:'R01-v1'","version:'R01-native-v4'")
rep("fontReadinessPolicy:'Before initial selection, print DOM and final PDF collection, wait for actual html dataset.fontLoading ready|native|native-print, then document.fonts.ready. Record completion state and family without changing application fonts, storage, prices or print CSS. Early-print failure/fallback is separately covered by the BrowserFont supplement; this is stabilized-font PDF acceptance only.'", "fontReadinessPolicy:'Native CSS font strategy only. Before initial selection, print DOM and final PDF collection, await document.fonts.ready, two render frames, then document.fonts.ready using the matching release QA helper. No data-font-loading/controller/source-font variable requirement. Record native status/root and paper family without changing fonts, storage, prices or print CSS. BrowserFont supplement owns early-print checks; these are stabilized-font PDFs.'")
rep('fontLoading:document.documentElement.dataset.fontLoading,','')
rep("sourceTCFamily:root.getPropertyValue('--font-noto-sans-tc-source').trim(),",'')
assert 'dataset.fontLoading'not in s and "getPropertyValue('--font-noto-sans-tc-source')"not in s
new.write_text(s);diff=''.join(difflib.unified_diff(old.read_text().splitlines(True),s.splitlines(True),fromfile=str(old),tofile=str(new)));dp=r/'collect-candidate-to-native-v4.diff';dp.write_text(diff)
checks=[];logs=[]
for cmd in [['node','--check',str(new)],['node',str(new),'--preflight']]:
 start=datetime.datetime.now(datetime.timezone.utc).isoformat();p=subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True);checks.append({'command':cmd,'startedAt':start,'finishedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exitCode':p.returncode,'observation':'Actual subprocess.run child completion'});logs.append(p.stdout);assert p.returncode==0
log=r/'native-v4-preflight.log';log.write_text('\n'.join(logs));cp=r/'native-v4-preflight.json';cp.write_text(json.dumps({'testId':'DC007-R01-NATIVE-V4-PDF-TOOL-PREFLIGHT','status':'PASS','scope':'Only syntax/dependencies. No browser/render/PDF collection or glyph proof executed.','checks':checks,'log':str(log),'logSha256':sha(log)},indent=2)+'\n')
copyEvidence=[]
for name in ['verify-pdf.py','verify-batch.py']:
 a=Path('/tmp/xk-dc007/pdf')/name;b=r/name;assert sha(a)==sha(b);copyEvidence.append({'original':str(a),'copy':str(b),'sameSHA256':sha(a),'unchanged':True})
for name in ['monitor.cjs','neutral-query-contract-v5.cjs']:
 a=Path('/tmp/xk-dc007-r01/qa')/name;b=r/name;assert sha(a)==sha(b);copyEvidence.append({'original':str(a),'copy':str(b),'sameSHA256':sha(a),'unchanged':True})
ev=lambda p:{'path':str(p),'sha256':sha(p)}
prov={'testId':'DC007-R01-NATIVE-V4-PDF-PROVENANCE','createdAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'PENDING','preparationResult':'PASS','strategy':'Pure native CSS variable font Core plus complementary original subsets; no new FontLoadingController or font-loading dataset. Final strategy adoption/source/artifact still owned by Root.','collector':ev(new),'unchangedCandidateCollector':ev(old),'unchangedCandidateProvenance':ev(r/'provenance.json'),'diff':ev(dp),'readinessHelper':{'source':ev(helperSource),'localCopy':ev(helper),'byteIdentical':True,'sequence':'document.fonts.ready ->2requestAnimationFrame ->document.fonts.ready; assert FontFaceSet status loaded'},'samePhysicalAndMonitorTools':copyEvidence,'currentReadOnlySource':[ev(Path('/workspace/xk-website/src/app/layout.tsx')),ev(Path('/workspace/xk-website/src/app/fonts/noto-sans-tc.css'))],'candidateAssetManifest':ev(Path('/tmp/xk-dc007-r01/font-assets/candidate-v4/manifest.json')),'preflight':ev(cp),'preservedScope':'Same8 actualPDFs:3styles17SHOP40/60+ModernAPPfrom per mode; unchanged source-freeze guard, exact original Logo/twoQR, page.pdf preferCSSPageSize/printBackground, strict0.1pt full content boundaries and only original exact3whitecanvas signature. No pricing/print/DOM/state changes to pass.','versionBoundary':['Original candidate collector/provenance kept verbatim, although candidate strategy was not adopted; its prepared readiness contract is not used by this native collector.','Original pilots/source/raw and pre-R01 PDF/FAIL evidence stay unchanged.','Nativepilot, formal Normal/Pages captures, physical8PDF checks and manual8render/font/paper comparisons remain PENDING.','No browser, renderer, glyph proof, build or server started by this preparation; Root heavy glyphproof/performance windows remain exclusive.','Root must supply actual final source-after/fixture/catalog and formal scheduling; source-before is never accepted for optimized candidate proof.']}
(r/'provenance-native-v4.json').write_text(json.dumps(prov,ensure_ascii=False,indent=2)+'\n')
cli=(r/'CLI.txt').read_text().replace('DC007-R01 PDF acceptance','DC007-R01 native-v4 PDF acceptance').replace('/pdf/collect.cjs','/pdf/collect-native-v4.cjs')
for mode in ['normal','pages']:
 cli=cli.replace(mode+'-capture-v1',mode+'-native-v4-capture').replace(mode+'-physical-v1',mode+'-native-v4-physical').replace(mode+'-v1',mode+'-native-v4')
cli=cli.replace('Completed native/native-print datasets','Native FontFaceSet completion').replace('Early native-print/noJS/fallback cases','Early-print/noJS/fallback cases')
(r/'CLI-native-v4.txt').write_text(cli)
print(json.dumps({'collector':ev(new),'helper':ev(helper),'provenance':ev(r/'provenance-native-v4.json'),'preflight':'PASS','acceptance':'PENDING','browserLaunched':False}))
