'use strict';
const assert=require('node:assert/strict');
module.exports=async function fontReadiness(page,label='font readiness'){
 const startedAt=new Date().toISOString(),start=Date.now();
 await page.waitForFunction(()=>['ready','native','native-print'].includes(document.documentElement.dataset.fontLoading),null,{timeout:45000});
 let timer;try{await Promise.race([page.evaluate(()=>document.fonts.ready),new Promise((_,reject)=>timer=setTimeout(()=>reject(new Error(label+': document.fonts.ready exceeded30000ms')),30000))]);}finally{clearTimeout(timer);}
 const actual=await page.evaluate(()=>{const r=document.documentElement,s=getComputedStyle(r);return{url:location.href,state:r.dataset.fontLoading,fontStatus:document.fonts.status,activeFamily:s.getPropertyValue('--font-noto-sans-tc').trim(),sourceFamily:s.getPropertyValue('--font-noto-sans-tc-source').trim(),faceCount:document.fonts.size};});
 assert(['ready','native','native-print'].includes(actual.state),label+': invalid completed font state');assert.equal(actual.fontStatus,'loaded',label+': font set not loaded after ready');
 return{label,startedAt,finishedAt:new Date().toISOString(),elapsedMs:Date.now()-start,...actual};
};
