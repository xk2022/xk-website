from pathlib import Path
import subprocess,json,sys
r=Path('/workspace/xk-website');d=Path('/tmp/xk-dc007-r01/quality');d.mkdir(exist_ok=True)
commands=[('npm-ci',['npm','ci','--cache','/tmp/xk-npm-cache']),('typegen',['npx','next','typegen']),('typescript',['npx','tsc','--noEmit']),('lint',['npm','run','lint']),('unit',['npm','test']),('normal-build',['npm','run','build'])]
rows=[]
for key,cmd in commands:
 receipt=d/(key+'.json');log=d/(key+'.log')
 code=subprocess.run(['python3','scripts/run-with-evidence.py','--receipt',str(receipt),'--log',str(log),'--timeout','600','--',*cmd],cwd=r).returncode
 rows.append({'testId':key,'command':cmd,'exitCode':code,'receipt':str(receipt),'log':str(log)})
 (d/'summary.json').write_text(json.dumps({'status':'FAIL' if any(x['exitCode'] for x in rows) else 'PASS','checks':rows},indent=2)+'\n')
 print(json.dumps(rows[-1]),flush=True)
 if code:sys.exit(code)
