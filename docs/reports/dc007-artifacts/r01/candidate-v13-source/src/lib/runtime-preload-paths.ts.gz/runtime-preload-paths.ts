/** Only public, current-build JavaScript entries may become resource hints. */
export function runtimePreloadPaths(manifest: unknown): string[] {
  if (!manifest || typeof manifest !== "object" || !("rootMainFiles" in manifest)
    || !Array.isArray(manifest.rootMainFiles)) return [];
  // Next 16.4.6 already hints entry 0 (required-scripts.js bootstrapScript).
  return [...new Set(manifest.rootMainFiles.slice(1).filter((path): path is string =>
    typeof path === "string" && /^static\/chunks\/[a-zA-Z0-9._-]+\.js$/.test(path)
    && !path.includes("..")))].map((path) => `/_next/${path}`);
}
