import { readFileSync } from "node:fs";
import { join } from "node:path";

import { runtimePreloadPaths } from "./runtime-preload-paths";

/** Read after compilation, during prerender; never hardcode hashed chunk names. */
export function getRuntimePreloads(): string[] {
  try {
    const manifest: unknown = JSON.parse(readFileSync(join(process.cwd(), ".next/build-manifest.json"), "utf8"));
    return runtimePreloadPaths(manifest);
  } catch {
    // The manifest can be absent while the development compiler is starting.
    return [];
  }
}
