import assert from "node:assert/strict";
import test from "node:test";

import { runtimePreloadPaths } from "../src/lib/runtime-preload-paths.ts";
import { prioritizeRuntimeHtml } from "./lib/runtime-priority.mjs";

test("PRELOAD-01 malformed or absent root runtime lists produce no hints", () => {
  for (const value of [undefined, null, false, 0, "manifest", [], {}, { rootMainFiles: null }, { rootMainFiles: "static/chunks/a.js" }, { rootMainFiles: {} }]) {
    assert.deepEqual(runtimePreloadPaths(value), []);
  }
  assert.deepEqual(runtimePreloadPaths({ rootMainFiles: [] }), []);
});

test("PRELOAD-02 the first bootstrap entry remains Next-owned while later runtime entries receive hints", () => {
  assert.deepEqual(runtimePreloadPaths({ rootMainFiles: [
    "static/chunks/bootstrap.js", "static/chunks/runtime.js", "static/chunks/react-dom.js",
    "static/chunks/app-router.js", "static/chunks/framework.js",
  ] }), [
    "/_next/static/chunks/runtime.js", "/_next/static/chunks/react-dom.js",
    "/_next/static/chunks/app-router.js", "/_next/static/chunks/framework.js",
  ]);
  assert.deepEqual(runtimePreloadPaths({ rootMainFiles: ["static/chunks/bootstrap.js"] }), []);
});

test("PRELOAD-03 only public flat JavaScript chunk paths are accepted", () => {
  assert.deepEqual(runtimePreloadPaths({ rootMainFiles: ["bootstrap", "static/chunks/A1_b-2.c.js"] }), ["/_next/static/chunks/A1_b-2.c.js"]);
});

test("PRELOAD-04 traversal, nested paths, URLs, queries and non-JavaScript files never become hints", () => {
  const invalid = [
    "../static/chunks/a.js", "static/chunks/../a.js", "static/chunks/a..js",
    "static/chunks/nested/a.js", "static\\chunks\\a.js", "static/chunks/%2e%2e.js",
    "/static/chunks/a.js", "/_next/static/chunks/a.js", "https://example.com/a.js",
    "//example.com/a.js", "static/chunks/a.js?x=1", "static/chunks/a.js#x",
    "static/css/a.css", "static/chunks/a.mjs", "static/chunks/a.JS", "static/chunks/a js",
  ];
  assert.deepEqual(runtimePreloadPaths({ rootMainFiles: ["bootstrap", ...invalid] }), []);
});

test("PRELOAD-05 mixed entries are filtered and duplicate accepted paths preserve first-seen order", () => {
  assert.deepEqual(runtimePreloadPaths({ rootMainFiles: [
    "bootstrap", null, 12, false, {}, ["static/chunks/array.js"],
    "static/chunks/b.js", "static/chunks/a.js", "static/chunks/b.js", "static/chunks/a.js",
  ] }), ["/_next/static/chunks/b.js", "/_next/static/chunks/a.js"]);
});

test("PRELOAD-06 polyfill, page and other manifest fields are not added to the root runtime hints", () => {
  const fields = {
    polyfillFiles: ["static/chunks/polyfill.js"],
    lowPriorityFiles: ["static/chunks/low.js"],
    pages: { "/": ["static/chunks/page.js"] },
    rootMainFilesTree: { "/": ["static/chunks/tree.js"] },
  };
  assert.deepEqual(runtimePreloadPaths(fields), []);
  assert.deepEqual(runtimePreloadPaths({ ...fields, rootMainFiles: ["static/chunks/bootstrap.js", "static/chunks/runtime.js"] }), ["/_next/static/chunks/runtime.js"]);
});

test("PRELOAD-07 a frozen manifest and its arrays remain unchanged", () => {
  const entries = Object.freeze(["static/chunks/bootstrap.js", "static/chunks/a.js", "static/chunks/a.js"]);
  const manifest = Object.freeze({ rootMainFiles: entries, polyfillFiles: Object.freeze(["static/chunks/polyfill.js"]) });
  const before = JSON.stringify(manifest);
  assert.deepEqual(runtimePreloadPaths(manifest), ["/_next/static/chunks/a.js"]);
  assert.equal(JSON.stringify(manifest), before);
  assert.equal(manifest.rootMainFiles, entries);
});

test("PRELOAD-08 skipping position zero does not accidentally drop the first valid later entry", () => {
  assert.deepEqual(runtimePreloadPaths({ rootMainFiles: [null, "static/chunks/a.js"] }), ["/_next/static/chunks/a.js"]);
  assert.deepEqual(runtimePreloadPaths({ rootMainFiles: ["invalid", "static/chunks/a.js", "static/chunks/b.js"] }), ["/_next/static/chunks/a.js", "/_next/static/chunks/b.js"]);
});

test("PRELOAD-09 returned arrays are independent and caller changes cannot alter later results", () => {
  const manifest = { rootMainFiles: ["bootstrap", "static/chunks/a.js"] };
  const first = runtimePreloadPaths(manifest);
  first.push("/unrelated.js");
  assert.deepEqual(runtimePreloadPaths(manifest), ["/_next/static/chunks/a.js"]);
  assert.deepEqual(manifest.rootMainFiles, ["bootstrap", "static/chunks/a.js"]);
});

const runtimePaths = ["/_next/static/chunks/runtime.js", "/_next/static/chunks/react-dom.js"];
const runtimeHints = runtimePaths.map((href) => `<link rel="preload" as="script" href="${href}" fetchpriority="high"/>`);
const scriptTags = (html) => [...html.matchAll(/<script\b[^>]*>/g)].map((match) => match[0]);
const withoutPriority = (tag) => tag.replace(/\sfetchpriority="[^"]*"/gi, "");
const resourceUrls = (html) => [...html.matchAll(/\b(?:src|href)="([^"]*)"/g)].map((match) => match[1]).sort();

test("PRIORITY-01 only the same async runtime scripts gain priority; URLs, execution order and other attributes stay exact", () => {
  const html = `<html><head><script src="/_next/static/chunks/bootstrap.js" async="" nonce="one"></script><script src="${runtimePaths[0]}" async="" nonce="two" integrity="sha256-fixed" crossorigin="anonymous" fetchpriority="low"></script><script src="${runtimePaths[1]}" async="" nonce="three"></script>${runtimeHints.join("")}</head><body>unchanged</body></html>`;
  const result = prioritizeRuntimeHtml(html, runtimePaths);
  const before = scriptTags(html), after = scriptTags(result.html);
  assert.equal(result.scripts, 2);
  assert.equal(result.changed, true);
  assert.deepEqual(after.map(withoutPriority), before.map(withoutPriority));
  assert.equal(after[0], before[0]);
  assert(after.slice(1).every((tag) => tag.includes('fetchpriority="high"')));
});

test("PRIORITY-02 existing trusted hints keep their own order and precede the first external script", () => {
  const html = `<html><head><meta name="x" content="y"/><script src="/_next/static/chunks/bootstrap.js" async=""></script><title>Page</title>${runtimeHints.join("")}</head><body></body></html>`;
  const result = prioritizeRuntimeHtml(html, runtimePaths);
  assert.equal(result.hints, 2);
  assert(result.html.indexOf(runtimeHints[0]) < result.html.indexOf(runtimeHints[1]));
  assert(result.html.indexOf(runtimeHints[1]) < result.html.indexOf('<script src='));
  assert.equal(runtimeHints.filter((hint) => result.html.includes(hint)).length, 2);
});

test("PRIORITY-03 font/meta/body, non-target scripts, synchronous scripts and nomodule stay intact", () => {
  const font = '<link rel="preload" as="font" href="/_next/static/media/font.woff2" crossorigin="anonymous"/>';
  const meta = '<meta name="description" content="完整靜態內容"/>';
  const untouched = ['<script src="/other.js" async="" nonce="keep"></script>', `<script src="${runtimePaths[0]}" nomodule="" async=""></script>`, `<script src="${runtimePaths[1]}" nonce="sync"></script>`];
  const body = '<body><h1>Visible heading</h1><!--$--><main>完整文案</main><!--/$--><script nonce="body">self.__next_f.push([1,"payload"])</script></body>';
  const html = `<html><head>${meta}${font}${untouched.join("")}${runtimeHints.join("")}</head>${body}</html>`;
  const result = prioritizeRuntimeHtml(html, runtimePaths);
  assert.equal(result.scripts, 0);
  assert(result.html.includes(font) && result.html.includes(meta));
  untouched.forEach((tag) => assert(result.html.includes(tag)));
  assert.equal(result.html.slice(result.html.indexOf("<body>")), `${body}</html>`);
});

test("PRIORITY-04 processing the same document twice is byte-idempotent", () => {
  const html = `<html><head><script src="${runtimePaths[0]}" async=""></script>${runtimeHints[0]}</head><body>same</body></html>`;
  const first = prioritizeRuntimeHtml(html, runtimePaths);
  const second = prioritizeRuntimeHtml(first.html, runtimePaths);
  assert.equal(second.html, first.html);
  assert.equal(second.changed, false);
  assert.equal(second.scripts, 0);
});

test("PRIORITY-05 missing head, missing closing head or no external scripts returns the exact original document", () => {
  for (const html of ['<html><body>no head</body></html>', '<html><head>unfinished<body>same</body></html>', `<html><head>${runtimeHints.join("")}</head><body>no scripts</body></html>`, `<html><head><script>console.log("existing inline")</script>${runtimeHints[0]}</head><body>same</body></html>`]) {
    assert.deepEqual(prioritizeRuntimeHtml(html, runtimePaths), { html, changed: false, hints: 0, scripts: 0 });
  }
});

test("PRIORITY-06 no new executable tags or resource URLs are introduced, including unused target paths", () => {
  const html = `<html><head><script src="${runtimePaths[0]}" async=""></script>${runtimeHints[0]}<link rel="preload" as="script" href="/unrelated.js" fetchpriority="low"/></head><body><script>window.existing=1</script><img src="/image.webp"/></body></html>`;
  const result = prioritizeRuntimeHtml(html, [...runtimePaths, "/does-not-exist.js"]);
  assert.deepEqual(resourceUrls(result.html), resourceUrls(html));
  assert.deepEqual(scriptTags(result.html).map(withoutPriority), scriptTags(html).map(withoutPriority));
  assert(result.html.includes('<script>window.existing=1</script>'));
  assert(!result.html.includes("/does-not-exist.js"));
});
