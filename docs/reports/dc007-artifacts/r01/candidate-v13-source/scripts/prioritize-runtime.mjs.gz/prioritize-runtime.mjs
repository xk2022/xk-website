import { join } from "node:path";

import { prioritizeRuntimeDirectory } from "./lib/runtime-priority.mjs";

console.log(JSON.stringify(prioritizeRuntimeDirectory(process.argv[2] ?? join(process.cwd(), ".next/server/app"))));
