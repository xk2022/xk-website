import { readdirSync, readFileSync, writeFileSync } from "node:fs";
import { join } from "node:path";

import { runtimePreloadPaths } from "../../src/lib/runtime-preload-paths.ts";

const attributes = (tag) => Object.fromEntries([...tag.matchAll(/([\w:-]+)="([^"]*)"/g)].map((match) => [match[1].toLowerCase(), match[2]]));

/** Resource attributes/order only. Script URLs, execution order and body stay intact. */
export function prioritizeRuntimeHtml(html, paths) {
  const start = html.indexOf("<head>");
  const end = html.indexOf("</head>", start);
  if (start < 0 || end < 0) return { html, changed: false, hints: 0, scripts: 0 };
  const targets = new Set(paths);
  let head = html.slice(start, end);
  const hints = [];
  head = head.replace(/<link\b[^>]*>/g, (tag) => {
    const attrs = attributes(tag);
    if (attrs.rel === "preload" && attrs.as === "script" && attrs.fetchpriority === "high" && targets.has(attrs.href)) {
      hints.push(tag);
      return "";
    }
    return tag;
  });
  let scripts = 0;
  head = head.replace(/<script\b[^>]*>/g, (tag) => {
    const attrs = attributes(tag);
    if (!targets.has(attrs.src) || !/\sasync(?:\s|=|>)/.test(tag) || /\snomodule(?:\s|=|>)/.test(tag)) return tag;
    if (attrs.fetchpriority === "high") return tag;
    scripts++;
    return tag.replace(/\sfetchpriority="[^"]*"/gi, "").replace(/>$/, ' fetchpriority="high">');
  });
  const firstScript = head.search(/<script\b[^>]*\ssrc=/);
  if (firstScript < 0) return { html, changed: false, hints: 0, scripts: 0 };
  head = head.slice(0, firstScript) + hints.join("") + head.slice(firstScript);
  const next = html.slice(0, start) + head + html.slice(end);
  return { html: next, changed: next !== html, hints: hints.length, scripts };
}

export function prioritizeRuntimeDirectory(directory, manifestPath = join(process.cwd(), ".next/build-manifest.json")) {
  const paths = runtimePreloadPaths(JSON.parse(readFileSync(manifestPath, "utf8")));
  if (!paths.length) throw new Error("Current build manifest has no eligible runtime entries.");
  const files = [];
  function walk(dir) {
    for (const entry of readdirSync(dir, { withFileTypes: true })) {
      const path = join(dir, entry.name);
      if (entry.isDirectory()) walk(path);
      else if (entry.isFile() && entry.name.endsWith(".html")) files.push(path);
    }
  }
  walk(directory);
  let changed = 0;
  let scripts = 0;
  for (const file of files) {
    const result = prioritizeRuntimeHtml(readFileSync(file, "utf8"), paths);
    if (result.changed) { writeFileSync(file, result.html); changed++; }
    scripts += result.scripts;
  }
  return { directory, files: files.length, changed, scripts, runtimeTargets: paths.length };
}
