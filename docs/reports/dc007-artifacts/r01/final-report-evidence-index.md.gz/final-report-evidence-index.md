# DC-007-R01 最終證據索引（待完成範本）

本索引只定位原始證據，不推導驗收 PASS。最終 source 為 `source-after-v2.json`：337 files，SHA `9d18fdf7aaac71987afaae10aeb969784b0929bdd5d4f8bfd366fc1599f84936`。各測試仍須核對自身 source、固定 profile、樣本數、命令與實際 OS receipt；前一版本不能直接稱為新版本實測。

|階段|原始資料位置（相對 `/tmp/xk-dc007-r01`）|交付時必填|
|---|---|---|
|Fresh before|`before/summary.json`、`before-process.json`|18 樣本實值、6 組 median/range、原 exit 1 與未通過門檻|
|候選與失敗實驗|`pilot-v*/`、`candidate-*-source/`、`source-candidate-*.json`、各 `*-process.json`|保留每次真 FAIL／中斷／不適用；不得選擇性刪除或混作正式 after|
|正式最終 after|`after-v2/summary.json` 與相應 process receipt|6 組 ×3 cold，LCP／CLS／TBT median/range，真 exit，個別 Required gate|
|暖快取與操作|`warm-final-v2/` 與相應 process receipt|6 cases 的 cache/readiness/actions/load/interaction；HEAD 原始旗標與實際已知／未知分開，無 field 資料不聲稱 INP|
|最終品質|`quality-v2/summary.json`、各 JSON receipt/log|npm ci、typegen／tsc、lint、unit、normal build、Pages build 的實際命令／exit|
|一般與 Pages QA|`qa/`、`a11y/`、root 下 `browser-*`／補驗 composite JSON|各模式原結果、工具失敗與完整／定向重驗、source bridge；人工目視與自動 axe 分開|
|PDF／列印|`pdf/`|一般與 Pages capture／physical／manual／comparison，尺寸、QR、字型、PII 與真 receipts|
|字型保真與來源|`font-assets/verified-facts.json`、`glyph-proof-v4.json`、`candidate-v4/`、`reproduction.json`|882×4 ordinary、48 UVS、closure／layout、source license／master pin；目前 Gstatic URL 不冒充舊 bytes 的 exact source|
|被拒字型實驗|`font-assets/range-400-700/`、`font-assets/table-experiments/`|range 完整 FAIL；去子常式不適用；語言 pruning 因效益未證實／保真風險而未執行，raw table bytes 不構成壓縮收益上限|
|遠端準備／CI|`remote/`、`remote-final/`|local artifact 與 actual CI artifact 明分；未取得新 head／run 的欄位保留 PENDING，不沿用 PR45 舊 CI|
|圖檔|repo `docs/screenshots/design-collection/dc007-r01/`|實際清冊、bytes／SHA、人工觀察範圍；封存以 exact repo-reference 去重|
|封存完整性|`archive-r01.py`、`archive-tool-final-preflight.json`、執行後 manifest|Root 停止 writers 後才 execute；raw／encoded SHA、gzip round-trip、canonical source mapping、全格式 dedup、signed URL／secret guard 與選取清冊穩定性|

## 最終結果待填

- 最終冷載、暖快取、兩模式 QA／PDF：**PENDING（以各原始結果及真 receipt 填寫，不預設通過）**。
- 效能門檻維持 LCP ≤2.5s、CLS ≤0.1、TBT ≤200ms；未通過的組別列 FAIL，不能以改善率取代門檻。
- Human AT／實際 screen-reader 與既有未判明 Network gate，依本輪原始證據保持其狀態，不被綠品質檢查取代。
- 純程序 exit 0 僅證明程序完成；suite expected count、assertions、版本與完整標記仍須核對。
- 本輪未核准自動合併／發布；PR／main deployment 證據必須是之後實際發生的事件。
