import json,pathlib,hashlib,datetime,re
from html.parser import HTMLParser
P=pathlib.Path('/tmp/xk-dc007-r01');series=P/'after-v2';summary=json.loads((series/'summary.json').read_text());rows=[];sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for r in summary['runs']:
 report=pathlib.Path(r['report']);d=json.loads(report.read_text());m=d['audits']['metrics']['details']['items'][0];origin=m['observedTimeOriginTs'];fcp=(m['observedFirstContentfulPaintTs']-origin)/1000;tti=(m['interactiveTs']-origin)/1000;trace=report.parent/report.name.replace('.report.json','-0.trace.json');es=json.loads(trace.read_text())['traceEvents'];nav=next(e for e in es if e['name']=='navigationStart'and e.get('args',{}).get('data',{}).get('documentLoaderURL')=='http://127.0.0.1:3281'+r['route']);events=sorted([e for e in es if e.get('pid')==nav['pid']and e.get('tid')==nav['tid']],key=lambda e:e['ts']);tasks=[]
 for e in events:
  if e['name']not in {'RunTask','ThreadControllerImpl::RunTask','ThreadControllerImpl::DoWork','TaskQueueManager::ProcessTaskFromWorkQueue'}or not e.get('dur'):continue
  start=(e['ts']-origin)/1000;end=(e['ts']+e['dur']-origin)/1000
  if tasks and start<tasks[-1]['endMs']:tasks[-1]['endMs']=start-.001
  tasks.append({'startMs':start,'endMs':end,'durationMs':e['dur']/1000})
 fonts=[{'timeMs':(e['ts']-origin)/1000,'url':e['args'].get('url'),'fontName':e['args'].get('name')}for e in events if e['name']=='RemoteFontLoaded'];layouts=[{'startMs':(e['ts']-origin)/1000,'durationMs':e.get('dur',0)/1000,'beginData':e['args'].get('beginData'),'endData':e['args'].get('endData')}for e in events if e['name']=='Layout'and e.get('args',{}).get('beginData',{}).get('frame')==nav['args']['frame']];debug=d['audits']['long-tasks']['details']['debugData'];contributing=[]
 for t in tasks:
  impact=max(0,min(t['endMs'],tti)-max(t['startMs'],fcp)-50)
  if impact<=0:continue
  nearest=min(debug['tasks'],key=lambda q:abs(q['startTime']-t['startMs']));assert abs(nearest['startTime']-t['startMs'])<.2
  t.update(fcpClippedBlockingMs=impact,url=debug['urls'][nearest['urlIndex']],approxAuditCategoryMs={k:v for k,v in nearest.items()if k not in {'startTime','duration','urlIndex'}},layouts=[q for q in layouts if t['startMs']<=q['startMs']<t['endMs']]);contributing.append(t)
 total=sum(t['fcpClippedBlockingMs']for t in contributing);assert abs(total-d['audits']['total-blocking-time']['numericValue'])<.002
 rows.append({'run':r['testId'],'metrics':r['metrics'],'fcpMs':fcp,'ttiMs':tti,'recomputedFcpTtiClippedTbtMs':total,'reportedTbtMs':d['audits']['total-blocking-time']['numericValue'],'exactReconciliationToleranceMs':.002,'contributingTasks':contributing,'fontCompletions':fonts,'fontNetwork':[q for q in d['audits']['network-requests']['details']['items']if q.get('resourceType')=='Font'],'allMainframeLayouts':layouts,'mainThreadAudit':d['audits']['mainthread-work-breakdown']['details']['items'],'report':str(report),'reportSha256':sha(report),'trace':str(trace),'traceSha256':sha(trace)})

out={'testId':'R01-FINAL-TRACE-RECONCILIATION','status':'PASS','sourceFingerprint':summary['sourceVersion']['sha256'],'scope':'Read-only final18 exactFCP-TTI task clipping and font/network diagnostics. PASS means arithmetic matches original LH audits, not performance acceptance. Original six group target statuses unchanged.','groups':summary['groups'],'rows':rows,'tbtMethod':'Top-level task clip to exact FCP→TTI, then subtract50ms; original trace overlap correction1microsecond. Sum reconciles audit within.002ms. Nested category totals are not additional blocking.','fieldWindow':None,'inpMs':None}
f=P/'final-trace-reconciliation.json';f.write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'status':'PASS','rows':len(rows),'groups':[{ 'style':g['style'],'page':g['page'],'status':g['status']}for g in summary['groups']],'sampleTasks':[{'testId':r['run'],'tbt':r['recomputedFcpTtiClippedTbtMs'],'tasks':[{'durationMs':t['durationMs'],'blockingMs':t['fcpClippedBlockingMs'],'url':t['url'],'categories':t['approxAuditCategoryMs']}for t in r['contributingTasks']]}for r in rows if 'quotation-mobile-r1' in r['run']]},ensure_ascii=False))
