'use strict';
// Read-only native CSS font evidence. No App imports, FontFace construction, font load/add, DOM mutation, or fetch.
// The only FontFaceSet.check call targets the actual mapped core family and explicit core text.
module.exports=async function nativeFontProof(page,mapping){
 return page.evaluate(mapping=>{
  const errors=[],stylesheetErrors=[];
  const normalize=value=>String(value??'').replace(/["'\s]/g,'').toLowerCase();
  const keys=['family','style','weight','stretch','unicodeRange','display','featureSettings','ascentOverride','descentOverride','lineGapOverride','variationSettings','status'];
  const nativeSnapshot=face=>Object.fromEntries(keys.map(key=>[key,face?.[key]??null]));
  function parseRanges(raw){
   const intervals=[],invalid=[];
   for(const part of String(raw??'').split(',')){
    const value=part.trim().match(/^U\+([0-9A-F?]{1,6})(?:-([0-9A-F]{1,6}))?$/i);
    if(!value||value[1].includes('?')&&(value[2]||!/^[0-9A-F]*\?+$/i.test(value[1]))){invalid.push(part);continue;}
    const low=parseInt(value[1].replace(/\?/g,'0'),16),high=parseInt(value[2]??value[1].replace(/\?/g,'F'),16);
    if(low>high||high>0x10ffff){invalid.push(part);continue;}intervals.push([low,high]);
   }
   return{raw:String(raw??''),intervals,invalid};
  }
  const contains=(ranges,point)=>ranges.intervals.some(([low,high])=>point>=low&&point<=high);
  const base=new URL(mapping.baseURL||location.href,location.href);
  function sourceURLs(raw,sheetURL){
   const urls=[];const regex=/url\((?:"([^"]+)"|'([^']+)'|([^\s)]+))\)/g;let match;
   while((match=regex.exec(String(raw??'')))){const extracted=match[1]??match[2]??match[3];try{const url=new URL(extracted,sheetURL||document.baseURI);urls.push({raw:extracted,url:url.href,origin:url.origin,pathname:url.pathname,search:url.search,hash:url.hash,sameOrigin:url.origin===base.origin});}catch(error){urls.push({raw:extracted,error:String(error)});}}
   return urls;
  }
  const allRules=[];
  function inspectRules(rules){for(const rule of Array.from(rules)){
   if(rule.type===CSSRule.FONT_FACE_RULE){const s=rule.style;allRules.push({family:s.getPropertyValue('font-family'),style:s.getPropertyValue('font-style'),weight:s.getPropertyValue('font-weight'),stretch:s.getPropertyValue('font-stretch'),display:s.getPropertyValue('font-display'),unicodeRange:s.getPropertyValue('unicode-range'),featureSettings:s.getPropertyValue('font-feature-settings'),ascentOverride:s.getPropertyValue('ascent-override'),descentOverride:s.getPropertyValue('descent-override'),lineGapOverride:s.getPropertyValue('line-gap-override'),rawSrc:s.getPropertyValue('src'),sheetURL:rule.parentStyleSheet?.href??null,urls:sourceURLs(s.getPropertyValue('src'),rule.parentStyleSheet?.href)});}
   else if('cssRules' in rule){try{inspectRules(rule.cssRules);}catch(error){stylesheetErrors.push({scope:'nested',error:String(error)});}}
  }}
  for(const sheet of Array.from(document.styleSheets)){try{inspectRules(sheet.cssRules);}catch(error){stylesheetErrors.push({href:sheet.href,error:String(error)});}}
  const allNative=document.fonts?Array.from(document.fonts):[];
  function mappedRules(spec){
   if(!spec?.urlPath)return[];
   const expected=new URL(spec.urlPath,base);
   return allRules.filter(rule=>rule.urls.some(url=>url.origin===expected.origin&&url.pathname===expected.pathname&&!url.search&&!url.hash)).map(rule=>{
    const range=parseRanges(rule.unicodeRange),nativeFaces=allNative.filter(face=>normalize(face.family)===normalize(rule.family)&&normalize(face.weight)===normalize(rule.weight)&&normalize(face.style)===normalize(rule.style||'normal')&&normalize(face.unicodeRange)===normalize(rule.unicodeRange));
    return{...rule,parsedRange:range,nativeFaces:nativeFaces.map(nativeSnapshot),nativeFaceCount:nativeFaces.length,nativeLoadedCount:nativeFaces.filter(face=>face.status==='loaded').length,nativeErrorCount:nativeFaces.filter(face=>face.status==='error').length,expected:{urlPath:spec.urlPath,url:expected.href,sha256:spec.sha256??null},sourceSameOrigin:rule.urls.some(url=>url.origin===expected.origin&&url.pathname===expected.pathname&&url.sameOrigin&&!url.search&&!url.hash)};
   });
  }
  const rootFamily=getComputedStyle(document.documentElement).getPropertyValue('--font-noto-sans-tc').trim(),activePrimary=rootFamily.split(',')[0].trim();
  const coreRules=mappedRules(mapping.core),fallbackRules=mappedRules(mapping.fallback),core=coreRules.length===1?coreRules[0]:null;
  const suppliedPoints=Array.isArray(mapping.core?.codepoints)?mapping.core.codepoints:[],validPoints=suppliedPoints.filter(point=>Number.isInteger(point)&&point>=0&&point<=0x10ffff),expectedPoints=[...new Set(validPoints)].sort((a,b)=>a-b);
  const coreErrors=[];
  if(validPoints.length!==suppliedPoints.length||!expectedPoints.length)coreErrors.push('Invalid or empty mapped core codepoints');
  if(coreRules.length!==1)coreErrors.push('Mapped core URL must identify exactly one @font-face rule');
  let actualCorePoints=[],coreCheck700={sample:'網站服務',font:null,available:typeof document.fonts?.check==='function',result:null,error:null,sampleInMappedCore:false};
  if(core){
   if(core.parsedRange.invalid.length)coreErrors.push('Invalid core unicode-range');
   const points=new Set();for(const [low,high] of core.parsedRange.intervals)for(let point=low;point<=high;point++)points.add(point);actualCorePoints=[...points].sort((a,b)=>a-b);
   if(actualCorePoints.length!==expectedPoints.length||actualCorePoints.some((point,index)=>point!==expectedPoints[index]))coreErrors.push('Core unicode-range differs from mapped codepoint set');
   if(normalize(activePrimary)!==normalize(core.family))coreErrors.push('Active root primary family differs from mapped core rule family');
   if(core.weight.trim().replace(/\s+/g,' ')!=='100 900')coreErrors.push('Core weight is not 100 900');
   if(core.display.trim()!=='swap')coreErrors.push('Core font-display is not swap');
   if(!core.sourceSameOrigin)coreErrors.push('Core mapped source is not same-origin');
   if(core.nativeFaceCount!==1)coreErrors.push('Core rule must identify exactly one native FontFace');
   if(core.nativeLoadedCount<1)coreErrors.push('Core native FontFace is not loaded');
   const samplePoints=Array.from(coreCheck700.sample,char=>char.codePointAt(0));coreCheck700.sampleInMappedCore=samplePoints.every(point=>expectedPoints.includes(point));
   if(!coreCheck700.sampleInMappedCore)coreErrors.push('Explicit core API sample is outside mapped core');
   coreCheck700.font=`700 16px ${core.family}`;
   if(coreCheck700.available&&coreCheck700.sampleInMappedCore){try{coreCheck700.result=document.fonts.check(coreCheck700.font,coreCheck700.sample);}catch(error){coreCheck700.error=String(error);}}
   if(coreCheck700.result!==true)coreErrors.push('Actual core-family check700 failed or unavailable');
  }
  const rarePoint=mapping.fallback?.codepoint,rareCharacter=mapping.fallback?.character;
  const fallbackErrors=[];
  if(fallbackRules.length!==1)fallbackErrors.push('Mapped fallback URL must identify exactly one @font-face rule');
  for(const rule of fallbackRules){
   rule.containsRare=Number.isInteger(rarePoint)&&contains(rule.parsedRange,rarePoint);
   rule.coreOverlap=expectedPoints.filter(point=>contains(rule.parsedRange,point));
   if(normalize(rule.family)!==normalize('Noto Sans TC'))fallbackErrors.push('Mapped fallback family is not Noto Sans TC');
   if(rule.parsedRange.invalid.length)fallbackErrors.push('Invalid fallback unicode-range');
   if(!rule.containsRare)fallbackErrors.push('Mapped fallback range does not cover rare character');
   if(rule.coreOverlap.length)fallbackErrors.push('Mapped fallback range overlaps core codepoints');
   if(!rule.sourceSameOrigin)fallbackErrors.push('Fallback mapped source is not same-origin');
  }
  if(rareCharacter!=='龘'||rarePoint!==0x9f98)fallbackErrors.push('Rare-character mapping differs from specified 龘 U+9F98');
  errors.push(...coreErrors,...fallbackErrors);
  return{kind:'READ_ONLY_NATIVE_CSS_FONT_PROOF_V4',url:location.href,baseURL:base.href,rootFamily,activePrimary,fontSetStatus:document.fonts?.status??null,nativeFaceCount:allNative.length,totalFontFaceRuleCount:allRules.length,core:{expected:mapping.core,ruleCount:coreRules.length,rules:coreRules,actualCodepoints:actualCorePoints,expectedCodepointCount:expectedPoints.length,actualCodepointCount:actualCorePoints.length,check700:coreCheck700,errors:coreErrors,normalProof:coreErrors.length===0},fallback:{expected:mapping.fallback,ruleCount:fallbackRules.length,rules:fallbackRules,loadedRequired:false,rareLoadDecision:'Caller owns rare-glyph case decision; helper never loads or checks this family',errors:fallbackErrors,descriptorProof:fallbackErrors.length===0},stylesheetErrors,errors,normalProof:errors.length===0,byteHashEvidence:'Mapping SHA values are recorded only. This read-only DOM helper does not fetch or verify font bytes; caller owns response hash evidence.',readOnly:{mutatedDOM:false,constructedFontFace:false,loadedFontFace:false,modifiedFontSet:false,checkedUnusedFamilies:false,fetchedResources:false}};
 },mapping);
};
