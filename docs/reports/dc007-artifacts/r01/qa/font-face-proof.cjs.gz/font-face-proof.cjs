'use strict';
// Read-only detached FontFace proof. No FontFace construction, load, check, fetch, or font-set mutation.
// Caller installs a transparent constructor observer recording {family,source,descriptors,face}.
const assert=require('node:assert/strict');
module.exports=async function fontFaceProof(page){
 const evidence=await page.evaluate(()=>{
  const alias='XK Noto Sans TC Batch';
  const normalize=value=>String(value??'').replace(/["'\s]/g,'').toLowerCase();
  // These are the nine descriptor names explicitly copied by the controller contract.
  const descriptorKeys=['style','weight','stretch','unicodeRange','display','featureSettings','ascentOverride','descentOverride','lineGapOverride'];
  const root=document.documentElement,computed=getComputedStyle(root),sourceFamily=computed.getPropertyValue('--font-noto-sans-tc-source').trim(),originalPrimary=sourceFamily.split(',')[0].trim(),activeFamily=computed.getPropertyValue('--font-noto-sans-tc').trim();
  const activePrimary=activeFamily.split(',')[0].trim();
  const allFaces=document.fonts?Array.from(document.fonts):[];
  const originals=allFaces.filter(face=>normalize(face.family)===normalize(originalPrimary));
  const registeredAliases=allFaces.filter(face=>normalize(face.family)===normalize(alias));
  const descriptorSnapshot=face=>Object.fromEntries(descriptorKeys.map(key=>[key,face?.[key]??null]));
  const nativeSnapshot=face=>({family:face?.family??null,status:face?.status??null,...descriptorSnapshot(face),variationSettings:face?.variationSettings??null,variant:face?.variant??null});
  const stylesheetErrors=[],fontRules=[];
  function readRules(rules){for(const rule of Array.from(rules)){
   if(rule.type===CSSRule.FONT_FACE_RULE)fontRules.push(rule);
   else if('cssRules' in rule){try{readRules(rule.cssRules);}catch(error){stylesheetErrors.push({scope:'nested-rule',error:String(error)});}}
  }}
  for(const sheet of Array.from(document.styleSheets)){try{readRules(sheet.cssRules);}catch(error){stylesheetErrors.push({href:sheet.href,error:String(error)});}}
  const sourceRules=fontRules.filter(rule=>normalize(rule.style.getPropertyValue('font-family'))===normalize(originalPrimary));
  function readURL(raw,baseURL){
   const match=String(raw??'').match(/url\((?:"([^"]+)"|'([^']+)'|([^\s)]+))\)/);
   const extracted=match?.[1]??match?.[2]??match?.[3];if(!extracted)return{raw:String(raw??''),extracted:null,url:null,selfHosted:false,error:'No CSS url()'};
   try{const url=new URL(extracted,baseURL);return{raw:String(raw??''),extracted,url:url.href,origin:url.origin,pathname:url.pathname,selfHosted:url.origin===location.origin&&url.pathname.startsWith('/_next/static/media/')&&!url.search&&!url.hash};}
   catch(error){return{raw:String(raw??''),extracted,url:null,selfHosted:false,error:String(error)};}
  }
  const rules=sourceRules.map((rule,index)=>{
   const unicodeRange=rule.style.getPropertyValue('unicode-range'),matchingOriginals=originals.filter(face=>normalize(face.unicodeRange)===normalize(unicodeRange));
   return{index,family:rule.style.getPropertyValue('font-family'),unicodeRange,source:readURL(rule.style.getPropertyValue('src'),rule.parentStyleSheet?.href??document.baseURI),matchingOriginalCount:matchingOriginals.length,originals:matchingOriginals.map(nativeSnapshot),cssDescriptors:{style:rule.style.getPropertyValue('font-style'),weight:rule.style.getPropertyValue('font-weight'),stretch:rule.style.getPropertyValue('font-stretch'),unicodeRange,display:rule.style.getPropertyValue('font-display'),featureSettings:rule.style.getPropertyValue('font-feature-settings'),ascentOverride:rule.style.getPropertyValue('ascent-override'),descentOverride:rule.style.getPropertyValue('descent-override'),lineGapOverride:rule.style.getPropertyValue('line-gap-override')}};
  });
  const observed=window.__fontSupplement?.constructed;
  const constructions=(Array.isArray(observed)?observed:[]).filter(record=>normalize(record.family)===normalize(alias)).map((record,index)=>{
   const descriptors=Object.fromEntries(descriptorKeys.map(key=>[key,record.descriptors?.[key]??null]));
   const matchingRules=rules.filter(rule=>normalize(rule.unicodeRange)===normalize(descriptors.unicodeRange));
   const rule=matchingRules.length===1?matchingRules[0]:null,original=rule?.matchingOriginalCount===1?rule.originals[0]:null,native=nativeSnapshot(record.face),actualSource=readURL(record.source,document.baseURI);
   const comparisons=descriptorKeys.map(key=>({key,original:original?.[key]??null,constructor:descriptors[key],nativeAlias:native[key],constructorMatchesOriginal:!!original&&descriptors[key]===original[key],nativeMatchesOriginal:!!original&&native[key]===original[key]}));
   const urlMatches=!!rule&&rule.source.selfHosted&&actualSource.selfHosted&&actualSource.url===rule.source.url;
   return{index,family:record.family,source:record.source,descriptors,native,registered:!!document.fonts&&!!record.face&&document.fonts.has(record.face),matchingRuleCount:matchingRules.length,matchingRuleIndex:rule?.index??null,matchingOriginalCount:rule?.matchingOriginalCount??0,expectedSource:rule?.source??null,actualSource,urlMatches,descriptorComparisons:comparisons,descriptorsMatch:comparisons.every(item=>item.constructorMatchesOriginal&&item.nativeMatchesOriginal)};
  });
  const errors=[];
  if(!originalPrimary)errors.push('Missing original source primary family');
  if(!Array.isArray(observed))errors.push('Constructor observer unavailable');
  if(!rules.length)errors.push('No original source @font-face rules');
  if(rules.length!==originals.length)errors.push('Original CSS-rule and FontFaceSet counts differ');
  if(constructions.length!==rules.length)errors.push('Alias construction count differs from original CSS rules');
  if(registeredAliases.length!==rules.length)errors.push('Registered alias count differs from original CSS rules');
  if(!registeredAliases.some(face=>face.status==='loaded'))errors.push('No loaded registered alias');
  if(normalize(activePrimary)!==normalize(alias))errors.push('Active primary family is not the detached alias');
  for(const item of constructions){if(item.matchingRuleCount!==1||item.matchingOriginalCount!==1)errors.push(`Construction ${item.index}: ambiguous original/rule range`);if(!item.urlMatches)errors.push(`Construction ${item.index}: original/alias source URL mismatch or non-self-hosted URL`);if(!item.descriptorsMatch)errors.push(`Construction ${item.index}: descriptor mismatch`);if(!item.registered)errors.push(`Construction ${item.index}: alias face is not registered`);}
  for(const rule of rules){if(constructions.filter(item=>item.matchingRuleIndex===rule.index).length!==1)errors.push(`Original rule ${rule.index}: alias construction coverage is not exactly one`);}
  return{kind:'READ_ONLY_DETACHED_FONT_FACE_PROOF',dataset:root.dataset.fontLoading??null,alias,sourceFamily,originalPrimary,activeFamily,activePrimary,descriptorKeys,descriptorCount:descriptorKeys.length,descriptorContractNote:'Nine explicitly named copied descriptors; variationSettings/variant are additionally reported without adding an unspecified copy requirement.',observerAvailable:Array.isArray(observed),originalRuleCount:rules.length,originalFontFaceSetCount:originals.length,originalLoadedCount:originals.filter(face=>face.status==='loaded').length,aliasConstructionCount:constructions.length,aliasFaceSetRegisteredCount:registeredAliases.length,aliasFaceSetLoadedCount:registeredAliases.filter(face=>face.status==='loaded').length,aliasFaceSetFaces:registeredAliases.map(nativeSnapshot),rules,constructions,stylesheetErrors,readyProofErrors:errors,readOnly:{constructedFaces:false,loadedFaces:false,checkedFonts:false,modifiedFontSet:false,fetchedResources:false},unusedOriginalFacesRequiredLoaded:false};
 });
 if(evidence.dataset==='ready')assert.deepEqual(evidence.readyProofErrors,[],'Detached alias ready proof: '+evidence.readyProofErrors.join('; '));
 return evidence;
};
