'use strict';
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto'),assert=require('node:assert/strict');
const hash=p=>crypto.createHash('sha256').update(fs.readFileSync(p)).digest('hex');
module.exports=function resolveNativeFonts(outDir,manifestFile,factsFile){
 const manifest=JSON.parse(fs.readFileSync(manifestFile)),facts=JSON.parse(fs.readFileSync(factsFile)),pointsFile=path.join(path.dirname(manifestFile),'codepoints.json'),points=JSON.parse(fs.readFileSync(pointsFile)).core;
 assert.equal(manifest.coreSha256,facts.asset.coreSha256);assert.equal(manifest.coreBytes,facts.asset.coreBytes);assert.equal(points.length,manifest.coreCodepointCount);const rare=manifest.fallbackTest;assert.equal(rare.originalSha256,facts.coverage.fallbackTest.originalSha256);assert(!points.includes(rare.codepoint));
 const wanted=new Set([manifest.coreSha256,rare.originalSha256]),matches=[];for(const relative of fs.readdirSync(outDir,{recursive:true}).filter(p=>p.endsWith('.woff2'))){const file=path.join(outDir,relative),sha256=hash(file);if(wanted.has(sha256))matches.push({file,relative,urlPath:'/'+relative.split(path.sep).join('/'),sha256,bytes:fs.statSync(file).size});}
 const match=sha=>{const a=matches.filter(v=>v.sha256===sha);assert.equal(a.length,1,'Need one exact served-out mapping for raw font SHA '+sha);assert(a[0].urlPath.startsWith('/_next/static/media/'),'Input must be the served export root, not guessed filesystem URLs');return a[0];};
 return{core:{...match(manifest.coreSha256),codepoints:points,weightRange:facts.asset.weightRange,display:facts.asset.display},fallback:{...match(rare.originalSha256),character:rare.character,codepoint:rare.codepoint,family:facts.asset.family},inputs:[manifestFile,factsFile,pointsFile].map(p=>({path:p,sha256:hash(p)})),verifiedProofReference:facts.proof,scope:'Actual export-file bytes mapped by supplied exact rawSHA. No browser, guessedfilename or generatedfamily assumption.'};
};
