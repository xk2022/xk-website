'use strict';
// Narrow DC007-R01 supplement v2. Original v1 and syntax evidence are immutable.
// Only script GET failures exactly "csp" in a script-disabled case get the known noJS classification.
// CLI: node font-supplement.cjs normal|pages BASE RUN SOURCE_BRIDGE_JSON
// Reuses the frozen passive monitor; no routing, cache override, PDF, or timer acceleration.
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto'),assert=require('node:assert/strict');
const [mode,baseArg,run,sourceFile]=process.argv.slice(2);
assert(['normal','pages'].includes(mode)&&baseArg&&run&&sourceFile,'normal|pages BASE RUN SOURCE_BRIDGE_JSON');
assert(/^[A-Za-z0-9_-]+$/.test(run));
const base=new URL(baseArg);assert(['127.0.0.1','localhost'].includes(base.hostname)&&base.pathname==='/'&&!base.search&&!base.hash);
const hash=b=>crypto.createHash('sha256').update(b).digest('hex'),sourceBytes=fs.readFileSync(sourceFile),source=JSON.parse(sourceBytes);
const fixtureFile=process.env.DC007_FIXTURE||'/tmp/xk-dc007/fixture.json',fixtureBytes=fs.readFileSync(fixtureFile),fixture=JSON.parse(fixtureBytes);assert.equal(fixture.routes.length,49);
const monitorFile=path.join(__dirname,'../qa/monitor.cjs'),monitor=require(monitorFile),monitorHash=hash(fs.readFileSync(monitorFile));
const playwrightFile=process.env.DC007_PLAYWRIGHT||'/tmp/xk-browser-check/node_modules/playwright-core',executable=process.env.DC007_CHROMIUM||'/usr/bin/chromium';
const outDir=path.join(__dirname,`${mode}-font-${run}`);fs.mkdirSync(outDir,{recursive:false});
const out={testId:'DC007-R01-FONT-SUPPLEMENT',status:'PENDING',mode,base:base.href,run,startedAt:new Date().toISOString(),source:{path:sourceFile,sha256:hash(sourceBytes),data:source},fixture:{path:fixtureFile,sha256:hash(fixtureBytes)},monitor:{path:monitorFile,sha256:monitorHash},scope:{cases:10,viewport:{width:375,height:1000},timeout:'Real controller 15000ms; no timer monkeypatch',earlyPrint:'Synthetic beforeprint DOM event followed by print media inspection; not a physical print or PDF',network:'Frozen passive monitor, no new cancellation exceptions',personalData:'No names, projects, email or message entered; mailto defaults prevented'},cases:[],fatal:null};
const save=()=>fs.writeFileSync(path.join(outDir,'result.json'),JSON.stringify(out,null,2)+'\n');
const routePath=(style,kind)=>`${style==='modern'?'':'/design-collection/'+style}${kind==='home'?'/':'/quotation'}`;
const urlFor=(style,kind)=>new URL(routePath(style,kind).replace(/\/$/,'')+(mode==='pages'?'/':'' )||'/',base).href;
const bounded=async(p,label,ms=30000)=>{let timer;try{return await Promise.race([p,new Promise((_,reject)=>{timer=setTimeout(()=>reject(new Error(label+' exceeded '+ms+'ms')),ms);})]);}finally{clearTimeout(timer);}};
const frames=p=>bounded(p.evaluate(()=>new Promise(resolve=>requestAnimationFrame(()=>requestAnimationFrame(resolve)))),'two frames');
const normalize=p=>p.replace(/\/$/,'')||'/';
const sameFamily=(a,b)=>a.replace(/[\s\"']/g,'')===b.replace(/[\s\"']/g,'');
const expectedPaths=[...new Set(fixture.routes.map(r=>normalize(r.path)))].sort();
function initRow(spec){return{...spec,status:'PENDING',startedAt:new Date().toISOString(),requests:[],consoleErrors:[],runtimeErrors:[],networkErrors:[],privacyLeaks:[],expected404:[],expected404Console:[],expectedPrefetchCancellations:[],expectedNoJSScriptCSP:[],expectedNoJSScriptBlocks:[],lifecycle:[]};}
function classifyNoJSConsole(row){
 // These exact engine messages prove disabled script execution only. No generic CSP/error exemption.
 if(!row.noJS)return;
 const locationURL=row.url;
 row.consoleErrors=row.consoleErrors.filter(e=>{
  const allowed=[`Blocked script execution in '${locationURL}' because the document's frame is sandboxed and the 'allow-scripts' permission is not set.`];
  if(allowed.includes(e.text)&&e.location?.url===locationURL){row.expectedNoJSScriptCSP.push({...e,reason:'Exact noJS sandbox script-execution message; not a resource cancellation'});return false;}
  return true;
 });
}
function classifyNoJSScriptBlocks(row){
 if(!row.noJS)return;
 row.networkErrors=row.networkErrors.filter(record=>{
  if(record.method==='GET'&&record.type==='script'&&record.error==='csp'){
   row.expectedNoJSScriptBlocks.push({rawRecord:record,reason:'Exact known JavaScript-disabled script GET prohibition: error csp. No cancellation exemption.'});
   return false;
  }
  return true;
 });
}
function strict(row){classifyNoJSConsole(row);classifyNoJSScriptBlocks(row);for(const k of ['consoleErrors','runtimeErrors','networkErrors','privacyLeaks'])assert.deepEqual(row[k],[],k+' must remain strict');}
async function fontState(page){return page.evaluate(async()=>{
 const root=document.documentElement,cs=getComputedStyle(root),original=cs.getPropertyValue('--font-noto-sans-tc-source').trim(),active=cs.getPropertyValue('--font-noto-sans-tc').trim(),primary=original.split(',')[0].trim(),text=document.body.innerText;
 if(document.fonts)await document.fonts.ready;
 return{dataset:root.dataset.fontLoading||null,original,active,primary,fontStatus:document.fonts?.status||null,check700:document.fonts?.check?document.fonts.check(`700 16px ${primary}`,text):null,textLength:text.length,bodyFont:getComputedStyle(document.body).fontFamily};
 });}
async function geometry(page){return page.evaluate(()=>{
 const h=document.querySelector('h1'),footer=document.querySelector('footer');
 function box(e){const r=e.getBoundingClientRect(),s=getComputedStyle(e);return{text:e.innerText,box:{x:r.x,y:r.y,width:r.width,height:r.height},display:s.display,visibility:s.visibility,opacity:s.opacity};}
 return{url:location.href,h1:h?box(h):null,footer:footer?box(footer):null,width:innerWidth,rootScroll:document.documentElement.scrollWidth,bodyScroll:document.body.scrollWidth,footerPaths:footer?[...new Set([...footer.querySelectorAll('a[href]')].map(a=>new URL(a.href,location.href)).filter(u=>u.origin===location.origin).map(u=>u.pathname.replace(/\/$/,'')||'/'))].sort():[]};
 });}
async function checkLayout(page,row){
 if(!row.noJS)await frames(page);const a=await geometry(page);if(!row.noJS)await frames(page);const b=await geometry(page);row.geometry={first:a,second:b,twoFrames:!row.noJS,noJSReason:row.noJS?'Script-disabled context; document.fonts.ready and repeated synchronous DOM geometry, not a simulated rAF':null};
 for(const g of [a,b]){assert(g.h1&&g.h1.text.trim()&&g.h1.box.width>0&&g.h1.box.height>0&&g.h1.display!=='none'&&g.h1.visibility!=='hidden');assert(g.footer&&g.footer.text.trim()&&g.footer.box.width>0&&g.footer.box.height>0&&g.footer.display!=='none'&&g.footer.visibility!=='hidden');assert(g.rootScroll<=g.width+1&&g.bodyScroll<=g.width+1,'horizontal document overflow');assert.deepEqual(g.footerPaths,expectedPaths,'49 published Footer paths');assert.equal(new URL(g.url).search,'','no query fields');assert.equal(new URL(g.url).hash,'');}
 assert.equal(a.h1.text,b.h1.text);for(const key of ['x','y','width','height'])assert(Math.abs(a.h1.box[key]-b.h1.box[key])<=1,'post-font h1 geometry must settle');
 assert.equal(a.footer.text,b.footer.text);for(const key of ['x','y','width','height'])assert(Math.abs(a.footer.box[key]-b.footer.box[key])<=1,'post-font footer geometry must settle');
}
async function summary(page,row,select=true){
 await page.locator('#quotation-estimator[data-quotation-ready="true"]').waitFor();
 // Pick real catalog IDs from actual controls; never enter personal fields.
 const service=page.locator('input[name="quotation-service"]').first();if(select)await service.check();
 const build=page.locator('input[name="quotation-build"]').first();if(select)await build.check();
 assert.equal(await page.locator('#quotation-customer').inputValue(),'');assert.equal(await page.locator('#quotation-project').inputValue(),'');
 const paper=page.locator('[data-a4-sheet="true"]');await paper.waitFor({state:'visible'});row.summary={text:await paper.innerText(),service:await service.inputValue(),build:await build.inputValue()};
 assert(row.summary.text.includes('未填寫')&&row.summary.text.includes('非正式報價'));assert(row.summary.text.trim().length>100);
 row.summary.images=[];for(const image of await paper.locator('img').all())row.summary.images.push(await bounded(image.evaluate(async e=>{await e.decode();const r=e.getBoundingClientRect(),s=getComputedStyle(e);return{src:e.getAttribute('src'),complete:e.complete,naturalWidth:e.naturalWidth,width:r.width,height:r.height,display:s.display,visibility:s.visibility};}),'Logo/QR decode'));
 assert.deepEqual(row.summary.images.map(i=>i.src),['/brand/source/xk-logo-horizontal.svg','/images/quotation/website-qr.svg','/images/quotation/portfolio-qr.svg']);assert(row.summary.images.every(i=>i.complete&&i.naturalWidth>0&&i.width>0&&i.height>0&&i.display!=='none'&&i.visibility!=='hidden'));
}
let browser;
(async()=>{try{
 save();const {chromium}=require(playwrightFile);browser=await chromium.launch({executablePath:executable,headless:true,args:['--no-sandbox','--disable-dev-shm-usage']});out.environment={node:process.version,browser:browser.version(),playwright:require(path.join(playwrightFile,'package.json')).version,executable};
 const cases=[...['modern','heritage','luxury'].map(style=>({id:'NORMAL-'+style,style,kind:'home',fault:null})),...['modern','heritage','luxury'].map(style=>({id:'NOJS-'+style,style,kind:'home',noJS:true})),...['reject','timeout','unavailable','earlyprint'].map(fault=>({id:'QUOTATION-'+fault,style:'modern',kind:'quotation',fault}))];
 for(const spec of cases){const row=initRow(spec);out.cases.push(row);save();let context,finish;const pending=new Set(),waiters=new Set();
  async function drain(label){const start=Date.now();while(pending.size){await bounded(new Promise(r=>waiters.add(r)),label,Math.max(1,20000-(Date.now()-start)));if(Date.now()-start>=20000&&pending.size)throw new Error('Unsettled actual requests: '+[...pending].map(r=>r.url()).join(','));}row.lifecycle.push({label,elapsedMs:Date.now()-start,pending:pending.size});}
  try{
   context=await browser.newContext({viewport:out.scope.viewport,deviceScaleFactor:1,javaScriptEnabled:!spec.noJS,reducedMotion:'reduce',timezoneId:'Asia/Taipei'});
   finish=await monitor(context,{base,mode,out:row,publishedPaths:fixture.routes.map(r=>r.path)});
   if(spec.fault)await context.addInitScript(({fault})=>{
    window.__fontSupplement={fault,calls:[],startedAt:performance.now(),nativeFontsReady:null};
    const original=FontFaceSet.prototype.load;
    if(fault==='unavailable'){Object.defineProperty(document.fonts,'load',{value:undefined,configurable:true});return;}
    FontFaceSet.prototype.load=function(font,text){window.__fontSupplement.calls.push({font,textLength:String(text).length,at:performance.now()});if(fault==='reject')return Promise.reject(new Error('DC007 deliberate FontFaceSet.load rejection'));if(fault==='timeout'||fault==='earlyprint')return new Promise(()=>{});return original.call(this,font,text);};
   },{fault:spec.fault});
   context.on('request',r=>pending.add(r));const ended=r=>{pending.delete(r);for(const resolve of waiters)resolve();waiters.clear();};context.on('requestfinished',ended);context.on('requestfailed',ended);
   const page=await context.newPage();page.setDefaultTimeout(30000);row.url=urlFor(spec.style,spec.kind);const nav=await page.goto(row.url,{waitUntil:'domcontentloaded',timeout:30000});assert.equal(nav.status(),200);await page.locator('h1').waitFor();
   if(spec.noJS){row.font=await bounded(fontState(page),'noJS fonts.ready');assert.equal(row.font.dataset,null);assert(row.font.original&&sameFamily(row.font.active,row.font.original),'noscript restores original source family');assert.equal(row.font.fontStatus,'loaded');assert.equal(row.font.check700,true);row.noJSProof=await page.evaluate(()=>({noscript:[...document.querySelectorAll('noscript style')].map(e=>e.textContent),controllerRan:!!window.__fontSupplement}));assert(row.noJSProof.noscript.some(x=>x.includes('--font-noto-sans-tc-source')));}
   else if(spec.fault==='earlyprint'){
    await page.waitForFunction(()=>document.documentElement.dataset.fontLoading==='loading'&&window.__fontSupplement?.calls.length>0);await summary(page,row);row.beforePrint=await page.evaluate(()=>({dataset:document.documentElement.dataset.fontLoading,at:performance.now()}));
    assert.equal(row.beforePrint.dataset,'loading','beforeprint must occur before fallback timeout');row.event=await page.evaluate(()=>{const event=new Event('beforeprint');window.dispatchEvent(event);return{type:event.type,isTrusted:event.isTrusted,dataset:document.documentElement.dataset.fontLoading,active:getComputedStyle(document.documentElement).getPropertyValue('--font-noto-sans-tc').trim(),source:getComputedStyle(document.documentElement).getPropertyValue('--font-noto-sans-tc-source').trim()};});
    assert.equal(row.event.dataset,'native-print');assert(sameFamily(row.event.active,row.event.source),'synchronous native family restore');await page.emulateMedia({media:'print'});await bounded(page.evaluate(()=>document.fonts.ready),'early-print native fonts.ready');await summary(page,row,false);row.printMediaOnly=true;await page.emulateMedia({media:'screen'});row.font=await fontState(page);assert.equal(row.font.dataset,'native-print');
   }else{
    await page.waitForFunction(()=>['ready','native','native-print'].includes(document.documentElement.dataset.fontLoading),null,{timeout:25000});row.font=await bounded(fontState(page),'completed fonts.ready');
    assert(row.font.original&&sameFamily(row.font.active,row.font.original),'controller activates original family');assert.equal(row.font.fontStatus,'loaded');assert.equal(row.font.check700,true,'real 700 check against full document.body.innerText');
    if(spec.fault){assert.equal(row.font.dataset,'native');row.injection=await page.evaluate(()=>({...window.__fontSupplement,observedAt:performance.now()}));if(spec.fault==='timeout'){assert(row.injection.calls.length>0);assert(row.injection.observedAt-row.injection.calls[0].at>=14900,'real 15-second timeout must elapse');}if(spec.fault==='reject')assert(row.injection.calls.length>0);await summary(page,row);}else assert(['ready','native','native-print'].includes(row.font.dataset));
   }
   if(spec.fault==='earlyprint'){assert.equal(row.font.check700,true);assert.equal(row.font.fontStatus,'loaded');}
   await checkLayout(page,row);row.privacy=await page.evaluate(()=>({url:location.href,cookie:document.cookie,local:JSON.stringify(localStorage),session:JSON.stringify(sessionStorage),mail:window.__dc006Mail||[],storageLeaks:window.__dc006StorageLeaks||[]}));assert(!monitor.containsPII(JSON.stringify(row.privacy)));assert.deepEqual(row.privacy.storageLeaks,[]);assert.deepEqual(row.privacy.mail,[]);assert.equal(new URL(row.privacy.url).search,'');
   await drain('all actual requests before context close');await finish();strict(row);row.status='PASS';
  }catch(error){row.status='FAIL';row.error=error.stack;}
  finally{if(context)await context.close();if(finish)try{await finish();strict(row);}catch(error){row.status='FAIL';row.lateError=error.stack;}row.finishedAt=new Date().toISOString();save();}
 }
 assert.equal(hash(fs.readFileSync(sourceFile)),hash(sourceBytes),'Source bridge changed during run');assert.equal(hash(fs.readFileSync(fixtureFile)),hash(fixtureBytes),'Fixture changed');assert.equal(hash(fs.readFileSync(monitorFile)),monitorHash,'Frozen monitor changed');assert.equal(out.cases.length,10);out.status=out.cases.every(r=>r.status==='PASS')?'PASS':'FAIL';
}catch(error){out.status='FAIL';out.fatal=error.stack;}
finally{if(browser)await browser.close();out.finishedAt=new Date().toISOString();out.exitCode=out.status==='PASS'?0:1;save();console.log('DC007_R01_FONT_SUPPLEMENT_COMPLETE',JSON.stringify({status:out.status,cases:out.cases.length,result:path.join(outDir,'result.json'),exitCode:out.exitCode}));process.exitCode=out.exitCode;}})();
