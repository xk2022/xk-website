'use strict';
// Offline-prepared helper. Caller supplies an already launched browser; this module never starts a server/build.
const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path');
const monitor=require('./monitor.cjs');
async function noJS({browser,base,mode,fixture,from,to,outDir}){
 base=new URL(base);assert(['normal','pages'].includes(mode));assert(['localhost','127.0.0.1'].includes(base.hostname)&&base.pathname==='/'&&!base.search&&!base.hash);
 const routes=Array.isArray(fixture)?fixture:fixture.routes,routeOf=value=>typeof value==='string'?routes.find(r=>r.path.replace(/\/$/,'')===value.replace(/\/$/,'')):value;
 const source=routeOf(from),target=routeOf(to);assert(source&&target,'Both routes must exist in fixture');assert.equal(source.styleId,target.styleId,'Same-style native Footer target');
 const hrefFor=route=>{const pathname=route.path.replace(/\/$/,'')||'/';return pathname==='/'?'/':pathname+(mode==='pages'?'/':'');};
 const sourceURL=new URL(hrefFor(source),base).href,targetURL=new URL(hrefFor(target),base).href;
 const row={testId:'DC007-R01-V7-NOJS-FOOTER-'+source.styleId,mode,style:source.styleId,status:'PENDING',startedAt:new Date().toISOString(),from:source,to:target,sourceURL,targetURL,requests:[],consoleErrors:[],runtimeErrors:[],networkErrors:[],privacyLeaks:[],expected404:[],expected404Console:[],expectedPrefetchCancellations:[],expectedScriptBlocks:[],lifecycle:[],scriptPolicy:'JavaScript disabled. Only exact GET + script + error csp is classified; every other error remains strict.'};
 const save=()=>{if(outDir){fs.mkdirSync(outDir,{recursive:true});fs.writeFileSync(path.join(outDir,'footer-nojs-'+source.styleId+'.json'),JSON.stringify(row,null,2)+'\n');}};
 const pending=new Set(),waiters=new Set();let context,finish,failure;
 const bounded=async(p,label,ms=30000)=>{let timer;try{return await Promise.race([p,new Promise((_,reject)=>{timer=setTimeout(()=>reject(new Error(label+' exceeded '+ms+'ms')),ms);})]);}finally{clearTimeout(timer);}};
 const classify=()=>{row.networkErrors=row.networkErrors.filter(record=>{if(record.method==='GET'&&record.type==='script'&&record.error==='csp'){row.expectedScriptBlocks.push({rawRecord:record,reason:'Exact known JavaScript-disabled script GET prohibition'});return false;}return true;});};
 const strict=()=>{classify();for(const key of ['consoleErrors','runtimeErrors','networkErrors','privacyLeaks'])assert.deepEqual(row[key],[],key+' must remain strict');};
 const drain=async label=>{const started=Date.now();while(pending.size){await bounded(new Promise(resolve=>waiters.add(resolve)),label,Math.max(1,20000-(Date.now()-started)));if(Date.now()-started>=20000&&pending.size)throw new Error('Unsettled requests: '+[...pending].map(r=>r.url()).join(','));}row.lifecycle.push({label,elapsedMs:Date.now()-started,pending:0});};
 const documentState=async page=>bounded(page.evaluate(async()=>{if(document.fonts)await document.fonts.ready;const h=document.querySelector('h1');return{url:location.href,timeOrigin:performance.timeOrigin,width:innerWidth,rootWidth:document.documentElement.scrollWidth,bodyWidth:document.body.scrollWidth,h1:h?.innerText??'',fontsStatus:document.fonts?.status??null,cookie:document.cookie,local:JSON.stringify(localStorage),session:JSON.stringify(sessionStorage)};}),'native noJS document fonts/read-only state');
 const checkDocument=state=>{assert.equal(new URL(state.url).search,'');assert.equal(new URL(state.url).hash,'');assert(state.h1.trim(),'Visible document has h1 text');assert(state.rootWidth<=state.width+1&&state.bodyWidth<=state.width+1,'No horizontal document overflow');assert(!monitor.containsPII(JSON.stringify(state)),'No persistent or URL PII');};
 try{
  save();context=await browser.newContext({viewport:{width:375,height:1000},deviceScaleFactor:1,javaScriptEnabled:false,reducedMotion:'reduce',timezoneId:'Asia/Taipei'});
  finish=await monitor(context,{base,mode,out:row,publishedPaths:routes.map(r=>r.path)});
  context.on('request',request=>pending.add(request));const ended=request=>{pending.delete(request);for(const resolve of waiters)resolve();waiters.clear();};context.on('requestfinished',ended);context.on('requestfailed',ended);
  const page=await context.newPage();page.setDefaultTimeout(30000);
  const response=await page.goto(sourceURL,{waitUntil:'domcontentloaded',timeout:30000});assert(response);row.sourceResponse={url:response.url(),status:response.status()};assert.equal(response.status(),200);assert.equal(page.url(),sourceURL);
  row.before=await documentState(page);checkDocument(row.before);assert.equal(row.before.fontsStatus,'loaded');await drain('source actual requests complete');
  const footer=page.locator('footer');assert.equal(await footer.count(),1);assert(await footer.isVisible());
  const links=footer.locator('a[href]'),hrefs=await links.evaluateAll(elements=>elements.map(a=>({attribute:a.getAttribute('href'),href:a.href,text:a.innerText})));
  const indices=hrefs.map((link,index)=>link.href===targetURL?index:-1).filter(index=>index>=0);assert(indices.length,'Actual Footer must have exact mode-aware target href');row.footer={links:hrefs,targetIndices:indices,activation:'Real focused native anchor + keyboard Enter, no click script or router invocation'};
  const anchor=links.nth(indices[0]);await anchor.scrollIntoViewIfNeeded();assert(await anchor.isVisible());await anchor.focus();row.focus=await page.evaluate(()=>({tag:document.activeElement?.tagName,href:document.activeElement?.href??null}));assert.equal(row.focus.tag,'A');assert.equal(row.focus.href,targetURL);
  const [navigation]=await Promise.all([page.waitForNavigation({waitUntil:'domcontentloaded',timeout:30000}),page.keyboard.press('Enter')]);assert(navigation,'Native Enter must create an actual document navigation response');row.targetResponse={url:navigation.url(),status:navigation.status(),resourceType:navigation.request().resourceType(),method:navigation.request().method()};assert.equal(navigation.status(),200);assert.equal(navigation.url(),targetURL);assert.equal(row.targetResponse.resourceType,'document');assert.equal(page.url(),targetURL);
  row.after=await documentState(page);checkDocument(row.after);assert.equal(row.after.fontsStatus,'loaded');assert.notEqual(row.before.timeOrigin,row.after.timeOrigin,'Native Enter must replace document/timeOrigin');await drain('target actual requests complete');await finish();strict();row.status='PASS';
 }catch(error){row.status='FAIL';row.error=error.stack;failure=error;}
 finally{if(context)try{await context.close();}catch(error){row.status='FAIL';row.closeError=error.stack;failure??=error;}if(finish)try{await finish();strict();}catch(error){row.status='FAIL';row.lateError=error.stack;failure??=error;}row.finishedAt=new Date().toISOString();save();}
 if(failure){failure.evidence=row;throw failure;}return row;
}
module.exports=noJS;
module.exports.noJS=noJS;
