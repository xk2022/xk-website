'use strict';
// Bounded WCAG 2.2 target geometry + WCAG 1.4.12 text-spacing evidence.
// No claim of complete target-size or visual-clipping conformance.
module.exports = async function releaseAccessibility(page, route) {
  const targets = await page.evaluate(() => {
    const rect = r => ({ x:r.x,y:r.y,width:r.width,height:r.height,right:r.right,bottom:r.bottom });
    const visible = e => { const s=getComputedStyle(e),r=e.getBoundingClientRect();return r.width>0&&r.height>0&&s.display!=='none'&&s.visibility==='visible'&&e.getClientRects().length>0; };
    const selector='a[href],button,input:not([type="hidden"]),select,textarea,summary,[role="button"],[role="link"],[tabindex]:not([tabindex="-1"])';
    return [...document.querySelectorAll(selector)].filter(visible).map((e,index) => {
      const r=e.getBoundingClientRect(),s=getComputedStyle(e),label=e.getAttribute('aria-label')||e.textContent||e.getAttribute('placeholder')||e.id||e.tagName;
      const row={index,tag:e.tagName.toLowerCase(),id:e.id||null,role:e.getAttribute('role'),text:label.trim().slice(0,180),href:e.getAttribute('href'),rect:rect(r),fontSize:s.fontSize,lineHeight:s.lineHeight,display:s.display,disabled:!!e.disabled,classification:null,evidence:null};
      if(e.disabled||e.getAttribute('aria-disabled')==='true'){row.classification='inactive-control';row.evidence='Inactive component; actual disabled/aria-disabled recorded, not an active target-size assertion.';}
      else if(r.width>=24&&r.height>=24){row.classification='geometry-at-least-24';}
      else {
        const labels=e.labels?[...e.labels].filter(visible):[];
        const adequate=labels.find(l=>{const a=l.getBoundingClientRect();return a.width>=24&&a.height>=24&&(l.control===e);});
        const p=e.parentElement,inlineText=e.tagName==='A'&&s.display==='inline'&&p&&['P','LI','DD','DT','BLOCKQUOTE','FIGCAPTION'].includes(p.tagName)&&[...p.childNodes].some(n=>n.nodeType===Node.TEXT_NODE&&n.textContent.trim());
        if(adequate){row.classification='native-associated-label-target';row.evidence={controlId:e.id,labelFor:adequate.htmlFor||null,containsControl:adequate.contains(e),labelText:adequate.textContent.trim().slice(0,180),labelRect:rect(adequate.getBoundingClientRect()),basis:'Actual native label.control association and label itself at least24x24; control small geometry is retained.'};}
        else if(inlineText){row.classification='inline-text-exception';row.evidence={parentTag:p.tagName.toLowerCase(),parentText:p.textContent.trim().slice(0,200),basis:'Inline link inside text paragraph/list/description with actual non-link text sibling.'};}
        else {row.classification='manual-target-size-review';row.evidence={associatedLabels:labels.map(l=>({for:l.htmlFor||null,text:l.textContent.trim().slice(0,100),rect:rect(l.getBoundingClientRect())})),reason:'Below24px in at least one dimension; spacing/equivalent/essential exceptions not proven by this helper. Not automatically FAIL or PASS.'};}
      }
      return row;
    });
  });
  const styleId='dc007-qa-text-spacing-'+Date.now();
  let textSpacing;
  try {
    await page.evaluate(id=>{const style=document.createElement('style');style.id=id;style.textContent='*{line-height:1.5!important;letter-spacing:.12em!important;word-spacing:.16em!important}p{margin-bottom:2em!important}';document.head.appendChild(style);},styleId);
    await require('./cv-render-v5.cjs')(page,'actual WCAG textspacing nativeCV');
    await page.evaluate(()=>new Promise(resolve=>requestAnimationFrame(()=>requestAnimationFrame(resolve))));
    textSpacing=await page.evaluate(() => {
      const visible=e=>{const s=getComputedStyle(e),r=e.getBoundingClientRect();return r.width>0&&r.height>0&&s.display!=='none'&&s.visibility==='visible'&&e.getClientRects().length;};
      const potentialClipping=[];
      for(const e of document.querySelectorAll('body *')){
        if(!visible(e)||!e.textContent.trim())continue;
        const s=getComputedStyle(e),r=e.getBoundingClientRect(),x=e.scrollWidth>e.clientWidth+1,y=e.scrollHeight>e.clientHeight+1;
        if((x&&['hidden','clip'].includes(s.overflowX))||(y&&['hidden','clip'].includes(s.overflowY)))potentialClipping.push({tag:e.tagName.toLowerCase(),id:e.id||null,className:typeof e.className==='string'?e.className:null,text:e.textContent.trim().slice(0,160),rect:{x:r.x,y:r.y,width:r.width,height:r.height},client:[e.clientWidth,e.clientHeight],scroll:[e.scrollWidth,e.scrollHeight],overflowX:s.overflowX,overflowY:s.overflowY,reason:'Potential clipped text after actual spacing override; manual visual review required.'});
      }
      return {viewportWidth:innerWidth,documentScrollWidth:document.documentElement.scrollWidth,bodyScrollWidth:document.body.scrollWidth,horizontalOverflow:Math.max(document.documentElement.scrollWidth,document.body.scrollWidth)>innerWidth+1,applied:{lineHeight:1.5,paragraphMarginEm:2,letterSpacingEm:.12,wordSpacingEm:.16},potentialClipping,manualReviewRequired:potentialClipping.length>0,scope:'Actual spacing CSS and geometry; does not certify absence of overlap or loss by screenshot alone.'};
    });
  } finally {
    await page.evaluate(id=>document.getElementById(id)?.remove(),styleId);
  }
  return {route:typeof route==='string'?route:route?.path||null,viewport:page.viewportSize(),manualTargets:targets.filter(t=>t.classification==='manual-target-size-review'),targets,textSpacing};
};
