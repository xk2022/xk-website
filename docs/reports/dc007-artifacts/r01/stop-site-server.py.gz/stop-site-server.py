from pathlib import Path
import argparse,json,os,signal,socket,time,datetime
p=argparse.ArgumentParser();p.add_argument('--port',required=True,type=int,choices=[3280,3281]);p.add_argument('--receipt',required=True,type=Path);a=p.parse_args();assert not a.receipt.exists()
rows=[];target=f'{a.port:04X}'
for line in Path('/proc/net/tcp').read_text().splitlines()[1:]:
 fields=line.split()
 if fields[1]=='0100007F:'+target and fields[3]=='0A':rows.append(fields[9])
assert len(rows)==1,rows
owners=[]
for d in Path('/proc').iterdir():
 if not d.name.isdigit():continue
 try:
  if not any(os.readlink(x)=='socket:['+rows[0]+']' for x in (d/'fd').iterdir()):continue
  cmd=[x.decode() for x in (d/'cmdline').read_bytes().split(b'\0') if x];cwd=os.readlink(d/'cwd');exe=os.readlink(d/'exe')
  safe=(a.port==3280 and cwd=='/workspace/xk-website' and 'node' in exe and cmd[0].startswith('next-server')) or (a.port==3281 and len(cmd)>1 and cmd[1]=='/tmp/xk-dc007/performance/serve-pages.py')
  assert safe,(cmd,cwd,exe)
  owners.append({'pid':int(d.name),'command':cmd,'cwd':cwd,'executable':exe})
 except (FileNotFoundError,PermissionError):continue
assert len(owners)==1,owners
os.kill(owners[0]['pid'],signal.SIGTERM)
code=None
for _ in range(100):
 s=socket.socket();code=s.connect_ex(('127.0.0.1',a.port));s.close()
 if code==111:break
 time.sleep(.05)
assert code==111,code
v={'status':'PASS','action':'Intentional stop of exact owned loopback server before replacing its build','owners':owners,'port':a.port,'finalConnectEx':code,'at':datetime.datetime.now(datetime.timezone.utc).isoformat()};a.receipt.write_text(json.dumps(v,indent=2)+'\n');print(json.dumps(v))
