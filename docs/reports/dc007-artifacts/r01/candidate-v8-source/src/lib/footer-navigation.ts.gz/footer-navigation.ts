export type FooterNavigationIntent = Readonly<{
  href: string | null;
  defaultPrevented: boolean;
  button: number;
  metaKey: boolean;
  ctrlKey: boolean;
  shiftKey: boolean;
  altKey: boolean;
  target: string | null;
  download: boolean;
}>;

/** Match the existing Pages directory URLs without changing query/hash text. */
export function formatFooterHref(href: string, pagesExport: boolean): string {
  if (!pagesExport || !href.startsWith("/") || href.startsWith("//")) return href;
  const split = href.search(/[?#]/);
  const path = split < 0 ? href : href.slice(0, split);
  if (path.endsWith("/") || /\.[^/]+$/.test(path)) return href;
  return `${path}/${split < 0 ? "" : href.slice(split)}`;
}

/** Null means preserve the anchor's native browser behavior. */
export function getFooterNavigationHref(intent: FooterNavigationIntent, currentHref: string): string | null {
  if (intent.defaultPrevented || intent.button !== 0 || intent.metaKey || intent.ctrlKey
    || intent.shiftKey || intent.altKey || intent.download
    || (intent.target && intent.target.toLowerCase() !== "_self") || !intent.href) return null;
  try {
    const current = new URL(currentHref);
    const target = new URL(intent.href, current);
    if (!/^https?:$/.test(target.protocol) || target.origin !== current.origin) return null;
    return `${target.pathname}${target.search}${target.hash}`;
  } catch {
    return null;
  }
}
