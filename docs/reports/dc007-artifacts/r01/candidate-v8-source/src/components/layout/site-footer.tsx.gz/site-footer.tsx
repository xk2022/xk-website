import { FooterNavigation } from "@/components/layout/footer-navigation";
import { formatFooterHref } from "@/lib/footer-navigation";
import { XkLogo } from "@/components/brand/xk-logo";
import { Container } from "@/components/layout/container";
import { services } from "@/config/homepage";
import { siteConfig } from "@/config/site";
import { getDesignDirectoryGroups, getDesignNavigationModel } from "@/lib/design-collection/navigation-model";
import { resolveDesignHref } from "@/lib/design-collection/routes";
import { isPrivacyPolicyPublished } from "@/lib/privacy-publication";

const footerLinkStyles =
  "inline-flex min-h-11 items-center rounded-sm text-primary-foreground/80 transition-colors duration-brand ease-brand hover:text-primary-foreground motion-reduce:transition-none";

export function SiteFooter() {
  const pagesExport = process.env.XK_PAGES_EXPORT === "1";
  const groups = getDesignDirectoryGroups(["modern", "heritage", "luxury"]);
  const modern = groups.find(({ id }) => id === "modern");
  const homeHref = getDesignNavigationModel().styles.find(({ id }) => id === "modern")?.homeHref;
  if (!modern || !homeHref) throw new Error("Modern directory requires its published routes");
  const presentationDirectories = groups.filter(({ id }) => id !== "modern");
  const serviceLinks = services.map((service) => {
    const href = resolveDesignHref({ styleId: "modern", pageKey: "home", hash: `service-${service.anchor}` });
    if (!href) throw new Error("Service directory requires a published homepage anchor");
    return { id: service.id, label: service.name, href };
  });

  return (
    <FooterNavigation className="bg-primary text-primary-foreground [&_a:focus-visible]:outline-primary-foreground">
      <Container className="py-14 sm:py-16">
        <div className="grid gap-10 sm:grid-cols-2 lg:grid-cols-[1.4fr_1fr_1.4fr] lg:gap-12">
          <div className="min-w-0 sm:col-span-2 lg:col-span-1">
            <a href={formatFooterHref(homeHref, pagesExport)} className="inline-flex min-h-11 max-w-full items-center gap-3 rounded-sm">
              <XkLogo size={48} variant="white" showWordmark={false} decorative />
              <span lang="en" className="type-body font-semibold">{siteConfig.name}</span>
              <span className="sr-only">首頁，Logo 為暫定版本</span>
            </a>
            <p lang="en" className="type-body-lg mt-5 max-w-xs text-primary-foreground/90">{siteConfig.slogan}</p>
            <p className="type-body-sm mt-5 max-w-xs text-primary-foreground/75">整合 Web、Java 與 AI 技術，探索企業的數位可能。</p>
          </div>

          <nav aria-label="頁尾導覽">
            <h2 className="type-body mb-4 font-semibold">{modern.title}</h2>
            <ul className="type-body-sm space-y-1">
              {modern.entries.map(({ href, label }) => <li key={href}><a href={formatFooterHref(href, pagesExport)} className={`${footerLinkStyles} max-w-full break-words`}>{label}</a></li>)}
            </ul>
          </nav>

          <nav aria-label="服務分類">
            <h2 className="type-body mb-4 font-semibold">服務分類</h2>
            <ul className="type-body-sm space-y-1">
              {serviceLinks.map(({ id, href, label }) => <li key={id}><a href={formatFooterHref(href, pagesExport)} className={footerLinkStyles}>{label}</a></li>)}
            </ul>
          </nav>

          <div className="grid min-w-0 gap-10 sm:col-span-2 sm:grid-cols-2 lg:col-span-3 lg:grid-cols-3">
            {presentationDirectories.map(({ id, title, entries }) => (
              <nav key={id} aria-labelledby={`site-directory-${id}`} className="min-w-0">
                <h2 id={`site-directory-${id}`} className="type-body mb-4 font-semibold">{title}</h2>
                <ul className="type-body-sm space-y-1">
                  {entries.map(({ href, label }) => <li key={href} className="min-w-0"><a href={formatFooterHref(href, pagesExport)} className={`${footerLinkStyles} max-w-full break-words`}>{label}</a></li>)}
                </ul>
              </nav>
            ))}
          </div>
        </div>

        <div className="type-body-sm mt-12 flex flex-col gap-4 border-t border-primary-foreground/20 pt-6 text-primary-foreground/65 sm:flex-row sm:items-center sm:justify-between">
          <p lang="en">© {new Date().getFullYear()} {siteConfig.name}. All rights reserved.</p>
          {isPrivacyPolicyPublished() ? <a href={formatFooterHref("/privacy", pagesExport)} className={footerLinkStyles}>隱私權政策</a> : <p>隱私權政策（待確認）</p>}
        </div>
      </Container>
    </FooterNavigation>
  );
}
