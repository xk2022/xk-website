"use client";

import { useRouter } from "next/navigation";
import type { MouseEvent, ReactNode } from "react";

import { getFooterNavigationHref } from "@/lib/footer-navigation";

/** One client boundary; all anchor children are supplied by Server Components. */
export function FooterNavigation({ children, className }: Readonly<{ children: ReactNode; className?: string }>) {
  const router = useRouter();

  function navigate(event: MouseEvent<HTMLElement>) {
    if (!(event.target instanceof Element)) return;
    const anchor = event.target.closest<HTMLAnchorElement>("a[href]");
    if (!anchor || !event.currentTarget.contains(anchor)) return;
    const href = getFooterNavigationHref({
      href: anchor.getAttribute("href"),
      defaultPrevented: event.defaultPrevented,
      button: event.button,
      metaKey: event.metaKey,
      ctrlKey: event.ctrlKey,
      shiftKey: event.shiftKey,
      altKey: event.altKey,
      target: anchor.getAttribute("target"),
      download: anchor.hasAttribute("download"),
    }, window.location.href);
    if (href === null) return;
    event.preventDefault();
    router.push(href);
  }

  return <footer className={className} onClick={navigate}>{children}</footer>;
}
