import assert from "node:assert/strict";
import test from "node:test";

import { formatFooterHref, getFooterNavigationHref } from "../src/lib/footer-navigation.ts";

const current = "https://www.xplorekaleidoscope.com/quotation/?old=1";
const plain = { href: "/about", defaultPrevented: false, button: 0, metaKey: false, ctrlKey: false, shiftKey: false, altKey: false, target: null, download: false };

test("FOOTER-01 normal URLs retain their exact path, query and hash", () => {
  for (const href of ["/", "/about", "/services#service-plans", "/contact?source=x#contact-channels", "/design-collection/luxury/quotation"])
    assert.equal(formatFooterHref(href, false), href);
});

test("FOOTER-02 Pages slash belongs before query/hash and root stays root", () => {
  for (const [href, expected] of [["/", "/"], ["/#services", "/#services"], ["/about", "/about/"], ["/about/", "/about/"], ["/contact?source=x#contact-channels", "/contact/?source=x#contact-channels"], ["/services#service-plans", "/services/#service-plans"], ["/design-collection/luxury/quotation", "/design-collection/luxury/quotation/"]])
    assert.equal(formatFooterHref(href, true), expected);
});

test("FOOTER-03 unrelated absolute, protocol, relative and file URLs are not reformatted", () => {
  for (const href of ["https://example.com/about", "//example.com/about", "mailto:owner@example.com", "#services", "../about", "/brand/logo.svg"])
    assert.equal(formatFooterHref(href, true), href);
});

test("FOOTER-04 plain left and keyboard-generated clicks use same-origin router destinations", () => {
  assert.equal(getFooterNavigationHref(plain, current), "/about");
  assert.equal(getFooterNavigationHref({ ...plain, href: "/about/", target: "_self" }, current), "/about/");
  assert.equal(getFooterNavigationHref({ ...plain, href: "https://www.xplorekaleidoscope.com/services/#service-plans" }, current), "/services/#service-plans");
  // Native Enter activation emits an ordinary click with button=0 as well.
  assert.equal(getFooterNavigationHref({ ...plain, href: "#quotation-results" }, current), "/quotation/?old=1#quotation-results");
});

test("FOOTER-05 default prevention, modifiers and non-left buttons remain native", () => {
  for (const change of [{ defaultPrevented: true }, { metaKey: true }, { ctrlKey: true }, { shiftKey: true }, { altKey: true }, { button: 1 }, { button: 2 }])
    assert.equal(getFooterNavigationHref({ ...plain, ...change }, current), null);
});

test("FOOTER-06 target/download intents remain native, including empty download attributes", () => {
  for (const change of [{ target: "_blank" }, { target: "_parent" }, { target: "named-window" }, { download: true }])
    assert.equal(getFooterNavigationHref({ ...plain, ...change }, current), null);
});

test("FOOTER-07 external origins, unsafe schemes, missing and malformed hrefs are never pushed", () => {
  for (const href of ["https://example.com/", "http://www.xplorekaleidoscope.com/", "mailto:owner@example.com", "tel:123", "javascript:alert(1)", "data:text/html,x", "https://[", "", null])
    assert.equal(getFooterNavigationHref({ ...plain, href }, current), null);
});

test("FOOTER-08 query/hash order is preserved without copying current personal query into route links", () => {
  assert.equal(getFooterNavigationHref({ ...plain, href: "/contact/?source=footer#contact-channels" }, current), "/contact/?source=footer#contact-channels");
  assert.equal(getFooterNavigationHref({ ...plain, href: "/" }, current), "/");
  assert.equal(getFooterNavigationHref(plain, "not a location"), null);
});
