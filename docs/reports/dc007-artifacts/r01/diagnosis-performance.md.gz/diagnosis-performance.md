# DC-007-R01 唯讀效能診斷與最小實驗

狀態：診斷完成；候選尚未由本 agent 建置或量測。原 DC007 的 18 cold、6 warm 及 FAIL 均保留，不改寫。機器事實與 SHA 見同目錄 `diagnosis-performance.json`。

## 原始證據支持甚麼

原六組 mobile cold 的 TBT median 為 Modern Home1552.949ms／Quotation1294.676ms、Heritage Home1441.245ms／Quotation1225.644ms、Luxury Home1305.136ms／Quotation1201.206ms，全部超過200ms；18筆個別TBT也都超標。LCP六組median1629.815–1889.860ms、CLS全0。18個Lighthouse子程序皆真Exit0，capture完整；外層按門檻真Exit1，不是timeout或缺樣本。

Modern Home三個原trace中，main-frame Layout合計1994.146／2228.117／1499.642ms。12／13／13個>50ms Layout緊隨RemoteFontLoaded≤20ms，dirty/total objects約1147。例r1：font3185.860ms完成→Layout3193.028ms開始、223.821ms；另一font3886.427ms完成→Layout3890.759ms開始、230.359ms。原trace SHA和每筆時序在 `/tmp/xk-dc007/performance/cold-home-diagnostic.json`。

每次Modern Home實際16個font請求＝Inter1＋Noto15，font transfer1,091,912B／總transfer1,380,352B，約79%。這不是把115個產物字體檔全部當初載入。r1 Style & Layout2129.944ms，Script Evaluation606.617ms；共享ReactDOM-containing chunk092r-mewpaf3q.js亦有247.1ms script-evaluation長task。GC在首三筆僅5.767ms／14.846ms／無，不支持GC為主因。字體分批完成後反覆全頁排版是主要可重複觀察，並非已證某一subset、某個hook或單一修法的唯一因果。

原warm-v2六case完成、真Exit0，load LCP468–800ms、CLS0，同document27個實際動作。這是不同cache條件，不是App優化後結果，也沒有證明單一字體策略能獨立消除TBT。原40個HEAD取消已有原CDP200 headers，仍保留review-required，不在此補做協定分類。

## 現有字體與 critical CJK 的具體限制

- RootLayout仍為Inter／Noto Sans TC，Noto使用weight:variable、display:swap、preload:false。現有Noto下載face為108個unicode-range＋1個fallback，非原Task011四個weight重複宣告問題；不能再以去重四weights當新修正。
- 既有三個代表字體binary SHA與Task011實際解碼紀錄相同，wght軸100–900；400與700共用variable檔是有來源的判斷，不代表本輪已驗證候選字重呈現。
- 以原HTML的H1非ASCII字元，對原CSS宣告的unicode-range做靜態映射：三套Home相同26個codepoints分布5檔、原檔合計307,144B；Quotation H1相同8個codepoints分布2檔、131,536B。這只是一個可重現的H1 probe，不是完整375首屏字元、不證明實際glyph cmap或量測transfer。
- 因此只預載某一檔不涵蓋Home標題；為保證全首屏而直接預載所有CJK又會搶占帶寬。installed Next文件明確區分subsets與preload；subsets:['latin']不等於僅下載Latin，也不會把CJK合併成一批。原指南禁止無證據預載全部中文字體。
- 將現有15份variable碎片串接／交給generic Merger，不能視為安全。安裝的FontTools4.61.1沒有fvar/gvar/HVAR/MVAR/STAT mergeMap，DefaultTable.merge對未知表回NotImplemented；可能丟variable表，不能直接用於正式資產。原生Python WOFF2唯讀decode亦實際因缺Brotli extension Exit1，未修改字體。若走新合併字體，須另固定原始版本/OFL授權、全部軸／glyph outlines／metrics／shaping與未知字元fallback，工作量及風險較大。

## 優先最小實驗：原 faces 批次啟用

Root提出的單一變數候選較直接對應trace：保留原Next/font family、108個unicode face、variable軸、display:swap及preload:false；先用既有device fallback，Client leaf以FontFaceSet.load載入當前DOM所需的原faces，完成後一次啟用原Noto family。Inter不改。這是待驗證假設，沒有已知提升率。

必須保留的邊界：

1. 解析真實family，記load開始／完成／activation時間、回傳face數與status。load可resolve空陣列；不能把空值當批次成功。不得以改hash、等待到測量窗口後才顯示或隱藏內容取得PASS。
2. 以codepoint去重（Array.from／for…of），避免UTF16 split拆壞補充平面字元。body.innerText僅作記憶體內的字體匹配；不收集input value，不記錄／儲存／傳送整段文字或PII，也不新增外部font請求。
3. initial innerText不涵蓋collapsed menu、後續條件內容、print-only文案及任意訪客輸入。原faces必須一直保留，後續字元照常原生載入；不能將缺字轉成永久system字型。400預載後須實驗700同檔是否可用。
4. FontFaceSet缺少、reject、空face或有界timeout時回原Noto原生loading；noscript亦使用原Noto，不能永遠停留device fallback。避免unmount後callback、StrictMode重複啟用及跨route殘留錯誤。
5. effect晚於hydration才啟動，可能推遲完整品牌字型顯示；初始fallback→Noto時機確實不同。必測CLS、最終字型、文字折行與視覺，不能宣稱瞬態像素完全不變。慢網路／font失敗／後續中文字／中英混排與字重皆須有真證據。
6. 不能以document.fonts.ready作「所有未宣告使用字元皆已載入」的證明；在print布局啟用後仍須確認真正font狀態及8份標準A4內容／QR／頁數。

候選若仍未達標，先看新trace是否把12–13次長Layout縮成一次及剩餘React script長task；不要立即增加第二變數或換字體。次選可在單一非首屏容器實驗screen-only排版隔離，但content-visibility／contain可能改anchor位置、focus、find-in-page、AT及列印，必須單獨實證，不能同時堆疊後歸因。

## 固定工具 readiness 與下一步

本次直接唯讀版本命令均真Exit0：Node24.22.1、Chromium156.0.8078.79、Lighthouse13.6.0、Playwright-core1.65.1。沒有升版、安裝App依賴或新Browser session。

原mobile profile SHA256 `4f0810f189f3cc1960de5a9c57de728f97ec647d3b44932061c51885441f097a`：375×812／DPR1／CPU4／DevTools實際150ms、200000down／93750up bytes/s，storage reset false值指disableStorageReset=false，即每cold重置。原run-lighthouse.py全18與measure-warm-v2.cjs全6工具SHA均列機器事實；warm-v1失敗及v2只加URL-commit等待的邊界保留。

- Root先對獨立candidate實際production輸出做同profile Modern Home三cold pilot，所有原始JSON/HTML/trace/receipt保留，僅作機制／風險驗證，不等於正式18接受。原全18 driver沒有單route CLI，pilot可直接重用相同LH CLI/config三次，不修改profile或把診斷混入正式series。
- 若有可重複收益且無回歸，再同一版本／傳輸模型／工具跑正式六route×3cold及六warm，列所有值、median/range及individual exceedances。不得拿warm當cold after或選最小樣本。
- Required：最終字型／字重、全部五寬可見排版、CLS、49頁兩模式、anchors／skip／focus／keyboard／mobile menu／Reduced Motion／AT、條件文字／個資邊界、八份A4及跨頁print隔離。保留Inter/Noto、內容、價格、原native行為與SEO/private保護。
- Root仍擁有build、server、Git、獨占CPU排程與正式接受；本診斷沒有執行新採樣、沒有修改App。新code-map、server readiness、相同profile及對應產物須在正式run前確認。

沒有field資料，INP／CWV p75為null／待證；TBT僅用LH audit，EventTiming和longtask sums不冒稱INP或TBT。雲端host負載和實體頻率限制仍在，不能為消除FAIL改profile或把所有成本推給環境。
