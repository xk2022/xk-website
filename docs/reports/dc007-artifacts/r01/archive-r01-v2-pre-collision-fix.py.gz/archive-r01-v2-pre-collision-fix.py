#!/usr/bin/env python3
"""R01 evidence archive. Default is a stat-only estimate; --execute is explicit.
Run only after Root freezes all evidence and stops perf/QA writers. No QA verdict
is inferred. Existing DC007 evidence and repo fonts/screens are referenced by hash.
"""
import argparse, gzip, hashlib, json, os, re, tempfile
from collections import Counter, defaultdict
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import parse_qsl, urlsplit

TEXT={'.json','.log','.html','.htm','.md','.txt','.py','.js','.cjs','.mjs','.ts','.tsx','.jsx','.css','.diff','.pb','.yml','.yaml','.sh','.csv','.svg'}
BINARY={'.png','.jpg','.jpeg','.webp','.pdf','.woff2','.gz'}
PRUNE={'node_modules','.next','.git','__pycache__','browser-profile','chrome-profile','chromium-profile','user-data','user_data','company-files','company-snapshot','company-documents','documentation'}
OMIT_NAMES={'archive-process.json','archive-process.log','archive-r01-process.json','archive-r01-process.log','archive-r01-plan.json','desktop-session.json','cookies','login data','local state','preferences'}
EXTRA={name:Path('/tmp/xk-dc007/performance')/name for name in ['run-lighthouse.py','measure-warm-v2.cjs','serve-pages.py','profiles/lighthouse-mobile.json']}
FINAL_ROOTS=['after-v2','warm-final-v2','quality-v2','remote-final','qa','pdf','a11y']

def final_discovery(chosen):
 # This index locates original evidence; presence is never an acceptance verdict.
 return {root:{'state':'DISCOVERED' if any(name==root or name.startswith(root+'/') for name,file,origin in chosen) else 'PENDING_OR_NOT_CREATED',
               'files':[name for name,file,origin in chosen if (name==root or name.startswith(root+'/')) and file.suffix in {'.json','.pdf','.png'}],
               'note':'Read actual result, source version and OS receipt. Discovery does not infer PASS or a completed test.'}
         for root in FINAL_ROOTS}
sha=lambda data:hashlib.sha256(data).hexdigest()

def secret_reason(text):
 if re.search(r'(?m)^[ \t]*-----BEGIN (?:RSA |EC |OPENSSH |DSA )?PRIVATE KEY-----[ \t]*$',text):return 'private-key marker'
 if re.search(r'(?<![A-Za-z0-9_])(?:github_pat_[A-Za-z0-9_]{40,}|gh[pousr]_[A-Za-z0-9]{30,}|sk-(?:proj-)?[A-Za-z0-9_-]{32,})(?![A-Za-z0-9_])',text):return 'credential-like token'
 for url in re.findall(r'https?://[^\s<>"\\]+',text):
  try:query={k.lower():v for k,v in parse_qsl(urlsplit(url.rstrip("',);.")).query)}
  except ValueError:continue  # Malformed-URL test literals are not credentials.
  if any(len(query.get(k,''))>=24 for k in ['x-amz-signature','x-goog-signature','access_token','refresh_token']):return 'signed URL or access token'
  if len(query.get('sig',''))>=24 and any(k in query for k in ['sv','se','sp']):return 'signed SAS URL'
 return None

def select(source):
 chosen=[];excluded=[]
 for directory,dirs,names in os.walk(source,followlinks=False):
  parent=Path(directory)
  for name in list(dirs):
   p=parent/name;rel=p.relative_to(source)
   if p.is_symlink() or name in PRUNE or (name=='out' and len(rel.parts)==1) or (len(rel.parts)==1 and name=='company'):
    dirs.remove(name);excluded.append({'sourcePath':str(p),'reason':'excluded directory/profile/company/dependency/generated tree'})
  for name in sorted(names):
   p=parent/name;rel=p.relative_to(source).as_posix()
   if p.is_symlink():raise ValueError('Refuse source symlink: '+str(p))
   suffix=p.suffix.lower();reason=None
   if name.lower() in OMIT_NAMES or name.startswith('.env'):reason='live archive receipt/plan or private session file'
   elif suffix in {'.ttf','.otf','.zip','.tar','.7z','.exe','.so','.pyc'}:reason='upstream master, duplicate build/archive, binary tool or cache'
   elif suffix not in TEXT|BINARY:reason='unrecognized evidence format; Root must review before adding'
   if reason:excluded.append({'sourcePath':str(p),'bytes':p.stat().st_size,'reason':reason})
   else:chosen.append((rel,p,'r01'))
 for name,path in EXTRA.items():
  if not path.is_file():raise ValueError('Missing fixed original harness: '+str(path))
  chosen.append(('original-tools/'+name,path,'original-performance-tools'))
 if len({x[0]for x in chosen})!=len(chosen):raise ValueError('Archive logical-path collision')
 return sorted(chosen),excluded

def old_references(repo):
 refs={};manifest=repo/'docs/reports/dc007-artifacts/manifest.json'
 if manifest.is_file():
  data=json.loads(manifest.read_text())
  for row in data['files']:
   if row.get('encoding') not in {'gzip','identity'}:continue
   path=manifest.parent/row['path']
   if not path.resolve().is_relative_to(repo) or not path.is_file() or path.is_symlink():raise ValueError('Invalid old evidence reference')
   if row.get('decodedSha256'):refs.setdefault(row['decodedSha256'],{'file':path,'encoding':row['encoding'],'encodedSha256':row['sha256'],'kind':'existing-dc007-evidence'})
 for root,kind in [(repo/'src/app/fonts','tracked-font'),(repo/'docs/screenshots/design-collection/dc007-r01','separate-r01-screenshot')]:
  if not root.exists():continue
  for file in sorted(root.rglob('*')):
   if file.is_file() and not file.is_symlink() and file.suffix.lower() in {'.woff2','.png','.jpg','.webp'}:
    digest=sha(file.read_bytes());refs.setdefault(digest,{'file':file,'encoding':'identity','encodedSha256':digest,'kind':kind})
 return refs

def estimate(chosen,excluded,repo):
 groups=defaultdict(lambda:{'files':0,'rawBytes':0});total=0
 for name,file,root in chosen:
  size=file.stat().st_size;groups[name.split('/')[0]]['files']+=1;groups[name.split('/')[0]]['rawBytes']+=size;total+=size
 # WOFF2 candidates mostly match the109tracked assets; this is only a stat bound.
 font_raw=sum(file.stat().st_size for name,file,root in chosen if file.suffix.lower()=='.woff2')
 return {'mode':'ESTIMATE_ONLY_NO_ARCHIVE','sourceFiles':len(chosen),'selectedRawBytesIncludingFontCandidates':total,'fontCandidateBytesMostlyReferencedElsewhere':font_raw,'nonFontSelectedRawBytes':total-font_raw,'excludedFileBytes':sum(x.get('bytes',0)for x in excluded),'groups':dict(groups),'forecastAfter18RawBytes':6*groups.get('pilot-v6',{}).get('rawBytes',0),'forecastNote':'After18 size estimate uses measured size of3pilot-v6fileset x6; not acceptance or generated data. Compressed size remains unmeasured. Binary font/screens and old identical evidence will be referenced at execution.','sourceCompleteness':'Draft; all final after-v2,warm-final-v2,quality-v2,remote-final,QA/PDF and failed experiments are recursively selected only after Root freezes writers.','finalEvidenceDiscovery':final_discovery(chosen)}

def execute(chosen,excluded,source,repo,dest):
 allowed=repo/'docs/reports/dc007-artifacts'
 if not dest.resolve().is_relative_to(allowed.resolve()):raise ValueError('Destination outside approved report artifacts')
 if dest.exists() and any(dest.iterdir()):raise ValueError('Refuse to overwrite an existing archive')
 refs=old_references(repo);dest.parent.mkdir(parents=True,exist_ok=True);stage=Path(tempfile.mkdtemp(prefix='.r01-archive-',dir=dest.parent));records=[];seen_payloads={};states=[]
 try:
  for logical,file,source_root in chosen:
   before=file.stat();raw=file.read_bytes();after=file.stat()
   if (before.st_size,before.st_mtime_ns)!=(after.st_size,after.st_mtime_ns):raise ValueError('Evidence changed while reading: '+str(file))
   states.append((file,after.st_size,after.st_mtime_ns));digest=sha(raw);suffix=file.suffix.lower()
   inspected=raw
   if suffix=='.gz':inspected=gzip.decompress(raw)
   if suffix in TEXT or (suffix=='.gz' and file.with_suffix('').suffix in TEXT):
    reason=secret_reason(inspected.decode('utf-8'))
    if reason:raise ValueError('Sensitive evidence blocked ('+reason+'): '+str(file))
   row={'logicalPath':logical,'sourcePath':str(file),'sourceRoot':source_root,'rawBytes':len(raw),'rawSha256':digest}
   reference=refs.get(digest)
   if reference:
    encoded=reference['file'].read_bytes()
    if sha(encoded)!=reference['encodedSha256']:raise ValueError('Referenced existing bytes changed')
    decoded=gzip.decompress(encoded) if reference['encoding']=='gzip' else encoded
    if decoded!=raw:raise ValueError('Existing reference does not restore original raw bytes')
    row.update(storage='repo-reference',path=reference['file'].relative_to(repo).as_posix(),encoding=reference['encoding'],encodedBytes=len(encoded),encodedSha256=sha(encoded),referenceKind=reference['kind'])
   elif digest in seen_payloads:
    # Any byte-identical raw evidence can share one stored payload, preserving each source mapping.
    row.update(seen_payloads[digest],storage='archive-reference')
   else:
    if suffix=='.woff2':
     # Unique failed-core bytes are retained once;109current fonts are repo refs.
     encoded=raw;encoding='identity';target=logical
    elif suffix in TEXT:
     encoded=gzip.compress(raw,compresslevel=6,mtime=0);encoding='gzip';target=logical+'.gz'
    else:
     encoded=raw;encoding='identity';target=logical
     if suffix=='.gz':gzip.decompress(raw)  # Validate source gzip without altering it.
    if (stage/target).exists():raise ValueError('Encoded-path collision: '+target)
    path=stage/target;path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(encoded)
    verified=path.read_bytes();decoded=gzip.decompress(verified) if encoding=='gzip' else verified
    if decoded!=raw or sha(verified)!=sha(encoded):raise ValueError('Archive roundtrip failed')
    row.update(storage='archive',path=target,encoding=encoding,encodedBytes=len(encoded),encodedSha256=sha(encoded))
    seen_payloads[digest]={key:row[key]for key in ['path','encoding','encodedBytes','encodedSha256']}
   records.append(row)
  for file,size,mtime in states:
   s=file.stat()
   if (s.st_size,s.st_mtime_ns)!=(size,mtime):raise ValueError('Evidence changed during archive; freeze first: '+str(file))
  # Catch new or removed evidence as well as edits to files that were already selected.
  current_selection,_=select(source)
  if [(name,str(file),root)for name,file,root in current_selection] != [(name,str(file),root)for name,file,root in chosen]:
   raise ValueError('Evidence file inventory changed during archive; stop writers and freeze first')
  result={'archiveIntegrity':'PASS','qaAcceptance':'NOT_DERIVED_SEE_R01_REPORT','createdAt':datetime.now(timezone.utc).isoformat(),'sourceRoots':{'r01':str(source),'original-performance-tools':'/tmp/xk-dc007/performance'},'scope':'All selected R01raw/failures/receipts/tools. Original DC007archive, runtime fonts and47website screenshots stored once and referenced by exact bytes. No dependency tree, browserprofile, generated websiteout or upstream TTF.','finalEvidenceDiscovery':final_discovery(chosen),'inventoryStableThroughCompletion':True,'separateScreenshotRoot':'docs/screenshots/design-collection/dc007-r01','fileCount':len(records),'rawBytes':sum(r['rawBytes']for r in records),'storedPayloadBytes':sum(r['encodedBytes']for r in records if r['storage']=='archive'),'files':records,'excluded':excluded,'counts':dict(Counter(r['storage']for r in records))}
  (stage/'manifest.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
  if dest.exists():dest.rmdir()
  stage.rename(dest);print(json.dumps({k:result[k]for k in ['archiveIntegrity','fileCount','rawBytes','storedPayloadBytes','counts']},ensure_ascii=False))
 except Exception:
  # Keep partial safe output for diagnosis; never rename it to accepted destination.
  raise RuntimeError('Archive failed; inspect source error and partial path '+str(stage)) from __import__('sys').exc_info()[1]

def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--source',type=Path,default=Path('/tmp/xk-dc007-r01'));p.add_argument('--repo',type=Path,default=Path('/workspace/xk-website'));p.add_argument('--destination',type=Path);p.add_argument('--execute',action='store_true');p.add_argument('--plan',type=Path);a=p.parse_args();source=a.source.resolve(strict=True);repo=a.repo.resolve(strict=True);chosen,excluded=select(source);dest=a.destination or repo/'docs/reports/dc007-artifacts/r01'
 if not a.execute:
  result=estimate(chosen,excluded,repo)
  if a.plan:
   if a.plan.resolve().is_relative_to(repo):p.error('Draft plan must stay outside repository')
   a.plan.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
  print(json.dumps({k:v for k,v in result.items()if k!='groups'},ensure_ascii=False));return
 execute(chosen,excluded,source,repo,dest)
if __name__=='__main__':main()
