"use client";

import { Suspense, type ReactNode } from "react";

/** Keep server-rendered children intact while React schedules their hydration. */
export function HydrationBoundary({ children }: Readonly<{ children: ReactNode }>) {
  return <Suspense fallback={null}>{children}</Suspense>;
}
