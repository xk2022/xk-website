"use client";

import { useEffect } from "react";

/** Load the existing variable-font faces together, then make one font swap. */
export function FontLoadingController({ family }: Readonly<{ family: string }>) {
  useEffect(() => {
    const root = document.documentElement;
    let disposed = false;
    let activated = false;
    let timeout: ReturnType<typeof setTimeout> | undefined;

    const activate = (result: "ready" | "native" | "native-print") => {
      if (disposed || activated) return;
      activated = true;
      clearTimeout(timeout);
      root.style.setProperty("--font-noto-sans-tc", family);
      root.dataset.fontLoading = result;
    };
    const beforePrint = () => activate("native-print");
    window.addEventListener("beforeprint", beforePrint);

    if (!document.fonts?.load) {
      activate("native");
    } else {
      root.dataset.fontLoading = "loading";
      // innerText includes the rendered page, not input values or RSC scripts.
      // Keep this sample in memory; do not persist it or send it to a service.
      const text = Array.from(new Set(Array.from(document.body.innerText))).join("");
      const primaryFamily = family.split(",")[0];
      timeout = setTimeout(() => activate("native"), 15_000);
      void document.fonts.load(`400 16px ${primaryFamily}`, text).then(
        (faces) => {
          const loaded = faces.length > 0 && faces.every((face) => face.status === "loaded");
          activate(loaded && document.fonts.check(`700 16px ${primaryFamily}`, text) ? "ready" : "native");
        },
        () => activate("native"),
      );
    }

    return () => {
      disposed = true;
      clearTimeout(timeout);
      window.removeEventListener("beforeprint", beforePrint);
    };
  }, [family]);

  return null;
}
