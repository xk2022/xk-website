# R01 補充：基準範圍與 FCP 後 JS 阻塞

原 `diagnosis-js.md` 的198檔 source bridge／7個公開UI Client邊界，對應Root指定的 `3b2eb50` 原runtime、在新增 FontLoadingController 之前的讀取時點。它沒有驗證後來候選controller或layout，也不是其after結果。候選新增Client邊界與字體狀態須由新的sourceMap、正式QA v3及font supplement獨立驗證；原報告、source evidence和原FAIL保留。

原提到247.1ms是Lighthouse r1該task的Script Evaluation分類。直接讀trace的 ReactDOM `EvaluateScript` 是273.728ms，2036.797–2310.525ms；FCP2037.639ms，因此僅早0.842ms開始，絕大部分在FCP後。r2/r3對應EvaluateScript亦在FCP後，不能用「初始化在首繪前」排除JS成本。

[逐task JSON](js-after-fcp.json)與[計算說明](js-after-fcp.md)使用實際mainframe/thread及navigationStart，按Lighthouse算法先將RunTask裁切至[FCP,TTI]再扣50ms，沒有把total evaluation當TBT：

| ModernHome run | 原／復算TBT ms | ReactDOM task blocking ms | Style主導task blocking ms | 其他 ms |
| --- | ---: | ---: | ---: | ---: |
| r1 | 1552.949 | 229.206 | 1323.743 | 0 |
| r2 | 1814.294 | 155.716 | 1658.578 | 0 |
| r3 | 965.657 | 143.673 | 814.693 | 7.291 |

復算三筆與LH差0；每筆是整task clipping後的blocking歸類，不是某函數的獨立成本或可消除收益。任一task可能含多種工作，無source-mapped profile可指認自製hook。r1 JS主導task已超過200ms，但另外兩筆較低；不能將這些舊值當作候選font batch後的固定JS下界。

結論仍是先量相同profile after。若style/layout已大幅下降但post-FCP framework task仍讓TBT超標，才用after trace決定進一步最小JS候選；不能提前為一個標準庫bundle改寫route/404/Link或刪除互動。未執行新browser、build、server或時間採樣。
