#!/usr/bin/env python3
"""Exact decomposed outlines and advances for the882core points at4weights."""
from pathlib import Path
import json,hashlib,datetime,re,sys
from fontTools.ttLib import TTFont
from fontTools.pens.recordingPen import DecomposingRecordingPen
R=Path('/tmp/xk-dc007-r01/font-assets');C=R/'candidate-v3';manifest=json.loads((C/'manifest.json').read_text());codepoints=json.loads((C/'codepoints.json').read_text())['core'];weights=[400,500,600,700];sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();assert len(codepoints)==882;assert sha(C/'fonts/noto-sans-tc-core.woff2')==manifest['coreSha256']
master=TTFont(R/'upstream/NotoSansTC[wght].ttf');core=TTFont(C/'fonts/noto-sans-tc-core.woff2');mf=master.getBestCmap();cf=core.getBestCmap();sources={};metadata=[]
for p in sorted(Path('/tmp/xk-dc007-build/out/_next/static/media').glob('*.woff2')):
 f=TTFont(p);metadata.append({'file':p.name,'sha256':sha(p),'bytes':p.stat().st_size,'family':f['name'].getDebugName(1),'version':f['name'].getDebugName(5),'axes':[{'tag':a.axisTag,'min':a.minValue,'default':a.defaultValue,'max':a.maxValue}for a in f['fvar'].axes]if'fvar'in f else[],'cmapCount':len(f.getBestCmap())});f.close()
assert len(metadata)==115
for row in manifest['partition']['faces']:
 p=C/'fonts'/row['file'];f=TTFont(p);coverage={c for low,high in row['originalRanges']for c in range(low,high+1)};cmap=f.getBestCmap();matched=[cp for cp in codepoints if cp in coverage and cp in cmap]
 if matched:sources[row['file']]={'font':f,'cmap':cmap,'points':matched,'path':p}
 else:f.close()
master_sets={w:master.getGlyphSet(location={'wght':w})for w in weights};core_sets={w:core.getGlyphSet(location={'wght':w})for w in weights};source_sets={(name,w):r['font'].getGlyphSet(location={'wght':w})for name,r in sources.items()for w in weights}
def draw(gs,name):
 g=gs[name];pen=DecomposingRecordingPen(gs);g.draw(pen);return{'advance':g.width,'outline':pen.value}
def digest(value):return hashlib.sha256(json.dumps(value,separators=(',',':')).encode()).hexdigest()
checks=[];failures=[]
for index,cp in enumerate(codepoints):
 matching=[(name,row)for name,row in sources.items()if cp in row['points']];assert matching
 for w in weights:
  m=draw(master_sets[w],mf[cp]);c=draw(core_sets[w],cf[cp]);olds=[(name,draw(source_sets[name,w],row['cmap'][cp]))for name,row in matching];ok=m==c and all(value==m for name,value in olds);row={'codepoint':cp,'unicode':'U+'+format(cp,'X'),'weight':w,'sourceFaces':[name for name,value in olds],'advance':m['advance'],'masterSignature':digest(m),'coreSignature':digest(c),'originalSignatures':{name:digest(value)for name,value in olds},'status':'PASS'if ok else'FAIL'};checks.append(row)
  if not ok:
   row.update(master=m,core=c,originals=dict(olds));failures.append(row);break
 if failures:break
 if index%100==0:print(json.dumps({'pointsCompleted':index+1,'checks':len(checks)}),flush=True)

def layout_info(font):
 return{'glyphCount':font['maxp'].numGlyphs,'tables':list(font.keys()),'GSUBFeatures':sorted({r.FeatureTag for r in font['GSUB'].table.FeatureList.FeatureRecord})if'GSUB'in font else[],'GSUBScripts':sorted(r.ScriptTag for r in font['GSUB'].table.ScriptList.ScriptRecord)if'GSUB'in font else[],'cmapFormats':sorted({r.format for r in font['cmap'].tables}),'uvs':{str(t.platformID)+'/'+str(t.platEncID):sum(len(v)for v in t.uvsDict.values())for t in font['cmap'].tables if t.format==14}}
layout={'master':layout_info(master),'core':layout_info(core),'method':'FontTools Subsetter layout_features/layout_scripts [*], layout_closure=True; retained glyph-name closure. Full glyph proof compares cmap glyph drawing after component decomposition at4weights.','UVSApplicability':'PENDING'}
layout['UVSApplicability']='Not Applicable: original master has no cmap format14/UVS records'if not layout['master']['uvs']else'Original UVS present; needs separate per-sequence closure proof'
assert set(cf)==set(codepoints);masterglyphs=set(master.getGlyphOrder());coreglyphs=set(core.getGlyphOrder());assert coreglyphs<=masterglyphs;layout['retainedUnencodedClosureGlyphs']=len(coreglyphs-{cf[c]for c in codepoints})
out={'status':'FAIL'if failures else'PASS','checkedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'All882core codepoints, including punctuation/Latin, at400/500/600/700. Exact Python equality of decomposed recording-pen outlines and advances; no tolerance, scaling or metric normalization. Every matching original CSS-range/cmap source compared with pinned master and generated core.','expectedChecks':3528,'actualChecks':len(checks),'checkedCoreCodepoints':len({r['codepoint']for r in checks}),'failures':failures,'checks':checks,'original115FontMetadata':metadata,'sourceFaceCountUsed':len(sources),'coreSha256Before':manifest['coreSha256'],'coreSha256After':sha(C/'fonts/noto-sans-tc-core.woff2'),'masterSha256':sha(R/'upstream/NotoSansTC[wght].ttf'),'layoutClosure':layout,'nameRFNCheck':{'reservedName':'Source','coreIdentityNames':{str(k):core['name'].getDebugName(k)for k in [1,2,3,4,6,16,17]},'copyright':core['name'].getDebugName(0),'OFLFirstLine':(C/'OFL.txt').read_text().splitlines()[0]}};assert failures or len(checks)==3528;assert out['coreSha256Before']==out['coreSha256After'];(R/'glyph-proof.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'status':out['status'],'checks':len(checks),'failures':len(failures),'layout':layout,'file':str(R/'glyph-proof.json')},ensure_ascii=False),flush=True);sys.exit(1 if failures else 0)
