const fs=require('node:fs'),path=require('node:path');
const ts=require('/workspace/xk-website/node_modules/typescript');
const root=process.argv[2],out=process.argv[3];
const files=[];
function walk(dir){for(const item of fs.readdirSync(dir,{withFileTypes:true})){const p=path.join(dir,item.name);if(item.isDirectory())walk(p);else if(/\.(tsx?|jsx?)$/.test(p)&&!/(?:privacy|\/dev\/|\.test\.)/.test(p)&&/(?:contact|quotation|inquiry|website-core)/.test(p))files.push(p);}}
walk(path.join(root,'src'));
const result=files.sort().map(file=>{const source=fs.readFileSync(file,'utf8'),ast=ts.createSourceFile(file,source,ts.ScriptTarget.Latest,true),strings=[];function visit(n){if(ts.isStringLiteral(n)||ts.isNoSubstitutionTemplateLiteral(n)||ts.isJsxText(n)||ts.isTemplateHead(n)||ts.isTemplateMiddle(n)||ts.isTemplateTail(n))strings.push(n.text);ts.forEachChild(n,visit);}visit(ast);return{file:path.relative(root,file),strings};});
fs.writeFileSync(out,JSON.stringify({scope:'Public Contact/Quotation/inquiry source literals and JSX text only; no App execution, values, storage or private/dev sources.',files:result},null,2)+'\n');console.log(JSON.stringify({files:result.length,strings:result.reduce((n,r)=>n+r.strings.length,0),out}));
