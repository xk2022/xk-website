#!/usr/bin/env python3
"""Offline reproducible font subsetting; writes only a fresh candidate directory."""
import argparse,hashlib,json,re,shutil,datetime
from pathlib import Path
from html.parser import HTMLParser
from fontTools.ttLib import TTFont
from fontTools import subset
from fontTools.unicodedata import mirrored
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def points(value):
 result=set()
 for item in value.split(','):
  pair=item.strip().upper().removeprefix('U+').split('-');low=int(pair[0].replace('?','0'),16);high=int(pair[-1].replace('?','F'),16);result.update(range(low,high+1))
 return result
def ranges(values):
 result=[]
 for value in sorted(values):
  if result and value==result[-1][1]+1:result[-1][1]=value
  else:result.append([value,value])
 return result
def css_range(values):return ','.join('U+'+format(a,'X')+('-'+format(b,'X')if b!=a else'')for a,b in ranges(values))
class Text(HTMLParser):
 def __init__(self):super().__init__(convert_charrefs=True);self.skip=0;self.text=[]
 def handle_starttag(self,tag,attrs):
  if tag in {'script','style'}:self.skip+=1
  if not self.skip:
   self.text.extend(v for k,v in attrs if v and(k in {'placeholder','alt','title'}or k.startswith('aria-')))
 def handle_endtag(self,tag):
  if tag in {'script','style'}:self.skip-=1
 def handle_data(self,data):
  if not self.skip:self.text.append(data)
def strings(value):
 if isinstance(value,str):yield value
 elif isinstance(value,dict):
  for v in value.values():yield from strings(v)
 elif isinstance(value,list):
  for v in value:yield from strings(v)
def main():
 p=argparse.ArgumentParser();p.add_argument('--source',type=Path,required=True);p.add_argument('--baseline-out',type=Path,required=True);p.add_argument('--catalog',type=Path,required=True);p.add_argument('--dynamic',type=Path,required=True);p.add_argument('--upstream',type=Path,required=True);p.add_argument('--destination',type=Path,required=True);p.add_argument('--font-modified',type=int,required=True);a=p.parse_args();assert not a.destination.exists();a.destination.mkdir();fonts=a.destination/'fonts';fonts.mkdir()
 contract=json.loads((a.source/'scripts/fixtures/design-collection-contract.json').read_text());paths=contract['publishedPaths'];assert len(paths)==49;corpus=[];inputs=[]
 for route in paths:
  file=a.baseline_out/('index.html'if route=='/'else route.strip('/')+'/index.html');parser=Text();parser.feed(file.read_text());corpus.extend(parser.text);inputs.append({'path':str(file),'sha256':sha(file)})
 corpus.extend(strings(json.loads(a.catalog.read_text())));dynamic=json.loads(a.dynamic.read_text());corpus.extend(s for row in dynamic['files']for s in row['strings']);inputs.extend({'path':str(a.source/row['file']),'sha256':sha(a.source/row['file'])}for row in dynamic['files']);inputs.extend([{'path':str(a.catalog),'sha256':sha(a.catalog)},{'path':str(a.dynamic),'sha256':sha(a.dynamic)}]);chars={ord(c)for text in corpus for c in text};css=next(p for p in(a.baseline_out/'_next/static/chunks').glob('*.css')if'font-family:Noto Sans TC;'in p.read_text());faces=[];fallback=[];union=set();cmaps={};original_fonts=[]
 for block in re.findall(r'@font-face\{([^}]+)\}',css.read_text()):
  if re.search(r'font-family:[\"\']?Noto Sans TC Fallback',block):fallback.append('@font-face{'+block+'}');continue
  if'font-family:Noto Sans TC;'not in block:continue
  source=re.search(r'src:url\(([^)]+)\)',block)[1];file=(css.parent/source).resolve();coverage=points(re.search(r'unicode-range:([^;]+)',block)[1]);font=TTFont(file);cmap=font.getBestCmap();cmaps[file.name]=cmap;union|=coverage;original_fonts.append({'file':file.name,'sha256':sha(file),'bytes':file.stat().st_size,'version':font['name'].getDebugName(5),'axes':[(x.axisTag,x.minValue,x.defaultValue,x.maxValue)for x in font['fvar'].axes]});faces.append({'block':block,'file':file,'coverage':coverage,'cmap':set(cmap)});font.close();shutil.copyfile(file,fonts/file.name)
 assert len(faces)==108 and len(fallback)==1
 actual_original=set().union(*(f['coverage']&f['cmap']for f in faces));master=TTFont(a.upstream/'NotoSansTC[wght].ttf');master_cmap=master.getBestCmap();core=chars&union&actual_original&set(master_cmap);requested_core=set(core);core|={v for c in tuple(core)if (v:=mirrored(c))is not None and v in union and v in actual_original and v in master_cmap};assert core;version=master['name'].getDebugName(5);assert all(r['version']==version for r in original_fonts)
 opts=subset.Options();opts.layout_features=['*'];opts.layout_scripts=['*'];opts.layout_closure=True;opts.glyph_names=True;opts.name_IDs=['*'];opts.name_legacy=True;opts.name_languages=['*'];opts.notdef_glyph=True;opts.notdef_outline=True;opts.recommended_glyphs=True;opts.recalc_timestamp=False;worker=subset.Subsetter(options=opts);uvs_pairs=[{'selector':selector,'base':base,'glyph':glyph}for table in master['cmap'].tables if table.format==14 for selector,values in table.uvsDict.items()for base,glyph in values if base in core];uvs_selectors={r['selector']for r in uvs_pairs};worker.populate(unicodes=core|uvs_selectors);worker.subset(master);extra=set(master.getBestCmap())-core;missing=core-set(master.getBestCmap());print(json.dumps({'subsetExtra':sorted(extra),'subsetMissing':sorted(missing)},ensure_ascii=False),flush=True);assert not extra and not missing
 master.recalcTimestamp=False;master['head'].modified=a.font_modified;master.flavor='woff2';core_path=fonts/'noto-sans-tc-core.woff2';master.save(core_path);master.close();loaded=TTFont(core_path);assert set(loaded.getBestCmap())==core;axes=[{'tag':x.axisTag,'min':x.minValue,'default':x.defaultValue,'max':x.maxValue}for x in loaded['fvar'].axes];assert axes==[{'tag':'wght','min':100.0,'default':100.0,'max':900.0}];loaded.close()
 css_rules=['/* Same upstream glyphs, one core; native same-family legacy ranges retain unknown text. */','@font-face{font-family:"Noto Sans TC";font-style:normal;font-weight:100 900;font-display:swap;src:url("./fonts/noto-sans-tc-core.woff2")format("woff2");unicode-range:'+css_range(core)+';}'];partitions=[];remaining_union=set()
 for face in faces:
  rest=face['coverage']-core;remaining_union|=rest;partitions.append({'file':face['file'].name,'originalRanges':ranges(face['coverage']),'remainingRanges':ranges(rest),'removedCoreCount':len(face['coverage']&core),'originalSha256':sha(face['file'])})
  if rest:
   block=re.sub(r'src:url\([^)]+\)',lambda _: 'src:url("./fonts/'+face['file'].name+'")',face['block']);block=re.sub(r'unicode-range:[^;]+',lambda _:'unicode-range:'+css_range(rest),block);css_rules.append('@font-face{'+block+'}')
 assert not(core&remaining_union)and core|remaining_union==union;css_rules.extend(fallback);(a.destination/'noto-sans-tc.css').write_text('\n'.join(css_rules)+'\n');shutil.copyfile(a.upstream/'OFL.txt',a.destination/'OFL.txt');(a.destination/'corpus.txt').write_text(''.join(chr(c)for c in sorted(chars)));(a.destination/'codepoints.json').write_text(json.dumps({'core':sorted(core),'originalCoverageRanges':ranges(union),'coreRanges':ranges(core),'remainingCoverageRanges':ranges(remaining_union)},indent=2)+'\n')
 fallback_cp=next((c for c in [0x9f98,0x9f49,0x9ea4,0x9f8d]if c in actual_original-core),min(actual_original-core));legacy=next(f for f in faces if fallback_cp in f['coverage']and fallback_cp in f['cmap']);manifest={'status':'GENERATED_PROOF_PENDING','createdAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'command':__import__('sys').argv,'fontToolsVersion':__import__('fontTools').__version__,'upstreamCommit':'b950a7257470b900078f2bf3223823a8602de7e1','masterSha256':sha(a.upstream/'NotoSansTC[wght].ttf'),'masterVersion':version,'axes':axes,'coreCodepointCount':len(core),'fontModifiedTimestamp':a.font_modified,'uvsSelectorsForClosure':sorted(uvs_selectors),'uvsPairsForCore':uvs_pairs,'requestedCorpusCoreCount':len(requested_core),'bidiClosureAdded':sorted(core-requested_core),'bidiClosureReason':'FontTools preserves mirrored Unicode companions; additions are explicitly restricted to original CSS coverage/cmap and master cmap','coreCjkCodepointCount':sum(0x3400<=c<=0x9fff or 0x20000<=c<=0x323af for c in core),'corpusCodepointCount':len(chars),'coreBytes':core_path.stat().st_size,'coreSha256':sha(core_path),'cssSha256':sha(a.destination/'noto-sans-tc.css'),'originalCss':str(css),'originalCssSha256':sha(css),'fallbackFaceExact':fallback[0],'partition':{'coreSubsetOfOriginalCoverageAndCmap':True,'coreAndLegacyDisjoint':True,'unionEqualsOriginalCoverage':True,'originalCoveragePointCount':len(union),'remainingCoveragePointCount':len(remaining_union),'faces':partitions},'fallbackTest':{'codepoint':fallback_cp,'unicode':'U+'+format(fallback_cp,'X'),'character':chr(fallback_cp),'originalFile':legacy['file'].name,'originalSha256':sha(legacy['file']),'remainingRange':next([low,high]for low,high in ranges(legacy['coverage']-core)if low<=fallback_cp<=high)},'originalFonts':original_fonts,'inputs':inputs,'license':{'source':'OFL.txt','sha256':sha(a.upstream/'OFL.txt'),'reservedFontName':'Source','coreIdentityUsesReservedName':False,'note':'Preserve copyright/OFL. Family/PostScript Noto Sans TC/NotoSansTC-Thin do not use reserved Source name.'},'coverageExcludedFromCore':sorted(chars-set(master_cmap)),'subsetOptions':{'layout_features':['*'],'layout_scripts':['*'],'layout_closure':True,'glyph_names':True,'name_IDs':['*'],'name_legacy':True,'name_languages':['*'],'notdef_glyph':True,'notdef_outline':True,'recommended_glyphs':True,'recalc_timestamp':False}}
 (a.destination/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n');print(json.dumps({k:manifest[k]for k in ['status','coreCodepointCount','coreCjkCodepointCount','coreBytes','coreSha256','fallbackTest']},ensure_ascii=False),flush=True)
if __name__=='__main__':main()
