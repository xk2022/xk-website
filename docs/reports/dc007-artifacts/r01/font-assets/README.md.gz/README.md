# R01 native Noto core 候選交接

使用 **candidate-v4**；v1/v2為生成工具失敗快照，v3雖普通glyph相同但缺12條必要UVS，不是最終資產。v4普通cmap882點、774CJK，281,768B，wght100–900，core SHA256 `8c1e22167a472d67e2e51c5c811b3b2c2815742d054a0994e7f49ef071b99018`。

## App-ready

- `candidate-v4/fonts/noto-sans-tc-core.woff2`。
- `candidate-v4/fonts/`內108原WOFF2，檔名與rawSHA原封不動。
- `candidate-v4/noto-sans-tc.css`，CSSfamily仍Noto Sans TC／normal／100 900／swap；core與扣除core後的legacy ranges互斥，聯集恰等原16661普通coverage點。所有src是相對fonts/路徑，交Next CSS bundler雜湊，不使用public新cache政策。
- `candidate-v4/OFL.txt`完整保留；Arial fallback face規則的原始metrics在manifest/facts逐字保存。
- `candidate-v4/codepoints.json`與原始manifest是維護／稽核輸入，不要當大型Client資料引入。Root可製作compact App manifest，完整原始資料另封存。

`verified-facts.json`是本次凍結事實清單，含全部證據路徑／bytes／SHA。普通glyph 882×4＝3528、retained glyph1259×4＝5036、UVS12×4＝48，400/500/600/700下均為exact decomposed outline＋advance，沒有tolerance或度量正規化；真receipt Exit0。GSUB/GPOS/GDEF/BASE與相同subset重編譯資料一致，保留locl；普通cmap沒有加入FE00/FE01，僅保必要cmap14及其glyph閉包。

這些proof不等於所有Browser跨舊shard文字shaping／換行／print或效能已通過，仍由Root執行正式候選驗收。沒有新Browser、server、build或Git操作由本owner執行。

## Source／License

原Font來自精確已驗Next/font/google build：`/tmp/xk-dc007-build/out`。108舊Noto及115整體字體metadata／rawSHA實讀保留；並未拿當前Gstatic新檔覆蓋它們。

同版母檔固定Google Fonts commit `b950a7257470b900078f2bf3223823a8602de7e1`：

```text
https://raw.githubusercontent.com/google/fonts/b950a7257470b900078f2bf3223823a8602de7e1/ofl/notosanstc/NotoSansTC%5Bwght%5D.ttf
master sha256 864727d210d54f2537bbe23b3a839436c3992af72de9322af5270897246bd44f
```

母檔與原WOFF2皆Version2.004-H2、wght100–900；更重要的是實際glyph／advance proof，而非只比name。OFL首行明定Reserved Font Name **Source**；Noto Sans TC Thin／NotoSansTC-Thin等identity沒有使用該RFN，copyright及完整OFL保留。

當前Google Fonts CSS v40的108個range對應font已下載比對，rawSHA全不等舊build；五個舊version first-file probe亦未匹配。因此`gstatic-provenance-v2.json`及其真Exit1只是保留「不匹配」證據，**不是已找回舊字體exact URL**。舊exact Gstatic URLs未保存，facts誠實列null，不冒充。授權來源是固定Google Fonts master＋OFL，原glyph相容性是實測proof。

## 可重生模式

原`generate-core-v4.py`／`generate-core-final.py`是完整49HTML＋catalog＋公共Contact/Quotation AST corpus、原CSS-range與cmap交集的生成快照；它們的舊/tmp路徑是當次輸入，不宜偽裝成日後任意repo可直接運作的通用命令。完整原manifest、原CSS、codepoints及工具都應隨原始證據封存。新增文案時須重新稽核corpus及原coverage／UVS，不能只手加字碼。

日常「從repo已reviewed glyph清單重生相同core」使用小型`regenerate-font-core.py`，只需repo codepoints與固定母檔，不依舊/tmp/out或49舊HTML，不改npm依賴：

```sh
python3 -m pip install --target /tmp/xk-font-tools FontTools==4.61.1 Brotli==1.1.0
# 將上述固定URL母檔下載至/tmp/noto-sans-tc-master.ttf；script會核其SHA。
PYTHONPATH=/tmp/xk-font-tools python3 scripts/regenerate-font-core.py \
  --master /tmp/noto-sans-tc-master.ttf \
  --master-sha256 864727d210d54f2537bbe23b3a839436c3992af72de9322af5270897246bd44f \
  --codepoints src/app/fonts/codepoints.json \
  --modified 3878588441 \
  --expected-sha256 8c1e22167a472d67e2e51c5c811b3b2c2815742d054a0994e7f49ef071b99018 \
  --output /tmp/noto-core-reproduced.woff2
```

固定head.modified是為重現v4既有bytes，不能依執行當下時間改字體。`reproduction.json`真Exit0已證完整snapshot重生core及CSS逐byte相同。這支pure-repo小工具只完成AST語法檢查，Root可在exclusive採樣後用同命令做一次真執行；不要在效能採樣時加入重CPU作業。它拒絕覆蓋既有asset，或在master／輸出SHA不匹配時報錯，不會靜默替換正式font。

## 原失敗保留

- generation／v2：FontTools預設bidi closure增加U+003C。v3顯式在原coverage內加鏡射閉包，cmap精確相等，未放寬範圍。
- proof首版：工具語法錯誤；v2：錯誤假設postformat3未編碼glyph名稱存檔後不會重建。改用確定GID order映射，普通／全部retained glyph exact proof才完成。
- v3：辨識原UVS後發現缺必要cmap14，保留舊版本，v4顯式保12UVS並重新完整proof。
- Gstatic比對不匹配保留真Exit1，不拿它當授權或raw-origin成功。
