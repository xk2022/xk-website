#!/usr/bin/env python3
from pathlib import Path
import datetime, hashlib, json
from fontTools.ttLib import TTFont
import fontTools
R=Path('/tmp/xk-dc007-r01/font-assets/table-experiments')
S=Path('/workspace/xk-website/src/app/fonts/fonts/noto-sans-tc-core.woff2')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
expected='8c1e22167a472d67e2e51c5c811b3b2c2815742d054a0994e7f49ef071b99018'
assert sha(S)==expected
f=TTFont(S,recalcTimestamp=False)
tables=sorted([{'tag':tag,'rawBytes':len(f.getTableData(tag)),'rawSha256':hashlib.sha256(f.getTableData(tag)).hexdigest()}for tag in f.keys()if tag!='GlyphOrder'],key=lambda r:-r['rawBytes'])
layout={}
for tag in ['GSUB','GPOS']:
 t=f[tag].table
 layout[tag]={'rawBytes':len(f.getTableData(tag)),'features':[r.FeatureTag for r in t.FeatureList.FeatureRecord],'scripts':[{'tag':r.ScriptTag,'hasDefault':r.Script.DefaultLangSys is not None,'languages':[x.LangSysTag for x in r.Script.LangSysRecord]}for r in t.ScriptList.ScriptRecord]}
layout_raw=sum(x['rawBytes']for x in layout.values())
out={'status':'COMPLETE','candidateAcceptance':'NO_CANDIDATE','checkedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'fontToolsVersion':fontTools.version,'source':str(S),'sourceSha256Before':expected,'sourceSha256After':sha(S),'sourceWoff2Bytes':S.stat().st_size,'tables':tables,'rawTotalBytes':sum(t['rawBytes']for t in tables),'axes':[{'tag':a.axisTag,'min':a.minValue,'default':a.defaultValue,'max':a.maxValue}for a in f['fvar'].axes],'ordinaryCmapCount':len(f.getBestCmap()),'glyphCount':len(f.getGlyphOrder()),'layout':layout,'experimentA':{'status':'Not Applicable','reason':'Exact source is TrueType glyf/gvar and has neither CFF nor CFF2. CFF2 subroutine inlining cannot apply; converting outlines to another format is outside the preservation contract.','generatedFile':None,'proofExecuted':False},'experimentB':{'status':'Not Executed','reason':'Owner permits language pruning only with substantial table potential. GSUB+GPOS total only15854 raw bytes,5.63%of current WOFF2 size; this raw/encoded ratio is screening context, not a mathematical bound on compressed saving. No evidence for required>=15% saving; pruning would alter original layout contract.','rawLayoutBytes':layout_raw,'rawLayoutRelativeToCurrentWoff2Percent':100*layout_raw/S.stat().st_size,'minimumSavingForFullProofBytes':.15*S.stat().st_size,'generatedFile':None,'proofExecuted':False},'limitation':'This is a read-only feasibility inspection, not a font or performance acceptance PASS. No repository write, build, browser, sampling, glyph normalization, rounding or feature removal occurred.'}
assert out['sourceSha256Before']==out['sourceSha256After']
(R/'result.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'status':out['status'],'candidateAcceptance':out['candidateAcceptance'],'sourceWoff2Bytes':out['sourceWoff2Bytes'],'A':out['experimentA']['status'],'B':out['experimentB']['status'],'result':str(R/'result.json')},ensure_ascii=False))
