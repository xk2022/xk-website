#!/usr/bin/env python3
from pathlib import Path
import datetime, hashlib, json, sys, time
from fontTools.ttLib import TTFont
from fontTools.varLib.instancer import instantiateVariableFont
from fontTools.pens.recordingPen import DecomposingRecordingPen
import fontTools
R=Path('/tmp/xk-dc007-r01/font-assets/range-400-700')
S=Path('/workspace/xk-website/src/app/fonts/fonts/noto-sans-tc-core.woff2')
C=R/'noto-sans-tc-core-400-700.woff2'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def stamp():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def save(name,data):
 (R/name).write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')
def axes(f):return [{'tag':a.axisTag,'min':a.minValue,'default':a.defaultValue,'max':a.maxValue}for a in f['fvar'].axes]
def signature(gs,name):
 g=gs[name];p=DecomposingRecordingPen(gs);g.draw(p);return {'advance':g.width,'outline':p.value}
def digest(v):return hashlib.sha256(json.dumps(v,separators=(',',':')).encode()).hexdigest()
def features(f):
 return {tag:{'features':[r.FeatureTag for r in f[tag].table.FeatureList.FeatureRecord]if f[tag].table.FeatureList else [],'scripts':[r.ScriptTag for r in f[tag].table.ScriptList.ScriptRecord]if f[tag].table.ScriptList else [],'sha256':hashlib.sha256(f[tag].compile(f)).hexdigest()} for tag in ['GSUB','GPOS']if tag in f}
def uvs(f):
 return {(sel,cp):name for table in f['cmap'].tables if table.format==14 for sel,rows in table.uvsDict.items()for cp,name in rows}
start=stamp();assert sha(S)=='8c1e22167a472d67e2e51c5c811b3b2c2815742d054a0994e7f49ef071b99018'
old=TTFont(S,recalcTimestamp=False);original_axes=axes(old)
t=time.monotonic();new=instantiateVariableFont(TTFont(S,recalcTimestamp=False),{'wght':(400,700)},inplace=True,optimize=True)
new['head'].modified=old['head'].modified;new.flavor='woff2';new.save(C);new=TTFont(C,recalcTimestamp=False)
base={'status':'PENDING','startedAt':start,'generatedAt':stamp(),'fontToolsVersion':fontTools.version,'source':str(S),'sourceSha256':sha(S),'sourceBytes':S.stat().st_size,'candidate':str(C),'candidateSha256':sha(C),'candidateBytes':C.stat().st_size,'savedBytes':S.stat().st_size-C.stat().st_size,'savingPercent':100*(1-C.stat().st_size/S.stat().st_size),'sourceAxes':original_axes,'candidateAxes':axes(new),'generationSeconds':time.monotonic()-t,'proof':'Exact Python equality of decomposed outlines and advance width, no tolerance or coordinate normalization','weights':[400,500,600,700]}
save('generation.json',base);print(json.dumps({'stage':'generated',**base}),flush=True)
oldmap=old.getBestCmap();newmap=new.getBestCmap();assert set(oldmap)==set(newmap) and len(oldmap)==882
uvold=uvs(old);uvnew=uvs(new);assert set(uvold)==set(uvnew) and len(uvold)==12
assert old.getGlyphOrder()==new.getGlyphOrder()
feature_old=features(old);feature_new=features(new)
assert {k:{q:v for q,v in row.items()if q!='sha256'}for k,row in feature_old.items()}=={k:{q:v for q,v in row.items()if q!='sha256'}for k,row in feature_new.items()}
checks=[];failures=[];uvchecks=[]
for w in [400,500,600,700]:
 oldgs=old.getGlyphSet(location={'wght':w});newgs=new.getGlyphSet(location={'wght':w})
 for cp in sorted(oldmap):
  a=signature(oldgs,oldmap[cp]);b=signature(newgs,newmap[cp]);ok=a==b
  row={'codepoint':cp,'unicode':f'U+{cp:04X}','weight':w,'status':'PASS'if ok else'FAIL','sourceSignature':digest(a),'candidateSignature':digest(b),'sourceAdvance':a['advance'],'candidateAdvance':b['advance']};checks.append(row)
  if not ok:
   failures.append({**row,'source':a,'candidate':b})
 for (selector,cp),name in sorted(uvold.items()):
  assert (name is None)==(uvnew[(selector,cp)]is None)
  a=signature(oldgs,name or oldmap[cp]);b=signature(newgs,uvnew[(selector,cp)]or newmap[cp]);ok=a==b
  row={'base':cp,'selector':selector,'weight':w,'default':name is None,'status':'PASS'if ok else'FAIL','sourceSignature':digest(a),'candidateSignature':digest(b)};uvchecks.append(row)
  if not ok:failures.append({**row,'source':a,'candidate':b})
 print(json.dumps({'stage':'weight-proof','weight':w,'checks':len(checks),'uvsChecks':len(uvchecks),'failures':len(failures)}),flush=True)
 assert sha(S)==base['sourceSha256']
result={**base,'status':'FAIL'if failures else'PASS','finishedAt':stamp(),'expectedOrdinaryChecks':3528,'actualOrdinaryChecks':len(checks),'expectedUVSChecks':48,'actualUVSChecks':len(uvchecks),'cmapCoverageUnchanged':True,'glyphOrderUnchanged':True,'layoutFeaturesAndScriptsUnchanged':True,'layoutTables':{'source':feature_old,'candidate':feature_new},'layoutTableBytesEqual':{tag:feature_old[tag]['sha256']==feature_new[tag]['sha256']for tag in feature_old},'failures':failures,'checks':checks,'uvsChecks':uvchecks,'sourceSha256After':sha(S),'candidateSha256After':sha(C),'limitation':'No browser/rendering/performance result. Source core had prior exact proof against pinned original at these weights. Range outside400..700 is deliberately absent and must remain available separately in any future application candidate.'}
save('proof.json',result);print(json.dumps({k:result[k]for k in ['status','candidateBytes','savingPercent','actualOrdinaryChecks','actualUVSChecks']}),flush=True);sys.exit(1 if failures else 0)
