import pathlib,re,json,urllib.request,hashlib,concurrent.futures,datetime
r=pathlib.Path('/tmp/xk-dc007-r01/font-assets');base=pathlib.Path('/tmp/xk-dc007-build/out');oldcss=next(p for p in(base/'_next/static/chunks').glob('*.css')if'font-family:Noto Sans TC;'in p.read_text());
def norm(s):
 result=set()
 for x in s.split(','):
  v=x.strip().upper().removeprefix('U+').split('-');result.update(range(int(v[0].replace('?','0'),16),int(v[-1].replace('?','F'),16)+1))
 return tuple(sorted(result))
old={}
for b in re.findall(r'@font-face\{([^}]+)\}',oldcss.read_text()):
 if'font-family:Noto Sans TC;'in b:
  ur=re.search('unicode-range:([^;]+)',b)[1];file=(oldcss.parent/re.search(r'src:url\(([^)]+)\)',b)[1]).resolve();old[norm(ur)]=file
items=[]
for b in re.findall(r'@font-face\s*\{([^}]+)\}',(r/'upstream/google-fonts.css').read_text()):
 ur=re.search(r'unicode-range:\s*([^;]+)',b)[1];url=re.search(r'url\(([^)]+)\)',b)[1];assert norm(ur)in old;items.append((old[norm(ur)],url))
assert len(items)==108
def fetch(item):
 file,url=item;data=urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'XK-Font-Provenance-Audit'}),timeout=35).read();local=hashlib.sha256(file.read_bytes()).hexdigest();remote=hashlib.sha256(data).hexdigest();return{'file':file.name,'gstaticSource':url,'localSha256':local,'remoteSha256':remote,'bytes':len(data),'identical':local==remote}
with concurrent.futures.ThreadPoolExecutor(max_workers=4)as pool:records=list(pool.map(fetch,items))
p=r/'gstatic-provenance-v2.json';p.write_text(json.dumps({'checkedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Current Google Fonts CSS gstatic URLs independently fetched and exact raw bytes compared with original build files; this corroborates origin, not a claim that a historical build network log was recovered.','cssQuery':'https://fonts.googleapis.com/css2?family=Noto+Sans+TC:wght@100..900&display=swap','cssSha256':hashlib.sha256((r/'upstream/google-fonts.css').read_bytes()).hexdigest(),'fontCount':108,'identicalCount':sum(x['identical']for x in records),'records':records},indent=2)+'\n');print(json.dumps({'count':108,'identical':sum(x['identical']for x in records),'path':str(p)}));assert all(x['identical']for x in records)
