# Native Core 單一預載 pilot v4

外層真Exit1，完成於2026-11-27T01:56:37.574361+00:00。3個LH子程序均Exit0／MEASURED；LCP median1735.101ms、CLS0，TBT median377.809ms仍FAIL。此為單頁3次pilot，不是正式18after。

| Run | FCP | Core完成 | 跨FCP Layout blocking | 共享092r JS blocking | Core附近0c98 Layout blocking | TBT |
|---|---:|---:|---:|---:|---:|---:|
| 1 | 1788.932 | 3394.225 | 85.525 | 163.827 | 190.320 | 439.672 |
| 2 | 1735.101 | 3394.259 | 45.482 | 157.325 | 129.552 | 332.359 |
| 3 | 1667.406 | 3362.691 | 76.978 | 153.956 | 146.875 | 377.809 |

三筆只有Inter與NotoCore兩個font完成事件，Core URL採預載.p.woff2且沒有多載legacy。Core仍在3.36–3.39秒完成，晚於1.67–1.79秒FCP，故這次預載沒有實現「Core在首繪前完成、移除late layout」的假設。沒有將未知headers補200、沒有改profile或觀測窗口。

剩餘仍是三種task：初始Inter附近跨FCP排版、共享ReactDOM-containing JS，以及Core完成附近Style/Layout。數值依Lighthouse13.6原TBTUtils先clip至精確FCP/TTI再減50ms，由RunTask原始微秒重算，三筆與LH audit相符（容差.002ms）。不把整份Layout／longtask總和當TBT。

Trace只給document layoutRoot／約1147objects，不能由此將成本指認為Footer某個連結；上一輪static DOM複雜度僅供隔離實驗選擇。v3與v4樣本範圍重疊且host不可完全控制，不能僅比較一次median就保證預載單一因果收益。

本agent未啟Browser／Build／render或新字形運算。原before18、pilotsv1/v2/v3全保留，等待Root依實際機制決定下一個小候選及正式驗收；本結果未解除任何Required／AT／network門檻，沒有fieldINP／CWVp75通過聲明。
