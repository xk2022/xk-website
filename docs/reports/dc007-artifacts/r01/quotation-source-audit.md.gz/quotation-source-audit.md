# Quotation 初始 Client／A4 source audit

範圍：exclusive after18期間只讀來源及22KB catalog；未執行App／CPU測試／Browser／render／build／trace分析。這是候選定位，不是成本或接受PASS。

- **Intl不是反覆建構**：`calculation.ts:104`已module-singleton，106–113共用。`toLocaleString`只在pending＋knownMin條件（estimator48、summary63、inquiry22），fresh default的buildId=null／empty totals不走這些分支。不能將cold額外JS時間歸因formatter迴圈。
- **初始不是17addon全部試算／繪製**：`calculation.ts:69–82`沒有build就回空結果；`summary.tsx:43–53`只顯示選方案提示。catalog9build/17addon是有限資料，不支持大幅重構。靜態website build-card格式化呼叫數見JSON，不是量測CPU。
- **最直接layout候選**：`globals.css:307–314`只選`.quotation-screen-only`非首區；A4是`summary.tsx:19`的`.quotation-preview-section`，不在CV集合，且`estimator.tsx:420`無條件render。其`quotation.css:22–64`使用container/cqw與整份A4 DOM；summary29/72/73有eagerLogo＋兩QR。可獨立測screen-only CV，不改目前print68–82，但需真earlyprint／summaryanchor／focus／可見預覽／8PDF＋QR證明。不能只說@screen就保證所有列印正確。
- **較後面的JS小候選**：`estimator.tsx:139`每render重算新estimate，420傳A4；`storage.ts:40–61`hydrate後切hydrated=true時selection可仍同default。`useMemo([selection,catalog])`＋`React.memo(QuotationSummary)`可避免status-only的再render，PII／selection真的改動仍更新。不會免除第一次hydrate，未量到收益，不預報省50ms。
- setter／serialize／calculate確有重複sanitize，但這些是小catalog保護邊界，不是已證cold主因，本輪不要為此改ID相容／價格／storage契約。

等Root釋出exclusive後再以Quote與Home同source真trace的FCP／TTI clip比較Script與Style；目前不把共享ReactDOM URL當作某函式唯一因果。
