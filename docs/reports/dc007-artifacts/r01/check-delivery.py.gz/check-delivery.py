from pathlib import Path
import json,gzip,hashlib,re,subprocess,urllib.parse,datetime,importlib.util
R=Path('/workspace/xk-website');P=Path('/tmp/xk-dc007-r01');rows=[]
def sha(b):return hashlib.sha256(b).hexdigest()
def ck(k,ok,actual):rows.append({'testId':k,'status':'PASS' if ok else 'FAIL','actual':actual})
f=json.loads((P/'source-after-v2.json').read_text());bad=[v['path'] for v in f['files'] if sha((R/v['path']).read_bytes())!=v['sha256']];ck('R01-FINAL-SOURCE',len(f['files'])==337 and not bad,{'fingerprint':f['sha256'],'mismatches':bad})
for name in ['package-lock.json','next.config.ts','.github/workflows/ci.yml','scripts/build-github-pages.mjs']:
 ck('PRESERVE-'+name,(R/name).read_bytes()==subprocess.check_output(['git','show',f['headBefore']+':'+name],cwd=R),name)
pkg=json.loads((R/'package.json').read_text());old=json.loads(subprocess.check_output(['git','show',f['headBefore']+':package.json'],cwd=R));ck('PRESERVE-DEPENDENCIES',all(pkg.get(k)==old.get(k)for k in ['dependencies','devDependencies']),{'dependenciesEqual':pkg.get('dependencies')==old.get('dependencies'),'devDependenciesEqual':pkg.get('devDependencies')==old.get('devDependencies')})
manifest=R/'docs/reports/dc007-artifacts/r01/manifest.json';m=json.loads(manifest.read_text());bad=[]
for v in m['files']:
 p=R/v['path'] if v['storage']=='repo-reference' else manifest.parent/v['path'];b=p.read_bytes();raw=gzip.decompress(b)if v['encoding']=='gzip' else b
 if sha(b)!=v['encodedSha256'] or len(b)!=v['encodedBytes'] or sha(raw)!=v['rawSha256'] or len(raw)!=v['rawBytes']:bad.append(v['logicalPath'])
ck('R01-ARCHIVE-INTEGRITY',not bad,{'records':len(m['files']),'bad':bad,'storedPayloadBytes':m['storedPayloadBytes']})
changed=subprocess.check_output(['git','diff','--name-only',f['headBefore']],cwd=R,text=True).splitlines();new=subprocess.check_output(['git','ls-files','--others','--exclude-standard'],cwd=R,text=True).splitlines();paths=sorted(set(changed+new));md=[p for p in paths if p.endswith('.md')];links=[];errors=[]
def anchors(t):
 out=set(re.findall(r'<a\s+(?:id|name)=[\"\']([^\"\']+)',t));seen={}
 for h in re.findall(r'^#{1,6}\s+(.+?)\s*#*$',t,re.M):
  h=re.sub(r'!?\[([^\]]+)\]\([^)]*\)',r'\1',h);h=re.sub(r'<[^>]+>','',h);slug=re.sub(r'[^\w\-\s]','',h.lower());slug=re.sub(r'\s','-',slug);n=seen.get(slug,0);seen[slug]=n+1;out.add(slug+('-'+str(n)if n else ''))
 return out
for name in md:
 p=R/name;t=p.read_text();ck('FORMAT-'+name,not re.search(r'[ \t]+$',t,re.M)and t.endswith('\n')and not t.endswith('\n\n'),name);ck('FENCES-'+name,len(re.findall(r'^```',t,re.M))%2==0,name)
 active=re.sub(r'^```[^\n]*\n.*?^```[^\n]*$','',t,flags=re.S|re.M)
 for raw in re.findall(r'!?\[[^\]]*\]\(([^\n)]+)\)',active):
  target=raw.strip().strip('<>');u=urllib.parse.urlsplit(target)
  if u.scheme or target.startswith('//'):continue
  dest=(p.parent/urllib.parse.unquote(u.path)).resolve()if u.path else p.resolve();ok=dest.exists()
  if ok and u.fragment and dest.is_file()and dest.suffix=='.md':ok=urllib.parse.unquote(u.fragment)in anchors(dest.read_text())
  row={'source':name,'target':target,'existsAndAnchor':ok};links.append(row)
  if not ok:errors.append(row)
ck('MARKDOWN-LOCAL-LINKS',not errors,{'documents':len(md),'links':len(links),'errors':errors})
forbidden=[n for n in paths if any(x in {'.next','out','node_modules','.env','.env.local','__pycache__'}for x in Path(n).parts)];ck('NO-GENERATED-OR-SECRET-FILES',not forbidden,forbidden)
for n,expect in [(f'quality-v2/{k}.json',0)for k in ['npm-ci','typegen','typescript','lint','unit','normal-build','pages-build']]+[('after-v2-process.json',1),('warm-final-v2-process.json',0)]:
 d=json.loads((P/n).read_text());ck('ACTUAL-EXIT-'+n,d['exitCode']==expect and d['terminationReason']=='completed',{'observed':d['exitCode'],'expected':expect,'receipt':n})
d=json.loads((P/'after-v2/summary.json').read_text());ck('PRESERVED-PERFORMANCE-FAIL',d['captureStatus']=='COMPLETE'and len(d['runs'])==18 and sum(g['status']=='FAIL'for g in d['groups'])==3,{'groups':[{ 'style':g['style'],'page':g['page'],'status':g['status']}for g in d['groups']]})
diff=subprocess.run(['git','diff','--check'],cwd=R,capture_output=True,text=True);ck('DIFF-CHECK',diff.returncode==0,diff.stdout+diff.stderr)
result={'testId':'R01-FINAL-DELIVERY-INTEGRITY','status':'FAIL'if any(x['status']=='FAIL'for x in rows)else'PASS','scope':'Source/docs/attachments/actual-exit integrity only. Not performance PASS, full DC007 release, human AT, CI or deployment. All original FAIL preserved.','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'checks':rows,'counts':{'checks':len(rows),'failures':sum(x['status']=='FAIL'for x in rows)},'changedFiles':paths,'markdownLinks':links}
(P/'final-delivery-integrity.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'status':result['status'],'counts':result['counts'],'failures':[x for x in rows if x['status']=='FAIL']},ensure_ascii=False));raise SystemExit(1 if result['status']=='FAIL' else 0)
