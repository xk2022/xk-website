from pathlib import Path
import os,json,signal,socket,time,datetime
p=Path('/proc/157893');cmd=[x.decode() for x in (p/'cmdline').read_bytes().split(b'\0') if x];assert cmd==['next-server (v16.4.6)'],cmd
s=(p/'stat').read_text();parts=s[s.rfind(')')+2:].split();assert parts[19]=='31010333';parent=Path('/proc')/parts[1];args=[x.decode() for x in (parent/'cmdline').read_bytes().split(b'\0') if x];expected='node node_modules/next/dist/bin/next start --hostname 127.0.0.1 --port 3280';assert args[-1]==expected and '/workspace/xk-website' in args
os.kill(157893,signal.SIGTERM)
for _ in range(100):
 s=socket.socket();code=s.connect_ex(('127.0.0.1',3280));s.close()
 if code==111:break
 time.sleep(.05)
assert code==111,code
r={'status':'PASS','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'pid':157893,'parentPid':parent.name,'parentCommand':expected,'ownershipEvidence':'Original exec launch + exact startTicks and parent sandbox command-cwd, not a broad process-name kill','port':3280,'connectEx':code,'other3200ServerUntouched':True};Path('/tmp/xk-dc007-r01/normal-server-stop.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r))
