import json,pathlib,hashlib,datetime,re
from html.parser import HTMLParser
P=pathlib.Path('/tmp/xk-dc007-r01');series=P/'pilot-v3';summary=json.loads((series/'summary.json').read_text());rows=[];sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for r in summary['runs']:
 report=pathlib.Path(r['report']);d=json.loads(report.read_text());m=d['audits']['metrics']['details']['items'][0];origin=m['observedTimeOriginTs'];fcp=(m['observedFirstContentfulPaintTs']-origin)/1000;tti=(m['interactiveTs']-origin)/1000;trace=report.parent/report.name.replace('.report.json','-0.trace.json');es=json.loads(trace.read_text())['traceEvents'];nav=next(e for e in es if e['name']=='navigationStart'and e.get('args',{}).get('data',{}).get('documentLoaderURL')=='http://127.0.0.1:3281/');events=sorted([e for e in es if e.get('pid')==nav['pid']and e.get('tid')==nav['tid']],key=lambda e:e['ts']);tasks=[]
 for e in events:
  if e['name']not in {'RunTask','ThreadControllerImpl::RunTask','ThreadControllerImpl::DoWork','TaskQueueManager::ProcessTaskFromWorkQueue'}or not e.get('dur'):continue
  start=(e['ts']-origin)/1000;end=(e['ts']+e['dur']-origin)/1000
  if tasks and start<tasks[-1]['endMs']:tasks[-1]['endMs']=start-.001
  tasks.append({'startMs':start,'endMs':end,'durationMs':e['dur']/1000})
 fonts=[{'timeMs':(e['ts']-origin)/1000,'url':e['args'].get('url'),'fontName':e['args'].get('name')}for e in events if e['name']=='RemoteFontLoaded'];layouts=[{'startMs':(e['ts']-origin)/1000,'durationMs':e.get('dur',0)/1000,'beginData':e['args'].get('beginData'),'endData':e['args'].get('endData')}for e in events if e['name']=='Layout'and e.get('args',{}).get('beginData',{}).get('frame')==nav['args']['frame']];debug=d['audits']['long-tasks']['details']['debugData'];contributing=[]
 for t in tasks:
  impact=max(0,min(t['endMs'],tti)-max(t['startMs'],fcp)-50)
  if impact<=0:continue
  nearest=min(debug['tasks'],key=lambda q:abs(q['startTime']-t['startMs']));assert abs(nearest['startTime']-t['startMs'])<.2
  t.update(fcpClippedBlockingMs=impact,url=debug['urls'][nearest['urlIndex']],approxAuditCategoryMs={k:v for k,v in nearest.items()if k not in {'startTime','duration','urlIndex'}},layouts=[q for q in layouts if t['startMs']<=q['startMs']<t['endMs']]);contributing.append(t)
 total=sum(t['fcpClippedBlockingMs']for t in contributing);assert abs(total-d['audits']['total-blocking-time']['numericValue'])<.002
 rows.append({'run':r['testId'],'metrics':r['metrics'],'fcpMs':fcp,'ttiMs':tti,'recomputedFcpTtiClippedTbtMs':total,'reportedTbtMs':d['audits']['total-blocking-time']['numericValue'],'exactReconciliationToleranceMs':.002,'contributingTasks':contributing,'fontCompletions':fonts,'fontNetwork':[q for q in d['audits']['network-requests']['details']['items']if q.get('resourceType')=='Font'],'allMainframeLayouts':layouts,'mainThreadAudit':d['audits']['mainthread-work-breakdown']['details']['items'],'report':str(report),'reportSha256':sha(report),'trace':str(trace),'traceSha256':sha(trace)})
class Doc(HTMLParser):
 def __init__(self):super().__init__();self.root={'tag':'root','attrs':{},'children':[],'text':''};self.stack=[self.root];self.nodes=[]
 def handle_starttag(self,t,a):
  n={'tag':t,'attrs':dict(a),'children':[],'text':''};self.stack[-1]['children'].append(n);self.nodes.append(n)
  if t not in {'area','base','br','col','embed','hr','img','input','link','meta','param','source','track','wbr'}:self.stack.append(n)
 def handle_endtag(self,t):
  for i in range(len(self.stack)-1,0,-1):
   if self.stack[i]['tag']==t:self.stack=self.stack[:i];return
 def handle_data(self,v):
  if not any(n['tag']in {'script','style'}for n in self.stack):
   for n in self.stack:n['text']+=v
html=pathlib.Path('/workspace/xk-website/out/index.html');doc=Doc();doc.feed(html.read_text())
def flatten(n):return[n]+[x for c in n['children']for x in flatten(c)]
def stat(n):
 ns=flatten(n);return{'tag':n['tag'],'id':n['attrs'].get('id'),'ariaLabelledby':n['attrs'].get('aria-labelledby'),'domElementCount':len(ns),'textCodepoints':len(re.sub(r'\s+','',n['text'])),'links':sum(q['tag']=='a'for q in ns),'images':sum(q['tag']=='img'for q in ns)}
blocks=[n for n in doc.nodes if n['tag']in {'header','footer'}or n['tag']=='section'];dom={'source':str(html),'sha256':sha(html),'scope':'Static HTML element/text counts only, not render-time cost attribution. Root Layout trace identifies document, not per-section milliseconds.','blocks':[stat(n)for n in blocks]};out={'status':'PILOT3_TBT_FAIL','generatedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Read-only nativeCore ModernHome3 pilot; no new browser/render/build/glyph work. Original prior pilots preserved.','actualOuterReceipt':json.loads((P/'pilot-v3-process.json').read_text()),'groups':summary['groups'],'rows':rows,'tbtMethod':'Lighthouse13.6 TBTUtils clips each top-level schedulable task to exact FCP→TTI, then subtracts50ms; preserves overlap correction1microsecond from TraceProcessor. Sum reconciles actual LH audit within.002ms. Never uses sum of Layout or longtasks as substitute.','tbtSource':'/tmp/xk-task011/tools/node_modules/@paulirish/trace_engine/models/trace/lantern/metrics/TBTUtils.js','domComplexity':dom,'limitations':['Only one NotoCore RemoteFontLoaded completion afterFCP perrun; this is evidence of one Core font load, not instrumentation counting every CSS font swap.','Mainframe Layout roots are#document with~1147dirty objects. No trace measurement assigns per-section milliseconds, so Footer or cards cannot be called proven unique bottleneck.','Static counts can rank a scoped layout-isolation experiment; no automatic semantic/AT/hash/focus/print safety claim.'],'fieldWindow':None,'inpMs':None};f=P/'pilot-v3-trace-comparison.json';f.write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'path':str(f),'sha256':sha(f),'rows':[{'run':r['run'],'fcp':r['fcpMs'],'tti':r['ttiMs'],'tbt':r['recomputedFcpTtiClippedTbtMs'],'tasks':[{'start':q['startMs'],'duration':q['durationMs'],'blocking':q['fcpClippedBlockingMs'],'url':q['url']}for q in r['contributingTasks']]}for r in rows],'dom':dom['blocks']},ensure_ascii=False))
