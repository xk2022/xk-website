# R01 字體 detached-face pilot v2：實際結果

更新：2026-11-27T01:21:30.483537+00:00

三筆capture完整、三個LH子程序均真Exit0；外層依門檻真Exit1。Formal18after尚未跑；舊before、v1、v2資料及原FAIL各自保留。此處不開Browser或新採樣。

| Metric | v2 values | v2 median [range] | Fresh-before median | 判定 |
|---|---|---|---|---|
| lcpMs | 1605.137, 1559.892, 1652.480 | **1605.137** [1559.892–1652.480] | 1762.650 | PASS |
| cls | 0.000, 0.000, 0.000 | **0.000** [0.000–0.000] | 0.000 | PASS |
| tbtMs | 1578.914, 1507.061, 1399.386 | **1507.061** [1399.386–1578.914] | 1306.136 | FAIL |

TBT median1507.061ms，對fresh-before1306.136ms上升15.38%；v1診斷median729.956ms另存，不混入。21份before/v2設定完全一致，仍LH13.6/Chrome156/375×812/DPR1/CPU4/150ms/200000down/93750up及原受控server，無改門檻。

## 仍有Layout與新增JS成本

| v2 run | font請求 | 最後font完成ms | afterFCP Layout ms | afterFCP>50ms | 其中font後≤20ms |
|---|---:|---:|---:|---:|---:|
| 1 | 17 | 8690.755 | 1200.630 | 11 | 9 |
| 2 | 17 | 8781.070 | 898.337 | 8 | 8 |
| 3 | 17 | 8694.257 | 1000.543 | 10 | 10 |

115個WOFF2產物仍全部同檔名／rawSHA，實際載入17個font仍包含v1的額外NotoLatin。r1有約2089.6ms開始744.7ms長task（其中Script Evaluation710.9ms、GC30.3ms），全run ScriptEval1177.401ms；末段8715.646ms的mainframe Layout349.342ms亦保留。font完成後多次>50ms Layout仍存在，不支持只剩一次全頁layout的假設。

候選source有一個具體可疑新增同步熱點：prepareFaces每條rule用originals.find，再在find內反覆normalize兩個長unicodeRange字串；108×108比較與重複分配可在不改語意下先改成一次normalization/Map查詢，但仍須JS owner callframe／新pilot證明，不能僅憑ReactDOM bundle URL歸咎React本身。此診斷不自行改App，也不把未實作的Map視為已修好。

同時需要分開驗證為何detached faces完成仍伴隨Layout；目前只有時序及source條件，沒有明確activation Performance marks，不能杜撰精確啟用時刻或唯一因果。後續若有新策略應保留這三筆原FAIL，新source／sameprofile重新量測；正式接受仍需18after/6warm與49兩模式／字體視覺／anchors/focus／A4/QR回歸。

機器事實見comparison-v2.json及pilot-v2-trace-comparison.json。沒有field INP／CWV p75或release PASS聲明。
