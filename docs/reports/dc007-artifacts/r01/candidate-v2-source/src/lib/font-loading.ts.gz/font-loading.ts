/** Internal alias for the same self-hosted Noto Sans TC files, not a new font. */
export const NOTO_BATCH_FAMILY = "XK Noto Sans TC Batch";

/** Match CSS unicode-range descriptors without splitting supplementary characters. */
export function unicodeRangeMatches(range: string, points: readonly number[]): boolean {
  return range.split(",").some((part) => {
    const value = part.trim().match(/^u\+([0-9a-f?]+)(?:-([0-9a-f]+))?$/i);
    const start = value?.[1];
    if (!start || start.length > 6) return false;
    if (start.includes("?") && (value?.[2] || !/^[0-9a-f]*\?+$/i.test(start))) return false;
    const low = Number.parseInt(start.replaceAll("?", "0"), 16);
    const high = Number.parseInt(value?.[2] ?? start.replaceAll("?", "f"), 16);
    return low <= high && high <= 0x10ffff && points.some((point) => point >= low && point <= high);
  });
}
