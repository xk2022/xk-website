"use client";

import { useEffect } from "react";

import { NOTO_BATCH_FAMILY, unicodeRangeMatches } from "@/lib/font-loading";

const normalize = (value: string) => value.replaceAll(/["'\s]/g, "").toLowerCase();

function fontRules(rules: CSSRuleList): CSSFontFaceRule[] {
  return Array.from(rules).flatMap((rule) => {
    if (rule.type === CSSRule.FONT_FACE_RULE) return [rule as CSSFontFaceRule];
    return "cssRules" in rule ? fontRules(rule.cssRules as CSSRuleList) : [];
  });
}

/** Prepare detached faces; their individual completions must not invalidate layout. */
function prepareFaces(family: string) {
  const primary = normalize(family.split(",")[0] ?? "");
  const originals = Array.from(document.fonts).filter((face) => normalize(face.family) === primary);
  const rules = Array.from(document.styleSheets).flatMap((sheet) => {
    try { return fontRules(sheet.cssRules); } catch { return []; }
  }).filter((rule) => normalize(rule.style.getPropertyValue("font-family")) === primary);

  if (rules.length === 0 || rules.length !== originals.length) throw new Error("Font descriptors unavailable");
  return rules.map((rule) => {
    const range = rule.style.getPropertyValue("unicode-range");
    const original = originals.find((face) => normalize(face.unicodeRange) === normalize(range));
    const match = rule.style.getPropertyValue("src").match(/url\((?:"([^"]+)"|'([^']+)'|([^\s)]+))\)/);
    const source = match?.[1] ?? match?.[2] ?? match?.[3];
    if (!original || !source) throw new Error("Font source unavailable");
    const url = new URL(source, rule.parentStyleSheet?.href ?? document.baseURI);
    if (url.origin !== location.origin || !url.pathname.startsWith("/_next/static/media/") || url.search || url.hash) {
      throw new Error("Font source must remain self-hosted");
    }
    return new FontFace(NOTO_BATCH_FAMILY, `url("${url.href}")`, {
      style: original.style,
      weight: original.weight,
      stretch: original.stretch,
      unicodeRange: original.unicodeRange,
      display: original.display,
      featureSettings: original.featureSettings,
      ascentOverride: original.ascentOverride,
      descentOverride: original.descentOverride,
      lineGapOverride: original.lineGapOverride,
    });
  });
}

/** Reuse the original font bytes/axes and commit the prepared faces in one task. */
export function FontLoadingController({ family }: Readonly<{ family: string }>) {
  useEffect(() => {
    const root = document.documentElement;
    let disposed = false;
    let activated = false;
    let timeout: ReturnType<typeof setTimeout> | undefined;

    const activate = (result: "ready" | "native" | "native-print", faces?: FontFace[]) => {
      if (disposed || activated) return;
      activated = true;
      clearTimeout(timeout);
      if (result === "ready" && faces) {
        // The CSS family stays constant: no document-wide custom-property swap.
        // Unused ranges remain native lazy faces for later pages and user text.
        for (const face of faces) document.fonts.add(face);
      } else {
        root.style.setProperty("--font-noto-sans-tc", family);
      }
      root.dataset.fontLoading = result;
    };
    const beforePrint = () => activate("native-print");
    window.addEventListener("beforeprint", beforePrint);

    if (!document.fonts?.add || typeof FontFace !== "function") {
      activate("native");
    } else {
      root.dataset.fontLoading = "loading";
      // innerText includes the rendered page, not input values or RSC scripts.
      // Keep this sample in memory; do not persist it or send it to a service.
      const points = Array.from(new Set(Array.from(document.body.innerText)), (char) => char.codePointAt(0)!);
      timeout = setTimeout(() => activate("native"), 15_000);
      void Promise.resolve().then(async () => {
        const faces = prepareFaces(family);
        const needed = faces.filter((face) => unicodeRangeMatches(face.unicodeRange, points));
        if (needed.length === 0) throw new Error("No matching font faces");
        await Promise.all(needed.map((face) => face.load()));
        activate("ready", faces);
      }).catch(() => activate("native"));
    }

    return () => {
      disposed = true;
      clearTimeout(timeout);
      window.removeEventListener("beforeprint", beforePrint);
    };
  }, [family]);

  return null;
}
