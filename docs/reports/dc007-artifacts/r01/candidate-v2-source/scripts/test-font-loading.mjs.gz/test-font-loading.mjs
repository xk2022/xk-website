import assert from "node:assert/strict";
import test from "node:test";

import { unicodeRangeMatches } from "../src/lib/font-loading.ts";

const cases = [
  ["inclusive CJK lower bound", "U+4E00-9FFF", [0x4e00], true],
  ["inclusive CJK upper bound", "U+4E00-9FFF", [0x9fff], true],
  ["outside the CJK range", "U+4E00-9FFF", [0x3400, 0xa000], false],
  ["one codepoint descriptor", "U+3001", [0x3001], true],
  ["one codepoint does not include its neighbour", "U+3001", [0x3002], false],
  ["comma-separated ranges", "U+20-7E, U+3000-303F", [0x3001], true],
  ["case and surrounding whitespace", " u+00a0-00ff , U+4e00 ", [0x4e00], true],
  ["wildcard lower bound", "U+4??", [0x400], true],
  ["wildcard upper bound", "U+4??", [0x4ff], true],
  ["outside wildcard", "U+4??", [0x500], false],
  ["supplementary CJK codepoint", "U+20000-2A6DF", Array.from("𠀀", (char) => char.codePointAt(0)), true],
  ["surrogate halves are not supplementary codepoints", "U+20000-2A6DF", [0xd840, 0xdc00], false],
  ["empty sample", "U+0-10FFFF", [], false],
  ["empty descriptor", "", [0x4e00], false],
  ["malformed descriptor", "not a range", [0x4e00], false],
  ["reversed bounds", "U+9FFF-4E00", [0x5000], false],
  ["outside Unicode", "U+110000", [0x110000], false],
  ["nontrailing wildcard is invalid", "U+4?1", [0x441], false],
  ["wildcard combined with range is invalid", "U+4??-5FF", [0x440], false],
];

for (const [name, range, points, expected] of cases) {
  test(name, () => assert.equal(unicodeRangeMatches(range, points), expected));
}
