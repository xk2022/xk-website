# DC-007-R01：JS／Hydration 唯讀診斷

2026-11-27。Root 指定 `/workspace/xk-website`、`test/design-collection-release`、預期 head `3b2eb50`；本分工未使用 Git 獨立認證 head。已讀目前 AGENTS、subagent workflow、DC-007／工作包及既有報告。沒有改 App、依賴、Git、build、server、瀏覽器或量測 profile。

**建議本輪先處理已重複觀察的字體完成後全頁 layout 成本。** JS／React 初始化確實有成本，但目前證據不支持刪功能、全面改寫 Client Components、移除動畫或換 framework 來達成 TBT。既有六組 cold 全未達標；本文件沒有 after、改善率或新的效能 PASS。

## 證據版本與界限

- 唯讀比對目前 `src/`、`public/`、package／lock／Next config 共 **198 檔**，全部 SHA 與原 `/tmp/xk-dc007/source.json` 相同。這支持既有 runtime 證據適用；不是本輪新 build 或 fresh timing。
- 實際輸出取 `/tmp/xk-dc007-build/out` 與其 `.next/server/app/*client-reference-manifest.js`。原始 Lighthouse18份／trace／DevTools log 在 `/tmp/xk-dc007/performance/cold`；暖快取互動在 `warm-v2`。完整逐檔 SHA、實際 network rows、manifest、chunk 字串簽名保存在 [js-evidence.json](js-evidence.json)。
- 解析既有 chunk 時只在隔離 VM 收集 Turbopack factory registrations，**未呼叫 factory**；沒有瀏覽器或 App 執行。結果見 [module-registrations.json](module-registrations.json)。同 module ID 重複註冊證明 payload 重複，不能當作 effect／元件被 hydrate 兩次的證據。
- 以下是 lab 的 main-thread 分類，不是 field INP，也不能把 Script Evaluation 全部命名為「自製元件 hydration」。沒有足夠 source-mapped callstack 可把某個 hook 單獨定為根因。

## 實際 CPU／傳輸相對量

每組三次既有 cold、CPU4／375×812／150ms／200000Bps；CPU 欄為三次中位數，JS 傳輸欄列 r1 實際 network transfer（含 HTTP overhead），不是 HTML 預估下載。

| 風格／頁面 | TBT median ms | Style/Layout median ms | Script Evaluation median ms | Parse/Compile median ms | 實際 JS transfer B |
| --- | ---: | ---: | ---: | ---: | ---: |
| Modern Home | 1552.949 | 2129.9 | 601.6 | 78.0 | 165012 |
| Modern Quotation | 1294.676 | 1860.7 | 729.9 | 66.2 | 186660 |
| Heritage Home | 1441.245 | 2063.1 | 460.8 | 68.4 | 171400 |
| Heritage Quotation | 1225.644 | 1882.6 | 624.2 | 76.1 | 200627 |
| Luxury Home | 1305.136 | 1909.9 | 500.9 | 68.1 | 171400 |
| Luxury Quotation | 1201.206 | 1872.4 | 594.2 | 71.9 | 200627 |

Style/Layout 約為 JS evaluation 的 2.6–4.5 倍；主線程分類可重疊於長 task，不可將這些欄位相加或相減當作某修法的 TBT 收益。原 ModernHome 三 trace 的 Layout 合計1499–2228ms，12–13次 >50ms Layout 緊接 RemoteFontLoaded ≤20ms；dirty objects 約1147。`cold-home-diagnostic.json` 已有精確事件／SHA。這是時序關聯，仍需單變數對照驗證因果。

ModernHome r1 的 `092r-mewpaf3q.js`（ReactDOM／Next App Router）scripting463.821ms，另有247.1ms script-evaluation 長 task；`0c98xzjfks9hq.js`（Next client router/cache）scripting88.388ms。六組 r1 的 bootup 大項都落在這兩個共用 framework chunks，沒有足夠資料將其全歸給 StyleSwitcher 或某個計算函數。GC不是既有 trace 的主要成本。

實際 font transfer 約1.02–1.09MB，佔各 r1 總傳輸76–79%；JS只佔12–15%。ModernHome HTML雖列201341B gzip6腳本、H/L Home207380B、H/L Quotation235907B，這些是**HTML全部 script tags 的離線總和**。其中 `0cz1d0mv5g_q7.js` 是 `nomodule` polyfill（39473B gzip6），目前 Chromium 沒請求它，不能把它當作這18次可移除的 JS 負擔。ModernQuotation另因實際預抓取得一個不在其初始 script 清單的共享 chunk，亦說明 HTML總和不能取代 network。

## Client 邊界已相當受限

公開自訂 `use client` UI共7檔：Modern mobile menu、Heritage navigation、Luxury navigation、StyleSwitcher、ContactCopyEmail、ContactInquiryForm、QuotationEstimator；另有 quotation storage hook。`src/components/dev/button-demo.tsx` 是開發樣本，不是公開頁 Client 入口。三套 Frame、首頁內容、Services／Portfolio／detail compositions、Footer 與 navigation-model/content adapter 仍是 Server Components。

| 來源 | 需要保留的行為／成本界線 |
| --- | --- |
| `src/components/design-collection/shared/style-switcher.tsx:1–5`、`src/lib/design-collection/navigation-model.ts:27–38` | server 建立公開 route／slug／anchor model後才跨 Client 邊界；未將完整 business DTO送入 switcher |
| `src/components/design-collection/shared/style-switcher-client.tsx:12–56` | pathname／hash訂閱與啟動前刷新 href；只有事件驅動、單次可取消 rAF，無輪詢。三次49項 find 不是已證明的熱點；先前 stale-path修復與原生新分頁／hash契約應保留 |
| `src/components/layout/mobile-navigation.tsx:20–55` | open 時的 Escape／outside handlers、一次 matchMedia 訂閱；清理齊全，沒有 scroll loop |
| `src/components/design-collection/{heritage,luxury}/*navigation.tsx:15–49` | 原生 details，加上 Escape／outside／focus／band點擊協調；未見持續 effect loop |
| `src/components/sections/contact/contact-inquiry-form.tsx:19–65` | 必要 controlled fields、hydration gate、錯誤／預覽 focus、Activity／bfcache個資清除；這些不是可刪的裝飾 JS |
| `src/components/sections/quotation/quotation-estimator.tsx:77–143`、`src/lib/quotation/storage.ts:47–95` | 同一選項 store、catalog filter、計算／摘要、僅 IDs存盤；snapshot 已按raw快取，並非每frame寫localStorage |

QuotationSummary沒有自己的 `use client` 宣告，但因 Estimator import，屬其 Client dependency graph；每次選項／個人欄位更新會更新摘要。`quotation-estimator.tsx:134–143` 每次 render 都做 filter／calculate／inquiry；資料只有4services／9builds／17addons。暖快取已有64–256ms EventTiming及選項更新 long tasks，但缺乏 callstack 證明小型 pure calculation 是主要成本，不能由「每次 render」直接推論需要大型 memo/refactor。

## 重複載入：確有少量 code registration 重疊，沒有三份業務邏輯

- 三系列 Quotation 都使用同一 **`07buvx6m299d9.js`**（51017B raw／14774B gzip6），裡面是共用 estimator／summary／pricing／storage；Home初始清單沒有這份程式。三風格沒有各自再實作計價或表單控制器。
- `[style]` server routes 同時 import Heritage／Luxury compositions，例如 `src/app/(collection)/design-collection/[style]/page.tsx:2–5,16–18`。因此 H/L頁 manifest 同列兩個 native navigation client refs；兩個 Home 的 initial script清單完全相同。這是共用動態 route 的 module graph，不代表兩套 Frame 同時顯示或執行。
- 根 `src/app/not-found.tsx:1–5` 用 ModernFrame，故 H/L manifest／實際初載也帶 Modern `MobileNavigation` 所需的 `452t24sb17p93.js`（2150B gzip6）與共用 chunk。這保留了真404單Frame和完整導覽；直接拔掉會改功能。
- `StyleSwitcherClient` module ID **81044** 同時存在已載入的 `3mab9m1_i1erf.js` 和 `0w6oqdb1ed0rf.js`；pure navigation ID18566亦重疊。H/L Home有8個重複註冊ID、Contact15、Quotation16；Modern這三類頁為0。其他重疊包括 Next image/link helpers與Radix Slot／Button utilities。`module-registrations.json`列完整來源chunk與factory指紋。
- `src/components/ui/button.tsx:3,66` 用 Radix Slot支援 `asChild`；不是載入整套互動元件就可直接刪 Radix。factory grouping的bytes會相互重疊，未將它們加總成假的可節省容量。

H/L Home HTML腳本gzip總和只比Modern多6039B；實際JS transfer差6388B，還伴隨不同Image/Frame module graph。這個量級不足以直接解釋約1.2–1.6秒的TBT，亦不能據此保證拆module會省同等時間。

## 動畫／第三方

[animation-thirdparty-inventory.md](animation-thirdparty-inventory.md)記錄逐檔行號與18份原 DevTools logs：732個requestWillBeSent hostname全為loopback；沒有 analytics、tag manager、外部 runtime、Framer/GSAP/Lottie或持續自排程 JS動畫。next/font輸出是同源woff2；JSON-LD是資料，不能當作追蹤script移除。H/L Quotation的少量CSS button色彩轉場已結束，不能當成持續動畫或TBT根因。`AnimationFrame`瀏覽器pipeline名稱不等於App rAF callback。

## 建議優先序／最小實驗

1. **優先字體／排版候選，保留整體 JS架構。** 採用其他owner的最小單變數 font/layout候選，保持Inter／Noto、字重、色彩、三風格、所有文字與標準A4；先以同profile三次ModernHome對照，再擴六組。字體完成後 layout是目前最大可重複觀察，沒有宣稱某個CSS屬性一定有效。
2. **低風險實作階段不動必需的 hydration／PII hooks。** 保留現有 Server/Client邊界、共享計算、原生menus與switcher所有啟動語義。不刪JSON-LD、不延後到首次互動才hydrate表單、不懶載入印表摘要或QR；後者會重演已修復的列印時效與漏內容風險。
3. **若主因改善後仍需降JS，再單獨處理實測重複。** 先研究能否讓root404與目前page的client dependency graph共享既有module，避免同ID code重複，保持路由／404版型／native links。這是有具體8/15/16ID證據的次要候選，**不是本輪直接拆49routes或重造Frame的理由**。Server dynamic import並不保證Client chunk自動分割，須讀Next16.4.6文件並以實產物證明；收益目前未量測。
4. **預抓策略僅作後續小實驗。** 三Footer目錄有49個NextLink（`site-footer.tsx:43,59`及兩style Frame）；Next本身只有一個共享IntersectionObserver，不是49個獨立 observer。r1僅見4–6個RSC請求／約27–38KB，不支持全站關閉預抓能解本次TBT。若想降低實際可見目錄預抓，可只對該目錄比較 `prefetch={false}`，保留原URL／Link／新分頁／鍵盤，量測點擊延遲與cold/warm；**不可為消除QA取消紀錄而關閉預抓或泛略錯誤**。
5. **暫不為小資料加泛用memo層。** 可於另輪具體profile顯示pure計算成本後，才將 `calculateQuotation(selection,catalog)` 以穩定依賴局部memo，避免個人欄位改字重算。不能預估它能修好TBT，也不能延後摘要、清除或儲存時序。

變更前後須保留所有樣本，固定瀏覽器／CPU／網路／cache及獨占時窗。先驗證實際腳本傳輸、同ID重複與Layout/JS分類是否真降，再報時間收益；原 TBT FAIL、Human AT／transport限制不由這份source診斷解除。原始計價／Contact／Switcher／Storage／PII／print、49路由SEO和五寬的重驗範圍依實際修改決定，不能只以bundle變小代替功能驗收。
