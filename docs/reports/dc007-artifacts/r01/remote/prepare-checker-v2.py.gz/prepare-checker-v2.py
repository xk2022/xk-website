from pathlib import Path
import ast
import hashlib
import json

remote = Path('/tmp/xk-dc007-r01/remote')
original = remote / 'inspect-ci-artifact.py'
target = remote / 'inspect-ci-artifact-v2.py'
baseline_path = remote / 'artifact-baseline/baseline.json'
source_manifest_path = remote / 'artifact-baseline/source-manifest.json'
repo = Path('/workspace/xk-website')
assert not target.exists(), 'Do not replace an existing checker revision'
sha = lambda raw: hashlib.sha256(raw).hexdigest()
original_raw = original.read_bytes()
baseline_raw = baseline_path.read_bytes()
manifest_raw = source_manifest_path.read_bytes()
frozen = json.loads(baseline_raw)
manifest = json.loads(manifest_raw)
rows = {row['path']: row for row in manifest['files']}
output_path = 'fonts/OFL-Noto-Sans-TC.txt'
source_paths = ['public/' + output_path, 'src/app/fonts/OFL.txt']
license_bytes = (repo / source_paths[0]).read_bytes()
license_sha = sha(license_bytes)
ssot_path = 'src/app/fonts/font-assets.json'
ssot_bytes = (repo / ssot_path).read_bytes()
ssot = json.loads(ssot_bytes)
ssot_license = ssot['license']
assert sha(manifest_raw) == frozen['sourceSnapshot']['rawSha256']
assert ssot_license['identifier'] == 'OFL-1.1' and ssot_license['file'] == 'OFL.txt'
assert ssot_license['sha256'] == license_sha
assert license_bytes.decode('utf-8').splitlines()[0] == ssot_license['firstLine']
assert rows[ssot_path]['sha256'] == sha(ssot_bytes) and rows[ssot_path]['bytes'] == len(ssot_bytes)
for path in source_paths:
    assert (repo / path).read_bytes() == license_bytes
    assert rows[path]['sha256'] == license_sha and rows[path]['bytes'] == len(license_bytes)
entry = frozen['inventory']['files'][output_path]
assert entry['sha256'] == license_sha and entry['bytes'] == len(license_bytes)
assert frozen['normalizedFileSha256'][output_path] == license_sha
approved = {'path': output_path, 'bytes': len(license_bytes), 'sha256': license_sha,
            'sourcePaths': source_paths, 'ssotPath': ssot_path, 'ssotSha256': sha(ssot_bytes),
            'ssotLicense': ssot_license}
constant = 'APPROVED_PUBLIC_FONT_LICENSE = ' + repr(approved) + '\n'
helper = '''def approved_public_font_license(name, data, frozen):
    contract = APPROVED_PUBLIC_FONT_LICENSE
    if name != contract['path'] or data is None:
        return False
    expected = (contract['bytes'], contract['sha256'])
    baseline = frozen['inventory']['files'].get(name, {})
    if (len(data), sha(data)) != expected or (baseline.get('bytes'), baseline.get('sha256')) != expected:
        return False
    if frozen['normalizedFileSha256'].get(name) != contract['sha256']:
        return False
    manifest_bytes = (BASELINE / 'source-manifest.json').read_bytes()
    if sha(manifest_bytes) != frozen['sourceSnapshot']['rawSha256']:
        return False
    rows = {row['path']: row for row in json.loads(manifest_bytes)['files']}
    if rows.get(contract['ssotPath'], {}).get('sha256') != contract['ssotSha256']:
        return False
    license_record = contract['ssotLicense']
    if (license_record.get('identifier'), license_record.get('file'), license_record.get('sha256')) != ('OFL-1.1', 'OFL.txt', contract['sha256']):
        return False
    if data.decode('utf-8').splitlines()[0] != license_record['firstLine']:
        return False
    return all((rows.get(path, {}).get('bytes'), rows.get(path, {}).get('sha256')) == expected for path in contract['sourcePaths'])


'''
before = "    check('RSC payloads belong only to public/error routes', [], [name for name in files if name.endswith('.txt')\n          and name != 'robots.txt' and ('' if str(PurePosixPath(name).parent) == '.' else str(PurePosixPath(name).parent)) not in public_payload_dirs])"
after = "    check('RSC payloads belong only to public/error routes', [], [name for name in files if name.endswith('.txt')\n          and name != 'robots.txt' and not approved_public_font_license(name, files[name], frozen)\n          and ('' if str(PurePosixPath(name).parent) == '.' else str(PurePosixPath(name).parent)) not in public_payload_dirs])"
text = original_raw.decode('utf-8')
assert text.count(before) == 1
text = text.replace("EXPECTED_FONT_COUNT = 116\n", "EXPECTED_FONT_COUNT = 116\n" + constant, 1)
text = text.replace('def inspect(files, evidence=None):', helper + 'def inspect(files, evidence=None):', 1)
text = text.replace(before, after, 1)
ast.parse(text)
restored = text.replace(constant, '', 1).replace(helper, '', 1).replace(after, before, 1)
assert restored.encode('utf-8') == original_raw, 'Only the one RSC classification check and its exact-bound helper/constant may change'
with target.open('x') as stream:
    stream.write(text)
bridge = {'status': 'PREPARED_NOT_RUN', 'originalChecker': str(original), 'originalCheckerSha256': sha(original_raw),
          'revisedChecker': str(target), 'revisedCheckerSha256': sha(target.read_bytes()),
          'baseline': str(baseline_path), 'baselineSha256': sha(baseline_raw),
          'baselineSourceManifestSha256': sha(manifest_raw), 'approvedPublicLicense': approved,
          'singleChangedAssertion': 'RSC payloads belong only to public/error routes',
          'oldClassification': 'All .txt outside robots/public-route/error-route directories are RSC payloads',
          'newClassification': 'Only the exact approved font-license path with matching raw bytes/SHA, frozen baseline inventory/hash and SSOT/OFL source records is excluded from RSC classification',
          'byteComparisonsAndInventoryUnchanged': True, 'expectedFonts': 116, 'expectedPublicRoutes': 49,
          'sourceFileCount': frozen['sourceSnapshot']['verifiedFiles'],
          'baselineRegenerated': False, 'formalCheckerRun': False,
          'staticAstSyntax': 'PASS', 'restoringOnlySingleCheckAndHelperProducesOriginalBytes': True,
          'retainedFirstFailure': {}}
for name in ['artifact-local-check.json', 'local-check-process.json']:
    p = remote / name
    if p.exists():
        raw = p.read_bytes()
        d = json.loads(raw)
        bridge['retainedFirstFailure'][name] = {'sha256': sha(raw), 'status': d.get('status'),
                                               'passed': d.get('passed'), 'assertionCount': d.get('assertionCount'), 'exitCode': d.get('exitCode')}
with (remote / 'checker-v2-license-bridge.json').open('x') as stream:
    stream.write(json.dumps(bridge, ensure_ascii=False, indent=2) + '\n')
assert original.read_bytes() == original_raw
assert baseline_path.read_bytes() == baseline_raw
assert source_manifest_path.read_bytes() == manifest_raw
print(json.dumps({'status':'PREPARED_NOT_RUN','checker':str(target),'checkerSha256':bridge['revisedCheckerSha256'],
                  'licenseSha256':license_sha,'licenseBytes':len(license_bytes),'staticAstSyntax':'PASS',
                  'singleClassificationChangeOnly':True,'baselineUnchanged':True,'sourceFiles':bridge['sourceFileCount']}))
