from pathlib import Path
import ast
import hashlib
import json

original = Path('/tmp/xk-dc006-final/remote/inspect-ci-artifact.py')
target = Path('/tmp/xk-dc007-r01/remote/inspect-ci-artifact.py')
source = original.read_text()
assert not target.exists(), 'Do not replace an existing R01 checker'

def edit(before, after):
    global source
    assert source.count(before) == 1, before[:120]
    source = source.replace(before, after, 1)

edit('Offline DC006 navigation49 Pages artifact checks; never performs HTTP requests or builds.', 'Offline DC007 R01 49-route Pages artifact checks; never performs HTTP requests or builds.')
edit("BASELINE = HERE / 'artifact-baseline'", "BASELINE = HERE / 'artifact-baseline'\nEXPECTED_FONT_COUNT = 116")
edit('def prepare(repo, root, build_receipt):', '''def source_manifest_metadata(repo, path):
    raw = path.read_bytes()
    manifest = json.loads(raw)
    rows = manifest.get('files')
    if not isinstance(rows, list) or not rows:
        raise ValueError('Source manifest must contain its exact nonempty files inventory')
    seen = set()
    for row in rows:
        name = row['path']
        if not isinstance(name, str) or safe_name(name) != name or name in seen:
            raise ValueError('Unsafe or duplicate source manifest entry')
        seen.add(name)
        source = repo / name
        if source.is_symlink() or not source.is_file():
            raise ValueError('Source manifest path is missing or a symlink: ' + name)
        data = source.read_bytes()
        if len(data) != row['bytes'] or sha(data) != row['sha256']:
            raise ValueError('Source manifest byte mismatch: ' + name)
    return raw, {'path': str(path.resolve()), 'rawSha256': sha(raw),
                 'declaredFingerprint': manifest.get('sha256'),
                 'testId': manifest.get('testId'), 'createdAt': manifest.get('createdAt'),
                 'headBefore': manifest.get('headBefore'), 'verifiedFiles': len(rows)}


def prepare(repo, root, build_receipt, source_manifest):''')
edit("    helper = load_helper(repo / 'scripts/smoke-website.py', repo)", "    source_manifest_bytes, source_snapshot = source_manifest_metadata(repo, source_manifest)\n    helper = load_helper(repo / 'scripts/smoke-website.py', repo)")
edit('    files = read_directory(root)\n    BASELINE.mkdir()', "    files = read_directory(root)\n    if sum(name.endswith('.woff2') for name in files) != EXPECTED_FONT_COUNT:\n        raise ValueError('R01 must retain exactly 116 approved font files')\n    if len(smoke.public_pages) != 49:\n        raise ValueError('R01 must retain exactly 49 public routes')\n    BASELINE.mkdir()")
edit("    shutil.copyfile(repo / 'scripts/smoke-website.py', BASELINE / 'smoke-website.py')", "    shutil.copyfile(repo / 'scripts/smoke-website.py', BASELINE / 'smoke-website.py')\n    (BASELINE / 'source-manifest.json').write_bytes(source_manifest_bytes)")
edit("              'sourceData': smoke.data, 'sourceEnvironment': smoke.environment,", "              'sourceData': smoke.data, 'sourceEnvironment': smoke.environment,\n              'sourceSnapshot': source_snapshot,")
edit("                      'publicRoutes': len(smoke.public_pages), 'buildId': build_id(files)}))", "                      'publicRoutes': len(smoke.public_pages), 'fonts': EXPECTED_FONT_COUNT,\n                      'sourceManifestSha256': source_snapshot['rawSha256'], 'verifiedSourceFiles': source_snapshot['verifiedFiles'],\n                      'buildId': build_id(files)}))")
edit("    paths = smoke.design_contract['publishedPaths']", "    check('Frozen R01 source manifest remains byte-identical to baseline preparation',\n          frozen['sourceSnapshot']['rawSha256'], sha((BASELINE / 'source-manifest.json').read_bytes()))\n    check('R01 artifact retains exactly 116 approved font files', EXPECTED_FONT_COUNT, sum(name.endswith('.woff2') for name in files))\n    paths = smoke.design_contract['publishedPaths']")
edit("'scope': 'DC006 navigation49-route offline artifact only; no live HTTP/browser/axe/interaction or merge/deployment claim'", "'scope': 'DC007 R01 49-route offline artifact only; no live HTTP/browser/axe/interaction or merge/deployment claim'")
edit("            'helperSha256': frozen['helperSha256'], 'checkerSha256': sha(Path(__file__).read_bytes()),", "            'helperSha256': frozen['helperSha256'], 'checkerSha256': sha(Path(__file__).read_bytes()),\n            'sourceSnapshot': frozen['sourceSnapshot'],")
edit("    parser.add_argument('--build-receipt', type=Path)", "    parser.add_argument('--build-receipt', type=Path)\n    parser.add_argument('--source-manifest', type=Path, help='Exact final R01 source manifest; required only for fresh baseline preparation')")
edit("        if not args.build_receipt:\n            parser.error('--prepare requires the actual final --build-receipt')\n        prepare(args.repo, args.directory or args.repo / 'out', args.build_receipt)", "        if not args.build_receipt or not args.source_manifest:\n            parser.error('--prepare requires the actual final --build-receipt and --source-manifest')\n        prepare(args.repo, args.directory or args.repo / 'out', args.build_receipt, args.source_manifest)")
ast.parse(source)
with target.open('x') as stream:
    stream.write(source)
record = {'status': 'PREPARED_NOT_EXECUTED', 'original': str(original), 'originalSha256': hashlib.sha256(original.read_bytes()).hexdigest(),
          'copy': str(target), 'copySha256': hashlib.sha256(target.read_bytes()).hexdigest(),
          'changes': ['R01 scope labels', 'Exactly 116 woff2 and 49 public routes', 'Final source manifest verified per-file before freeze and retained with raw manifest SHA'],
          'unchangedStrictChecks': ['Full artifact file inventory', 'All runtime/static asset sizes and raw SHA256', 'Only actual Next BuildID token in HTML/RSC plus three manifest paths normalized', 'Archive safety, exact-head/digest binding, route/SEO/robots/private payload/49-Footer/switcher/links/assets/anchors/Logo checks'],
          'baselinePrepared': False, 'formalCheckerRun': False}
Path('/tmp/xk-dc007-r01/remote/checker-preparation.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(record, indent=2))
