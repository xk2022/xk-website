from pathlib import Path
import json,hashlib,datetime,struct
R=Path('/tmp/xk-dc007-r01');N=R/'qa/native-complete-pages-retained-v2';B=Path('/workspace/xk-website/docs/screenshots/design-collection/dc007');P=Path('/tmp/xk-dc007/visual-previews')
notes={
'luxury-home-320':'原viewport頂圖中Logo完整、三版band保留窄欄換行，H1為四行且與舊crop0所見相符；完整長圖可見五服務、三展示、技術／Why／Solutions、CTA及單欄三系列Footer，未見CV遺留空白段或橫向裁切。',
'luxury-home-375':'頂部Logo、詢價CTA與三版band完整，H1為三行，與舊基準頂部所見相符；長圖可見所有主要區段、三張網站展示及單欄Footer，未見不合理缺頁空洞。',
'luxury-home-768':'頂部Logo與詢價鈕左右分置，三版band橫排；H1三行與舊基準相符。長圖技術與Why區為雙欄，展示圖與Footer三列皆可見，未見主要區塊裁切。',
'luxury-home-1440':'桌面Header／Logo／導航／band完整，H1維持三行置中；完整長圖看見所有Service/Plans/Showcases/技術與CTA，Footer三欄與底部copyright可見，未見舊CV空白段。',
'luxury-home-1920':'內容維持置中max-width，Logo／桌面導航／三版band完整；H1三行，卡片節奏與舊基準所見一致。全頁長圖展示／多欄卡片／Footer皆有實際內容，無明顯橫向截斷或空白缺段。',
}
notes.update({'luxury-services-375': 'Logo與三版band完整；服務Hero兩行標題與舊基準相符，卡片、方案、Pricing、五項服務詳述、Process與CTA依序有內容；Footer為單欄三系列，未見控制項或文字塊明顯越界。', 'luxury-services-1440': '桌面導航標示服務頁，Hero單行大標題與原基準相符；長頁所有服務內容與方案條目可見，Pricing兩欄及Footer三欄保留，未見CV造成的大塊內容空白或卡片截斷。', 'luxury-portfolio-375': 'Logo與band完整，Hero兩行標題與舊基準相符；六張品牌展示預覽均可見，後續模板／Planned技術規劃／技術方向及狀態說明沒有缺段，Footer單欄完整。', 'luxury-portfolio-1440': '頂部Hero維持兩行、導航與三版band完整；全頁六張品牌圖片、技術方向卡與下方CTA均有內容，置中寬度與舊基準所見一致，Footer三欄無明顯裁切。', 'luxury-brand-showcase-march-tangbao-375': '三月手工湯包名稱維持單行，Logo與品牌標籤未變形；原生長圖可見背景／使用者情境、網站預覽與來源、設計與限制及相關服務，來源長網址正常換行、Footer單欄無橫向裁切。', 'luxury-brand-showcase-march-tangbao-1440': '桌面品牌名稱單行與舊基準相符；湯包預覽圖片、來源網址、設計取捨／功能／限制及相關CTA清楚排列，深色區域與Footer三欄完整，沒有空白缺段。', 'luxury-contact-375': 'Logo與band完整，Contact兩行Hero文字與舊基準相符；詢價欄位為單欄排列，按鈕與Email區、需求準備／下一步／資料範圍說明及Footer皆有內容，未見欄位或文段明顯裁切。', 'luxury-contact-1440': '桌面Logo／Contact導航／band完整，Hero兩行與舊基準相符；稱呼與Email兩欄、需求文字框及按鈕皆在容器內，後續說明與Footer三欄可見，沒有CV空白缺段。', 'luxury-quotation-375': '窄版Logo與band完整，試算標題單行、步驟／類型／四種建置與複雜度卡垂直排列，與舊基準的結構相符；總額、A4預覽、聯絡摘要框及Footer皆已繪出，未見整段空白或明顯橫向截斷。A4細字與真實列印不在本次縮圖判讀內。', 'luxury-quotation-1440': '桌面試算標題左置單行、右側Logo資訊卡與原基準相符；服務類型雙欄、複雜度三欄、建置卡、即時摘要與A4白紙預覽均有內容；Footer三欄完整，未見CV遺留空白。此處不替代實際列印／QR與控制操作驗證。'})
# Only add a row after actually viewing the fresh tall image, fresh original top,
# and identified baseline views. This writer never infers visual verdicts.
viewed={
'luxury-home-320':[B/'luxury-home-320.png',P/'luxury-home-320-crop0.png'],
'luxury-home-1440':[B/'luxury-home-1440.png'],
'luxury-home-375':[P/'luxury-home-375.png'],
'luxury-home-768':[P/'luxury-home-768.png'],
'luxury-home-1920':[P/'luxury-home-1920.png'],
}
for stem in ['luxury-services-375', 'luxury-services-1440', 'luxury-portfolio-375', 'luxury-portfolio-1440', 'luxury-brand-showcase-march-tangbao-375', 'luxury-brand-showcase-march-tangbao-1440', 'luxury-contact-375', 'luxury-contact-1440', 'luxury-quotation-375', 'luxury-quotation-1440']:viewed[stem]=[P/(stem+'.png')]
capture_path=N/'result.json';capture_raw=capture_path.read_bytes();capture=json.loads(capture_raw);capture_cases={c['name']:c for c in capture['cases']}
assert capture['source']['data']['sha256']=='9d18fdf7aaac71987afaae10aeb969784b0929bdd5d4f8bfd366fc1599f84936'
def artifact(p):
 raw=p.read_bytes();assert raw[:8]==b'\x89PNG\r\n\x1a\n';w,h=struct.unpack('>II',raw[16:24]);return {'path':str(p),'file':p.name,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'width':w,'height':h}
rows=[]
for stem,note in notes.items():
 tall=artifact(N/(stem+'-tall-diagnostic.png'));top=artifact(N/(stem+'-original-top.png'));base=artifact(B/(stem+'.png'))
 width=int(stem.rsplit('-',1)[1]);case=capture_cases[stem];route=case['route'];assert case['width']==width
 rows.append({'testId':stem,'route':route,'width':width,'sourceVersion':'9d18fdf7aaac71987afaae10aeb969784b0929bdd5d4f8bfd366fc1599f84936','freshTall':tall,'freshOriginalViewportTop':top,'baselineOriginal':base,'captureCaseStatus':case['status'],'tallRejectedUnchanged':case['tallRejected'],'maxGeometryDeltaOriginalRecord':case['maxObservedGeometryDelta'],'semanticDeltaCountOriginalRecord':len(case['semanticDeltas']),'baselineViewsActuallyViewed':[artifact(x)for x in viewed[stem]],'actualViews':['fresh native tall full-page image','fresh original-height top companion','listed baseline views'],'observation':note,'viewedScopeDecision':'NO_OBVIOUS_VISUAL_REGRESSION_IN_VIEWED_SCOPE','fullPageDisplayHeightCap':6000,'estimatedDisplayedFullPageWidth':round(tall['width']*min(1,6000/tall['height'])),'lineWrapScope':'Header/band and visible Hero text compared; long body reviewed structurally at reduced scale, not every glyph or line.','limitations':['Tall viewport differs from ordinary viewport; original top companion covers only initial viewport.','6000px image-tool height cap reduces full-page fine text; fractional geometry differences are not decided by this human review.','No pixel-identical assertion, automated QA override, WCAG certification, interaction result or performance result.']})
out={'status':'COMPLETE'if len(rows)==15 else'IN_PROGRESS','reviewMethod':'Actual local-image viewing, no Browser/capture or App changes. Only reviewed files listed; no invented observations for missing files.','updatedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'expectedCases':15,'reviewedCases':len(rows),'sourceVersion':'9d18fdf7aaac71987afaae10aeb969784b0929bdd5d4f8bfd366fc1599f84936','scope':'Luxury baseline15 counterparts. Native tall diagnostic and original-top images are separate evidence; rejected geometry metadata remains untouched.','pixelEquivalence':'NOT_CLAIMED','wcagCertification':'NOT_CLAIMED','automatedQaOverride':False,'captureStatusUnchanged':capture['status'],'captureEvidence':{'path':str(capture_path),'bytes':len(capture_raw),'sha256':hashlib.sha256(capture_raw).hexdigest()},'ordinaryViewportFullPageValidity':'NOT_OVERRIDDEN_BY_TALL_IMAGE_REVIEW','overallViewedScopeDecision':'NO_OBVIOUS_VISUAL_REGRESSION_IN_15_ACTUALLY_VIEWED_CASES'if len(rows)==15 else'PENDING','cases':rows}
(R/'visual/luxury-review.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'status':out['status'],'reviewedCases':len(rows),'report':str(R/'visual/luxury-review.json')},ensure_ascii=False))
