# Next HEAD 來源與取消原因：唯讀界線

結論：**可精確證明舊40筆由 Next.js 原生預取路徑發出，也可證明CDP記為 canceled；不能證明Next主動取消或取消的具體原因。** 不改monitor或歷史network門檻。

- **實際觀察**：原warm-v2六組40/40 HEAD，皆原response200 HTML及`loadingFailed.canceled=true`。CDP initiator全部由`0c98xzjfks9hq.js`的`n`（0-based line1,col37430）→`ey`（col22652）起始。
- **直接callsite證據**：前者編譯內容是`function n(e,t){return fetch(e,t)}`；後者是含RSC-prefetch標頭建立、`await fetch(url,{method:"HEAD"})`的Next`fetchRouteOnCacheMiss`。這比僅看相鄰RSC request更精確，證明發起來源。
- **原始碼**：Next16.4.6 `segment-cache/cache.js:1131–1148,1188–1203`在static-export模式先HEAD檢redirect/status，再fetch RSCtree；此HEAD沒有AbortSignal。`segment-cache/fetch.js:22–30`直接交原生fetch。
- **取消並未獲證**：`scheduler.js:130–139`的`cancelPrefetchTask`只markCanceled／移queue；`:237`明說不abort進行中的requests，`:477`仍是手動abort未來工作的TODO。不能用方法名或CDP canceled旗標反推「Next故意abort」。request initiator也不是canceller。
- **新tiny界線**：目前`qa/pages-tiny-candidate-v2/result.json`嚴格networkErrors實際3筆（226/227/228），全HEAD／原response200；沒有CDP initiator可對應。舊40筆的來源證據不回填新筆原因，原tinyFAIL保持。Root口頭初值4與此實際檔案3的差異不靠猜測補一筆。

[逐筆與source SHA](head-initiator-readonly-review.json)保存40原records、編譯offset、Next source excerpts及新tiny原records。v2 runner實際Exit0只表示唯讀診斷完成，不是網路門檻PASS。v1 receipt因錯將口頭4硬寫為tiny數量而Exit1，原log/工具保留；v2改按實際3筆讀取，沒有變更任何App或suite結果。全程沒有browser/build/server/HTTP/Git，不影響pilot採樣。
