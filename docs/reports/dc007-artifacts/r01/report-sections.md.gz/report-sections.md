<!-- R01 report sections: read-only consolidation; repository not edited. Snapshot 2026-11-27T02:13:18.615084+00:00 -->

## 起點、來源與狀態界線

沿用`test/design-collection-release`及同一Draft PR #45，初始head為`3b2eb5093f23ba6cc49e3be1da7af5138c5edfa4`，其base為`ee4b4709a9f8daa755e2595a46c158b3c92d8229`。初始PR run45871766244（#104）的Quality／Pages成功、Deploy跳過，原artifact15142713761 ZIP SHA256為`8eeb6f760fbcfb57ad4dde30d244637c51fc28a1262f6f812f52c3025921e280`。這是R01前的實際起點，**不是新候選CI或部署通過**。本段依既有remote/verification-events.json及pr45-artifact-metadata.json，沒有在本子題重新查遠端。

公司唯讀來源在2026-11-27T00:55:52Z重新核對，latest main仍`f1be01c0c5d8bc5b1238f250838e336bef47b149`、tree`84f9388877b9f73dc81276200d0164625d228c90`，與DC007固定來源0commit／0file差異；14份相關治理／工程／測試／品牌文件fresh全文核讀由來源owner記錄。沒有新公司規則支持替換字體、改Logo或調整業務。英數Inter／繁中Noto Sans TC及device fallback沿用；swap是網站既有策略限制，不冒充新公司規範。

原DC007的18個TBT FAIL、47網站圖、8PDF、incomplete／工具失敗及尚缺真人AT／原unknown network門檻全部保留。R01重建fresh before，不把歷史36個樣本混算，也不把性能改善自動擴張為完整發布、fieldINP或CWV p75通過。

## 固定量測與fresh before

Pages loopback3281、同一serve-pages.py模型：文字gzip6／hashed assets600秒／HTML no-cache與ETag；LH13.6.0、Chromium156.0.8078.79、Node24.22.1，mobile375×812／DPR1／CPU4／DevTools實際150ms／200000down／93750up B/s。每cold新Chrome process/profile並重置storage，沒有改profile或以simulated成績混比；Root將Browser／PDF／axe／build排出採樣時窗。雲端host實體頻率及背景負載仍有限制。

Fresh before source為`661f6cd2ac68add9e0887849819b8568f647b867ee72b8fa85ecf27beb39f16c`，2026-11-27T00:56:46–01:03:42Z完成18／18；18個LH子程序皆真Exit0，外層依原門檻真Exit1。六組均LCP／CLS達標而TBT失敗。以下median［min–max］，單位ms（CLS無單位）；三筆原值完整在before/summary.json。

| 頁面 | LCP | CLS | TBT | 判定 |
|---|---:|---:|---:|---|
| modern/home | 1762.650 [1644.633–1764.392] | 0.000 [0.000–0.000] | 1306.136 [991.173–1392.539] | FAIL：TBT |
| modern/quotation | 1614.841 [1565.926–1616.265] | 0.000 [0.000–0.000] | 1125.176 [809.845–1135.686] | FAIL：TBT |
| heritage/home | 1667.109 [1577.556–1672.843] | 0.000 [0.000–0.000] | 1249.817 [1008.403–1270.489] | FAIL：TBT |
| heritage/quotation | 1691.499 [1644.150–1745.693] | 0.000 [0.000–0.000] | 912.835 [847.766–1069.803] | FAIL：TBT |
| luxury/home | 1614.508 [1575.841–1622.754] | 0.000 [0.000–0.000] | 1023.287 [873.795–1213.802] | FAIL：TBT |
| luxury/quotation | 1663.725 [1638.029–1866.440] | 0.000 [0.000–0.000] | 871.978 [778.041–1403.431] | FAIL：TBT |

## 根因與有證據的邊界

原Modern Home實際16font請求（Inter1＋Noto15），font transfer1,091,912B／全量1,380,352B，約79%；不是把115個font產物容量當初載入下載。原trace的12–13次>50ms全頁Layout緊隨RemoteFontLoaded≤20ms，dirty objects約1147；Style/Layout是主要可重複成本，GC沒有主要成本證據。多個Noto子集先後完成造成重排的假設有時序支持，但不將某一subset或單一函式當唯一根因。

共享ReactDOM-containing chunk在FCP後仍有真blocking：歷史原三筆按FCP／TTI精確clip的JS主導task為229.206／155.716／143.673ms，不可因bundle在首繪附近開始就說全在FCP前，也不可把全頁Script Evaluation約600ms當TBT或可節省量。native Core後，pilot4的該JS task仍貢獻163.827／157.325／153.956ms，約155ms量級；它是另一個真成本，但沒有source-mapped證據可歸咎某個自製hook或直接刪除標準runtime。

TBT採LH13.6實際算法：每個主執行緒RunTask先裁切至[FCP,TTI]，再減50ms。Native pilot3／4的精確復算與audit相符，沒有把Layout／longtask總和冒充TBT。Trace Layout roots只定位#document，不能把某區塊直接標為已測得多少毫秒。靜態複雜度可選隔離目標：Services157元素，Footer140元素／55anchors，但這不是區域CPU歸因。

原JS／動畫盤點沒有找到可移除的持續App rAF或第三方analytics；唯一switcher rAF是一次事件通知，其他listener有生命週期清理。舊18份network樣本732個request均同源，此範圍不擴張成所有49頁全操作都無第三方的數學證明。JSON-LD不是tracking，不能為清script而移除。

## 各候選與實際失敗（均不是正式after18）

每個有效pilot只測Modern Home三次，全部原值與原source／log保留。下表median［min–max］，TBT均仍高於200ms；不能選最好一次或將下降幅度冒充發布達標。

| Pilot | 候選 | LCP | CLS | TBT | 真外層Exit／判定 |
|---|---|---:|---:|---:|---|
| v1 | 原FontFaceSet.load批次啟用原family | 1566.837 [1523.589–1615.389] | 0.000 [0.000–0.000] | 729.956 [719.277–1034.895] | 1／FAIL |
| v2 | Detached alias faces批次加入 | 1605.137 [1559.892–1652.480] | 0.000 [0.000–0.000] | 1507.061 [1399.386–1578.914] | 1／FAIL |
| v3 | 純原生單Core＋108 legacy分區 | 1766.260 [1608.571–1884.576] | 0.000 [0.000–0.000] | 436.395 [345.740–558.090] | 1／FAIL |
| v4 | 唯一281KB Core critical preload | 1735.101 [1667.406–1788.932] | 0.000 [0.000–0.000] | 377.809 [332.359–439.672] | 1／FAIL |

- **v1**：TBT median729.956ms，對本輪fresh Home1306.136ms下降44.11%，仍FAIL。115font raw完全相同，但實際多載Noto Latin一檔25,257B，font總量1,117,169B；最後font完成約7.9–8.1秒，比before約7.3–7.4秒晚。仍多次font→Layout，不支持「只剩一次Layout」。
- **v2**：TBT median1507.061ms，反高於fresh before。r1新增744.7ms task，內ScriptEval710.9ms；prepareFaces反覆normalize長unicodeRange／108×find是可疑新增同步工作，但未用URL誤歸咎React引擎。仍有多次font後重排及末段349ms Layout。兩個Client字體控制候選未被當成正式修正，原檔快照保留後移除。
- **v3 NativeCore**：只有Inter與Core兩個font完成，Noto15個分時序列已消失。TBT median436.395ms仍FAIL；剩三類task是跨FCP初始Inter附近Layout（blocking105.684／83.956／41.468ms）、共享JS（202.981／186.840／112.018ms）及Core附近Style/Layout（249.425／165.599／192.254ms）。Core完成仍在3.41–3.69秒，晚於FCP。
- **v4 critical preload**：只有一份Core被預載，108 legacy沒有預載，無新Client。Core真的在213–230ms發request、isLinkPreload=true／High，但282,090 transferB約3.35–3.38秒才完，字體完成3.36–3.39秒，仍晚於FCP1.67–1.79秒。不是hint失效／重複下載；晚到大Layout依舊。精確blocking三類分別85.525/45.482/76.978、163.827/157.325/153.956、190.320/129.552/146.875ms。v3/v4樣本範圍重疊、host有限制，不將小median差當獨立因果保證。

### v5：server版本不符，已中止，不合資格

新server bind失敗，先前server經wrapper Control-C後仍存活；同一路徑／port並不保證已換到新的預先載入產物。Root辨識不一致後停止舊server PID154571及pilot PID156108／子LH PID156340。最外層真returnCode=-15、exitCode143，完成時間2026-11-27T02:10:01.596Z，原summary仍PENDING，沒有把它改成完成。
原資料有1筆MEASURED及1筆PENDING；已量到的值[{"lcpMs": 1939.662, "cls": 0, "tbtMs": 371.182, "fcpMs": 1939.662}]只保留診斷，**不計median／after／改善率或候選接受**。此為測試環境／版本有效性FAIL，不歸因App退化。證據：pilot-v5-server-mismatch-stop.json、pilot-v5-process.json/log。

### v6：同build7重啟正確server，結果待Root核定

本整理時Root正在同build7的native Core preload＋screen-only content-visibility:auto候選重測：Home後續section、Quotation非首區與Footer。這是後續獨立實驗，不把v5數字搬來用。有效三筆、真receipt、Core完成／TBT及幾何／anchors／focus／AT／print等結果均待該版本資料核定；本段不預填PASS，亦未另開Browser或讀新heavy trace。

## Native font資產、來源與可重生證據

採用的core候選仍為原Inter／Noto Sans TC、原wght100–900及swap/fallback，沒有改品牌字體或永久用device font。Core由49公開HTML（排script/style，含placeholder／aria／alt／title）、catalog及31個公共Contact／Quotation／inquiry檔案的2746個AST literal／JSX text建立corpus，再intersect原108 CSS普通coverage、原cmap與固定master cmap；不是把母版20745 glyph全匯入。

- 固定Google Fonts commit`b950a7257470b900078f2bf3223823a8602de7e1`，NotoSansTC[wght].ttf11,941,968B，SHA`864727d210d54f2537bbe23b3a839436c3992af72de9322af5270897246bd44f`；原WOFF與母檔均Version2.004-H2及同軸。
- 最終v4 Core281,768B，882普通codepoints／774CJK，SHA`8c1e22167a472d67e2e51c5c811b3b2c2815742d054a0994e7f49ef071b99018`；108 legacy原檔rawSHA保留。Core882與legacy剩餘15779普通CSS點互斥、聯集恰等原宣告16661點，不擴張coverage。
- 882×400/500/600/700＝3528組原CSS指定source／master／core的decomposed outline與advance逐項exact相同；全部1259 retainedglyph×4＝5036也exact相同；GSUB/GPOS/GDEF/BASE與確定subset重新編譯資料相同，locl閉包保留。這不是只比較version或畫面縮圖。
- 初v3發現缺UVS後保留舊檔、改新v4；12個必要FE00/FE01序列×4＝48組與原／master／core exact一致。Selectors沒有加入普通CSScoverage，非core字元仍保原legacy行為。
- 龘U+9F98是非core fallback測例，仍用原d2603e585543d43b-s.3jgbw7fjdxemy.woff2，SHA`16ea48778a406f69c486a7f6285dd4df9b20f1a3eed2fd4a003fbf2b19f0cb14`。Arial fallback face的原ascent/descent/line-gap/size-adjust規則逐字保留。
- OFL首行RFN是**Source**，不是Noto Sans TC。Core identity沒有使用該RFN，copyright及完整OFL保留；public/fonts公開授權副本供維護。
- 舊exact Gstatic URL未保存；當前Google CSS v40的108個對應rawSHA全部不符、舊version首檔probe亦不符，真Exit1保留，沒有用新檔冒充舊檔。Legacy來源明記精確已驗Next/font/google artifact；授權／glyph底層來源為固定master＋OFL與實際proof。
- 完整snapshot重生在固定head.modified3878588441後，core與CSS逐byte相同，reproduction真Exit0。純repo已審codepoints模式另提供regenerate-font-core.py，不依舊/tmp/out；它重生固定清單，不等於重新掃新文案corpus。全部工具僅/tmp外部FontTools4.61.1／Brotli1.1.0，不改npm deps/lockfile。

最終字體facts與完整證據清單：font-assets/verified-facts.json（SHA`de2785416ee6138d27673e52aa5ec856374eded7de8a2eed7012c76165781b90`）；glyph-proof-v4.json／glyph-proof-v4-process.json真0；uvs-audit.json；reproduction.json/log；candidate-v4/manifest.json/codepoints.json/CSS；upstream-download.json與OFL；README及所有原FAIL。這些proof不替代合併core後的跨舊shard文字shaping、各頁換行、AT或print實測。

## 保留門檻與待交付

採用小候選後仍須完成同版本18 after＋6 warm、六品質指令、49頁×五寬兩模式、完整原531及受影響業務、字型／未知字元／無JS與early print、八份A4／QR、視覺與可及性回歸；不能拿單頁pilot或字形proof取代。新source／最後exact-head CI與真artifact由Root另核，不借起點CI成功。

原HEAD原response200與Next原生prefetch initiator來源已有精確callsite證據；但initiator不是canceller，CDP canceled也不能證明Next主動取消。舊40筆來源不回填新tiny三筆原因，原unknown network與Required真人AT各自追蹤，不因TBT改善自動解除。無field資料，不宣稱INP／CWVp75／真機通過。

本輪沿同Draft PR45交付，不Merge、不部署、不改DNS；原DC007未完成狀態維持。上述PENDING待Root最新正式結果補入，本整理不將測試流程成功當發布成功。
