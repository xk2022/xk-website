# DC-007-R01 Fresh before 與字型批次 pilot 比較

更新：2026-11-27T01:11:37.640423+00:00

三筆pilot完整，但TBT仍FAIL。Fresh before18和pilot3的21份LH report設定逐項一致，工具LH13.6／Chrome156、375×812／DPR1／CPU4／RTT150ms／200000down／93750up、cold新process/profile；21個LH子程序皆真Exit0，兩個外層皆按真門檻Exit1。舊2026-11-26 DC00718僅歷史，完全未混入本輪median或delta。

Fresh before source `661f6cd2ac68add9e0887849819b8568f647b867ee72b8fa85ecf27beb39f16c`；pilot source `5142b1399b539e43c9ac9d8e01b7c7f77357609278569540c3c5493b6bcc0a9a`。來源差異清冊：`src/app/globals.css`、`src/app/layout.tsx`、`src/components/layout/font-loading-controller.tsx`。

## 本輪 Fresh before 六組（各3，全部保留）

| 頁面 | LCP values ms；median [range] | CLS values；median [range] | TBT values ms；median [range] | Status |
|---|---|---|---|---|
| modern/home | 1764.392, 1762.650, 1644.633; **1762.650** [1644.633–1764.392] | 0.000, 0.000, 0.000; **0.000** [0.000–0.000] | 1306.136, 991.173, 1392.539; **1306.136** [991.173–1392.539] | FAIL:TBT |
| modern/quotation | 1614.841, 1616.265, 1565.926; **1614.841** [1565.926–1616.265] | 0.000, 0.000, 0.000; **0.000** [0.000–0.000] | 1135.686, 809.845, 1125.176; **1125.176** [809.845–1135.686] | FAIL:TBT |
| heritage/home | 1667.109, 1672.843, 1577.556; **1667.109** [1577.556–1672.843] | 0.000, 0.000, 0.000; **0.000** [0.000–0.000] | 1008.403, 1249.817, 1270.489; **1249.817** [1008.403–1270.489] | FAIL:TBT |
| heritage/quotation | 1644.150, 1691.499, 1745.693; **1691.499** [1644.150–1745.693] | 0.000, 0.000, 0.000; **0.000** [0.000–0.000] | 912.835, 1069.803, 847.766; **912.835** [847.766–1069.803] | FAIL:TBT |
| luxury/home | 1622.754, 1614.508, 1575.841; **1614.508** [1575.841–1622.754] | 0.000, 0.000, 0.000; **0.000** [0.000–0.000] | 1213.802, 1023.287, 873.795; **1023.287** [873.795–1213.802] | FAIL:TBT |
| luxury/quotation | 1866.440, 1663.725, 1638.029; **1663.725** [1638.029–1866.440] | 0.000, 0.000, 0.000; **0.000** [0.000–0.000] | 1403.431, 778.041, 871.978; **871.978** [778.041–1403.431] | FAIL:TBT |

## Candidate v1：只限 Modern Home 三筆 pilot

| Metric | 三筆實值 | Median [min–max] | 門檻結果 |
|---|---|---|---|
| lcpMs | 1615.389, 1523.589, 1566.837 | **1566.837** [1523.589–1615.389] | PASS |
| cls | 0.000, 0.000, 0.000 | **0.000** [0.000–0.000] | PASS |
| tbtMs | 1034.895, 729.956, 719.277 | **729.956** [719.277–1034.895] | FAIL |

ModernHome TBT median由本輪1306.136ms變729.956ms，差-576.180ms（診斷pilot相對-44.11%）；仍遠高於200ms。LCP median1762.650→1566.837ms，CLS均0。這只支持單頁pilot的方向性變化，不能稱其他五組或正式after已通過，亦非因果隔離或field結論。

## 同font bytes與實際trace

Before與candidate115個WOFF2檔名及rawSHA逐一相同，沒有換glyph／字體binary。但實際網路16→17font：candidate額外載原Noto Latin檔`4f6d27b94ac7f0f8-s.3aqr1xxws37ij.woff2`，25,257 transferB；總font1,091,912→1,117,169B。body全文load包含原本由Inter處理的Latin字元，因此不能宣稱載入集合完全相同。

| 系列／run | 最後font完成ms | afterFCP Layout總ms | afterFCP>50ms Layout數 | 其中距font完成≤20ms |
|---|---:|---:|---:|---:|
| before/1 | 7428.270 | 1333.297 | 11 | 11 |
| before/2 | 7437.315 | 1144.696 | 12 | 12 |
| before/3 | 7318.149 | 1421.588 | 12 | 12 |
| pilot-v1/1 | 8099.256 | 1191.928 | 12 | 11 |
| pilot-v1/2 | 7993.950 | 980.018 | 4 | 3 |
| pilot-v1/3 | 7908.780 | 1003.489 | 6 | 5 |

候選仍有多次font完成後Layout，r1最後還有8111ms開始、約389ms的Style/Layout長task。其最後font完成約7909–8099ms，比before7318–7437ms晚；不能用unthrottled tiny ready530ms推定正式慢網路已更快完成字型。這些trace不支持「已只剩一次Layout」；但未記錄專用batch-start/activation Performance mark，所以不能僅由最後大Layout的時間就確稱那一筆是activation。逐筆時序、LH分類和原始SHA在`pilot-v1-trace-comparison.json`。

共享ReactDOM-containing JS亦保留實際eval成本；module/callstack細節引用同輪JS owner的`js-after-fcp.json`／`diagnosis-js-r01-addendum.md`，不再重造另一份module審查。TBT是LH audit，不把全部Layout或longtask總和改稱TBT。

## 接受界線

- 此pilot3不是正式after18，也未驗六warm、49頁兩模式、五寬、字型最終外觀、anchors/focus/menu、noJS／failure fallback或八份print/QR。
- 保留profile與全部raw；Root先依剩餘成本與實際風險決定下一候選，不以改門檻、丟r1或換品牌字體取得PASS。
- 若後續方案確有可重複收益，須同條件正式18after＋6warm，及實際影響的完整回歸；這裡沒有release PASS、field INP或CWV p75聲明。
