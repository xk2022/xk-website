# DC-007-R01 公司來源與文件邊界

公司 latest main **仍為 `f1be01c0c5d8bc5b1238f250838e336bef47b149`**，tree `84f9388877b9f73dc81276200d0164625d228c90`。Fresh GitHub branch/tree/compare 回傳 identical、0 commits、0 changed files；沒有新增適用公司規則。固定來源與實讀清單見同目錄 JSON。公司與網站均未修改。

## 優化可採用的限制

- UI 字體仍 Inter／Noto Sans TC；未載入時可由裝置 fallback。公司 typography（blob `7ade30e8703d18a79953804a6bbf3908e25f78f7`，L14–16、25–27）沒有要求 font-display 必須 swap；Manrope600只屬Logo向量字標。**swap是網站既有任務/維護策略**，若R01明確允許調loading/display，應在當次規格記決策、同條件對照及fallback/換行/print回歸；不能說成公司新規定或換品牌字體授權。
- Logo guidelines（`ff44b6107b388202f06bda344c5be68002bbc225`，§V1.0 L31–45）及palette（`42fa98d525b91f04e76f1f7cc3fb2efe65f477c6`，L22–38）允許既有部署素材/介面色票繼續使用。保留Logo03、三個已批准frame/字階、共享內容及標準白A4；不因效能工作遷移品牌。
- 工程架構（`679c475e57258c69790101f1ceedb96f1575d5c6`，§新案前端選型/系統分工）、testing/release（`7b525804e46753e9b45432c4ba05f387a9b46f6f`，網站展示/發布核對）仍區分靜態Next export網站和APP。保留既有Pages/www根路徑及一般Next build，APP的Vite/Spring/VPS/DB規範不適用本網站優化。
- 公司的網站驗收要求合法/錯誤輸入、返回修改、摘要網路與重整後狀態；保留Contact草稿與Quotation IDs-only、價目/unknown/來源gate。任何render優化須證明內容、深頁hash、keyboard/focus及print沒有退化。
- **LCP/CLS/TBT門檻與18cold/warm來自網站DC007工作包，並非本次公司新增數值規則。** 同profile/tool/cache/transport採after，保留全部原FAIL/真exit/每run/median/range；不把固定指紋或CI綠燈當產物/功能等價，不聲稱field INP/CWV p75。
- 根公司AGENTS（`a7ca443ddd1d1b847dc58152bbb56c1425c1b522`，L10）的metadata/四項治理驗證屬公司文件庫維護，不要求網站改用知識庫建置工具。網站自身AGENTS及現行授權控制本任務。

## 文件更新位置（建議，未編輯）

| 檔案／段落 | 最小更新 |
| --- | --- |
| `docs/task/dc007.md` — 新增DC-007-R01 follow-up小節（或Root指定的唯一R01規格） | 固定本輪授權、基準、瓶頸假設、允許/禁止的font loading或render策略、before/after同條件與受影響驗收；初始狀態PENDING。 |
| `AGENTS.md` — Current DC-007 release acceptance之後的R01當前範圍 | 讓R01 current instruction明確優先於歷史Task011/DC007-v1策略，固定公司同版與字體/設計/static保護；只有明確採用的最小策略才寫入。 |
| `docs/reports/dc007-implementation.md` — §6保留原baseline；追加R01修復/after與KnownIssues更新 | 保留18cold/六組TBT原FAIL與全部原receipts，追加確切策略、source與產物SHA、同profileafter/全部runs/median/range、失敗及重驗、不能等價的視覺/字體/print範圍。 |
| `docs/03_engineering/performance-measurement.md` — 準備與版本／採樣與判讀／重驗與證據 | 新增當前DC007/R01依規格選範圍的明確指引；Task011的/xk-website/及九頁範例標明歷史，現行www空basePath由deployment source與R01規格決定。 |
| `docs/03_engineering/design-collection-maintenance.md` — 效能問題的修復邊界 | 只有R01策略完成驗證後，記可操作的loading/fallback/深頁hash/focus/print回歸與rollback；若display策略實際變更，不能仍無條件要求舊swap而自相矛盾。 |
| `README.md` — §1目前功能／§2設計系列目前工作摘要 | 簡短標示R01為DC007未達門檻的修復/重驗，連到唯一規格/報告；保留49已發布基線與新release gate分離。 |
| `docs/task/README.md` — DC-007執行紀錄後的R01追蹤 | 加入唯一R01入口與實際進度，不再抄完整結果。 |
| `docs/task/ROADMAP.md` — DC007當前階段 | 將R01修復/重驗與原DC007基線、HumanAT/網路未解gate分開；只填真完成事件。 |
| `docs/98_decisions/implementation-notes.md` — 追加2026-11-27 DC007-R01版本/決定 | 記公司same f1be、已驗瓶頸、採用策略與差異/retst界線，連唯一R01報告段落。 |

原DC007的18個cold FAIL、原suite取消UNKNOWN與HumanAT BLOCKED保留原紀錄。R01的成功只可關閉有新證據支持的對應門檻，不能自動宣稱完整release、部署或品牌/法律/索引核准。

## 實讀與限制

Fresh全文讀14份公司文件（根AGENTS、治理入口、工程/品牌index、架構/流程/網站測試發布/命名、APP部署/測試邊界、typography/palette/logo）；其餘同commit/blob品牌決議沿用前輪核對，沒有再次下載全部公司歷史。Fresh tree完整且無獨立performance命名規範檔；數字門檻由網站當次規格取用。

已讀網站AGENTS、README、DC007 task/report、workflow、performance指南及維護效能段落。查找時 `docs/task/` 只有 `dc007.md`，沒有獨立R01規格；目前R01 request來源為parent handoff，未冒稱讀過未提供的完整user request。Root可將R01唯一規格路徑補進入口，無須另一大份歷史報告。

只輸出本目錄 JSON/MD；未Git、未browser/build/測試、未更動App或其他repo。PR/CI/部署由Root核對。
