import json
from pathlib import Path
r=Path('/tmp/xk-dc007-r01/after');d=json.loads((r/'modern-quotation-mobile-r1.report.json').read_text());a=d['audits']['metrics']['details']['items'][0];o=a['observedTimeOriginTs'];es=json.loads((r/'modern-quotation-mobile-r1-0.trace.json').read_text())['traceEvents'];nav=next(e for e in es if e['name']=='navigationStart' and e.get('args',{}).get('data',{}).get('documentLoaderURL')=='http://127.0.0.1:3281/quotation/');es=[e for e in es if e.get('pid')==nav['pid'] and e.get('tid')==nav['tid']];lo=o+2392.35*1000;hi=o+2644.25*1000
rows=[]
for e in es:
 if e['name'] in ['EvaluateScript','FunctionCall','RunMicrotasks','V8.Execute','V8.CompileCode','v8.compile'] and e.get('dur',0)>10000 and lo-1000<=e['ts']<=hi:rows.append({'name':e['name'],'startMs':(e['ts']-o)/1000,'durationMs':e['dur']/1000,'args':e.get('args')})
profs=[]
for e in es:
 if e['name'] in ['Profile','ProfileChunk']:
  p=e.get('args',{}).get('data',{});c=p.get('cpuProfile',{});profs.append({'name':e['name'],'id':e.get('id'),'ts':e['ts'],'keys':list(p),'startTime':p.get('startTime'),'nodes':len(c.get('nodes',[])),'samples':len(c.get('samples',[])),'firstNodes':c.get('nodes',[])[:2]})
out={'scope':'Read-only diagnostic of original accepted-profile V1 formal ModernQuote r1; no new sampling','taskIntervalMs':[2392.35,2644.25],'events':rows,'profiles':profs};Path('/tmp/xk-dc007-r01/task-function-diagnostic.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out)[:14000])
