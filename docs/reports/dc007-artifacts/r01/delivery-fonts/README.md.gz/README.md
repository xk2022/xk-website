# Reviewed local Noto Sans TC assets

The R01 core is a reviewed subset for the current public content, not a complete CJK font or a promise that future copy automatically enters the core. It contains 882 ordinary Unicode points (774 CJK), with the 12 required UVS mappings retained through cmap14. FE00/FE01 are variation selectors, not additional ordinary CSS-range points.

- Core: `fonts/noto-sans-tc-core.woff2`, 281,768 bytes; SHA256 `8c1e22167a472d67e2e51c5c811b3b2c2815742d054a0994e7f49ef071b99018`.
- `core-font.ts` declares the sole preloaded CJK core through `next/font/local`: normal, variable `wght` 100–900, `swap`, literal core `unicode-range`, and the original family/fallback chain. `noto-sans-tc.css` contains only the 108 retained legacy faces and the original Arial metrics fallback.
- Every original legacy WOFF2 file keeps its filename and bytes. Its CSS range is the original range minus the core, in the original rule order. Core plus legacy remain disjoint and together cover the original 16,661 ordinary points. Unseen characters within that original coverage can use the retained shards; characters outside it still depend on the existing system fallback.
- The fixed master is Google Fonts commit `b950a7257470b900078f2bf3223823a8602de7e1`, `ofl/notosanstc/NotoSansTC[wght].ttf`, SHA256 `864727d210d54f2537bbe23b3a839436c3992af72de9322af5270897246bd44f`. Version: `2.004-H2`; master and assets retain variable weight support. Current Gstatic files are not represented as the exact origin URLs of the old build binaries.
- Keep the complete `OFL.txt` and original copyright. OFL-1.1's Reserved Font Name is **Source**; the retained Noto identity does not use that reserved name. Do not replace or abbreviate the license.

`font-assets.json` is compact provenance and pinned asset identity, not client data. `codepoints.json` contains only the reviewed core and two UVS selectors. The full generated manifest, original CSS, all coverage inputs, glyph/layout/UVS proof, original failed attempts and exact reproduction are separate immutable R01 evidence. Resolve their relative paths and hashes through the archived evidence manifest; do not duplicate the large generation manifest here or import metadata into a Client Component.

## Contract test

Intended repository destinations:

- `src/app/fonts/{font-assets.json,codepoints.json,README.md}`
- `scripts/test-font-assets.mjs`
- `scripts/fixtures/font-contract.json`

After copying, run `node --test scripts/test-font-assets.mjs`. Before copying, the owner can point the test at the prepared metadata:

```sh
XK_FONT_TEST_ROOT=/workspace/xk-website \
XK_FONT_METADATA_ROOT=/tmp/xk-dc007-r01/delivery-fonts \
XK_FONT_FIXTURE_ROOT=/tmp/xk-dc007-r01/delivery-fonts \
node --test /tmp/xk-dc007-r01/delivery-fonts/test-font-assets.mjs
```

The independent fixture was extracted from immutable DC007 CSS `ce25680942558ee80c80ecb657ce6bff3934b922f36c52941b7a0598334f3b30` and its original files, not generated from the new stylesheet. The tests check hashes, the WOFF2 variable axis/cmap/UVS, source declarations, exact per-shard partition/order, source URLs, fallback metrics and full license. They do not prove browser shaping across formerly separate shards, visual/keyboard/hash behavior, print/PDF or measured performance. Those need the separate R01 browser and performance acceptance.

**Preparation status:** only `node --check` is authorized during the exclusive pilot window. Unit tests have not been run by this preparer; no test PASS is claimed. The owner runs them after the sampling window and records the real receipt.

## Future changes

New public or dynamic text needs a fresh corpus/coverage/UVS audit before changing the reviewed core. Do not append codepoints by guesswork or preload all legacy shards. Regeneration uses the pinned master, reviewed codepoint list, retained layout/UVS closure and fixed `head.modified=3878588441`; write a new temporary output and require the expected SHA before any replacement. The existing reproduction tool and raw proof document the exact process. A new core requires new hashes/fixture review, browser shaping/fallback/print checks and comparable performance evidence; the present result does not establish automatic optimization for future CJK content.
