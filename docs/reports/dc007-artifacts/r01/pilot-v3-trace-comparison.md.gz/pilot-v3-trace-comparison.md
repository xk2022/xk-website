# Native Core pilot v3：FCP後剩餘成本

三筆capture完整；LH子程序皆真0，外層真1 at 2026-11-27T01:47:38.641305+00:00。LCP[1884.576,1766.260,1608.571]，CLS全0；TBT[558.090,436.395,345.740]，median436.395ms仍FAIL。不是正式18after。

## 精確FCP／TTI clip歸因

依本機Lighthouse13.6 TBTUtils，先將RunTask裁至FCP→TTI，再減50ms；跨FCP task不能整筆算入或整筆忽略。從原trace重算三筆sum分別558.090／436.395／345.740ms，與原audit差<.002ms。原debug分類只精度0.1ms，以下阻塞值則取原RunTask精度。

| Run | FCP ms | TTI ms | 跨FCP初始Layout task TBT | 092r ReactDOM-containing JS task TBT | 0c98 Core附近Style/Layout task TBT | 合計 |
|---|---:|---:|---:|---:|---:|---:|
| 1 | 1884.576 | 3971.091 | 105.684 | 202.981 | 249.425 | 558.090 |
| 2 | 1766.260 | 3769.517 | 83.956 | 186.840 | 165.599 | 436.395 |
| 3 | 1608.571 | 3640.328 | 41.468 | 112.018 | 192.254 | 345.740 |

1. 跨FCP初始task全長164.908／136.678／112.944ms，其中audit Style/Layout約140.7／112.6／96.8ms。Inter在FCP前約28／15／23ms完成；此task與初次font/style/layout過程重疊，不全算作FCP後字體swap。
2. 092r shared ReactDOM-containing chunk的task全長252.981／236.840／162.018ms。r1內ScriptEval222.8＋Parse30ms；URL是共享bundle歸因，不能只憑URL斷言React本身或某個自製hook唯一負責。縮Client範圍要先用JS owner的callframe/module證據選擇，不能直接刪互動或停prefetch。
3. 0c98 shared chunk附近task全長299.425／215.599／242.254ms，audit Style/Layout約262.3／192.7／200.2ms，ScriptEval僅1.7／1.4／4.8ms。此時主要是重新排版，不是需要刪掉200ms的自製JS函式。

## 字體時序與DOM範圍

三個trace都只有2個RemoteFontLoaded：Inter在1856.536／1751.118／1585.913ms；NotoCore在3690.076／3561.789／3410.707ms。這支持「只有一次NotoCore載入完成」，原15個Noto分批完成序列已消失。沒有另外的swap計數instrumentation，所以不把每個CSS/font事件都說成已完整計數。

Core完成位於上述0c98 task內，接續mainframe Layout；trace layoutRoots均是#document，dirty/total objects約1147，不能從這份trace將真毫秒精確分配Footer或Services。靜態HTML複雜度如下，可用來選單一隔離實驗，不能當CPU attribution：

| 區塊 | HTML元素數 | 非空白文字碼點數 | links |
|---|---:|---:|---:|
| header | 49 | 74 | 13 |
| home-title | 46 | 369 | 3 |
| about | 8 | 159 | 0 |
| services | 157 | 707 | 6 |
| service-plans | 81 | 510 | 4 |
| featured-websites | 87 | 429 | 7 |
| technologies | 55 | 515 | 0 |
| why-xk | 31 | 343 | 0 |
| solutions | 42 | 317 | 4 |
| contact | 18 | 145 | 2 |
| footer | 140 | 792 | 55 |

Services157元素／Footer140元素與55links，是兩個具體較大容器；但它們並非trace已證的獨立熱點。Footer實際55links含目錄與品牌等重複入口，不能把它寫成只有49個DOM anchor。

## 最小後續實驗界線

NativeCore已保固定，不再加字體Client控制層。可先只在一個確知首屏以外的容器做screen-only排版隔離／content-visibility可行性pilot，確認FCP後初始Layout及Core Layout是否實際縮短；不在一次候選中同步改Client和多個CSS變數。若有明顯收益，再按Root所判定範圍擴至其餘容器。

此類CSS不是免測改動：intrinsic size與native hash scroll、keyboard/skip focus、find-in-page／AT、所有內容與全頁截圖、print/PDF/QR及跨頁print隔離均須真驗。不得以隱藏Footer內容、移除links、裁切或改為別種導航取得PASS。即使JS task仍是112–203ms blocking，是否單一CSS就能讓median≤200仍是待測，不能先保證。

另一個字體載入順序的小實驗若由Root選擇，可針對現已縮成281KB的唯一core評估preload優先序；這與盲目預載108碎片不同，但會與JS/Inter爭帶寬、可能推遲LCP，仍須單變數三次同profile，不能以搬移FCP或減少觀察窗口掩蓋阻塞。

實際採樣／Browser／Build皆由Root管理，本分析沒有新採樣或Glyph重算。原fresh-before18與v1/v2所有FAIL保留；此pilot不解除其他AT／network／release門檻，亦不宣稱fieldINP／CWV p75。
