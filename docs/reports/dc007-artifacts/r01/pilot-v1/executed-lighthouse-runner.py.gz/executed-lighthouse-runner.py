#!/usr/bin/env python3
"""DC007 sequential fixed-profile cold lab baseline; tools remain outside the app."""
import argparse,hashlib,json,math,statistics,subprocess,sys
from pathlib import Path
from datetime import datetime,timezone
from urllib.parse import urlsplit,urljoin
ROOT=Path('/tmp/xk-dc007/performance');REPO=Path('/workspace/xk-website')
CLI=Path('/tmp/xk-task011/tools/node_modules/lighthouse/cli/index.js')
ROUTES=[('modern','home','/')]
now=lambda:datetime.now(timezone.utc).isoformat()
sha=lambda b:hashlib.sha256(b).hexdigest()
def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--base',required=True);p.add_argument('--code-map',type=Path,required=True);p.add_argument('--output',type=Path,required=True);p.add_argument('--label',default='release-candidate-baseline');a=p.parse_args()
 url=urlsplit(a.base)
 if url.scheme!='http' or url.hostname not in {'127.0.0.1','localhost'} or url.path not in {'','/'} or url.query or url.fragment or url.username:p.error('Require the root loopback Pages production URL')
 if a.output.exists():p.error('Output must be a fresh directory; never overwrite samples')
 code=json.loads(a.code_map.read_text());a.output.mkdir(parents=True)
 config=ROOT/'profiles/lighthouse-mobile.json';config_bytes=config.read_bytes();(a.output/config.name).write_bytes(config_bytes)
 source=Path(__file__).read_bytes();(a.output/'executed-lighthouse-runner.py').write_bytes(source)
 summary={'status':'PENDING','captureStatus':'PENDING','targetStatus':'PENDING','label':a.label,'startedAt':now(),'mode':'pages','origin':a.base,'sourceManifest':str(a.code_map),'sourceManifestSha256':sha(a.code_map.read_bytes()),'sourceVersion':code,'command':[sys.executable,*sys.argv],'harnessSha256':sha(source),'profile':'mobile375x812-DPR1-CPU4-HTTP150ms-200000down-93750up','configSha256':sha(config_bytes),'expectedRuns':3,'order':'Grouped by each of six routes with three consecutive repetitions; fresh Chrome process/profile and Lighthouse storage reset each time. First complete group is Modern Home.','targetRule':'For each route require3 valid numeric samples; median LCP<=2500ms, CLS<=0.1, TBT<=200ms. Preserve individual values, per-run exceedances, min/max and all raw evidence. No sample selection.','fieldWindow':None,'inpMs':None,'fieldLimitation':'Local controlled lab only; no field INP/CWV p75 or real-device claim','runs':[],'groups':[]}
 def save():
  (a.output/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
 save();reference_settings=None
 for style,page,route in ROUTES:
  for n in range(1,4):
   ident=f'{style}-{page}-mobile-r{n}';prefix=a.output/ident;receipt=Path(str(prefix)+'.receipt.json');log=Path(str(prefix)+'.log')
   command=['env','CHROME_PATH=/usr/bin/chromium','node',str(CLI),urljoin(a.base,route),'--config-path='+str(config),'--chrome-flags=--headless --no-sandbox --disable-dev-shm-usage','--output=json','--output=html','--output-path='+str(prefix),'--save-assets','--no-enable-error-reporting']
   row={'testId':'DC7-PERF-'+ident,'style':style,'page':page,'route':route,'runNumber':n,'cache':'cold fresh Chrome profile; storage reset enabled','startedAt':now(),'status':'PENDING','command':command,'receipt':str(receipt),'log':str(log),'configSha256':sha(config_bytes)};summary['runs'].append(row);save()
   result=subprocess.run([sys.executable,str(REPO/'scripts/run-with-evidence.py'),'--receipt',str(receipt),'--log',str(log),'--timeout','150','--',*command],cwd=REPO)
   row.update(wrapperActualExitCode=result.returncode,finishedAt=now())
   if result.returncode:
    row['status']='FAIL';summary.update(status='FAIL',captureStatus='INCOMPLETE',error='Actual Lighthouse process failed; original receipt/log retained');save();return result.returncode
   report=Path(str(prefix)+'.report.json');data=json.loads(report.read_text())
   if data.get('runtimeError'):
    row.update(status='FAIL',runtimeError=data['runtimeError']);summary.update(status='FAIL',captureStatus='INCOMPLETE');save();return 1
   assert data['lighthouseVersion']=='13.6.0'
   settings=data['configSettings'];assert settings['throttlingMethod']=='devtools' and settings['throttling']['cpuSlowdownMultiplier']==4
   assert settings['screenEmulation']['width']==375 and settings['screenEmulation']['height']==812 and settings['screenEmulation']['deviceScaleFactor']==1
   assert settings['throttling']['requestLatencyMs']==150 and math.floor(settings['throttling']['downloadThroughputKbps']*1024/8)==200000 and math.floor(settings['throttling']['uploadThroughputKbps']*1024/8)==93750
   assert settings['disableStorageReset'] is False
   if reference_settings is None:reference_settings=settings
   assert settings==reference_settings,'Configuration drift between samples'
   values={key:data['audits'][audit]['numericValue'] for key,audit in [('lcpMs','largest-contentful-paint'),('cls','cumulative-layout-shift'),('tbtMs','total-blocking-time'),('fcpMs','first-contentful-paint')]}
   assert all(isinstance(v,(int,float)) and math.isfinite(v) for v in values.values())
   network=data['audits'].get('network-requests',{}).get('details',{}).get('items',[])
   row.update(status='MEASURED',metrics=values,perRunTargetStatus='PASS' if values['lcpMs']<=2500 and values['cls']<=0.1 and values['tbtMs']<=200 else 'FAIL',report=str(report),reportSha256=sha(report.read_bytes()),html=str(prefix)+'.report.html',lighthouseVersion=data['lighthouseVersion'],fetchTime=data['fetchTime'],requestedUrl=data['requestedUrl'],finalDisplayedUrl=data['finalDisplayedUrl'],environment=data.get('environment'),configSettings=settings,performanceScore=data['categories']['performance']['score'],networkSummary={'auditedRequests':len(network),'transferBytes':sum(x.get('transferSize',0) for x in network),'decodedBytes':sum(x.get('resourceSize',0) for x in network),'scriptRequests':[x for x in network if x.get('resourceType')=='Script']},rawAssets=[{'path':str(x),'sha256':sha(x.read_bytes()),'bytes':x.stat().st_size} for x in sorted(a.output.glob(ident+'-*')) if x.is_file()])
   save();print(json.dumps({'run':ident,'status':row['status'],'metrics':values,'perRunTargetStatus':row['perRunTargetStatus']},ensure_ascii=False),flush=True)
 for style,page,route in ROUTES:
  runs=[row for row in summary['runs'] if row['style']==style and row['page']==page];assert len(runs)==3 and all(row['status']=='MEASURED' for row in runs)
  metrics={}
  for key,target in [('lcpMs',2500),('cls',0.1),('tbtMs',200)]:
   vals=[row['metrics'][key] for row in runs];metrics[key]={'n':3,'values':vals,'median':statistics.median(vals),'min':min(vals),'max':max(vals),'target':target,'medianTargetStatus':'PASS' if statistics.median(vals)<=target else 'FAIL','individualExceedances':sum(v>target for v in vals)}
  summary['groups'].append({'style':style,'page':page,'route':route,'status':'PASS' if all(v['medianTargetStatus']=='PASS' for v in metrics.values()) else 'FAIL','metrics':metrics})
 assert len(summary['runs'])==3 and len(summary['groups'])==1
 passed=all(row['status']=='PASS' for row in summary['groups']);summary.update(status='PASS' if passed else 'FAIL',captureStatus='COMPLETE',targetStatus='PASS' if passed else 'FAIL',finishedAt=now());save();print(json.dumps({'captureStatus':'COMPLETE','targetStatus':summary['targetStatus'],'runs':3,'groups':summary['groups']},ensure_ascii=False),flush=True)
 return 0 if passed else 1
if __name__=='__main__':raise SystemExit(main())
