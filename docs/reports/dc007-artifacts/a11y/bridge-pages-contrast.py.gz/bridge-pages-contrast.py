"""Exact Pages paint-input bridge; never reruns the 384 normal calculations."""
import argparse,copy,hashlib,json,re,collections
from pathlib import Path
from urllib.parse import urlsplit
from datetime import datetime,timezone

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
ALIASES={
 '.underline-offset-4.mt-4[href$="about/"]':'.underline-offset-4.mt-4[href$="about"]',
 '.mb-8 > .hover\\:text-secondary.rounded-sm[href$="portfolio/"]':'.mb-8 > .hover\\:text-secondary.rounded-sm[href$="portfolio"]',
 '.hover\\:text-secondary.rounded-sm[href$="portfolio/#website-cases"]':'.hover\\:text-secondary.rounded-sm[href$="portfolio#website-cases"]',
 '.mt-3.underline-offset-4[href$="services/#service-plans"]':'.mt-3.underline-offset-4[href$="services#service-plans"]',
 '.mt-3.hover\\:underline[href$="services/#service-plans"]':'.mt-3.hover\\:underline[href$="services#service-plans"]',
}
def href_delta(n,p,routes):
    if n==p:return None
    nh=re.findall(r'\bhref="([^"]*)"',n);ph=re.findall(r'\bhref="([^"]*)"',p);assert len(nh)==len(ph)==1,'Only a single exact href difference is supported';a,b=urlsplit(nh[0]),urlsplit(ph[0]);assert not a.scheme and not a.netloc and not a.query and not b.query and a.path!='/' and b.path==a.path+'/' and a.fragment==b.fragment and a.path in routes
    assert not a.fragment or a.fragment in routes[a.path]['anchors'],'Only an independently declared public semantic hash may be aliased'
    assert n.replace('href="'+nh[0]+'"','href="'+ph[0]+'"',1)==p,'Other HTML differences must be reviewed'
    return{'normalHref':nh[0],'pagesHref':ph[0],'publishedPath':a.path,'declaredHash':a.fragment or None,'reason':'Exact approved non-root route single trailing slash, before the unchanged declared hash; no arbitrary URL normalization.'}
parser=argparse.ArgumentParser();parser.add_argument('--projection',required=True);parser.add_argument('--normal-raw',required=True);parser.add_argument('--normal-evidence',required=True);parser.add_argument('--normal-adjudication',required=True);parser.add_argument('--pages-menus',required=True);parser.add_argument('--fixture',required=True);parser.add_argument('--output',required=True);args=parser.parse_args();output=Path(args.output);assert not output.exists()
p=json.loads(Path(args.projection).read_text());n=json.loads(Path(args.normal_raw).read_text());ne=json.loads(Path(args.normal_evidence).read_text());normal=json.loads(Path(args.normal_adjudication).read_text());menus=json.loads(Path(args.pages_menus).read_text());fixture=json.loads(Path(args.fixture).read_text());routes={r['path']:r for r in fixture['routes']};assert len(routes)==49
assert len(p['axeCompletion']['records'])==len(p['axeCompletion']['formalTests'])==119 and all(t['status']=='PASS'for t in p['axeCompletion']['formalTests']);assert p['source']==n['source'];assert p['incomplete']==n['incomplete'];assert normal['status']=='PASS_SCOPED_MANUAL_CONTRAST'and normal['coverageExact'];assert sha(args.normal_evidence)==normal['evidence']['sha256'];assert menus['status']=='PAGES_MENU_CSS_CAPTURE_COMPLETE_NOT_ADJUDICATED';assert menus['projection']['sha256']==sha(args.projection)and menus['normalEvidence']['sha256']==sha(args.normal_evidence)
assert len(menus['css'])==len(ne['runtimeCSS'])==5
for c in menus['css']:assert c['status']==200 and c['exactBytes']and sha(c['snapshot'])==c['sha256']==c['normalSha256']
for s in menus['screenshots']:assert sha(s['path'])==s['sha256']
rows=[];href_changes=0;selector_changes=0;alias_counts=collections.Counter();fresh_menu_rows=0
for gi,(ng,pg)in enumerate(zip(n['manualStyles'],p['manualStyles'])):
    assert(ng['route'],ng['width'],ng['state'])==(pg['route'],pg['width'],pg['state'])and len(ng['nodes'])==len(pg['nodes'])
    for ni,(nn,pn)in enumerate(zip(ng['nodes'],pg['nodes'])):
        page_target=pn['target'];canonical_target=[ALIASES.get(t,t)for t in page_target];assert canonical_target==nn['target'];delta=href_delta(nn['html'],pn['html'],routes);href_changes+=delta is not None
        if page_target!=canonical_target:selector_changes+=1;alias_counts[page_target[0]]+=1;assert delta,'Selector suffix alias must have the corresponding exact href delta'
        pc=copy.deepcopy(pn['computed']);pc['target']=canonical_target;assert pc==nn['computed'],'Actual computed ancestors/panel/hits/text differ'
        for key in nn:
            if key not in('html','target','computed'):assert pn[key]==nn[key],'Other original target evidence differs: '+key
        prior=normal['rows'][len(rows)];assert prior['target']==nn['target']and prior['sourceManualPointer']==f'/manualStyles/{gi}/nodes/{ni}'and prior['status'].startswith('PASS_')
        row={'testId':f'DC007-PAGES-CONTRAST-{len(rows)+1:03d}','sourceTestId':prior['sourceTestId'],'pagesProjectionPointer':f'/manualStyles/{gi}/nodes/{ni}','pagesAxeIndex':next(i for i,a in enumerate(p['axeCompletion']['records'])if(a['route'],a['width'],a['state'])==(pg['route'],pg['width'],pg['state'])),'route':pg['route'],'width':pg['width'],'state':pg['state'],'pagesTarget':page_target,'normalTarget':nn['target'],'htmlDifference':delta,'computedPaintInputsByteEquivalent':True,'threshold':prior['requiredRatio'],'inheritedNormalMath':{'rowTestId':prior['testId'],'rowIndex':len(rows),'status':prior['status'],'minimumContrast':prior['paint']['minimumContrast'],'formulaRecomputed':False},'status':'PASS_EXACT_PAINT_INPUT_BRIDGE'}
        if prior['reasonKeys']==['bgOverlap']:
            mg=next(g for g in menus['groups']if(g['route'],g['width'],g['state'])==(pg['route'],pg['width'],pg['state']));ngFresh=next(g for g in ne['groups']if(g['route'],g['width'],g['state'])==(pg['route'],pg['width'],pg['state']));assert mg['actual']['panel']==ngFresh['actual']['panel']
            for state in ['closed','actual']:
                fresh=next(v for v in mg[state]['nodes']if v['target']==page_target);old=next(v for v in ngFresh[state]['nodes']if v['target']==nn['target']);assert fresh==old,'Fresh Pages menu node/geometry/effects differ'
            fresh=next(v for v in mg['actual']['nodes']if v['target']==page_target);assert fresh['panelCoverageRatio']==1;points=[q for q in fresh['hitTests']if q['inViewport']];assert len(points)==9 and all(q['stack'][0]['panelContains']for q in points)
            row['freshPagesClosedOpen']={'exactSamePaintAndGeometryAsNormal':True,'coverageRatio':1,'topmostPanelHits':9,'closedTargetIndependentlyFound':True,'menuEvidenceGroup':menus['groups'].index(mg)};fresh_menu_rows+=1
        rows.append(row)
assert len(rows)==384 and selector_changes==20 and href_changes==27 and fresh_menu_rows==30 and len(alias_counts)==5
counts=collections.Counter(r['inheritedNormalMath']['status']for r in rows)
report={'testId':'DC007-PAGES-384-EXACT-PAINT-BRIDGE','status':'PASS_SCOPED_PAGES_CONTRAST_PENDING_FINAL_RAW_LINK','generatedAt':datetime.now(timezone.utc).isoformat(),'pagesProjection':{'path':args.projection,'sha256':sha(args.projection),'frozenAfterCompletedFormalAxeRecords':119,'runningWholeFileShaUsed':False},'normalProof':{'rawPath':args.normal_raw,'rawSha256':sha(args.normal_raw),'evidencePath':args.normal_evidence,'evidenceSha256':sha(args.normal_evidence),'adjudicationPath':args.normal_adjudication,'adjudicationSha256':sha(args.normal_adjudication)},'pagesMenus':{'path':args.pages_menus,'sha256':sha(args.pages_menus),'groups':3,'closedOpenTargetPairs':30,'screenshots':menus['screenshots']},'runtimeCSS':menus['css'],'coverage':{'groups':31,'targets':384,'computedPaintInputsExact':384,'htmlHrefSingleSlashDifferences':href_changes,'selectorAliases':selector_changes,'explicitAliasKinds':dict(alias_counts),'freshClosedOpenMenuPairsExact':fresh_menu_rows,'runtimeCSSExactBodies':5},'decisionCounts':dict(counts),'unknownTargets':0,'demonstratedContrastDefects':0,'formulaPolicy':'Reuse the already proved normal v2 row result only after exact current Pages color/font/ancestor/geometry/panel/hit/related/viewport evidence comparison, same frozen source and five actual CSS byte identities. No new384 math or31-state browser capture. Only five explicit known href-suffix aliases plus27 independently published route/hash slash differences are allowed; no other computed/style delta.', 'originalPolicy':'Pages119 formal scans still have384incomplete and zero violations; original suite status/exit is not changed or pre-filled. Normal original Exit1 is not called Exit0. This is not network, fullWCAG or humanAT certification.','visualReview':'PENDING separate six-actual-PNG observation record','finalRawLink':'PENDING Root reprojects the finished raw via project-pages-contrast.py --compare and records final whole-file SHA; do not infer the overall suite exit from this scoped bridge.','rows':rows}
output.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'status':report['status'],'coverage':report['coverage'],'decisionCounts':report['decisionCounts'],'unknownTargets':0}));
