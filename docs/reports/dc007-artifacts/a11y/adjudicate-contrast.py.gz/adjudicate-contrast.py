"""Fresh per-target paint/occlusion decisions, preserving the formal suite's Exit 1."""
import argparse,collections,hashlib,itertools,json,math,re
from pathlib import Path
from datetime import datetime,timezone

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def color(value):
    m=re.fullmatch(r'(rgba?|color|oklab)\(([^()]+)\)',value);assert m,'Unsupported actual color '+value
    kind,body=m.groups();parts=body.replace(',',' ').replace('/',' ').split()
    if kind=='color':
        assert parts.pop(0)=='srgb';rgb=[float(v)*255 for v in parts[:3]]
    elif kind=='oklab':
        L,a,b=map(float,parts[:3]);l=(L+.3963377774*a+.2158037573*b)**3;mm=(L-.1055613458*a-.0638541728*b)**3;s=(L-.0894841775*a-1.2914855480*b)**3
        linear=[4.0767416621*l-3.3077115913*mm+.2309699292*s,-1.2684380046*l+2.6097574011*mm-.3413193965*s,-.0041960863*l-.7034186147*mm+1.7076147010*s]
        rgb=[255*(12.92*v if v<=.0031308 else 1.055*max(0,v)**(1/2.4)-.055)for v in linear];rgb=[min(255,max(0,v))for v in rgb]
    else:rgb=list(map(float,parts[:3]))
    return rgb,float(parts[3])if len(parts)>3 else 1.
def lum(rgb):
    q=[min(1,max(0,v/255))for v in rgb];return sum(w*(v/12.92 if v<=.04045 else((v+.055)/1.055)**2.4)for w,v in zip([.2126,.7152,.0722],q))
def ratio(f,b):
    x,y=lum(f),lum(b);return(max(x,y)+.05)/(min(x,y)+.05)
def interval_paint(lo,hi,rgb,alpha,optional=False):
    alphas=[0.,alpha]if optional else[alpha];values=[[b*(1-a)+c*a for b in [lo[i],hi[i]]for a in alphas]for i,c in enumerate(rgb)]
    return[min(v)for v in values],[max(v)for v in values]
def interval_contrast(flo,fhi,blo,bhi):
    if lum(blo)>lum(fhi):return(lum(blo)+.05)/(lum(fhi)+.05)
    if lum(flo)>lum(bhi):return(lum(flo)+.05)/(lum(bhi)+.05)
    return 1.
def effects_plain(item,allow_image=False,allow_mask=False):
    s=item['style'];assert s['opacity']=='1','Group opacity not resolved';assert s['filter']==s['backdropFilter']=='none','Filter not resolved';assert s['mixBlendMode']=='normal','Blend not normal';assert s['textShadow']=='none','Text shadow needs separate glyph proof'
    if not allow_image:assert s['backgroundImage']=='none','Unresolved background image'
    if not allow_mask:assert s['maskImage']=='none','Unresolved mask on content/ancestor'
    for p in item['pseudos']:assert p['content']in('none','normal')or p['display']=='none'or p['visibility']=='hidden','Painted pseudo needs separate review'
def intersect(a,b):return min(a['right'],b['right'])>max(a['left'],b['left'])and min(a['bottom'],b['bottom'])>max(a['top'],b['top'])
def paint(n):
    for a in n['ancestors']:effects_plain(a)
    fg,alpha=color(n['element']['style']['color']);assert 0<alpha<=1
    opaque_index=next(i for i,a in enumerate(n['ancestors'])if color(a['style']['backgroundColor'])[1]==1)
    opaque=n['ancestors'][opaque_index];bg,_=color(opaque['style']['backgroundColor']);lo,hi=bg[:],bg[:];layers=[];excluded=[]
    for d in n['decorations']:
        relevant=d['path'].startswith(opaque['path']+'>')and intersect(d['rect'],n['element']['rect'])
        if not relevant:excluded.append({'path':d['path'],'className':d['className'],'reason':'Outside nearest opaque paint stratum or no measured box intersection; opaque descendant surface blocks outer decoration.'});continue
        effects_plain(d,allow_image=True,allow_mask=True);s=d['style'];assert s['position']=='absolute'and s['zIndex']=='auto'and d['beforeTarget']and not d['decorationContainsTarget'],'Decoration paint order not established'
        foreground_context=next((a for a in n['ancestors'][:opaque_index]if a['style']['position']=='relative'and a['style']['zIndex']=='auto'and not d['path'].startswith(a['path']+'>')),None)
        assert foreground_context,'No later positioned foreground context over decorative sibling'
        cls=d['className'];image=s['backgroundImage'];colors=[color(c)for c in re.findall(r'(?:rgba?|color|oklab)\([^()]+\)',image)];nonzero=[(c,a)for c,a in colors if a>0]
        assert color(s['backgroundColor'])[1]==0,'Decoration opaque color needs explicit compositing'
        if 'brand-pattern-gradient'in cls:assert image.startswith('radial-gradient(')and len(nonzero)==1 and abs(nonzero[0][1]-.12)<1e-9
        elif 'brand-pattern-kaleidoscope'in cls:assert image.startswith('repeating-conic-gradient(')and nonzero and all(abs(a-.07)<1e-9 for _,a in nonzero);nonzero=[nonzero[0]]
        elif 'brand-pattern-grid'in cls:assert image.count('linear-gradient(')==2 and len(nonzero)==2 and all(abs(a-.09)<1e-9 for _,a in nonzero)
        else:raise AssertionError('Unresolved decorative type '+cls)
        for rgb,a in nonzero:lo,hi=interval_paint(lo,hi,rgb,a,True)
        layers.append({'path':d['path'],'className':cls,'actualImage':image,'maskImage':s['maskImage'],'alphaBounds':[{'rgb':c,'minimumAlpha':0,'maximumAlpha':a}for c,a in nonzero],'maskTreatment':'Opacity/mask may reduce alpha; no mask paint color is added.','foregroundPaintContext':foreground_context['path'],'proof':'Absolute z-auto decoration precedes target; a distinct later relative z-auto foreground context paints text above it.'})
    for a in reversed(n['ancestors'][:opaque_index]):
        rgb,a_alpha=color(a['style']['backgroundColor'])
        if a_alpha:lo,hi=interval_paint(lo,hi,rgb,a_alpha)
    flo,fhi=interval_paint(lo,hi,fg,alpha)
    return{'foregroundCss':n['element']['style']['color'],'foregroundSRGB':fg,'foregroundAlpha':alpha,'actualOpaqueSurface':{'path':opaque['path'],'tag':opaque['tag'],'className':opaque['className'],'color':opaque['style']['backgroundColor'],'rgb':bg},'decorativeLayers':layers,'excludedDecorations':excluded,'backgroundIntervalSRGB':{'lower':lo,'upper':hi},'compositedTextIntervalSRGB':{'lower':flo,'upper':fhi},'minimumContrast':interval_contrast(flo,fhi,lo,hi),'method':'WCAG sRGB .04045 luminance; actual ancestor/paint stratum, alpha endpoints and per-channel intervals conservatively enclose actual gradient/grid/mask paint, with foreground alpha composited over the same interval. No screenshot anti-alias pixel sampling.'}

parser=argparse.ArgumentParser();parser.add_argument('--evidence',required=True);parser.add_argument('--output',required=True);args=parser.parse_args();output=Path(args.output);assert not output.exists(),'Preserve old adjudication'
ev=json.loads(Path(args.evidence).read_text());raw=json.loads(Path(ev['input']['path']).read_text());assert sha(ev['input']['path'])==ev['input']['sha256'];assert ev['status']=='CAPTURE_COMPLETE_NOT_ADJUDICATED';assert raw['counters']['incompleteNodes']==384
for s in ev['sourceSnapshots']:assert sha(s['snapshot'])==s['sha256']==s['expectedFrozen']
for c in ev['runtimeCSS']:assert sha(c['snapshot'])==c['sha256']and c['status']==200
expected=collections.Counter((g['route'],g['width'],g['state'],tuple(n['target']))for g in raw['manualStyles']for n in g['nodes']);observed=collections.Counter();rows=[];tests={t['testId']for t in raw['tests']}
for gi,g in enumerate(ev['groups']):
    original_group=raw['manualStyles'][g['originalGroupIndex']];assert(g['route'],g['width'],g['state'])==(original_group['route'],original_group['width'],original_group['state'])
    axe_index=next(i for i,a in enumerate(raw['axe'])if(a['route'],a['width'],a['state'])==(g['route'],g['width'],g['state']))
    source_test=('AXE-ACTUAL-MOBILE-MENU-'+g['route']if g['state']=='actual-mobile-menu-expanded'else'AXE-ACTUAL-DISCLOSURES-'+g['route']if g['state']=='all-native-disclosures-expanded'else f"AXE-CONTACT-modern-{g['width']}-{g['state']}"if g['state']in('required-error-summary','valid-preview')else'AXE-'+g['state']+'-'+g['route']);assert source_test in tests,source_test
    for ni,n in enumerate(g['actual']['nodes']):
        original=original_group['nodes'][ni];key=(g['route'],g['width'],g['state'],tuple(n['target']));observed[key]+=1
        row={'testId':f'DC007-CONTRAST-{len(rows)+1:03d}','sourceTestId':source_test,'sourceAxeIndex':axe_index,'sourceManualPointer':f"/manualStyles/{g['originalGroupIndex']}/nodes/{ni}",'evidencePointer':f'/groups/{gi}/actual/nodes/{ni}','route':g['route'],'width':g['width'],'state':g['state'],'target':n['target'],'originalHtml':original['html'],'freshHtml':n.get('html'),'text':n.get('text'),'originalChecks':original['checks'],'status':'MANUAL_PENDING'}
        try:
            assert original['rule']=='color-contrast'and n['resolution']=='FOUND';assert n['target']==original['target']and n['text'][:300]==original['computed']['text'],'Original/fresh exact text or target differs'
            for prop in ['color','fontSize','fontWeight']:assert n['element']['style'][prop]==original['computed']['ancestors'][0]['style'][prop],'Original/fresh text style differs: '+prop
            required=max(float(c['data']['expectedContrastRatio'].split(':')[0])for c in original['checks']);row['requiredRatio']=required;reasons={c['data'].get('messageKey')for c in original['checks']};row['reasonKeys']=sorted(reasons)
            if reasons=={'bgGradient'}:
                calc=paint(n);assert calc['decorativeLayers'],'Original gradient reason has no actual relevant paint layer';row['paint']=calc
                assert calc['minimumContrast']>=required+.001,'Conservative gradient bound insufficient; needs more precise actual paint review'
                row['status']='PASS_ACTUAL_GRADIENT_PAINT_BOUND';row['decision']='Fresh actual glyph surface and complete relevant decorative strata yield a conservative lower bound above threshold; external opaque ancestor decorations excluded only with explicit paint-stratum evidence.'
            elif reasons=={'bgOverlap'}:
                closed=next(c for c in g['closed']['nodes']if c['target']==n['target']);assert closed['resolution']=='FOUND'and closed['text']==n['text'];assert closed['element']['style']['color']==n['element']['style']['color'];calc=paint(closed);assert not calc['decorativeLayers'];assert calc['minimumContrast']>=required+.001
                panel=g['actual']['panel'];effects_plain(panel);s=panel['style'];assert s['backgroundColor']=='rgb(255, 255, 255)'and s['display']!='none';points=[p for p in n['hitTests']if p['inViewport']];assert len(points)==9 and all(p['stack']for p in points)
                covered=sum(p['stack'][0]['panelContains']for p in points);assert n['panelCoverageRatio']>=1-1e-9 and covered==9,'Partial/uncertain menu occlusion requires separate exposed shadow bound'
                row.update(paint=calc,actualMenuSurface={'path':panel['path'],'background':s['backgroundColor'],'opacity':s['opacity'],'image':s['backgroundImage'],'rect':panel['rect']},occlusion={'boxCoverage':n['panelCoverageRatio'],'inViewportHitTests':9,'topmostPanelDescendants':covered},closedEvidencePointer=f'/groups/{gi}/closed/nodes/{ni}')
                row['status']='PASS_FULL_OPAQUE_OCCLUSION_WITH_CLOSED_PAINT';row['decision']='All measured target box covered by actual opaque menu and 9/9 topmost panel descendants; invisible underlying glyphs have no invented visible contrast. Exact same closed target independently has passing actual contrast.'
            else:raise AssertionError('Unreviewed contrast reason '+repr(reasons))
        except Exception as e:row['decision']=str(e)
        rows.append(row)
counts=collections.Counter(r['status']for r in rows);coverage=expected==observed;pending=[r['testId']for r in rows if r['status']=='MANUAL_PENDING'];status='PASS_SCOPED_MANUAL_CONTRAST'if coverage and len(rows)==384 and not pending else'MANUAL_PENDING'
report={'testId':'DC007-FRESH-384-CONTRAST-ADJUDICATION','status':status,'generatedAt':datetime.now(timezone.utc).isoformat(),'input':ev['input'],'evidence':{'path':args.evidence,'sha256':sha(args.evidence)},'tool':{'path':__file__,'sha256':sha(__file__)},'scope':'Fresh normal 31 scan/state groups only; 354 actual gradient paint and 30 menu occlusion nodes. No original result mutation, axe rerun or full WCAG/AT certification.','originalPolicy':'Formal normal suite Exit1, zero119-scan violations and384incomplete remain unchanged. Other attribution/network failures are outside this adjudication.','sourceSnapshots':ev['sourceSnapshots'],'runtimeCSS':ev['runtimeCSS'],'coverageExact':coverage,'targets':len(rows),'counts':dict(counts),'minimumGradientBound':min((r['paint']['minimumContrast']for r in rows if r['status']=='PASS_ACTUAL_GRADIENT_PAINT_BOUND'),default=None),'minimumClosedBound':min((r['paint']['minimumContrast']for r in rows if r['status']=='PASS_FULL_OPAQUE_OCCLUSION_WITH_CLOSED_PAINT'),default=None),'pending':pending,'screenshots':ev['screenshots'],'visualInspection':'PENDING; separate actual PNG inspection record required.','collectorNetworkLimit':'Focused collector captured six aborted GET fetch observations verbatim; captureExit0 only means requested paint capture complete, not a network PASS. Original full-suite network/attribution adjudication is separately owned.','rows':rows}
output.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print(json.dumps({k:report[k]for k in ['status','coverageExact','targets','counts','minimumGradientBound','minimumClosedBound','pending']}));raise SystemExit(0 if status=='PASS_SCOPED_MANUAL_CONTRAST'else 2)
