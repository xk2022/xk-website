"""Freeze/compare only completed formal axe evidence, not a running file hash."""
import argparse,json,hashlib
from pathlib import Path
from datetime import datetime,timezone

def projection(raw):
    assert raw['mode']=='pages'
    axe=raw['axe'];tests=[t for t in raw['tests']if t['testId'].startswith('AXE-')]
    assert raw['axePlan']['scans']==119 and len(axe)==len(tests)==119
    assert all(t['status']=='PASS'for t in tests),'All119 formal AXE records must have completed'
    assert all(not a['violations']for a in axe)
    assert len(raw['manualStyles'])==31 and sum(len(g['nodes'])for g in raw['manualStyles'])==384
    return{'schemaVersion':1,'testId':'DC007-PAGES-COMPLETED-AXE-PROJECTION','mode':raw['mode'],'baseURL':raw['baseURL'],'source':raw['source'],'tools':raw['tools'],'inputs':raw['inputs'],'axePlan':raw['axePlan'],'axeCompletion':{'expectedScans':119,'records':axe,'formalTests':tests},'manualStyles':raw['manualStyles'],'incomplete':raw['incomplete'],'manualEvidenceErrors':raw['manualEvidenceErrors'],'closedContrastEvidence':raw['closedContrastEvidence']}
def encoded(d):return(json.dumps(d,ensure_ascii=False,sort_keys=True,separators=(',',':'))+'\n').encode()
parser=argparse.ArgumentParser();parser.add_argument('--input',required=True);parser.add_argument('--output');parser.add_argument('--compare');args=parser.parse_args();raw=json.loads(Path(args.input).read_text());p=projection(raw);b=encoded(p);digest=hashlib.sha256(b).hexdigest()
if args.compare:
    assert raw.get('finishedAt') and raw['status'] not in ('PENDING','RUNNING'),'Final raw reconciliation requires a truly finished suite; do not label a running raw as final'
    frozen=Path(args.compare).read_bytes();assert frozen==b,'Completed formal axe projection changed; do not inherit the earlier review'
    print(json.dumps({'status':'PASS_FINAL_RAW_PROJECTION_IDENTICAL','projectionSha256':digest,'rawFinalStatus':raw['status'],'rawFinishedAt':raw.get('finishedAt'),'rawFullSha256':hashlib.sha256(Path(args.input).read_bytes()).hexdigest()}))
else:
    assert args.output;pout=Path(args.output);assert not pout.exists(),'Preserve the first projection';pout.write_bytes(b)
    meta={'status':'FROZEN_COMPLETED_119_AXE_RECORDS','capturedAt':datetime.now(timezone.utc).isoformat(),'rawPath':args.input,'rawStatusAtRead':raw['status'],'rawFinishedAtAtRead':raw.get('finishedAt'),'runningWholeFileShaUsed':False,'projection':{'path':str(pout),'sha256':digest,'bytes':len(b)},'groups':31,'targets':384,'scans':119,'formalAxeTestsCompleted':119,'finalReconciliation':'After the suite finishes, invoke this same tool with --compare and verify the complete frozen projection and final raw SHA.'}
    Path(str(pout)+'.meta.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2)+'\n');print(json.dumps(meta,ensure_ascii=False))
