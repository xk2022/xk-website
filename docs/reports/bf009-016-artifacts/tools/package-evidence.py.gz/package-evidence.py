import datetime,gzip,hashlib,json,pathlib,re,subprocess,sys
root=pathlib.Path('/workspace/xk-website'); temp=pathlib.Path('/tmp/xk-bf009-016'); artifacts=root/'docs/reports/bf009-016-artifacts'; screenshots=root/'docs/screenshots/bf009-016'
assert not artifacts.exists(), 'Evidence destination already exists: refuse overwrite'
assert not screenshots.exists(), 'Screenshot destination already exists: refuse overwrite'
artifacts.mkdir(parents=True);screenshots.mkdir(parents=True)
sha=lambda b:hashlib.sha256(b).hexdigest()
now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
source=json.loads((temp/'source.json').read_text());base=source['base']
tracked=subprocess.check_output(['git','diff','--name-status',base],cwd=root,text=True).splitlines();untracked=subprocess.check_output(['git','ls-files','--others','--exclude-standard'],cwd=root,text=True).splitlines()
excluded=('docs/reports/bf009-016-artifacts/','docs/screenshots/bf009-016/')
changes=[]
for line in tracked:
 parts=line.split('\t');p=parts[-1]
 if p.startswith(excluded):continue
 b=(root/p).read_bytes() if (root/p).is_file() else None
 changes.append({'path':p,'status':parts[0],'source':'git diff --name-status '+base,'sha256':sha(b) if b is not None else None,'bytes':len(b) if b is not None else None})
for p in untracked:
 if p.startswith(excluded):continue
 b=(root/p).read_bytes();changes.append({'path':p,'status':'UNTRACKED','source':'git ls-files --others --exclude-standard','sha256':sha(b),'bytes':len(b)})
changed={'capturedAt':now(),'base':base,'headAtCapture':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'scope':'Implementation/documentation snapshot excluding generated evidence directories. Root owns subsequent stage/commit/remote identifiers.','files':changes}
changed_bytes=(json.dumps(changed,ensure_ascii=False,indent=2)+'\n').encode();(artifacts/'changed-files.json').write_bytes(changed_bytes)
files=[];security=[]
fullshots=['home-1440','about-375','portfolio-1440','portfolio-375','qi-detail-1440','qi-detail-375','march-detail-375']
shotmap={f'pages-final/{name}.png':name+'.png' for name in fullshots}
for name in ['focus-with-context.png','overlap-menu-about-375.png','overlap-menu-portfolio-375.png','overlap-menu-portfolio-showcases-qiangang-windows-375.png']:shotmap[name]=name
external=[pathlib.Path('/tmp')/name for name in ['xk-bf016-failure.json','xk-bf016-failure.log','xk-bf016-failure-receipt.json','xk-bf016-url-classification.json']]
assert all(p.is_file() for p in external)
inputs=[p for p in temp.rglob('*') if p.is_file() and p.name not in {'package-evidence.py','package-evidence.receipt.json','package-evidence.log'}]+external
sensitive=re.compile(rb'x-amz-signature=|x-goog-signature=|[?&](?:access_token|token|sig|signature)=|(?:gh[pousr]_[A-Za-z0-9]{20,})',re.I)
for p in sorted(inputs):
 raw=p.read_bytes();rel=p.relative_to(temp).as_posix() if p.is_relative_to(temp) else p.name
 if p.suffix not in {'.png','.webp'}:
  assert not sensitive.search(raw), 'Potential sensitive URL/token in '+str(p)
 security.append(rel)
 parsed=None
 if p.suffix=='.json':
  try:parsed=json.loads(raw)
  except ValueError:raise AssertionError('Invalid JSON '+str(p))
 receipt=isinstance(parsed,dict) and ('exitCode' in parsed or 'observedExitCode' in parsed) and ('command' in parsed or 'executionSession' in parsed)
 if rel in shotmap:
  dst=screenshots/shotmap[rel];compression='identity';category='representative-screenshot' if rel.startswith('pages-final/') else 'targeted-screenshot'
 else:
  mapped={'normal-final/result.json':'browser-normal-result.json','pages-final/result.json':'browser-pages-result.json'}.get(rel,rel)
  if receipt:mapped='commands/'+mapped
  if rel=='pages-final/focus-brand-link.png':mapped='diagnostics/focus-brand-link.png'
  compress=p.suffix!='.json' or len(raw)>24576 or mapped.endswith('-result.json') or mapped.endswith('/result.json')
  dst=artifacts/(mapped+('.gz' if compress else ''));compression='gzip' if compress else 'identity';category='command-receipt' if receipt else 'source-evidence' if rel.startswith('sources/') else 'visual-derivative' if rel.startswith('visual-crops/') else 'raw-evidence'
 dst.parent.mkdir(parents=True,exist_ok=True);assert not dst.exists(),str(dst)
 archived=gzip.compress(raw,compresslevel=9,mtime=0) if compression=='gzip' else raw;dst.write_bytes(archived)
 assert (gzip.decompress(archived) if compression=='gzip' else archived)==raw
 row={'sourcePath':str(p),'logicalPath':({'normal-final/result.json':'browser-normal-result.json','pages-final/result.json':'browser-pages-result.json'}.get(rel,rel)),'archivePath':dst.relative_to(root).as_posix(),'category':category,'compression':compression,'rawBytes':len(raw),'rawSha256':sha(raw),'archiveBytes':len(archived),'archiveSha256':sha(archived)}
 if receipt:row['observedExitCode']=parsed.get('exitCode',parsed.get('observedExitCode'));row['receiptStatus']=parsed.get('status');row['observationMethod']=parsed.get('observationMethod','Tool exec/write_stdin completed process observation; see original receipt')
 files.append(row)
source_mismatches=[]
for p,h in source['files'].items():
 f=root/p
 if not f.is_file() or sha(f.read_bytes())!=h:source_mismatches.append(p)
manifest={'schemaVersion':1,'testBatch':'BF009–016','createdAt':now(),'scope':'Immutable local evidence packaging only. No app changes, rerun, Git mutation, CI/deployment or live acceptance is claimed by this manifest.','source':{'base':base,'backlogSource':source.get('backlogSource'),'fingerprint':source['fingerprint'],'fingerprintScopeFiles':len(source['files']),'sourceSnapshot':'source.json','sourceSnapshotRawSha256':sha((temp/'source.json').read_bytes()),'currentFingerprintFileMismatches':source_mismatches,'bridge':source.get('bridge')},'changedFiles':{'snapshot':'changed-files.json','rawSha256':sha(changed_bytes),'archiveSha256':sha(changed_bytes),'count':len(changes),'capturedHead':changed['headAtCapture']},'mappingNotes':['Report names browser-normal-result.json and browser-pages-result.json map to identically named .json.gz archives.','Original raw bytes are recoverable with gzip -dc. SHA256 is recorded both before and after compression.','Command receipts are preserved verbatim under commands/, including original nonzero exits and successful retests. The Pages browser exit 2 remains MANUAL_PENDING; final adjudication is separate.','PNG screenshot bytes are copied unchanged. Source screenshots and derivative review sheets are gzip archives in this evidence directory; representative full-page and focus/menu screenshots are in docs/screenshots/bf009-016/.','SourcePath records temporary provenance, not an online download link. No credentials or signed download URLs are included.'],'securityReview':{'selectedInputFiles':len(inputs),'scannedNonImageFiles':sum(p.suffix not in {'.png','.webp'} for p in inputs),'potentialSecretMatches':0,'selection':'Only current /tmp/xk-bf009-016 files plus four explicit BF016 validator files; excludes this packaging helper/receipt/log and unrelated temporary files.'},'totals':{'inputFiles':len(files),'commandReceipts':sum(f['category']=='command-receipt' for f in files),'screenshots':sum(f['category'] in {'representative-screenshot','targeted-screenshot'} for f in files),'rawBytes':sum(f['rawBytes'] for f in files),'archiveBytes':sum(f['archiveBytes'] for f in files),'gzipFiles':sum(f['compression']=='gzip' for f in files)},'files':files,'limitations':['Local tested-source fingerprint is not a commit, CI artifact, deployment or public live-site acceptance result. Root separately owns these stages.','The 32-case URL classification JSON has no separate OS process receipt in the supplied inputs; it remains scoped to parser/URL cases as originally recorded.','The targeted overlap receipt records actual tool-observed process exit 0; it is distinct from run-with-evidence.py receipts.','Initial command/tool failures and retests are retained as supplied. No missing original outcome is reconstructed.','Manifest excludes its own hash to avoid self-reference. changed-files.json is hashed separately; packaging command receipt is a separate generated artifact.']}
manifest['totals']['savedBytes']=manifest['totals']['rawBytes']-manifest['totals']['archiveBytes'];manifest['totals']['reductionPercent']=round(100*manifest['totals']['savedBytes']/manifest['totals']['rawBytes'],2)
(artifacts/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
assert manifest['totals']['screenshots']==11
assert not source_mismatches,source_mismatches
print(json.dumps({'status':'PACKAGED','manifest':str(artifacts/'manifest.json'),'sourceFingerprint':source['fingerprint'],'totals':manifest['totals'],'changedFiles':len(changes)},ensure_ascii=False))
