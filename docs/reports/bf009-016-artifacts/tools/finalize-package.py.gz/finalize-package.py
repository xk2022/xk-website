import gzip,hashlib,json,pathlib,datetime
root=pathlib.Path('/workspace/xk-website');artifacts=root/'docs/reports/bf009-016-artifacts';temp=pathlib.Path('/tmp/xk-bf009-016');manifest=artifacts/'manifest.json';d=json.loads(manifest.read_text());sha=lambda b:hashlib.sha256(b).hexdigest();omitted=[];kept=[]
for f in d['files']:
 p=f['logicalPath'];bulk=(p.startswith('sources/') and p.endswith(('.png','.html','.txt'))) or (p.startswith('visual-crops/') and p.endswith('.png'))
 if bulk:
  dest=root/f['archivePath'];assert dest.is_relative_to(artifacts);assert sha(dest.read_bytes())==f['archiveSha256'];dest.unlink();omitted.append({'sourcePath':f['sourcePath'],'logicalPath':p,'rawBytes':f['rawBytes'],'rawSha256':f['rawSha256'],'reason':'Not copied: redundant full source page/screenshot or deterministic derivative. Relevant structured source/interaction evidence, source manifest, crop manifest and seven original reviewed page screenshots are archived.'})
 else:kept.append(f)
d['files']=kept;d['omittedRelatedArtifacts']=omitted
def add(src,logical,dest,compress=False,category='packaging-evidence'):
 raw=src.read_bytes();archived=gzip.compress(raw,compresslevel=9,mtime=0) if compress else raw;target=artifacts/dest;target.parent.mkdir(parents=True,exist_ok=True);assert not target.exists();target.write_bytes(archived);row={'sourcePath':str(src),'logicalPath':logical,'archivePath':target.relative_to(root).as_posix(),'category':category,'compression':'gzip' if compress else 'identity','rawBytes':len(raw),'rawSha256':sha(raw),'archiveBytes':len(archived),'archiveSha256':sha(archived)}
 if category=='command-receipt':
  r=json.loads(raw);row.update(observedExitCode=r.get('exitCode',r.get('observedExitCode')),receiptStatus=r.get('status'),observationMethod=r.get('observationMethod'))
 d['files'].append(row)
add(temp/'package-evidence.receipt.json','package-evidence.receipt.json','commands/package-evidence.receipt.json',category='command-receipt')
add(temp/'package-evidence.log','package-evidence.log','package-evidence.log.gz',True)
add(temp/'package-evidence.py','package-evidence.py','tools/package-evidence.py.gz',True)
add(temp/'finalize-package.py','finalize-package.py','tools/finalize-package.py.gz',True)
d['toolExecutionStatus']={'check-artifact.py':'NOT_EXECUTED: snapshot supplied for future exact CI artifact comparison; no PASS inferred.','browser.cjs':'Actual normal/pages command receipts archived. Live acceptance not included.','package-evidence.py':'Executed with run-with-evidence.py; original exit 0 receipt archived.','finalize-package.py':'Execution outcome belongs to separately added packaging finalization receipt.'}
d['mappingNotes']=[x for x in d['mappingNotes'] if not x.startswith('PNG screenshot')]+['Eleven screenshot PNG bytes are copied unchanged to docs/screenshots/bf009-016/. Source PNG/HTML/TXT and derivative crop PNG files are intentionally omitted; exact raw SHA/bytes and rationale are recorded under omittedRelatedArtifacts. Structured source and interaction JSON, source manifest, visual review/crop manifest, seven original full pages and focus/menu context remain archived.']
d['limitations'].append('Source public-page HTML/plain text and source/derivative image bulk were not indiscriminately copied. OmittedRelatedArtifacts documents exact supplied bytes; the evidence selection retains structured extracts, decisions and original website acceptance screenshots.')
d['totals']={'inputFiles':len(d['files']),'commandReceipts':sum(f['category']=='command-receipt' for f in d['files']),'screenshots':sum(f['category'] in {'representative-screenshot','targeted-screenshot'} for f in d['files']),'rawBytes':sum(f['rawBytes'] for f in d['files']),'archiveBytes':sum(f['archiveBytes'] for f in d['files']),'gzipFiles':sum(f['compression']=='gzip' for f in d['files']),'omittedRelatedFiles':len(omitted),'omittedRelatedRawBytes':sum(f['rawBytes'] for f in omitted)};d['totals']['savedBytes']=d['totals']['rawBytes']-d['totals']['archiveBytes'];d['totals']['reductionPercent']=round(100*d['totals']['savedBytes']/d['totals']['rawBytes'],2);d['updatedAt']=datetime.datetime.now(datetime.timezone.utc).isoformat()
for f in d['files']:
 a=(root/f['archivePath']).read_bytes();assert sha(a)==f['archiveSha256'];b=gzip.decompress(a) if f['compression']=='gzip' else a;assert len(b)==f['rawBytes'] and sha(b)==f['rawSha256']
assert len(d['files'])==len({f['archivePath'] for f in d['files']});assert d['totals']['screenshots']==11
manifest.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'status':'FINALIZED','manifest':str(manifest),'totals':d['totals'],'verifiedRoundTrips':len(d['files'])}))
