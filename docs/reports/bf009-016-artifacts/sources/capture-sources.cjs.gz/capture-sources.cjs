const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const { chromium } = require('/tmp/xk-browser-check/node_modules/playwright-core');
const out = '/tmp/xk-bf009-016/sources';
const entries = [
 ['march-tangbao','https://xk2022.github.io/xk-showcase-march-tangbao/'],
 ['hongjia-birdnest','https://xk2022.github.io/xk-showcase-hongjia-birdnest/'],
 ['yupinyuan-bento','https://xk2022.github.io/xk-showcase-yupinyuan-bento/'],
 ['campaign-website-design','https://xk2022.github.io/xk-campaign-website-design/'],
 ['honest-diecut','https://xk2022.github.io/xk-showcase-honest-diecut/'],
 ['qiangang-windows','https://xk2022.github.io/xk-showcase-qiangang-windows/'],
 ['demo-001','https://xk2022.github.io/single-demo001/'],
 ['demo-002','https://xk2022.github.io/single-demo002/'],
 ['demo-003','https://xk2022.github.io/single-demo003/'],
 ['demo-004','https://xk2022.github.io/single-demo004/'],
];
(async()=>{
 const browser = await chromium.launch({executablePath:'/usr/bin/chromium',headless:true,args:['--no-sandbox']});
 const trustContext = await browser.newContext({viewport:{width:1280,height:800}});
 const trustPage = await trustContext.newPage();
 let trustProbe;
 try {const r=await trustPage.goto(entries[5][1],{waitUntil:'domcontentloaded',timeout:20000});trustProbe={checkedAt:new Date().toISOString(),ignoreHTTPSErrors:false,status:r.status()};}
 catch(e) {trustProbe={checkedAt:new Date().toISOString(),ignoreHTTPSErrors:false,error:e.message};}
 await trustContext.close();
 const context=await browser.newContext({viewport:{width:1280,height:800},deviceScaleFactor:1,ignoreHTTPSErrors:true,reducedMotion:'reduce'});
 const manifest={startedAt:new Date().toISOString(),browserVersion:browser.version(),viewport:{width:1280,height:800},deviceScaleFactor:1,ignoreHTTPSErrors:true,trustProbe,limitation:'A normal-trust request was attempted separately. Browser capture with ignoreHTTPSErrors is not certificate-trust verification.',entries:[]};
 for(let i=0;i<entries.length;i+=3) await Promise.all(entries.slice(i,i+3).map(async([id,url])=>{
  const page=await context.newPage(); const errors={pageErrors:[],requestFailures:[],httpErrors:[]};
  page.on('pageerror',e=>errors.pageErrors.push(e.message));
  page.on('requestfailed',r=>errors.requestFailures.push({url:r.url(),error:r.failure()?.errorText}));
  page.on('response',r=>{if(r.status()>=400)errors.httpErrors.push({url:r.url(),status:r.status()});});
  const response=await page.goto(url,{waitUntil:'networkidle',timeout:60000});
  await page.evaluate(async()=>{await document.fonts.ready;await Promise.all([...document.images].filter(i=>i.loading!=='lazy').map(i=>i.decode().catch(()=>{})));});
  const data=await page.evaluate(()=>({title:document.title,bodyText:document.body.innerText,headings:[...document.querySelectorAll('h1,h2,h3,h4')].map(e=>({level:e.tagName,text:e.innerText})),links:[...document.querySelectorAll('a')].map(e=>({text:e.innerText,href:e.href})),forms:[...document.forms].map(f=>({action:f.getAttribute('action'),method:f.method,text:f.innerText,controls:[...f.elements].map(e=>({tag:e.tagName,type:e.type,id:e.id,name:e.name,required:e.required,options:e.options?[...e.options].map(o=>({value:o.value,text:o.text})):undefined,label:e.labels?[...e.labels].map(l=>l.innerText):[],placeholder:e.placeholder}))})),buttons:[...document.querySelectorAll('button')].map(e=>({text:e.innerText,type:e.type,disabled:e.disabled})),images:[...document.images].map(i=>({src:i.currentSrc||i.src,alt:i.alt,complete:i.complete,width:i.naturalWidth,height:i.naturalHeight,inViewport:i.getBoundingClientRect().top<innerHeight&&i.getBoundingClientRect().bottom>0})),backgrounds:[...document.querySelectorAll('*')].map(e=>({tag:e.tagName,class:e.className,background:getComputedStyle(e).backgroundImage})).filter(e=>e.background.includes('url(')),fontStatus:document.fonts.status,dimensions:{width:document.documentElement.scrollWidth,height:document.documentElement.scrollHeight}}));
  const screenshot=path.join(out,`${id}.png`);await page.screenshot({path:screenshot,fullPage:false});
  fs.writeFileSync(path.join(out,`${id}.html`),await page.content());
  fs.writeFileSync(path.join(out,`${id}.txt`),data.bodyText);
  const record={id,url,finalUrl:page.url(),status:response.status(),headers:await response.allHeaders(),checkedAt:new Date().toISOString(),...data,errors,screenshot:{path:screenshot,bytes:fs.statSync(screenshot).size,sha256:crypto.createHash('sha256').update(fs.readFileSync(screenshot)).digest('hex')}};
  fs.writeFileSync(path.join(out,`${id}.json`),JSON.stringify(record,null,2));manifest.entries.push(record); await page.close();
 }));
 manifest.assets=[];
 for(const [id,url] of [
  ['demo-002-background','https://xk2022.github.io/single-demo002/assets/assets/img/bg-masthead.jpg'],
  ['demo-002-background-alternative','https://xk2022.github.io/single-demo002/assets/img/bg-masthead.jpg'],
  ['demo-003-logo','https://xk2022.github.io/single-demo003/img/logo.png'],
  ['demo-001-contact-map','https://xk2022.github.io/single-demo001/assets/img/map-image.png']
 ]){const r=await context.request.get(url);manifest.assets.push({id,url,status:r.status(),headers:r.headers(),checkedAt:new Date().toISOString()});}
 manifest.entries.sort((a,b)=>entries.findIndex(e=>e[0]===a.id)-entries.findIndex(e=>e[0]===b.id));manifest.finishedAt=new Date().toISOString();
 fs.writeFileSync(path.join(out,'source-manifest.json'),JSON.stringify(manifest,null,2));await browser.close();
 console.log(JSON.stringify({entries:manifest.entries.map(e=>({id:e.id,status:e.status,title:e.title,errors:e.errors})),assets:manifest.assets,trustProbe},null,2));
})().catch(e=>{console.error(e);process.exit(1)});
