import assert from 'node:assert/strict';
import fs from 'node:fs';
import {websiteShowcases,brandWebsiteShowcases,websiteSamples,featuredWebsiteShowcases,showcaseSettings,showcaseSeoPages,getBrandShowcase,showcaseDetailPath} from '/workspace/xk-website/src/config/website-showcases.ts';
const expected=['march-tangbao','hongjia-birdnest','yupinyuan-bento','campaign-website-design','honest-diecut','qiangang-windows'];
assert.deepEqual(brandWebsiteShowcases.map(s=>s.id),expected);assert.deepEqual(showcaseSettings.brandOrder,expected);assert.equal(websiteShowcases.length,10);assert.equal(websiteSamples.length,4);assert.equal(showcaseSeoPages.length,6);assert.deepEqual(featuredWebsiteShowcases.map(s=>s.id),['march-tangbao','hongjia-birdnest','honest-diecut']);
for(const id of expected){const s=getBrandShowcase(id);assert.ok(s?.href&&s.image&&s.detail);assert.equal(s.detail.designDecisions.length,3);assert.ok(s.detail.implementedFeatures.length>0&&s.detail.limitations.length>0);assert.ok(showcaseSeoPages.some(p=>p.path===showcaseDetailPath(id)&&p.availability==='public'));}
assert.equal(getBrandShowcase('demo-001'),undefined);assert.equal(getBrandShowcase('unknown'),undefined);
for(const id of ['demo-002','demo-003']){const s=websiteSamples.find(s=>s.id===id);assert.equal(s.availability,'reference-only');assert.equal(s.href,null);assert.equal(s.image,null);assert.ok(s.sourceHref&&s.attribution);assert.equal(s.detail,undefined);}
const bento=JSON.parse(fs.readFileSync('/tmp/xk-bf009-016/sources/yupinyuan-bento-interaction-retest.json'));const preview=bento.outputControls.find(c=>c.id==='order-message');assert.ok(preview.text.includes('20 份')&&preview.text.includes('社團例會'));
const originalBento=JSON.parse(fs.readFileSync('/tmp/xk-bf009-016/sources/yupinyuan-bento-interaction.json'));assert.deepEqual(originalBento.nonGetRequests,[]);
console.log(JSON.stringify({contract:'PASS',brandCount:6,templateCount:4,seoCount:6,referenceOnly:['demo-002','demo-003'],bentoRetest:'Existing native sample preview confirmed offline after undefined status-node text caused generic helper assertion error.'},null,2));
