const fs=require('node:fs');
const assert=require('node:assert/strict');
const {chromium}=require('/tmp/xk-browser-check/node_modules/playwright-core');
const dir='/tmp/xk-bf009-016/sources';
(async()=>{
 const browser=await chromium.launch({executablePath:'/usr/bin/chromium',headless:true,args:['--no-sandbox']});const results=[];
 for(const [id,submit,marker]of[
 ['march-tangbao','產生預留訊息','複製'],
 ['hongjia-birdnest','產生模擬洽詢摘要','模擬'],
 ['yupinyuan-bento',null,'詢問內容預覽'],
 ['campaign-website-design','產生需求摘要','你的建站需求摘要'],
 ['honest-diecut','產生模擬詢價摘要','模擬詢價已完成'],
 ['qiangang-windows','產生需求摘要','模擬換窗詢問已完成']]){
  const context=await browser.newContext({viewport:{width:1280,height:800},ignoreHTTPSErrors:true,reducedMotion:'reduce'});const page=await context.newPage();const source=JSON.parse(fs.readFileSync(`${dir}/${id}.json`));const requests=[];const result={id,startedAt:new Date().toISOString(),checks:[]};
  try{
   await page.goto(source.url,{waitUntil:'networkidle',timeout:60000});
   if(id==='hongjia-birdnest'){
    result.sampleButtonEnabled=await page.getByRole('button',{name:'帶入示範資料',exact:true}).isEnabled();
    await page.getByLabel('個人送禮',{exact:true}).check();await page.locator('#gift-email').fill('gift@example.com');await page.locator('#gift-quantity').fill('12');
    result.checks.push('Used native personal-gift fields with synthetic data because sample-data button was disabled.');
   }else await page.getByRole('button',{name:'帶入示範資料',exact:true}).click();
   page.on('request',r=>{if(r.method()!=='GET')requests.push({method:r.method(),url:r.url()});});
   result.beforeSubmitValues=await page.locator('input,select,textarea').evaluateAll(es=>es.map(e=>({id:e.id,type:e.type,value:e.value,checked:e.checked})));
   if(submit)await page.getByRole('button',{name:submit,exact:true}).click();
   result.afterActionText=await page.locator('body').innerText();assert.ok(result.afterActionText.includes(marker),`${id}: expected summary marker ${marker}`);
   result.outputControls=await page.locator('textarea,output,[role="status"]').evaluateAll(es=>es.map(e=>({tag:e.tagName,id:e.id,text:e.innerText||e.value})));
   if(id==='yupinyuan-bento')assert.ok(result.outputControls.some(e=>e.text.includes('20')),'bento sample summary should contain 20 portions');
   if(id==='qiangang-windows'){
    result.routes=[];
    for(const route of ['visit','project']){
     await page.getByRole('button',{name:'返回修改',exact:true}).click();await page.locator('#field-route').selectOption(route);await page.getByRole('button',{name:'帶入示範資料',exact:true}).click();
     const fields=await page.locator('form').innerText();await page.getByRole('button',{name:'產生需求摘要',exact:true}).click();const text=await page.locator('body').innerText();assert.equal(await page.locator('form').count(),0,`qia ${route} should render summary`);assert.ok(text.includes('未傳送給千剛實業'));
     result.routes.push({route,fields,summaryText:text.slice(text.indexOf('XK 提案體驗'))});
    }
   }
   assert.equal(requests.length,0,'no non-GET requests should result from synthetic summary action');result.nonGetRequests=requests;result.outcome='PASS';
  }catch(e){result.outcome='FAIL';result.error=e.message;result.currentText=await page.locator('body').innerText().catch(()=>null);}
  result.finishedAt=new Date().toISOString();fs.writeFileSync(`${dir}/${id}-interaction-retest.json`,JSON.stringify(result,null,2));results.push({id,outcome:result.outcome,error:result.error});await context.close();
 }
 await browser.close();fs.writeFileSync(`${dir}/interactions-retest.json`,JSON.stringify(results,null,2));console.log(JSON.stringify(results,null,2));if(results.some(r=>r.outcome!=='PASS'))process.exit(1);
})().catch(e=>{console.error(e);process.exit(1)});
