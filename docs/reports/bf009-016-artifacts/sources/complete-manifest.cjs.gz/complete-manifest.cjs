const fs=require('node:fs');
const {chromium}=require('/tmp/xk-browser-check/node_modules/playwright-core');
const dir='/tmp/xk-bf009-016/sources';
(async()=>{
 const browser=await chromium.launch({executablePath:'/usr/bin/chromium',headless:true,args:['--no-sandbox']});
 const trusted=await browser.newContext(); const tp=await trusted.newPage();let trustProbe;
 try{let r=await tp.goto('https://xk2022.github.io/xk-showcase-qiangang-windows/',{waitUntil:'domcontentloaded',timeout:20000});trustProbe={checkedAt:new Date().toISOString(),ignoreHTTPSErrors:false,status:r.status()};}catch(e){trustProbe={checkedAt:new Date().toISOString(),ignoreHTTPSErrors:false,error:e.message};}await trusted.close();
 const context=await browser.newContext({viewport:{width:1280,height:800},ignoreHTTPSErrors:true});const page=await context.newPage();const assets=[];
 for(const [id,url]of[
 ['demo-002-background','https://xk2022.github.io/single-demo002/assets/assets/img/bg-masthead.jpg'],
 ['demo-002-background-alternative','https://xk2022.github.io/single-demo002/assets/img/bg-masthead.jpg'],
 ['demo-003-logo','https://xk2022.github.io/single-demo003/img/logo.png'],
 ['demo-001-contact-map','https://xk2022.github.io/single-demo001/assets/assets/img/map-image.png']]){
 let r=await page.goto(url,{waitUntil:'domcontentloaded',timeout:30000}); assets.push({id,url,status:r.status(),headers:await r.allHeaders(),checkedAt:new Date().toISOString()});
 }
 const ids=['march-tangbao','hongjia-birdnest','yupinyuan-bento','campaign-website-design','honest-diecut','qiangang-windows','demo-001','demo-002','demo-003','demo-004'];const entries=ids.map(id=>JSON.parse(fs.readFileSync(`${dir}/${id}.json`)));
 const manifest={startedAt:entries[0].checkedAt,finishedAt:new Date().toISOString(),viewport:{width:1280,height:800},deviceScaleFactor:1,browserVersion:browser.version(),ignoreHTTPSErrors:true,trustProbe,limitations:['Normal trust returned ERR_CERT_AUTHORITY_INVALID; captures used ignoreHTTPSErrors and are not certificate-trust verification.','Initial capture command completed all ten source pages but failed during direct API asset request because API context bypassed the working Chromium network proxy. Original failed receipt/log retained. Asset checks below use fresh Chromium page navigation.'],entries,assets};
 fs.writeFileSync(`${dir}/source-manifest.json`,JSON.stringify(manifest,null,2));await browser.close();console.log(JSON.stringify({entries:entries.map(e=>({id:e.id,status:e.status,title:e.title})),assets,trustProbe},null,2));
})().catch(e=>{console.error(e);process.exit(1)});
