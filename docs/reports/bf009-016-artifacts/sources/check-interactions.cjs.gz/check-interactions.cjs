const fs=require('node:fs');
const {chromium}=require('/tmp/xk-browser-check/node_modules/playwright-core');
const dir='/tmp/xk-bf009-016/sources';
const tasks=[['march-tangbao','產生預留訊息'],['hongjia-birdnest','產生模擬洽詢摘要'],['yupinyuan-bento',null],['campaign-website-design','產生需求摘要'],['honest-diecut','產生模擬詢價摘要'],['qiangang-windows','產生需求摘要']];
(async()=>{
 const browser=await chromium.launch({executablePath:'/usr/bin/chromium',headless:true,args:['--no-sandbox']});
 const results=[];
 for(const [id,submit]of tasks){
  const context=await browser.newContext({viewport:{width:1280,height:800},ignoreHTTPSErrors:true,reducedMotion:'reduce'});const page=await context.newPage();
  const source=JSON.parse(fs.readFileSync(`${dir}/${id}.json`));let requests=[];let result={id,startedAt:new Date().toISOString(),steps:[],nonGetRequests:[],limitation:'Only the public demo flow and synthetic sample data were exercised; no business order, booking or enquiry was sent.'};
  try{
   await page.goto(source.url,{waitUntil:'networkidle',timeout:60000});
   await page.getByRole('button',{name:'帶入示範資料',exact:true}).waitFor({state:'visible'});
   await page.getByRole('button',{name:'帶入示範資料',exact:true}).click({timeout:10000});result.steps.push('Clicked native sample-data button');
   if(await page.getByRole('button',{name:'確認帶入示範資料',exact:true}).isVisible())await page.getByRole('button',{name:'確認帶入示範資料',exact:true}).click();
   if(await page.getByRole('button',{name:'載入示範',exact:true}).isVisible())await page.getByRole('button',{name:'載入示範',exact:true}).click();
   page.on('request',r=>{if(r.method()!=='GET')requests.push({method:r.method(),url:r.url()})});
   if(submit){await page.getByRole('button',{name:submit,exact:true}).click();result.steps.push(`Clicked ${submit}`);}
   result.afterActionText=await page.locator('body').innerText();
   result.formValues=await page.locator('form').evaluate(f=>[...f.elements].filter(e=>e.tagName!=='BUTTON'&&e.type!=='fieldset').map(e=>({id:e.id,type:e.type,value:e.value,checked:e.checked,valid:e.validity?.valid})));
   result.generatedOutput=await page.locator('textarea,output,[role="status"],[role="dialog"]').evaluateAll(es=>es.map(e=>({tag:e.tagName,role:e.getAttribute('role'),id:e.id,text:e.innerText||e.value})));
   result.nonGetRequests=requests;result.outcome=requests.length===0?'COMPLETED_NO_NON_GET_REQUESTS':'REVIEW_NON_GET_REQUESTS';
   if(id==='qiangang-windows'){
    result.residential={formValues:result.formValues,outputs:result.generatedOutput};
    for(const route of ['visit','project']){
     await page.locator('#field-route').selectOption(route);
     await page.getByRole('button',{name:'帶入示範資料',exact:true}).click();
     result[route]={bodyText:await page.locator('form').innerText(),controls:await page.locator('form').evaluate(f=>[...f.elements].map(e=>({id:e.id,type:e.type,value:e.value,required:e.required,options:e.options?[...e.options].map(o=>({value:o.value,text:o.text})):undefined})))};
     await page.getByRole('button',{name:'產生需求摘要',exact:true}).click();
     result[route].afterSubmit=await page.locator('body').innerText();
    }
   }
  }catch(e){result.outcome='FAILED';result.error=e.message;result.currentText=await page.locator('body').innerText().catch(()=>null);}
  result.finishedAt=new Date().toISOString();fs.writeFileSync(`${dir}/${id}-interaction.json`,JSON.stringify(result,null,2));results.push({id,outcome:result.outcome,error:result.error});await context.close();
 }
 fs.writeFileSync(`${dir}/interactions.json`,JSON.stringify(results,null,2));await browser.close();console.log(JSON.stringify(results,null,2));if(results.some(r=>r.outcome==='FAILED'))process.exit(1);
})().catch(e=>{console.error(e);process.exit(1)});
