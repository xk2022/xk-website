import json,re
from pathlib import Path
base=Path('/tmp/xk-bf009-016');r=json.loads((base/'pages-final/result.json').read_text());receipt=json.loads((base/'browser-pages.json').read_text());assert receipt['exitCode']==2 and r['status']=='MANUAL_PENDING';assert r['counters']['failedTests']==0 and r['counters']['actualAxe']==37 and r['counters']['actualResponsiveDefault']==75

def parse(s):
 if s.startswith('rgb'):
  x=[float(v)for v in re.findall(r'[\d.]+',s)];return x[:3],x[3]if len(x)>3 else 1
 m=re.fullmatch(r'oklab\(([-.\deE]+) ([-.\deE]+) ([-.\deE]+) / ([-.\deE]+)\)',s);assert m,s
 L,a,b,alpha=map(float,m.groups());l=(L+.3963377774*a+.2158037573*b)**3;m0=(L-.1055613458*a-.0638541728*b)**3;s0=(L-.0894841775*a-1.291485548*b)**3
 lin=[4.0767416621*l-3.3077115913*m0+.2309699292*s0,-1.2684380046*l+2.6097574011*m0-.3413193965*s0,-.0041960863*l-.7034186147*m0+1.707614701*s0]
 return [255*max(0,min(1,12.92*v if v<=.0031308 else 1.055*v**(1/2.4)-.055))for v in lin],alpha

def lum(c):return sum(k*(v/255/12.92 if v/255<=.04045 else((v/255+.055)/1.055)**2.4)for k,v in zip([.2126,.7152,.0722],c))
def ratio(a,b):
 x,y=sorted([lum(a),lum(b)]);return(y+.05)/(x+.05)
def blend(f,a,b):return[x*a+y*(1-a)for x,y in zip(f,b)]
rows=[]
overlap=[]
for c in r['manualStyles']:
 for node in c['nodes']:
  e=node['element'];assert e and e['opacity']=='1';assert all(a['opacity']=='1'for a in node['ancestors']);fg,alpha=parse(e['color']);opaque=[parse(a['background'])[0]for a in node['ancestors']if parse(a['background'])[1]==1];assert opaque;bg=opaque[0]
  related=list({v['html']:v for v in node['relatedNodes']}.values())
  if not related:
   assert c['state']=='mobile-menu-expanded';overlap.append({'path':c['path'],'width':c['width'],'state':c['state'],'target':node['target'],'text':e['text']});continue
  assert len(related)==1
  html=related[0]['html']
  if'brand-pattern-gradient'in html:overlay,maximum=[25,184,213],.12
  elif'brand-pattern-kaleidoscope'in html:overlay,maximum=[49,87,213],.07
  else:raise ValueError(html)
  end=blend(overlay,maximum,bg);low=[min(a,b)for a,b in zip(bg,end)];high=[max(a,b)for a,b in zip(bg,end)];minimum=min(ratio(blend(fg,alpha,b),b)for b in [low,high]);threshold=3 if float(e['fontSize'][:-2])>=24 or(float(e['fontSize'][:-2])>=18.66 and int(e['fontWeight'])>=700)else 4.5
  rows.append({'path':c['path'],'width':c['width'],'state':c['state'],'target':node['target'],'text':e['text'],'foreground':e['color'],'opaqueBackground':bg,'relatedDecoration':html,'maximumAlpha':maximum,'minimumRatio':minimum,'requiredRatio':threshold,'status':'PASS'if minimum>=threshold else'FAIL'})
raw_nodes=sum(len(v['nodes'])for c in r['incomplete']for v in c['items']);assert len(rows)==370 and len(overlap)==19 and raw_nodes==389
out={'status':'PASS'if all(x['status']=='PASS'for x in rows)else'FAIL','browserReceiptExit':receipt['exitCode'],'browserStatus':r['status'],'manualContrastNodes':len(rows),'overlapNeedsSeparateReview':overlap,'minimumRatio':min(x['minimumRatio']for x in rows),'method':'Fresh actual computed foreground/opacity/opaque ancestors and exact axe-related decorative span. CSS accent gradient12% or kaleidoscope7% maximum opacity; masks reduce contribution. Channel bounds and WCAG luminance, exact Oklab conversion. This closes only these color-contrast incomplete candidates, not visual review, full WCAG certification or AT.','rows':rows};(base/'manual-contrast.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n');print({k:v for k,v in out.items()if k not in ['rows','overlapNeedsSeparateReview']});assert out['status']=='PASS'
