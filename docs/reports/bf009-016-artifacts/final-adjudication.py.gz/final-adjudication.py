import json,hashlib,datetime
from pathlib import Path
p=Path('/tmp/xk-bf009-016');browser=json.loads((p/'pages-final/result.json').read_text());contrast=json.loads((p/'manual-contrast.json').read_text());overlap=json.loads((p/'overlap-review.json').read_text());visual=json.loads((p/'visual-review.json').read_text());receipt=json.loads((p/'overlap-review.receipt.json').read_text());assert receipt['observedExitCode']==0
assert browser['status']=='MANUAL_PENDING'and browser['counters']['failedTests']==0 and browser['counters']['actualAxe']==37 and browser['counters']['actualResponsiveDefault']==75
assert contrast['status']=='PASS'and contrast['manualContrastNodes']==370
assert visual['status']=='PASS_WITH_SCOPE_LIMITATIONS'and visual['blockingCount']==0 and not visual['blockingFindings'];assert len(visual['sourceScreenshots'])==9
assert overlap['counters']['actualNodes']==overlap['counters']['uniqueLookups']==19 and not overlap['runtimeErrors']
closed_rows={(x['path'],x['width'],tuple(x['target'])):x for x in contrast['rows']if x['state']=='default'};rows=[]
for c in overlap['cases']:
 assert c['panelOpaque']and c['panel']['style']['backgroundColor']=='rgb(255, 255, 255)'and c['panel']['style']['opacity']=='1'
 for n in c['nodes']:
  closed=n['closed'];expanded=n['expanded'];assert closed['lookup']==expanded['lookup']=='UNIQUE'and n['textUnchanged'];assert not n['originalDefault375']['sameTargetViolations'];assert expanded['menuOverlap']['areaFraction']>0
  hit=[s for s in expanded['samples']if s['tested']];assert len(hit)==9;menu_hits=sum(s['topInsideMenu']for s in hit);assert menu_hits>=6
  key=(c['path'],375,tuple(n['target']));default=closed_rows.get(key)
  if default:
   assert default['status']=='PASS';default_ratio=default['minimumRatio'];method='Same exact text/target has current default-state conservative gradient PASS.'
  else:
   assert not n['originalDefault375']['sameTargetIncomplete'];assert closed['dom']['style']['backgroundColor']=='rgb(255, 255, 255)';default_ratio=closed['contrast']['ratioIgnoringDecorativeLayers'];assert default_ratio>=4.5;method='Opaque white badge isolates background; actual solid-color contrast >=4.5.'
  rows.append({'path':c['path'],'target':n['target'],'text':closed['dom']['text'],'coverage':expanded['menuOverlap']['classification'],'coverageFraction':expanded['menuOverlap']['areaFraction'],'menuTopHitTests':menu_hits,'sampleCount':len(hit),'defaultContrastRatio':default_ratio,'method':method,'decision':'PASS: covered area is not visible; exposed text retains verified default contrast. No waiver for new unreviewed colors.'})
assert len(rows)==19
out={'status':'PASS','reviewedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'BF009–016 local Pages UI/keyboard/responsive/axe/manual scope; not a full WCAG, real-device or AT certification.','browserCollectorExitCode':2,'browserCollectorStatus':'MANUAL_PENDING','browserRequiredFailures':0,'baseResponsive':75,'additionalResponsive':5,'axeScans':37,'axeViolations':0,'manualCandidates':389,'gradientCandidates':370,'minimumConservativeContrast':contrast['minimumRatio'],'overlapCandidates':19,'visualScreenshots':7,'focusContext':'Actual screenshot with blue 2px outline and 4px offset reviewed, not inferred from tight crop.','visualReviewStatus':visual['status'],'remainingScopeLimits':visual['limitations'],'evidence':{name:hashlib.sha256((p/name).read_bytes()).hexdigest()for name in['pages-final/result.json','manual-contrast.json','overlap-review.json','visual-review.json']},'overlapDecisions':rows};(p/'final-adjudication.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n');print({k:out[k]for k in['status','baseResponsive','axeScans','manualCandidates','gradientCandidates','overlapCandidates','minimumConservativeContrast']})
