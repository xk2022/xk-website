import sys,importlib.util,json,re,html
from pathlib import Path
from types import SimpleNamespace
from urllib.request import urlopen
sys.dont_write_bytecode=True
spec=importlib.util.spec_from_file_location('xksmoke','/workspace/xk-website/scripts/smoke-website.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
seo=json.load(open('/tmp/xk-bf009-016/seo.json'));rows=[]
for path in ['/','/about','/portfolio/showcases/qiangang-windows']:
 expected='https://xplorekaleidoscope.com'+('/'if path=='/'else path);bare=expected[:-1]if expected.endswith('/')else expected
 with urlopen('http://127.0.0.1:3161/xk-website'+(''if path=='/'else path)+'/',timeout=15)as response:source=response.read().decode()
 variants=[(bare,True),(bare+'/',True),('http://xplorekaleidoscope.com'+path,False),('https://example.invalid'+path,False),('https://xplorekaleidoscope.com/wrong-path',False),(bare+'?smoke=1',False),(bare+'#smoke',False),(bare+'//',False)]
 for url,passing in variants:
  count=[0,0]
  def replace_link(match):count[0]+=1;return match[1]+html.escape(url,quote=True)+match[2]
  def replace_og(match):count[1]+=1;return match[1]+html.escape(url,quote=True)+match[2]
  fixture=re.sub(r'(<link\b[^>]*rel="canonical"[^>]*href=")[^"]*(")',replace_link,source)
  fixture=re.sub(r'(<meta\b[^>]*property="og:url"[^>]*content=")[^"]*(")',replace_og,fixture);assert count==[1,1],count
  suite=m.Smoke(SimpleNamespace(base_url='http://127.0.0.1:3161/xk-website/',check_external=False,check_source_assets=False,timeout=5));suite.data={'siteConfig':{'url':'https://xplorekaleidoscope.com','name':'Xplore Kaleidoscope'}};suite.public_pages=seo;suite.metadata(path,m.Document(fixture).root);checks=[x for x in suite.results if x['item']in[f'{path} exact canonical',f'{path} exact og:url']];assert len(checks)==2;assert all((x['status']=='PASS')==passing for x in checks),(url,checks)
  rows.append({'path':path,'input':url,'expectedPass':passing,'observed':[x['status']for x in checks]})
out={'status':'PASS','cases':len(rows),'scope':'Synthetic metadata fixtures from current Pages HTML; only root/trailingSlash equivalent accepted. Wrong scheme, domain, path, query, fragment and repeated slash rejected. No requests to synthetic destinations.','rows':rows};Path('/tmp/xk-bf009-016/smoke-metadata-negative.json').write_text(json.dumps(out,indent=2)+'\n');print({'status':'PASS','cases':len(rows)})
