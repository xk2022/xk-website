#!/usr/bin/env python3
"""Read-only DC-004 delivery checks. Run only after Root seals documentation/evidence."""

import argparse
from datetime import datetime, timezone
import gzip
import hashlib
import html
import json
from pathlib import Path
import re
import subprocess
import sys
from urllib.parse import unquote, urlsplit


BASE = "8ba299a5a48da41ca7f4d88d9b2149d7c83f6584"
V5_FINGERPRINT = "daafeceb4aec69b766f70f5430687d82a11455a9ebc7579ea4f032da85db6a0f"
SOURCE_ROOTS = ["src", "public", "scripts", "package.json", "package-lock.json", "next.config.ts", "tsconfig.json", ".github"]
FROZEN_STACK = ["package.json", "package-lock.json", "next.config.ts", "tsconfig.json", ".github/workflows/ci.yml", ".nvmrc"]
TEXT_SUFFIXES = {".md", ".ts", ".tsx", ".js", ".jsx", ".mjs", ".cjs", ".css", ".json", ".html", ".yml", ".yaml", ".py", ".txt", ".xml", ".svg"}
BINARY_SUFFIXES = {".png", ".jpg", ".jpeg", ".webp", ".gif", ".ico", ".pdf", ".woff", ".woff2", ".ttf"}
SECRET = re.compile(rb"-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----|github_pat_[A-Za-z0-9_]{20,}|gh[pousr]_[A-Za-z0-9_]{20,}|[?&](?:X-Amz-Signature|sig|access_token)=", re.I)


def now():
    return datetime.now(timezone.utc).isoformat()


def sha(data):
    return hashlib.sha256(data).hexdigest()


def decoded_bytes(path):
    data = path.read_bytes()
    return gzip.decompress(data) if path.suffix == ".gz" else data


def beneath(root, name):
    path = (root / name).resolve()
    if not path.is_relative_to(root.resolve()):
        raise ValueError("Path escapes its declared root: " + str(name))
    return path


def git(root, *args):
    result = subprocess.run(["git", "--no-optional-locks", *args], cwd=root, capture_output=True)
    if result.returncode:
        raise RuntimeError("git " + " ".join(args) + ": " + result.stderr.decode(errors="replace"))
    return result.stdout


def git_names(root, *args):
    return [name for name in git(root, *args).decode().split("\0") if name]


def visible_markdown(text):
    """Exclude fenced blocks while retaining line numbers for format checks."""
    visible = []
    fence = None
    for number, line in enumerate(text.splitlines(), 1):
        marker = re.match(r"^ {0,3}(`{3,}|~{3,})(.*)$", line)
        if fence:
            if marker and marker[1][0] == fence[0] and len(marker[1]) >= fence[1] and not marker[2].strip():
                fence = None
            continue
        if marker:
            fence = (marker[1][0], len(marker[1]))
            continue
        visible.append((number, line))
    return visible, fence is not None


def anchors_for(path):
    text = path.read_text()
    explicit = set(re.findall(r"\b(?:id|name)\s*=\s*['\"]([^'\"]+)['\"]", text))
    if path.suffix.lower() != ".md":
        return explicit
    visible, _ = visible_markdown(text)
    used = set()
    headings = []
    previous = ""
    for _, line in visible:
        match = re.match(r"^ {0,3}#{1,6}[ \t]+(.+?)(?:[ \t]+#+[ \t]*)?$", line)
        if match:
            headings.append(match[1])
        elif previous.strip() and re.fullmatch(r" {0,3}(?:=+|-+)[ \t]*", line):
            headings.append(previous.strip())
        previous = line
    for title in headings:
        title = re.sub(r"!?\[([^\]]+)\]\([^)]*\)", r"\1", title)
        title = html.unescape(re.sub(r"<[^>]*>", "", title)).strip().lower()
        stem = re.sub(r"[^\w\- ]", "", title).replace(" ", "-")
        candidate = stem
        suffix = 0
        while candidate in used:
            suffix += 1
            candidate = stem + "-" + str(suffix)
        used.add(candidate)
    return explicit | used


def markdown_destinations(body):
    """Handle inline destinations with balanced parentheses, titles and angle paths."""
    result = []
    for match in re.finditer(r"!?\[(?:\\.|[^\]\\])*\]\(", body):
        index = match.end()
        while index < len(body) and body[index].isspace():
            index += 1
        if index < len(body) and body[index] == "<":
            end = body.find(">", index + 1)
            if end >= 0:
                result.append(body[index + 1:end])
            continue
        value, depth = [], 0
        while index < len(body):
            char = body[index]
            if char == "\\" and index + 1 < len(body):
                value.append(body[index + 1])
                index += 2
                continue
            if char == "(" :
                depth += 1
            elif char == ")":
                if depth == 0:
                    break
                depth -= 1
            elif char.isspace() and depth == 0:
                break
            value.append(char)
            index += 1
        if value:
            result.append("".join(value))
    result.extend(match[1] or match[2] for match in re.finditer(r"^ {0,3}\[[^\]]+\]:\s*(?:<([^>]+)>|(\S+))", body, re.M))
    result.extend(match[1] for match in re.finditer(r"<(?:a|img)\b[^>]*\b(?:href|src)\s*=\s*['\"]([^'\"]+)['\"]", body))
    return result


def check_source(root, source_path):
    source = json.loads(source_path.read_text())
    files = source["files"]
    fingerprint = sha("".join(f"{name}\0{value}\n" for name, value in sorted(files.items())).encode())
    actual_names = set(git_names(root, "ls-files", "-z", "--cached", "--others", "--exclude-standard", "--", *SOURCE_ROOTS))
    mismatches = []
    for name, expected in files.items():
        path = beneath(root, name)
        actual = sha(path.read_bytes()) if path.is_file() else None
        if actual != expected:
            mismatches.append({"path": name, "expected": expected, "actual": actual})
    actual = {"source": str(source_path), "sourceFileSha256": sha(source_path.read_bytes()), "files": len(files), "fingerprint": fingerprint,
              "declaredFingerprint": source.get("sha256"), "base": source.get("base"), "mismatches": mismatches,
              "missingFromSourceInventory": sorted(actual_names - set(files)), "absentFromWorkingInventory": sorted(set(files) - actual_names)}
    ok = len(files) == 197 and fingerprint == source.get("sha256") == V5_FINGERPRINT and source.get("base") == BASE and not mismatches and actual_names == set(files)
    return ok, actual


def check_stack(root):
    changes = []
    for name in FROZEN_STACK:
        original = git(root, "show", BASE + ":" + name)
        current = beneath(root, name).read_bytes()
        if original != current:
            changes.append({"path": name, "baseSha256": sha(original), "actualSha256": sha(current)})
    return not changes, {"base": BASE, "files": FROZEN_STACK, "changed": changes}


def check_format(root, changed, new_names):
    errors, inspected = [], []
    for name in sorted(changed):
        path = beneath(root, name)
        if not path.is_file() or path.suffix.lower() not in TEXT_SUFFIXES:
            continue
        text = path.read_text()
        inspected.append(name)
        if text and (not text.endswith("\n") or text.endswith("\n\n")):
            errors.append({"path": name, "error": "expected one final LF", "newFile": name in new_names})
        if name in new_names and not text:
            errors.append({"path": name, "error": "empty new text file"})
        for number, line in enumerate(text.splitlines(), 1):
            if line.rstrip() != line:
                errors.append({"path": name, "line": number, "error": "trailing whitespace"})
            if re.match(r"^(?:<{7}(?: |$)|={7}$|>{7}(?: |$))", line):
                errors.append({"path": name, "line": number, "error": "conflict marker"})
        if path.suffix.lower() == ".md":
            visible, unclosed = visible_markdown(text)
            if unclosed:
                errors.append({"path": name, "error": "unclosed Markdown fence"})
            for number, line in visible:
                if re.match(r"^ {0,3}#{1,6}[^#\s]", line):
                    errors.append({"path": name, "line": number, "error": "Markdown heading needs a space after #"})
    return not errors, {"inspectedTextFiles": len(inspected), "errors": errors}


def check_markdown(root, changed):
    documents, checked, errors = [], 0, []
    for name in sorted(changed):
        path = beneath(root, name)
        if path.suffix.lower() != ".md" or not path.is_file():
            continue
        documents.append(name)
        visible, _ = visible_markdown(path.read_text())
        for destination in markdown_destinations("\n".join(line for _, line in visible)):
            parsed = urlsplit(html.unescape(destination))
            if parsed.scheme or parsed.netloc:
                continue
            checked += 1
            relative = unquote(parsed.path)
            target = beneath(root, relative.lstrip("/")) if relative.startswith("/") else (path.parent / relative).resolve() if relative else path
            if not target.is_relative_to(root):
                errors.append({"path": name, "link": destination, "error": "local link escapes repository"})
            elif not target.exists():
                errors.append({"path": name, "link": destination, "error": "missing local target"})
            elif parsed.fragment and target.is_file() and target.suffix.lower() in {".md", ".html", ".svg"}:
                if unquote(parsed.fragment) not in anchors_for(target):
                    errors.append({"path": name, "link": destination, "error": "missing local anchor"})
    return not errors, {"documents": documents, "localLinks": checked, "errors": errors, "scope": "Changed tracked and untracked Markdown only; target anchors are read without recursively auditing historical documents."}


def check_manifest(directory):
    manifest = directory / "SHA256SUMS"
    rows, errors = {}, []
    for number, line in enumerate(manifest.read_text().splitlines(), 1):
        if not line.strip():
            continue
        match = re.fullmatch(r"([a-fA-F0-9]{64}) [ *](.+)", line)
        if not match:
            errors.append({"line": number, "error": "invalid SHA256SUMS entry"})
            continue
        digest, name = match[1].lower(), match[2]
        if name in rows:
            errors.append({"path": name, "error": "duplicate manifest entry"})
        rows[name] = digest
        target = beneath(directory, name)
        if not target.is_file():
            errors.append({"path": name, "error": "missing manifest file"})
        elif sha(target.read_bytes()) != digest:
            errors.append({"path": name, "error": "manifest SHA mismatch"})
    actual = {str(path.relative_to(directory)) for path in directory.rglob("*") if path.is_file() and path != manifest}
    omitted = sorted(actual - set(rows))
    extra = sorted(set(rows) - actual)
    if not rows:
        errors.append({"error": "manifest is empty"})
    return not errors and not omitted and not extra, {"directory": str(directory), "listedFiles": len(rows), "actualFiles": len(actual), "omittedFiles": omitted, "extraEntries": extra, "errors": errors}


def check_receipts(directory):
    receipts, errors = [], []
    for path in sorted(directory.rglob("*")):
        if not path.is_file() or not (path.name.endswith(".json") or path.name.endswith(".json.gz")):
            continue
        data = json.loads(decoded_bytes(path))
        if not isinstance(data, dict) or not data.get("logSha256"):
            continue
        name = Path(data.get("logFile", "")).name
        expected = data["logSha256"]
        candidates = list(dict.fromkeys([path.parent / name, path.parent / (name + ".gz"), directory / name, directory / (name + ".gz")]))
        observed = [{"path": str(candidate.relative_to(directory)), "sha256": sha(decoded_bytes(candidate))} for candidate in candidates if candidate.is_file()]
        complete = isinstance(data.get("exitCode"), int) and isinstance(data.get("returnCode"), int) and data.get("status") != "RUNNING"
        matches = [item for item in observed if item["sha256"] == expected]
        receipts.append({"receipt": str(path.relative_to(directory)), "status": data.get("status"), "exitCode": data.get("exitCode"), "logSha256": expected, "matchedLogs": matches})
        if not name or not matches or not complete:
            errors.append({"receipt": str(path.relative_to(directory)), "error": "missing/mismatched archived raw-or-gzip log or incomplete OS receipt", "observedLogs": observed})
    return bool(receipts) and not errors, {"receipts": len(receipts), "records": receipts, "errors": errors, "notes": "Preserved FAIL/TIMEOUT receipts are allowed when complete and hash-verifiable; this check never reclassifies them as successful test runs."}


def check_secrets(root, changed):
    secrets, banned, scanned = [], [], 0
    for name in sorted(changed):
        if any(part in {".git", ".next", "out", "node_modules"} or part.startswith(".env") for part in Path(name).parts):
            banned.append(name)
        path = beneath(root, name)
        if not path.is_file() or path.suffix.lower() in BINARY_SUFFIXES:
            continue
        scanned += 1
        if SECRET.search(decoded_bytes(path)):
            secrets.append(name)
    return not secrets and not banned, {"scannedFiles": scanned, "suspectedSecretFiles": secrets, "forbiddenBuildOrEnvironmentPaths": banned, "notes": "Pattern scan of changed deliverables, including decompressed gzip evidence; not a claim of exhaustive secret detection."}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=Path("/workspace/xk-website"))
    parser.add_argument("--source", type=Path, default=Path("/tmp/xk-dc004/source-final-v5.json"))
    parser.add_argument("--artifacts", default="docs/reports/dc004-artifacts")
    parser.add_argument("--screenshots", default="docs/screenshots/design-collection/dc004")
    parser.add_argument("--output", type=Path, default=Path("/tmp/xk-dc004/final-check-result.json"))
    args = parser.parse_args()
    root = args.root.resolve()
    output = args.output.resolve()
    if output.exists():
        parser.error("Refusing to overwrite prior evidence; choose a new --output path")
    if output.is_relative_to(root):
        parser.error("Keep new result evidence outside the repository until Root archives it")
    started, checks = now(), []

    def run(test_id, function):
        try:
            ok, actual = function()
        except Exception as error:
            ok, actual = False, {"error": type(error).__name__ + ": " + str(error)}
        checks.append({"testId": test_id, "testedAt": now(), "environment": str(root), "expected": "all declared checks satisfied", "actual": actual, "status": "PASS" if ok else "FAIL"})

    changed = set(git_names(root, "diff", "--name-only", "-z", BASE, "--")) | set(git_names(root, "ls-files", "-z", "--others", "--exclude-standard"))
    base_names = set(git_names(root, "ls-tree", "-r", "--name-only", "-z", BASE))
    new_names = changed - base_names
    artifacts, screenshots = beneath(root, args.artifacts), beneath(root, args.screenshots)
    run("DC4-FINAL-SOURCE-V5", lambda: check_source(root, args.source.resolve()))
    run("DC4-FINAL-STACK-WORKFLOW-VERSION-LOCK", lambda: check_stack(root))

    def whitespace():
        result = subprocess.run(["git", "--no-optional-locks", "diff", "--check", BASE, "--"], cwd=root, capture_output=True, text=True)
        return result.returncode == 0, {"exitCode": result.returncode, "output": result.stdout + result.stderr}

    run("DC4-FINAL-DIFF-WHITESPACE", whitespace)
    run("DC4-FINAL-CHANGED-TEXT-FORMAT", lambda: check_format(root, changed, new_names))
    run("DC4-FINAL-MARKDOWN-LINKS-ANCHORS", lambda: check_markdown(root, changed))
    run("DC4-FINAL-ARTIFACT-MANIFEST", lambda: check_manifest(artifacts))
    run("DC4-FINAL-SCREENSHOT-MANIFEST", lambda: check_manifest(screenshots))
    run("DC4-FINAL-OS-RECEIPT-LOG-INTEGRITY", lambda: check_receipts(artifacts))
    run("DC4-FINAL-NO-SECRETS-OR-BUILD-DIRS", lambda: check_secrets(root, changed))
    status = "PASS" if all(check["status"] == "PASS" for check in checks) else "FAIL"
    result = {"suite": "DC-004 final source, documentation and evidence checks", "status": status, "exitCode": 0 if status == "PASS" else 1,
              "startedAt": started, "finishedAt": now(), "complete": True, "root": str(root), "base": BASE,
              "sourceFingerprint": V5_FINGERPRINT, "command": [sys.executable, *sys.argv], "changedFiles": sorted(changed), "newFiles": sorted(new_names), "checks": checks,
              "scopeNotes": ["Read-only repository inspection with optional Git locks disabled. No build/server/browser, dependency installation or repository mutation.", "Only current changed tracked/untracked deliverables are audited; historical Markdown is read only when resolving a current local link.", "Quality and browser outcomes remain their original evidence; receipt integrity is not test acceptance."]}
    output.parent.mkdir(parents=True, exist_ok=True)
    with output.open("x") as file:
        json.dump(result, file, ensure_ascii=False, indent=2)
        file.write("\n")
    print(json.dumps({"status": status, "exitCode": result["exitCode"], "result": str(output), "checks": [{"testId": check["testId"], "status": check["status"]} for check in checks]}, ensure_ascii=False, indent=2))
    return result["exitCode"]


if __name__ == "__main__":
    sys.exit(main())
