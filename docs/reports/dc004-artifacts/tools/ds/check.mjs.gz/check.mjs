import assert from 'node:assert/strict';
import { readFileSync, writeFileSync } from 'node:fs';
import { createRequire } from 'node:module';
import { heritageTokens, heritageThemeStyle } from '/workspace/xk-website/src/design-systems/heritage/index.ts';
import { requiredDesignTokenSchema, validateDesignSemanticTokens } from '/workspace/xk-website/src/lib/design-collection/tokens.ts';
const require = createRequire('/workspace/xk-website/package.json');
const postcss = require('postcss');
const result = validateDesignSemanticTokens(heritageTokens);
assert.deepEqual(result, {valid:true, errors:[]});
const count = Object.values(requiredDesignTokenSchema).reduce((sum, group) => sum + Object.keys(group).length, 0);
assert.equal(Object.keys(heritageThemeStyle).length, count);
assert.equal(heritageThemeStyle['--htg-color-background'], '#F4E9D8');
assert.equal(heritageThemeStyle['--htg-color-error-text'], '#B42318');
assert.equal(heritageThemeStyle['--htg-motion-reduced-duration'], '0ms');
assert.equal(heritageThemeStyle['--htg-typography-body-line-height'], 1.8);
assert(heritageThemeStyle['--htg-typography-body-font'].includes('var(--font-inter), var(--font-noto-sans-tc)'));
assert(!heritageThemeStyle['--htg-typography-body-font'].includes('var(--font-sans)'));
assert(Object.isFrozen(heritageTokens) && Object.values(heritageTokens).every(Object.isFrozen) && Object.isFrozen(heritageThemeStyle));
const css = readFileSync('/workspace/xk-website/src/design-systems/heritage/heritage.css', 'utf8');
const tree = postcss.parse(css);
let selectors = 0;
tree.walkRules((rule) => {
  for (const selector of postcss.list.comma(rule.selector)) {
    assert(selector.startsWith('.heritage-theme'), `unscoped selector ${selector}`);
    assert(!/^\.heritage-theme\s+(?:h[1-6]|p|ul|ol|a|input)\b/.test(selector), `generic reset ${selector}`);
    if (selector.includes('.quotation-paper')) assert(selector.includes(':not(:where(.quotation-paper, .quotation-paper *))'), 'paper only appears as explicit exclusion');
    selectors++;
  }
});
tree.walkAtRules((rule) => assert.notEqual(rule.name, 'page', 'no global @page rule'));
const definitions = new Set([...Object.keys(heritageThemeStyle), ...[...css.matchAll(/(--htg-[\w-]+)\s*:/g)].map((match) => match[1])]);
for (const match of css.matchAll(/var\((--htg-[\w-]+)/g)) assert(definitions.has(match[1]), `undefined semantic reference ${match[1]}`);
const frame = readFileSync('/workspace/xk-website/src/components/design-collection/heritage/heritage-frame.tsx', 'utf8');
assert(frame.includes('style={heritageThemeStyle}'), 'frame applies all emitted roles');
assert(css.includes(':has([data-quotation-page="true"])'), 'precise active print marker');
const luminance = (hex) => {
  const channels = hex.slice(1).match(/../g).map((part) => parseInt(part, 16) / 255).map((part) => part <= 0.04045 ? part / 12.92 : ((part + 0.055) / 1.055) ** 2.4);
  return channels[0] * 0.2126 + channels[1] * 0.7152 + channels[2] * 0.0722;
};
const pairs = [
  ['body/paper','#2D241E','#F4E9D8',4.5], ['body/surface','#2D241E','#FFF9F0',4.5],
  ['muted/paper','#705D4A','#F4E9D8',4.5], ['muted/surface','#705D4A','#FFF9F0',4.5],
  ['primary-label/surface','#FFF9F0','#2D241E',4.5], ['button-label/blue','#FFFFFF','#2563EB',4.5],
  ['blue-text/white','#2563EB','#FFFFFF',4.5], ['blue-text/surface','#2563EB','#FFF9F0',4.5],
  ['error/paper','#B42318','#F4E9D8',4.5], ['error/surface','#B42318','#FFF9F0',4.5],
  ['error-label/error','#FFFFFF','#B42318',4.5], ['success/paper','#166534','#F4E9D8',4.5],
  ['success-label/success','#FFFFFF','#166534',4.5], ['disabled/paper','#705D4A','#F4E9D8',4.5],
  ['input-boundary/paper','#806B55','#F4E9D8',3], ['input-boundary/surface','#806B55','#FFF9F0',3],
  ['focus/paper','#2563EB','#F4E9D8',3], ['focus/surface','#2563EB','#FFF9F0',3],
  ['footer-label/official','#FFFFFF','#101828',4.5],
].map(([name,foreground,background,minimum]) => {
  const a=luminance(foreground),b=luminance(background); const ratio=(Math.max(a,b)+.05)/(Math.min(a,b)+.05);
  assert(ratio>=minimum, `${name}: ${ratio} < ${minimum}`);
  return {name,foreground,background,minimum,ratio};
});
writeFileSync('/tmp/xk-dc004/ds/contrast.json', JSON.stringify({scope:'literal approved colors and functional roles only, not full rendered accessibility',pairs},null,2)+'\n');
console.log(JSON.stringify({tokenRoles:count,selectors,contrastPairs:pairs.length,all:'PASS'}));
console.log('HERITAGE_DS_TARGETED_COMPLETE PASS');
