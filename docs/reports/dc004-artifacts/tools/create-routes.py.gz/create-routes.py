from pathlib import Path
r=Path('/workspace/xk-website');root=r/'src/app/(collection)/design-collection/[style]';root.mkdir(parents=True,exist_ok=True)
(root/'layout.tsx').write_text('''import type { ReactNode } from "react";

// The page owns its complete frame. Unknown routes use the existing root 404
// without inheriting a second Header, main or Footer.
export const dynamicParams = false;

export function generateStaticParams() {
  return [{ style: "heritage" }];
}

export default function DesignStyleLayout({ children }: { children: ReactNode }) {
  return children;
}
''')
helper=r/'src/components/design-collection/heritage/heritage-route.ts';helper.parent.mkdir(parents=True,exist_ok=True)
helper.write_text('''import "server-only";
import { notFound } from "next/navigation";

import { createDesignPageMetadata } from "@/lib/design-collection/metadata";
import type { DesignContentPageKey } from "@/lib/design-collection/types";

export function assertHeritageStyle(style: string): asserts style is "heritage" {
  if (style !== "heritage") notFound();
}

export function heritagePageMetadata(style: string, pageKey: DesignContentPageKey, slug?: string) {
  assertHeritageStyle(style);
  const request = pageKey === "technical-project" || pageKey === "brand-showcase"
    ? { styleId: style, pageKey, slug: slug ?? "" } as const
    : { styleId: style, pageKey } as const;
  const metadata = createDesignPageMetadata(request);
  if (!metadata) notFound();
  return metadata;
}
''')
for key,component,module in [('home','HeritageHome','heritage-pages'),('about','HeritageAbout','heritage-pages'),('services','HeritageServices','heritage-pages'),('solutions','HeritageSolutions','heritage-pages'),('portfolio','HeritagePortfolio','heritage-pages'),('contact','HeritageContact','heritage-contact'),('quotation','HeritageQuotation','heritage-quotation')]:
 d=root if key=='home' else root/key;d.mkdir(parents=True,exist_ok=True)
 (d/'page.tsx').write_text(f'''import type {{ Metadata }} from "next";

import {{ HeritageFrame }} from "@/components/design-collection/heritage/heritage-frame";
import {{ {component} }} from "@/components/design-collection/heritage/{module}";
import {{ assertHeritageStyle, heritagePageMetadata }} from "@/components/design-collection/heritage/heritage-route";

type PageProps = {{ params: Promise<{{ style: string }}> }};

export async function generateMetadata({{ params }}: PageProps): Promise<Metadata> {{
  const {{ style }} = await params;
  return heritagePageMetadata(style, "{key}");
}}

export default async function Page({{ params }}: PageProps) {{
  const {{ style }} = await params;
  assertHeritageStyle(style);
  return <HeritageFrame pageKey="{key}"><{component} /></HeritageFrame>;
}}
''')
for key,sub,component,slugs in [('technical-project','portfolio/[slug]','HeritageTechnicalProject','technicalProjectSlugs'),('brand-showcase','portfolio/showcases/[slug]','HeritageBrandShowcase','brandShowcaseSlugs')]:
 d=root/sub;d.mkdir(parents=True,exist_ok=True)
 (d/'page.tsx').write_text(f'''import type {{ Metadata }} from "next";
import {{ notFound }} from "next/navigation";

import {{ HeritageFrame }} from "@/components/design-collection/heritage/heritage-frame";
import {{ {component} }} from "@/components/design-collection/heritage/heritage-pages";
import {{ assertHeritageStyle, heritagePageMetadata }} from "@/components/design-collection/heritage/heritage-route";
import {{ designCollectionRegistry }} from "@/config/design-collection";

type PageProps = {{ params: Promise<{{ style: string; slug: string }}> }};
export const dynamicParams = false;

export function generateStaticParams() {{
  return designCollectionRegistry.{slugs}.map((slug) => ({{ slug }}));
}}

function checkSlug(slug: string) {{
  if (!designCollectionRegistry.{slugs}.includes(slug)) notFound();
}}

export async function generateMetadata({{ params }}: PageProps): Promise<Metadata> {{
  const {{ style, slug }} = await params;
  assertHeritageStyle(style);
  checkSlug(slug);
  return heritagePageMetadata(style, "{key}", slug);
}}

export default async function Page({{ params }}: PageProps) {{
  const {{ style, slug }} = await params;
  assertHeritageStyle(style);
  checkSlug(slug);
  return <HeritageFrame pageKey="{key}" slug={{slug}}><{component} slug={{slug}} /></HeritageFrame>;
}}
''')
print('Created 9 route entries for 16 Heritage pages and a frame-free style layout')
