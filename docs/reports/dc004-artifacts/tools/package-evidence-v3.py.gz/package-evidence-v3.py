#!/usr/bin/env python3
"""Archive actual DC004 evidence. Default is read-only dry-run; no test verdicts."""
import argparse
from collections import Counter, defaultdict
from datetime import datetime, timezone
import gzip
import hashlib
import io
import json
import os
from pathlib import Path
import stat
import sys

FORMAT = 'xk-dc004-evidence-archive-v1'
ARTIFACTS = Path('docs/reports/dc004-artifacts')
SCREENSHOTS = Path('docs/screenshots/design-collection/dc004')
MANIFEST = 'archive-manifest.json'
TEXT_SUFFIXES = {'.json', '.jsonl', '.ndjson', '.log', '.txt', '.md', '.csv', '.tsv', '.html', '.css', '.xml', '.patch', '.diff', '.receipt', '.stdout', '.stderr', '.snap', '.pid', '.yaml', '.yml', '.toml'}
TOOL_SUFFIXES = {'.py', '.cjs', '.mjs', '.js', '.sh', '.ts', '.tsx'}
BINARY_SUFFIXES = {'.png', '.pdf', '.jpg', '.jpeg', '.webp'}
EXCLUDED_DIRS = {'__pycache__', '.git', 'node_modules', '.next', 'out', 'dist', 'build', 'baseline-site', 'normal-site', 'pages-site', 'artifact-unpacked', 'ci-artifact-unpacked', 'xplore-kaleidoscope', 'xk-website', 'company-repo', 'company-source', 'company-sources', '00_governance', '01_company', '02_business', '03_services', '04_products', '05_brand', '06_engineering', '07_operations', '08_projects', '09_knowledge', '10_decisions', '11_templates', '12_data', '13_automation', '99_archive'}
SECRET_SUFFIXES = {'.key', '.pem', '.pfx', '.p12', '.sqlite', '.sqlite3', '.db'}
RESERVED = {'README.md', 'SHA256SUMS', MANIFEST}


def digest(data):
    return hashlib.sha256(data).hexdigest()


def deterministic_gzip(data):
    buffer = io.BytesIO()
    with gzip.GzipFile(filename='', mode='wb', fileobj=buffer, compresslevel=9, mtime=0) as handle:
        handle.write(data)
    return buffer.getvalue()


def canonical(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(',', ':')).encode()


def json_bytes(value):
    return (json.dumps(value, ensure_ascii=False, indent=2) + '\n').encode()


def is_within(path, root):
    return path == root or root in path.parents


def sensitive_name(name):
    low = name.lower()
    return low == '.env' or low.startswith('.env.') or low in {'environment', 'environment.json', 'credentials', 'credentials.json', 'secrets', 'secrets.json', 'id_rsa', 'id_ed25519', '.netrc', '.npmrc', '.pypirc'} or Path(low).suffix in SECRET_SUFFIXES


def read_stable(path):
    before = path.lstat()
    if not stat.S_ISREG(before.st_mode):
        raise ValueError(f'Not a regular evidence file: {path}')
    with path.open('rb') as handle:
        opened = os.fstat(handle.fileno())
        if (opened.st_dev, opened.st_ino) != (before.st_dev, before.st_ino):
            raise ValueError(f'Evidence changed before read: {path}')
        data = handle.read()
    after = path.lstat()
    if (before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns) != (after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns):
        raise ValueError(f'Evidence is still changing; wait for its runner to finish: {path}')
    return data


def scan(source, minimum_gzip_bytes):
    rows, skipped, payloads, binary_canonical = [], [], {}, {}
    for current, dirs, files in os.walk(source, followlinks=False):
        kept = []
        for name in sorted(dirs):
            child = Path(current, name)
            reason = 'symlink directory' if child.is_symlink() else 'excluded build/cache/foreign-repository directory' if name in EXCLUDED_DIRS else 'hidden or sensitive directory' if name.startswith('.') or sensitive_name(name) else None
            if reason:
                skipped.append({'sourceRelativePath': child.relative_to(source).as_posix(), 'reason': reason})
            else:
                kept.append(name)
        dirs[:] = kept
        for name in sorted(files):
            file = Path(current, name)
            rel = file.relative_to(source)
            if file.is_symlink():
                skipped.append({'sourceRelativePath': rel.as_posix(), 'reason': 'symlink file; never follow outside evidence root'})
                continue
            if name.startswith('.') or sensitive_name(name):
                skipped.append({'sourceRelativePath': rel.as_posix(), 'reason': 'hidden, credential, environment or database filename; contents were not read'})
                continue
            suffix = file.suffix.lower()
            if suffix not in TEXT_SUFFIXES | TOOL_SUFFIXES | BINARY_SUFFIXES | {'.gz'}:
                skipped.append({'sourceRelativePath': rel.as_posix(), 'reason': 'unrecognized file type; contents were not read', 'requiresExplicitDisposition': True})
                continue
            if len(rel.parts) == 1 and name in RESERVED:
                raise ValueError(f'Source filename collides with generated archive metadata: {file}')
            raw = read_stable(file)
            original_sha = digest(raw)
            kind = 'binary' if suffix in BINARY_SUFFIXES else 'tool' if suffix in TOOL_SUFFIXES else 'data'
            row = {'originalPath': str(file), 'sourceRelativePath': rel.as_posix(), 'originalSizeBytes': len(raw), 'originalSha256': original_sha, 'kind': kind, 'deduplicatedBinary': False}
            if kind == 'binary':
                key = (original_sha, len(raw))
                if key in binary_canonical:
                    archive, first = binary_canonical[key]
                    row.update(archivePath=archive.as_posix(), canonicalOriginalPath=first, deduplicatedBinary=True)
                    stored = payloads[archive]
                else:
                    archive = SCREENSHOTS / rel
                    binary_canonical[key] = (archive, str(file))
                    stored = raw
                    payloads[archive] = stored
                    row['archivePath'] = archive.as_posix()
                row.update(compression='none', decodedPayloadSha256=original_sha)
            else:
                archive = ARTIFACTS / ('tools' if kind == 'tool' else '') / rel
                if suffix == '.gz':
                    try:
                        logical_sha = digest(gzip.decompress(raw))
                    except (OSError, EOFError) as error:
                        raise ValueError(f'Original gzip cannot be decoded; preserve and inspect before packaging: {file}: {error}') from error
                    stored = raw
                    compression = 'original-gzip-unchanged'
                elif kind == 'tool' or suffix == '.log' or len(raw) >= minimum_gzip_bytes:
                    # Empty filename header and mtime=0 make gzip bytes reproducible.
                    stored = deterministic_gzip(raw)
                    archive = Path(str(archive) + '.gz')
                    logical_sha = original_sha
                    compression = 'deterministic-gzip-mtime0'
                else:
                    stored = raw
                    logical_sha = original_sha
                    compression = 'none'
                if archive in payloads and payloads[archive] != stored:
                    archive = archive.with_name(archive.name.removesuffix('.gz') + '.source-' + original_sha[:12] + ('.gz' if archive.name.endswith('.gz') else ''))
                    if archive in payloads and payloads[archive] != stored:
                        raise ValueError(f'Conflicting archive payload identity at {archive}')
                payloads[archive] = stored
                row.update(archivePath=archive.as_posix(), compression=compression, decodedPayloadSha256=logical_sha)
            row.update(archiveSizeBytes=len(stored), archiveSha256=digest(stored))
            rows.append(row)
    rows.sort(key=lambda row: row['sourceRelativePath'])
    return rows, skipped, payloads


def current_source_paths(source):
    paths = set()
    for current, dirs, files in os.walk(source, followlinks=False):
        dirs[:] = [name for name in dirs if name not in EXCLUDED_DIRS and not name.startswith('.') and not sensitive_name(name) and not Path(current, name).is_symlink()]
        for name in files:
            file = Path(current, name)
            if file.is_symlink() or name.startswith('.') or sensitive_name(name):
                continue
            if file.suffix.lower() in TEXT_SUFFIXES | TOOL_SUFFIXES | BINARY_SUFFIXES | {'.gz'}:
                paths.add(str(file))
    return paths


def build_manifest(args, rows, skipped, payloads):
    original_index, logical_index = defaultdict(set), defaultdict(set)
    for row in rows:
        original_index[row['originalSha256']].add(row['archivePath'])
        logical_index[row['decodedPayloadSha256']].add(row['archivePath'])
    unique_binary = [value for path, value in payloads.items() if is_within(path, SCREENSHOTS)]
    binary_rows = [row for row in rows if row['kind'] == 'binary']
    snapshot = [{'path': row['sourceRelativePath'], 'sha256': row['originalSha256'], 'bytes': row['originalSizeBytes']} for row in rows]
    return {'format': FORMAT, 'operation': 'DRY_RUN' if not args.apply else 'ARCHIVED', 'testVerdicts': 'NOT_EVALUATED_BY_PACKAGER', 'sourceRoot': str(args.source), 'repositoryRoot': str(args.repo), 'archiveRoots': {'artifacts': ARTIFACTS.as_posix(), 'screenshots': SCREENSHOTS.as_posix()}, 'tool': {'path': str(Path(__file__).resolve()), 'sha256': digest(Path(__file__).read_bytes())}, 'gzip': {'minimumSourceBytes': args.gzip_min_bytes, 'level': 9, 'mtime': 0, 'originalGzip': 'kept byte-identical'}, 'sourceSnapshotSha256': digest(canonical(snapshot)), 'counts': {'originalFiles': len(rows), 'uniqueArchivedPayloads': len(payloads), 'originalBytes': sum(row['originalSizeBytes'] for row in rows), 'uniqueArchivedPayloadBytes': sum(len(value) for value in payloads.values()), 'binaryOriginalFiles': len(binary_rows), 'binaryUniqueFiles': len(unique_binary), 'binaryOriginalBytes': sum(row['originalSizeBytes'] for row in binary_rows), 'binaryUniqueBytes': sum(map(len, unique_binary)), 'binaryDuplicatesAvoided': sum(row['deduplicatedBinary'] for row in rows), 'filesByKind': dict(Counter(row['kind'] for row in rows)), 'skippedEntries': len(skipped)}, 'originalSha256ToArchivePaths': {key: sorted(value) for key, value in sorted(original_index.items())}, 'decodedPayloadSha256ToArchivePaths': {key: sorted(value) for key, value in sorted(logical_index.items())}, 'entries': rows, 'skipped': skipped, 'limitations': ['This is evidence packaging, never a test PASS, deployment or publication record.', 'Every original FAIL/PENDING/bridge/status and raw reference remains unchanged; resolve original paths or SHA through this manifest.', 'PNG/PDF and other captured raster evidence are not edited; exact-byte duplicate binaries share one archived file and retain every original-path mapping.', 'Only files actually present at scan time are included. Pages and visual completion must be established separately by Root.', 'No environment variables, credential files, other-repository source directories or build output are collected. Unrecognized files need explicit disposition before apply.']}


def existing_sha(file):
    if file.is_symlink():
        raise ValueError(f'Archive path must not be a symlink: {file}')
    return digest(file.read_bytes())


def check_destination_parents(file, repo):
    if not is_within(file, repo):
        raise ValueError(f'Destination escapes repository: {file}')
    for parent in (file.parent, *file.parents):
        if parent == repo.parent:
            break
        if parent.is_symlink():
            raise ValueError(f'Destination parent is a symlink: {parent}')


def write_new_or_equal(file, data):
    file.parent.mkdir(parents=True, exist_ok=True)
    if file.exists():
        if existing_sha(file) != digest(data):
            raise ValueError(f'Existing archive bytes differ; use a versioned source name, never overwrite evidence: {file}')
        return
    with file.open('xb') as handle:
        handle.write(data)


def generated_write(file, data):
    # Only the packager-owned manifest and sums use this helper.
    tmp = file.with_name(file.name + '.packaging-tmp')
    with tmp.open('xb') as handle:
        handle.write(data)
    os.replace(tmp, file)


def default_readmes(rows):
    reports = ('# DC-004 原始驗收證據\n\n本目錄是執行當下實際資料的封存，不新增測試 PASS、發布或部署結論。原始收據的命令、時間、退出碼、失敗及未完成狀態保持原樣。\n\n'
               '- `archive-manifest.json` 以原絕對路徑、原 SHA 與 decoded payload SHA 對照 repository 相對路徑；不改寫 raw JSON/log 的引用。\n'
               '- 大型文字以 mtime0 gzip 保存；原 `.gz` 的 bytes 保持不變。`SHA256SUMS` 核對實際封存檔，解壓內容另有 SHA。\n'
               '- 所有掃描到的 FAIL、診斷版本、bridges、原 HTMLgz/CSSgz 及工具保留。工具未加入網站依賴。\n'
               '- PNG/PDF 集中於 [畫面目錄](../../screenshots/design-collection/dc004/README.md)，只有 byte-identical binary 共用實體檔；每個原路徑仍在 manifest。\n'
               '- 本機、PR CI、merge、部署及公開驗證須由正式報告分別記載；此封存不代表後續階段完成。\n')
    canonical_binaries = sorted({row['archivePath'] for row in rows if row['kind'] == 'binary'})
    pdfs = [path for path in canonical_binaries if path.lower().endswith('.pdf')]
    pictures = [path for path in canonical_binaries if not path.lower().endswith('.pdf')]
    def links(paths):
        return '\n'.join(f'- [{Path(path).relative_to(SCREENSHOTS).as_posix()}]({Path(path).relative_to(SCREENSHOTS).as_posix()})' for path in paths) or '- 掃描時尚無此類資料；不推定已完成。'
    shots = ('# DC-004 實際畫面與原 PDF\n\n檔案保持原始 bytes，沒有裁切、縮放或修改。畫面及 PDF 的實際人工檢視／驗收以正式報告為準；此索引不新增 PASS。\n\n'
             'byte-identical binary 只存一份；完整原路徑、SHA、canonical archivepath 及每份收據引用對照見 [manifest](../../../reports/dc004-artifacts/archive-manifest.json)。\n\n'
             '## 原 PDF\n\n' + links(pdfs) + '\n\n## 實際 PNG／渲染\n\n' + links(pictures) + '\n')
    return {ARTIFACTS / 'README.md': reports.encode(), SCREENSHOTS / 'README.md': shots.encode()}


def apply_archive(args, manifest, payloads):
    if any(row.get('requiresExplicitDisposition') for row in manifest['skipped']):
        raise ValueError('Unrecognized files were listed by dry-run; classify them before apply')
    old_manifest = args.repo / ARTIFACTS / MANIFEST
    if old_manifest.exists():
        prior = json.loads(old_manifest.read_text())
        if prior.get('format') != FORMAT or prior.get('sourceRoot') != str(args.source):
            raise ValueError('An existing manifest belongs to another archive/source; do not overwrite')
        prior_keys = {(row['originalPath'], row['originalSha256']) for row in prior['entries']}
        current_keys = {(row['originalPath'], row['originalSha256']) for row in manifest['entries']}
        if not prior_keys <= current_keys:
            raise ValueError('Previously archived source is absent/changed. Preserve it and use a versioned source name before updating the archive')
    elif any((args.repo / root / 'SHA256SUMS').exists() for root in (ARTIFACTS, SCREENSHOTS)):
        raise ValueError('Existing archive sums have no packager ownership manifest; inspect before applying')
    generated = default_readmes(manifest['entries'])
    for rel, value in [*payloads.items(), *((rel, value) for rel, value in generated.items() if not (args.repo / rel).exists())]:
        dest = args.repo / rel
        check_destination_parents(dest, args.repo)
        if dest.exists() and existing_sha(dest) != digest(value):
            raise ValueError(f'Archive collision; existing evidence is never overwritten: {dest}')
    if current_source_paths(args.source) != {row['originalPath'] for row in manifest['entries']}:
        raise ValueError('Evidence files were added/removed after the scan; regenerate dry-run after runners finish')
    for row in manifest['entries']:
        if digest(read_stable(Path(row['originalPath']))) != row['originalSha256']:
            raise ValueError('Source changed after planning; wait for all QA runners and regenerate dry-run')
    for rel, value in payloads.items():
        write_new_or_equal(args.repo / rel, value)
    for rel, value in generated.items():
        if not (args.repo / rel).exists():
            write_new_or_equal(args.repo / rel, value)
    if current_source_paths(args.source) != {row['originalPath'] for row in manifest['entries']}:
        raise ValueError('Evidence files were added/removed after the scan; regenerate dry-run after runners finish')
    for row in manifest['entries']:
        if digest(read_stable(Path(row['originalPath']))) != row['originalSha256']:
            raise ValueError('Source changed while archiving; no completion manifest written')
    manifest['archivedAtUtc'] = datetime.now(timezone.utc).isoformat()
    generated_write(old_manifest, json_bytes(manifest))
    owned = set(payloads) | set(generated) | {ARTIFACTS / MANIFEST}
    for root in (ARTIFACTS, SCREENSHOTS):
        sums = []
        for rel in sorted(owned):
            if is_within(rel, root) and (args.repo / rel).is_file():
                sums.append(f'{existing_sha(args.repo / rel)}  {rel.relative_to(root).as_posix()}')
        generated_write(args.repo / root / 'SHA256SUMS', ('\n'.join(sums) + '\n').encode())


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    action = parser.add_mutually_exclusive_group()
    action.add_argument('--dry-run', action='store_true', help='Default: scan, hash, estimate gzip sizes and report; never write the repository')
    action.add_argument('--apply', action='store_true', help='Root runs only after Pages and visual review finish; creates archive files')
    parser.add_argument('--source', type=Path, default=Path('/tmp/xk-dc004'))
    parser.add_argument('--repo', type=Path, default=Path('/workspace/xk-website'))
    parser.add_argument('--gzip-min-bytes', type=int, default=4096)
    parser.add_argument('--list', action='store_true', help='Print each original→archive mapping after the summary')
    args = parser.parse_args()
    args.source = args.source.resolve(strict=True)
    args.repo = args.repo.resolve(strict=True)
    if args.gzip_min_bytes < 1024:
        parser.error('Use a gzip threshold of at least1024bytes')
    if is_within(args.source, args.repo) or is_within(args.repo, args.source):
        parser.error('Source evidence and repository must be separate, non-nested roots')
    rows, skipped, payloads = scan(args.source, args.gzip_min_bytes)
    if not rows:
        parser.error('No actual recognized evidence files found')
    manifest = build_manifest(args, rows, skipped, payloads)
    if args.apply:
        apply_archive(args, manifest, payloads)
    duplicates = [{'originalPath': row['originalPath'], 'canonicalOriginalPath': row['canonicalOriginalPath'], 'originalSha256': row['originalSha256'], 'archivePath': row['archivePath'], 'bytesAvoided': row['originalSizeBytes']} for row in rows if row['deduplicatedBinary']]
    print(json.dumps({'operation': manifest['operation'], 'testVerdicts': manifest['testVerdicts'], 'sourceSnapshotSha256': manifest['sourceSnapshotSha256'], 'counts': manifest['counts'], 'binaryDeduplication': duplicates, 'skipped': skipped, 'manifest': (ARTIFACTS / MANIFEST).as_posix() if args.apply else 'PLANNED_ONLY_NO_FILES_WRITTEN', 'completionMarker': 'DC004_EVIDENCE_ARCHIVE_COMPLETE' if args.apply else 'DC004_EVIDENCE_DRY_RUN_COMPLETE'}, ensure_ascii=False, indent=2))
    if args.list:
        for row in rows:
            print(json.dumps(row, ensure_ascii=False))
    return 0


if __name__ == '__main__':
    try:
        sys.exit(main())
    except (OSError, ValueError, KeyError, TypeError, json.JSONDecodeError) as error:
        print(json.dumps({'operation': 'ERROR', 'testVerdicts': 'NOT_EVALUATED_BY_PACKAGER', 'error': str(error)}, ensure_ascii=False), file=sys.stderr)
        sys.exit(1)
