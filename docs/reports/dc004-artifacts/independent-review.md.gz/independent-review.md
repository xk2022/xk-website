# DC004 離線獨立覆核

狀態：未發現新的產品阻擋問題；README／AGENTS 需要釐清歷史與功能分支狀態。這是來源與現有證據覆核，不是新的整站驗收。

## 共用內容與已修正項目

- Heritage 七主頁及九詳頁使用同一 DTO／原控制器：五類服務、三方案、四方案方向、六品牌／四模板、三個 Planned 技術案及參考價格來源均保留。
- 原 Home Maintenance 與 Services Cloud 的差異保留。三個技術案維持 Planned、空實作／媒體與 null source／Live；模板署名及 reference-only gate 未解除。
- Services 的一頁式導讀已提取為 `servicesPage.websiteGuide`；Modern 與 Heritage 使用相同文案與兩個作品分類入口，DTO adapter 自然帶入。Modern Services 的原始 HTML bridge 通過。舊 parity FAIL 仍是 v1 快照，當前 Services 已無候選遺漏。
- 六品牌 source URL 的 aria-label 現以完整可見 URL 開頭。離線讀取六頁封存 HTML 均吻合；18 個指定 brand label／axe 測項 PASS。所在 affected-v3 套件仍因另外的 network assertion 為 FAIL，不能把個別通過改稱整套通過。
- Quotation 沿用同一 9 類建置、17 個加購與計算／儲存／A4 核心；沒有 Heritage 專用價格矩陣或把未知費用當零。Contact 仍整理本機草稿並由訪客自行寄信。

## 可用的版本與資源結論

1. v1→v2：142 個 runtime 檔案原始雜湊相同，26 頁完整 HTML 只正規化實際 Build ID。六品牌頁僅證明單一 aria-label 以外的 server markup 相同；RSC bytes／分段不相同且明確排除，另以實際 hydration／18 項 axe 重驗補足。Services 有獨立五寬、導覽及 axe 重驗；第一份較寬 bridge 的 FAIL 保留。
2. v2→v3：五份 CSS 中四份原始 bytes 相同；唯一差異為 `@media screen` 下 Heritage Quotation disabled 元件規則。移除該精確 old／new rule 後其餘 CSS 相同。新的 12 項主題狀態、144 次 role 觀測通過；這只支持該範圍，不代表重新做過整站／PDF／完整 WCAG。Disabled 對比門檻是自願閱讀性目標。
3. Passive 資源裁定：精確 hash 綁定的 15 案中，11 案原 PASS；另 4 案／9 個 script ERR_ABORTED 記錄都有同案、同 URL、current-loader 200、實際 body SHA／bytes、已連接 script、native load 及 ResourceTiming 證據。11 筆明確 RSC prefetch 取消另列。原 probe、v1 及 27 筆資源失敗仍保留；沒有通用取消白名單，沒有觀測到舊 loader 的 transport 完成／取消，不能杜撰 `canceled=true` 或「未送出」。
4. Guide focused flow 新程序 Exit 0，兩張實圖 body 相符且無新失敗；它只重驗一個 1440px Enter flow 與 375px 前置，沒有證實前一輪兩筆取消的精確原因。

此組證據可分段形成複合結論，不能描述成「原 262 項全套重新 PASS」或「舊 27 筆全部已證明取消無害」。

## 文件需要修正

| 位置 | 具體矛盾 | 最小處理 |
| --- | --- | --- |
| `AGENTS.md:141` | 仍禁止 Heritage 公開連結及變更 planned registry，與 147–149 的正式 33 頁工作相衝 | 明訂該禁令只適用核准前本機原型；保留原型不輸出及未授權不發布限制 |
| `README.md:22` | 「Modern 可瀏覽，其餘規劃中」未註明是 main17 快照 | 分開正式 main17 與功能分支33，避免暗示已部署 |
| `README.md:44` | DC003 歷史敘述後仍以現在式稱 Heritage、palette、個資／print 隔離未落地 | 標示 DC003 合併時點，另列當前分支及 DC005／006 後續範圍 |
| `README.md:46` | 「完成後為33頁」混合實作清冊與驗收／發布 | 寫明分支實作清冊33頁，正式 main17；各驗收與遠端階段看實際證據 |

## 當時的驗收邊界

- Normal v3 HTTP：Exit 0，2329 PASS／2 個 private SSR N/A。
- Pages 名為 `http-pages-final-result.json` 的現存回執仍有 Gallery Heritage 入口尾斜線期望差異、Exit 1。Root 正收斂 guard；在有新版完成回執前，此 gate 不得寫 PASS。本覆核不把它另列為產品新缺陷。
- 抽查的 12 個內容／控制器原始檔均與 v3 source snapshot 相同；後續 builder／smoke 工具變動仍須由 Root 對應最終版本。
- 本次沒有 server、browser、build、Git、App 或 repo 文件寫入，也不建立 PR／部署／TLS／法律或索引核准證據。

逐項來源、原始狀態、限制及 SHA 見同目錄 `independent-review.json`。
