兩模式的補充判讀皆通過本次限定的38個 paint 候選；原正式 suite 仍各自保留 MANUAL_PENDING、真 Exit 2 與38 incomplete，未改成 axe 零 incomplete。

每模式30個漸層候選依實際 computed 前景、不透明底色與單一12% accent／7% secondary 裝飾層計算完整最差界限，最低對比5.13330695。6個menu-open候選的整個文字框被白色不透明 panel 覆蓋，9/9命中點屬panel；另以相同target的closed狀態確認正常對比。2個 badge 僅50.7234%遮覆，露出部分另外加入實際最高8%陰影對前景／背景的保守界限，品牌標籤最低5.17607324、可瀏覽標籤13.85279120，均高於4.5。

兩模式38組對應的 fresh styles、rects、對比計算、遮覆率及命中點計數逐字段相同。僅2筆 CSS target 字串呈正常模式 portfolio#website-cases 與 Pages portfolio/#website-cases 的精確尾slash差異，沒有泛化移除URL或React IDs。已實看兩模式open/closed四張真viewport；本結論僅關於既有76個色彩對比候選，不代表新增完整WCAG或AT認證。

| 模式 | 正式UI assertions / layouts / axe | 原incomplete / Exit | 漸層 | 全遮覆 | 部分遮覆 | 補充判讀Exit |
|---|---|---|---|---|---|---|
| normal | 59 / 48 / 8 | 38 / 2 | 30 | 6 | 2 | 0 |
| pages | 59 / 48 / 8 | 38 / 2 | 30 | 6 | 2 | 0 |

逐target及mode差異詳見 merge1-incomplete-supplement.json；完整算式與raw source映射分別位於 incomplete-normal-adjudication.json、incomplete-pages-adjudication.json，對應原始computed與兩張PNG在各自 incomplete-{mode}-final/。
