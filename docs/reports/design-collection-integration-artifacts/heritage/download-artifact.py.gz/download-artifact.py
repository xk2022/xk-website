import hashlib,json,sys,urllib.request
from pathlib import Path
payload=json.loads(sys.stdin.readline());url=payload.pop('downloadUrl');root=Path('/tmp/xk-dc006-merge/heritage')
assert payload['headSha']==payload['expectedHeadSha']=='8faf717ae0dc618cd9aee9b6d791495a0dee8a49'
assert payload['runId']==45795573857 and payload['pullRequest']==40 and payload['event']=='pull_request'
try:
 with urllib.request.urlopen(url,timeout=60) as response:data=response.read(100_000_001)
 digest=hashlib.sha256(data).hexdigest()
 if len(data)>100_000_000 or digest!=payload['digest'].removeprefix('sha256:'):raise ValueError('ZIP size/digest mismatch')
 with (root/'pr40-github-pages.zip').open('xb') as out:out.write(data)
 payload.update(zipSha256=digest,downloadedBytes=len(data))
 with (root/'pr40-artifact-metadata.json').open('x') as out:json.dump(payload,out,indent=2);out.write('\n')
 print(json.dumps({'status':'PASS','artifactId':payload['artifactId'],'zipSha256':digest,'bytes':len(data)}))
except Exception as error:
 print(json.dumps({'status':'FAIL','errorType':type(error).__name__,'httpStatus':getattr(error,'code',None)}));raise SystemExit(1)
