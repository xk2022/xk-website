"""Bounded per-target paint review; preserves original axe incomplete/Exit2."""
import argparse,hashlib,json,re,itertools
from pathlib import Path
from datetime import datetime,timezone
from collections import Counter

def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def color(v):
 m=re.fullmatch(r'(rgba?|color)\(([^()]+)\)',v.strip());assert m,'Unsupported color '+v
 kind,body=m.groups();p=body.replace(',',' ').replace('/',' ').split()
 if kind=='color':assert p.pop(0)=='srgb';rgb=[float(x)*255 for x in p[:3]]
 else:rgb=[float(x) for x in p[:3]]
 return rgb,float(p[3]) if len(p)>3 else 1.
def luminance(c):
 q=[v/255 for v in c];return sum(w*(x/12.92 if x<=.04045 else ((x+.055)/1.055)**2.4) for w,x in zip([.2126,.7152,.0722],q))
def blend(a,b,t):return [x*t+y*(1-t) for x,y in zip(a,b)]
def bounds(fg,base,layers,foreground_layers=()):
 backgrounds=[base]
 for c,a in layers:backgrounds=[blend(c,b,t) for b in backgrounds for t in (0,a)]
 lo=[min(c[i] for c in backgrounds) for i in range(3)];hi=[max(c[i] for c in backgrounds) for i in range(3)]
 foregrounds=[fg]
 for c,a in foreground_layers:foregrounds=[blend(c,f,t) for f in foregrounds for t in (0,a)]
 flo=[min(c[i] for c in foregrounds) for i in range(3)];fhi=[max(c[i] for c in foregrounds) for i in range(3)]
 bl,bh=luminance(lo),luminance(hi);fl,fh=luminance(flo),luminance(fhi)
 ratio=(bl+.05)/(fh+.05) if fh<bl else (fl+.05)/(bh+.05) if bh<fl else 1.
 return {'foreground':fg,'opaqueBase':base,'layers':[{'rgb':c,'maximumAlpha':a}for c,a in layers],'backgroundRGBLower':lo,'backgroundRGBUpper':hi,'foregroundRGBLower':flo,'foregroundRGBUpper':fhi,'contrastLowerBound':ratio,'method':'All alpha-extreme color boxes; monotone WCAG sRGB luminance bounds separate foreground/background luminance for every spatial gradient/mask/shadow contribution, without rounding thresholds.'}
def plain(e):
 for a in e['ancestors']:
  s=a['style'];assert s['opacity']=='1' and s['filter']=='none' and s['backdropFilter']=='none' and s['mixBlendMode']=='normal','Unsupported group paint'
  assert s['backgroundImage']=='none','Additional target ancestry image'
  assert all(p['content'] in ('none','normal') or p['display']=='none' or p['visibility']=='hidden' for p in a['pseudos']),'Painted pseudo'
 fg,fa=color(e['element']['style']['color']);assert fa==1,'Foreground alpha requires separate proof'
 positives=[(a,*color(a['style']['backgroundColor']))for a in e['ancestors'] if color(a['style']['backgroundColor'])[1]>0]
 assert positives and positives[0][2]==1,'No nearest opaque background';base,bg,_=positives[0]
 decos=[d for d in e['decorations'] if d['parent']['path']==base['path']]
 layers=[];description='Own opaque surface blocks ancestor decorative layers'
 if decos:
  assert len(decos)==1,'Multiple decorations need separate bound';d=decos[0];s=d['style'];assert s['opacity']=='1' and s['filter']=='none' and s['backdropFilter']=='none' and s['mixBlendMode']=='normal' and s['boxShadow']=='none';assert color(s['backgroundColor'])[1]==0
  assert all(p['content'] in ('none','normal') for p in d['pseudos']);image=s['backgroundImage'];stops=[color(x)for x in re.findall(r'(?:rgba?|color)\([^()]+\)',image)];visible=[(c,a)for c,a in stops if a>0];assert visible
  c=visible[0][0];assert all(all(abs(x-y)<.001 for x,y in zip(c,other))for other,a in visible)
  cap=max(a for _,a in visible)
  if 'brand-pattern-gradient' in d['className']:assert image.startswith('radial-gradient(') and abs(cap-.12)<1e-9;expected=[25,184,213]
  elif 'brand-pattern-kaleidoscope' in d['className']:assert image.startswith('repeating-conic-gradient(') and abs(cap-.07)<1e-9;expected=[49,87,213]
  else:raise AssertionError('Unknown decoration')
  assert all(abs(x-y)<.001 for x,y in zip(c,expected));layers=[(c,cap)];description={'decorationPath':d['path'],'className':d['className'],'computedImage':image,'maskImage':s['maskImage'],'maximumAlpha':cap,'independentSourceRGB':expected,'mask':'Only reduces contribution; ignoring it is conservative.'}
 else:assert base['path']==e['element']['path'],'No reviewed local decoration/own opaque target'
 return bounds(fg,bg,layers),description

a=argparse.ArgumentParser();a.add_argument('--evidence',required=True);a.add_argument('--output',required=True);args=a.parse_args();outpath=Path(args.output);assert not outpath.exists(),'Do not overwrite prior adjudication';ev=json.loads(Path(args.evidence).read_text());raw=json.loads(Path(ev['input']['path']).read_text());assert ev['input']['sha256']==sha(ev['input']['path']);assert ev['status']=='CAPTURE_COMPLETE_NOT_ADJUDICATED';css=Path(ev['sourceCSS']['snapshot']).read_text();assert sha(ev['sourceCSS']['snapshot'])==ev['sourceCSS']['sha256'];assert 'var(--accent) 12%, transparent' in css and 'var(--secondary) 7%, transparent' in css and 'mask-image: radial-gradient(ellipse at center, black, transparent 75%)' in css
expected=Counter((g['route'],g['width'],g['state'],tuple(n['target']))for g in raw['manualStyles']for n in g['nodes']);observed=Counter();rows=[]
for g in ev['groups']:
 for i,n in enumerate(g['actual']['nodes']):
  key=(g['route'],g['width'],g['state'],tuple(n['target']));observed[key]+=1;original=next(r for r in raw['manualStyles']if (r['route'],r['width'],r['state'])==key[:3])['nodes'][i];assert n['target']==original['target']
  row={'testId':f'DC006-MERGE1-PAINT-{len(rows)+1:03d}','route':g['route'],'width':g['width'],'state':g['state'],'target':n['target'],'text':n.get('text'),'originalRule':original['rule'],'originalChecks':original['checks'],'status':'NEEDS_MANUAL','evidenceGroupIndex':ev['groups'].index(g),'evidenceNodeIndex':i}
  try:
   assert n['resolution']=='FOUND' and n['text']==original['computed']['text'];assert n['element']['style']['color']==original['computed']['ancestors'][0]['style']['color']
   keys={c['data'].get('messageKey')for c in original['checks']};threshold=max(float(c['data']['expectedContrastRatio'].split(':')[0])for c in original['checks']);row['requiredRatio']=threshold
   if keys=={'bgGradient'}:
    calc,desc=plain(n);row.update(calculation=calc,paint=desc);assert calc['contrastLowerBound']>=threshold+.001;row['status']='PASS_CONSERVATIVE_GRADIENT'
   elif keys=={'bgOverlap'}:
    closed=next(c for c in g['closed']['nodes']if c['target']==n['target']);assert closed['resolution']=='FOUND' and closed['text']==n['text'];assert closed['element']['style']['color']==n['element']['style']['color'];calc,desc=plain(closed);assert calc['contrastLowerBound']>=threshold+.001
    panel=g['actual']['panel'];s=panel['style'];assert s['opacity']=='1' and s['backgroundColor']=='rgb(255, 255, 255)' and s['backgroundImage']=='none' and s['filter']=='none' and s['backdropFilter']=='none' and s['mixBlendMode']=='normal' and s['display']!='none'
    points=[p for p in n['hitTests']if p['inViewport']];assert len(points)==9 and all(p['stack']for p in points);covered=[p for p in points if p['stack'][0]['panelContains']];uncovered=[p for p in points if not p['stack'][0]['panelContains']];row.update(closedCalculation=calc,closedPaint=desc,panel=panel,panelCoverageRatio=n['panelCoverageRatio'],pointEvidence={'inViewport':len(points),'topmostPanel':len(covered),'topmostTarget':sum(p['stack'][0]['targetContains']for p in uncovered)})
    if n['panelCoverageRatio']>=1-1e-9:assert len(covered)==9;row['status']='PASS_OPAQUE_MENU_OCCLUSION_CLOSED_PAINT';row['reason']='Entire underlying text border box lies under actual opaque white menu;9/9 topmost hit tests are panel descendants. Closed same target/text/colors has passing conservative paint. No contrast is invented for invisible glyphs.'
    else:
     assert 0<n['panelCoverageRatio']<1 and covered and uncovered and all(p['stack'][0]['targetContains']for p in uncovered)
     shadow=[color(c)for c in re.findall(r'(?:rgba?|color)\([^()]+\)',s['boxShadow'])if color(c)[1]>0];assert len(shadow)==1;rgb,alpha=shadow[0];assert abs(alpha-.08)<1e-9 and all(abs(x-y)<.001 for x,y in zip(rgb,[16,26,51]))
     fg=calc['foreground'];bg=calc['opaqueBase'];assert calc['layers']==[];shadowBound=bounds(fg,bg,[(rgb,alpha)],[(rgb,alpha)]);assert shadowBound['contrastLowerBound']>=threshold+.001;row['exposedShadowCalculation']=shadowBound;row['status']='PASS_PARTIAL_MENU_EXPOSED_PAINT_BOUND';row['reason']='Panel covers only measured portion; remaining glyph surface independently passes even with the full8% actual menu shadow applied conservatively to both foreground/background. Covered glyphs are not assigned an invented contrast.'
   else:raise AssertionError('Unclassified incomplete reason')
  except Exception as e:row['reason']=str(e)
  rows.append(row)
coverage=expected==observed;counts=Counter(r['status']for r in rows);status='PASS_SCOPED_PAINT_REVIEW' if coverage and not counts['NEEDS_MANUAL'] else 'MANUAL_PENDING';report={'testId':'DC006-MERGE1-INCOMPLETE-PER-TARGET-ADJUDICATION','status':status,'generatedAt':datetime.now(timezone.utc).isoformat(),'mode':ev['mode'],'evidence':{'path':args.evidence,'sha256':sha(args.evidence)},'originalSuite':ev['input'],'originalResultPolicy':'Original MANUAL_PENDING and actual rawExit2 remain unchanged. This is a separate specific paint review, not a rerun or fullWCAG/AT certification.','sourceCSS':ev['sourceCSS'],'coverageExact':coverage,'counters':dict(counts),'targets':len(rows),'minimumConservativeRatio':min([r.get('calculation',r.get('closedCalculation',{})).get('contrastLowerBound',999)for r in rows]+[r['exposedShadowCalculation']['contrastLowerBound']for r in rows if 'exposedShadowCalculation'in r]),'visualEvidence':ev['screenshots'],'manualVisualObservation':'Normal exact open/closed PNGs inspected: panel obscures overview text, two badges partly exposed at panel lower edge; closing restores all labels. Pages image observation must be separately recorded if this tool is reused there.','rows':rows};outpath.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print(json.dumps({k:report[k]for k in ['status','coverageExact','counters','targets','minimumConservativeRatio']}));raise SystemExit(0 if status=='PASS_SCOPED_PAINT_REVIEW'else 2)
