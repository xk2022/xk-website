#!/usr/bin/env python3
"""Independent bounded dispositions using the captured3274 HTML and DTO."""
from collections import Counter
from datetime import datetime,timezone
import gzip
import hashlib
import importlib.util
import json
from pathlib import Path
import re
import sys

ROOT=Path('/tmp/xk-dc006-merge/luxury-parity')
REPO=Path('/tmp/xk-merge-luxury')

def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def norm(t):return re.sub(r'\s+','',t)
def now():return datetime.now(timezone.utc).isoformat()

def main():
    out=ROOT/'adjudication-final.json';summary=ROOT/'summary.md'
    assert not out.exists() and not summary.exists(),'Preserve previous verdicts'
    initial=json.loads((ROOT/'result.json').read_text());dto=json.loads((ROOT/'dto.json').read_text())
    assert sha(ROOT/'dto.json')==initial['dto']['sha256']
    assert len(initial['results'])==90
    spec=importlib.util.spec_from_file_location('capture_helpers',ROOT/'review-parity.py');helpers=importlib.util.module_from_spec(spec);spec.loader.exec_module(helpers)
    spec=importlib.util.spec_from_file_location('actual_smoke',REPO/'scripts/smoke-website.py');smoke=importlib.util.module_from_spec(spec);spec.loader.exec_module(smoke)
    assert sha(REPO/'scripts/smoke-website.py')==initial['tools']['reusedHtmlParser']['sha256']
    docs={}
    for ref in initial['httpObservations']:
        path=Path(ref['path']);assert sha(path)==ref['gzipSha256'];body=gzip.decompress(path.read_bytes());assert hashlib.sha256(body).hexdigest()==ref['rawSha256']
        doc=smoke.Document(body.decode()).root;main=doc.all('main');assert len(main)==1;parents={}
        def walk(e):
            for child in e.children:
                if isinstance(child,smoke.Element):parents[child]=e;walk(child)
        walk(doc);docs[ref['route']]=(main[0],parents)
    prefixes={'/':'dto.home.','/about':'dto.about.','/services':'dto.services.','/solutions':('dto.solutions.','dto.services.process[','dto.services.categories['),'/contact':'dto.contact.'}
    rows=[];errors=[]
    for original in initial['results']:
        row=dict(original);main,parents=docs[row['variantPath']]
        ids=row['modernParent']['ancestorIds'];contexts=[]
        for identity in ids:
            if identity=='main-content':continue
            matches=[e for e in main.all() if e.attrs.get('id')==identity]
            if matches:assert len(matches)==1;contexts=matches;break
        assert contexts,(row['testId'],'No corresponding semantic section/anchor')
        scope=contexts[0];nodes=[scope,*scope.all()];fragments=[];exceptions=[];unresolved=[]
        for index,f0 in enumerate(original['fragments']):
            f=dict(f0);text=f['expectedLeafText'];matches=[e for e in nodes if e.tag not in {'script','style','svg','path'} and norm(text)in norm(e.text())]
            matches.sort(key=lambda e:(len(norm(e.text())),len(e.all())))
            actual=[{'tag':e.tag,'text':e.text().strip(),'locator':helpers.locator(e,parents),**helpers.context(e,parents)}for e in matches[:3]]
            f['actualLeafEvidence']=actual
            if f['presentationOrdinal']:
                assert index==0 and re.match(r'^'+re.escape(text),row['expectedCandidate'])
                f['disposition']='EDITORIAL_ORDINAL_RECOMPOSED';f['reason']='This is the verified leading display ordinal; the following DTO facts are checked in the corresponding semantic section. It is not a measured result, fee, limit or missing source fact.'
            elif text=='服務組合' and row['variantPath']=='/design-collection/heritage/solutions' and row['testId']in {'DC006-PARITY-013','DC006-PARITY-014','DC006-PARITY-015'}:
                combos=[c for c in dto['solutions']['combinations']if norm(c['title'])in norm(row['expectedCandidate'])and norm(c['description'])in norm(row['expectedCandidate'])];assert len(combos)==1
                combination=combos[0]
                groups=[e for e in scope.all('li')if norm(combination['title'])in norm(e.text())and norm(combination['description'])in norm(e.text())];assert len(groups)==1
                group=groups[0];headings=[e for e in group.all('h4')if e.text().strip()=='相關技術服務'];assert len(headings)==1
                expected=[{'id':i,'title':next(s['title']for s in dto['services']['categories']if s['id']==i),'href':'/design-collection/heritage/services#'+i}for i in combination['serviceIds']]
                links=[{'title':a.text().strip(),'href':a.attrs.get('href')}for a in group.all('a')if (a.attrs.get('href')or'').startswith('/design-collection/heritage/services#')]
                assert links==[{k:r[k]for k in ('title','href')}for r in expected]
                f.update(disposition='UI_LABEL_RENAMED_WITH_IDENTICAL_SERVICE_FACTS_AND_DESTINATIONS',reason='In this Solutions combination, Modern「服務組合」is an editorial group label. Heritage uses「相關技術服務」above the same DTO serviceIds, exact service titles and correctly namespaced hrefs. The coincidental exact string at dto.services.page.integration.exampleLabel is unrelated to this source context and does not turn this UI label into a missing business fact.',dtoPaths=['dto.solutions.combinations.serviceIds -> dto.services.categories[id].title'],actualLeafEvidence=[{'tag':'h4','text':headings[0].text(),'locator':helpers.locator(headings[0],parents),**helpers.context(headings[0],parents)}],serviceLinkEvidence={'combinationTitle':combination['title'],'expected':expected,'actual':links})
                exceptions.append({'from':'服務組合','to':'相關技術服務','reason':'Editorial wording; actual service facts and hrefs preserved'})
            else:
                permitted=prefixes.get(row['canonicalPath'],'dto.portfolio.projects[')
                permitted=(permitted,)if isinstance(permitted,str)else permitted
                f['dtoPaths']=[p for p in f['dtoPaths']if p.startswith(permitted)]
                # In Solutions combinations this retained grouping label is UI too.
                if text in {'相關方案方向','服務組合'}:
                    f['dtoPaths']=[];f['dtoCorrespondence']='UI_GROUP_LABEL_NOT_BUSINESS_FIELD'
                if not actual:unresolved.append(text);f.update(disposition='UNRESOLVED',reason='The actual corresponding semantic section does not prove this source fragment.')
                elif f['dtoPaths']:f.update(disposition='DTO_FACT_RETAINED_IN_CORRESPONDING_SECTION',reason='The original DTO field text appears in a concrete HTML element within the corresponding semantic section/anchor, outside script/RSC payloads.')
                else:
                    assert text in {'相關方案方向','服務組合'},(row['testId'],text,'Unexpected non-DTO business fragment')
                    f.update(disposition='UI_LABEL_RETAINED',reason='This grouping label is literally retained within the corresponding section; its related field text/hrefs are checked separately.')
            fragments.append(f)
        row.update(fragments=fragments,unresolvedFragments=unresolved,semanticScope={'id':scope.attrs.get('id'),'locator':helpers.locator(scope,parents)},presentationChanges=exceptions,status='PASS'if not unresolved else'NEEDS_REVIEW',disposition='UI_LABEL_RENAME_AND_FACTS_RETAINED'if exceptions else'PARENT_RECOMPOSITION_WITH_DTO_FACTS_RETAINED')
        if unresolved:errors.append(row['testId'])
        rows.append(row)
    assert len(rows)==90 and len({row['testId']for row in rows})==90
    counts=Counter(row['disposition']for row in rows);parts=Counter(f['disposition']for row in rows for f in row['fragments'])
    report={'testId':'DC006-INTEGRATED-49-PARITY-90-FINAL','status':'PASS_SCOPED_PARITY_REVIEW'if not errors else'NEEDS_REVIEW','reviewedAtUtc':now(),'expected':{'diagnosticRows':32,'candidatePages':10,'candidates':90},'actual':{'reviewedCandidates':len(rows),'capturedHttpRoutes':len(docs),'candidatePages':len({r['variantPath']for r in rows}),'dispositions':dict(counts),'fragmentDispositions':dict(parts),'unresolvedTestIds':errors},'inputDiagnostic':initial['input'],'capture':{'path':str(ROOT/'result.json'),'sha256':sha(ROOT/'result.json'),'initialStatus':initial['status'],'receipt':{'path':str(ROOT/'review.receipt.json'),'sha256':sha(ROOT/'review.receipt.json'),'exitCode':json.loads((ROOT/'review.receipt.json').read_text())['exitCode']}},'tools':{'adjudicator':{'path':__file__,'sha256':sha(__file__)},**initial['tools']},'dto':initial['dto'],'sourceBridge':initial['sourceBridge'],'httpObservations':initial['httpObservations'],'results':rows,'limitations':['Only90 explicitly retained candidates on10 affected style pages were adjudicated; no blanket all49-page content-completeness claim is made.','Initial capture exited2 with3 unresolved UI labels and is kept unchanged. This independent pass explicitly identifies the3「服務組合」→「相關技術服務」renames and checks their exact serviceIds/titles/hrefs.','Every non-ordinal fact is checked within the corresponding actual semantic section, not merely found somewhere on the page. Native closed details and hidden/aria-hidden ancestors are retained in evidence; browser/CSS visibility/function checks are separate.','The approved-head22-file source bridge corroborates version only; it is never a replacement for these actual HTML/DTO comparisons.','No app edits, Git, builds, server lifecycle or outbound contact actions were performed. Only local3274 GET and offline/native data reads were used.'],'completionMarker':'DC006_PARITY_90_FINAL_COMPLETE'}
    out.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
    table='\n'.join(f"| {route} | {sum(r['variantPath']==route for r in rows)} |"for route in sorted({r['variantPath']for r in rows}))
    summary.write_text('# DC006整合49頁 —90項內容parity候選覆核\n\n'+('PASS：90項逐筆完成，未找到真正DTO事實遺漏。'if not errors else'仍有待覆核項目。')+'\n\n原diagnostic32 rows中10頁共90候選；已實取3274的18個Modern／variant HTML，並以該受測Repo原生getDesignContent DTO對照。每項expected原父li/p、actual實際leaf文字、DTO路徑、語意section及disposition均在[adjudication-final.json](adjudication-final.json)。\n\n| 受影響頁 | 候選數 |\n| --- | ---: |\n'+table+'\n\n87項為父節點串接／編號／內容順序重排；另3項Heritage Solutions把UI標籤「服務組合」改為「相關技術服務」，三組原serviceIds、實際服務名稱與href逐一完全相同。規劃、限制、技術及流程文字皆以同語意section內leaf保留證明，不用source bridge抵銷內容候選。\n\n第一階段保守收集因這3個UI標籤未裁決而真Exit2；原result／receipt保持不變。此final為明確後續裁決，非改標原結果。細節中的native closed details屬SSR存在性，CSS可見性／鍵盤功能須由Root瀏覽器矩陣另證；不宣稱所有49頁／全部DTO欄位均已內容驗收。\n\n只讀App與實際3274，未改App／Git／build／server，所有產物限本暫存目錄。\n')
    print(json.dumps({'status':report['status'],'candidates':len(rows),'counts':dict(counts),'fragments':dict(parts),'unresolved':errors,'result':str(out),'sha256':sha(out),'summarySha256':sha(summary)},ensure_ascii=False))
    return 2 if errors else 0

if __name__=='__main__':sys.exit(main())
