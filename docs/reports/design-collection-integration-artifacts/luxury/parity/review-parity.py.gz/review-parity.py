#!/usr/bin/env python3
"""Bounded fresh-HTTP review of the90 retained integration parity candidates."""
import argparse
from collections import Counter
from datetime import datetime, timezone
import gzip
import hashlib
import importlib.util
import io
import json
from pathlib import Path
import platform
import re
import subprocess
import sys
from urllib.parse import urlsplit
from urllib.request import ProxyHandler, build_opener

OUT=Path('/tmp/xk-dc006-merge/luxury-parity')
REPO=Path('/tmp/xk-merge-luxury')
INPUT=Path('/tmp/xk-dc006-merge/luxury/http-normal-result.json')
BRIDGE=Path('/tmp/xk-dc006-merge/luxury/source-bridge.json')
BASE='http://127.0.0.1:3274'
SMOKE=REPO/'scripts/smoke-website.py'


def sha(data):return hashlib.sha256(data).hexdigest()
def file_sha(path):return sha(Path(path).read_bytes())
def norm(text):return re.sub(r'\s+','',text)
def now():return datetime.now(timezone.utc).isoformat()
def save_json(path,data):path.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')
def gzip_raw(data):
    b=io.BytesIO()
    with gzip.GzipFile(fileobj=b,filename='',mode='wb',mtime=0,compresslevel=9) as f:f.write(data)
    return b.getvalue()

def flatten(value,path='dto'):
    if isinstance(value,str):yield path,value
    elif isinstance(value,list):
        for i,item in enumerate(value):yield from flatten(item,f'{path}[{i}]')
    elif isinstance(value,dict):
        for key,item in value.items():yield from flatten(item,path+'.'+key)


def locator(e,parents):
    parts=[]
    while e is not None and len(parts)<6:
        identity=e.tag+('#'+e.attrs['id'] if e.attrs.get('id') else '')
        if e.attrs.get('class'):identity+='.'+'.'.join(e.attrs['class'].split())
        if e.attrs.get('data-slot'):identity+='[data-slot='+e.attrs['data-slot']+']'
        parts.append(identity);e=parents.get(e)
    return ' > '.join(reversed(parts))


def context(e,parents):
    ids=[];details=[];hidden=[]
    while e is not None:
        if e.attrs.get('id'):ids.append(e.attrs['id'])
        if e.tag=='details':details.append({'open':'open' in e.attrs,'summary':[x.text().strip() for x in e.all('summary')][:1]})
        if 'hidden' in e.attrs or e.attrs.get('aria-hidden')=='true':hidden.append({'tag':e.tag,'id':e.attrs.get('id'),'hidden':'hidden'in e.attrs,'ariaHidden':e.attrs.get('aria-hidden')})
        e=parents.get(e)
    return {'ancestorIds':ids,'nativeDetailsAncestors':details,'hiddenOrAriaHiddenAncestors':hidden}


def text_runs(e,Element):
    if e.tag in {'script','style'}:return
    for child in e.children:
        if isinstance(child,Element):yield from text_runs(child,Element)
        elif child.strip():yield e,child.strip()


def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.parse_args()
    for name in ['result.json','summary.md','dto.json']:
        if (OUT/name).exists():raise ValueError('Preserve previous run; choose a new versioned script/output folder rather than overwriting '+name)
    raw=json.loads(INPUT.read_text());bridge=json.loads(BRIDGE.read_text())
    rows=raw['contentParityDiagnostics'];affected=[row for row in rows if row['candidateMissingChunks']]
    assert len(rows)==32 and len(affected)==10 and sum(len(r['candidateMissingChunks'])for r in rows)==90
    source_diff=[{'path':p,'expected':digest,'current':file_sha(REPO/p)} for p,digest in raw['environment']['sourceSha256'].items() if file_sha(REPO/p)!=digest]
    assert not source_diff,source_diff
    style_bridge=[row for row in bridge['files'] if row['path'].startswith(('src/components/design-collection/heritage/','src/components/design-collection/luxury/')) or row['path'] in {'src/design-systems/heritage/heritage.css','src/design-systems/luxury/luxury.css'}]
    assert len(style_bridge)==22
    assert all(file_sha(REPO/r['path'])==r['sha256'] for r in style_bridge)
    spec=importlib.util.spec_from_file_location('dc006_current_smoke',SMOKE);smoke=importlib.util.module_from_spec(spec);spec.loader.exec_module(smoke)
    node_command=['node','--import','./scripts/register-test-aliases.mjs','--input-type=module','-e',"import {getDesignContent} from './src/lib/design-collection/content.ts';process.stdout.write(JSON.stringify(getDesignContent()));"]
    result=subprocess.run(node_command,cwd=REPO,capture_output=True,text=True,check=False)
    assert result.returncode==0,result.stderr
    dto=json.loads(result.stdout);save_json(OUT/'dto.json',dto)
    facts=list(flatten(dto));exact={}
    for path,value in facts:
        if norm(value):exact.setdefault(norm(value),[]).append(path)
    opener=build_opener(ProxyHandler({}));documents={};observations=[]
    routes=sorted({p for row in affected for p in (row['canonicalPath'],row['path'])})
    assert len(routes)==18
    (OUT/'http').mkdir()
    for route in routes:
        assert route.startswith('/') and not urlsplit(route).netloc and not urlsplit(route).query and not urlsplit(route).fragment
        url=BASE+route
        with opener.open(url,timeout=20) as response:
            body=response.read();assert response.status==200
            assert urlsplit(response.geturl()).hostname=='127.0.0.1'
            observed={'route':route,'url':response.geturl(),'status':response.status,'contentType':response.headers.get('Content-Type'),'rawBytes':len(body),'rawSha256':sha(body),'capturedAt':now()}
        file=OUT/'http'/((route.strip('/').replace('/','__')or'home')+'.html.gz');file.write_bytes(gzip_raw(body));observed.update(path=str(file),gzipSha256=file_sha(file));observations.append(observed)
        doc=smoke.Document(body.decode('utf-8')).root;main_nodes=doc.all('main');assert len(main_nodes)==1
        parents={}
        def walk(e):
            for child in e.children:
                if isinstance(child,smoke.Element):parents[child]=e;walk(child)
        walk(doc)
        documents[route]=(main_nodes[0],parents)
    report_rows=[]
    for route_row in affected:
        modern,mp=documents[route_row['canonicalPath']];variant,vp=documents[route_row['path']]
        vn=[e for e in variant.all() if e.tag not in {'script','style','svg','path'} and e.text().strip()]
        for chunk_index,chunk in enumerate(route_row['candidateMissingChunks'],1):
            matches=[e for e in modern.all() if e.tag in {'p','li'} and e.text().strip()==chunk]
            assert matches,(route_row['path'],chunk)
            parent=min(matches,key=lambda e:len(e.all()))
            fragments=[];missing=[]
            for owner,text in text_runs(parent,smoke.Element):
                value=norm(text)
                presentation=bool(re.fullmatch(r'\d{1,2}',value))
                paths=exact.get(value,[])
                correspondence='EXACT_DTO_VALUE' if paths else 'NOT_AN_EXACT_DTO_VALUE'
                if not paths and not presentation:
                    paths=[path for path,fact in facts if len(value)>=4 and value in norm(fact)]
                    if paths:correspondence='CONTAINED_IN_DTO_VALUE'
                candidates=[e for e in vn if value in norm(e.text())]
                candidates.sort(key=lambda e:(len(norm(e.text())),len(e.all())))
                actual=[]
                for e in candidates[:3]:actual.append({'tag':e.tag,'text':e.text().strip(),'locator':locator(e,vp),**context(e,vp)})
                row={'expectedLeafText':text,'modernLocator':locator(owner,mp),'dtoPaths':paths,'dtoCorrespondence':correspondence,'presentationOrdinal':presentation,'actualLeafEvidence':actual}
                if presentation:
                    row['disposition']='PRESENTATION_ORDINAL_MAY_BE_RECOMPOSED';row['reason']='A leading one/two-digit sequence is an editorial list ordinal, not a service fact, price, limitation or claimed result. Its source facts are separately verified below.'
                elif actual and paths:
                    row['disposition']='DTO_FACT_RETAINED_IN_REAL_HTML_LEAF';row['reason']='The original field text occurs in an actual main-content element, not an RSC/script string. Its original DTO path is recorded.'
                elif actual:
                    row['disposition']='NON_DTO_UI_TEXT_RETAINED';row['reason']='An original UI label or partial text run is still present in an actual main-content element; no business claim is inferred.'
                else:
                    row['disposition']='UNRESOLVED_TEXT_ABSENCE';missing.append(text)
                fragments.append(row)
            assert fragments
            disposition='FACTS_RETAINED_WITH_PARENT_RECOMPOSITION' if not missing else 'NEEDS_INDEPENDENT_REVIEW'
            report_rows.append({'testId':f'DC006-PARITY-{len(report_rows)+1:03d}','variantPath':route_row['path'],'canonicalPath':route_row['canonicalPath'],'candidateIndex':chunk_index,'expectedCandidate':chunk,'modernParent':{'tag':parent.tag,'locator':locator(parent,mp),**context(parent,mp)},'actualContiguousParentTextPresent':norm(chunk)in norm(variant.text()),'expected':'All actual DTO fact/limitation text runs in this Modern parent remain available in corresponding style HTML; source ordinals and grouping may differ.','disposition':disposition,'unresolvedFragments':missing,'fragments':fragments})
    assert len(report_rows)==90
    unresolved=[r['testId'] for r in report_rows if r['unresolvedFragments']]
    counts=Counter(r['disposition']for r in report_rows)
    report={'testId':'DC006-INTEGRATED-49-PARITY-INDEPENDENT-REVIEW','status':'NEEDS_REVIEW' if unresolved else 'FACT_PRESERVATION_EVIDENCE_COMPLETE','startedAt':STARTED,'finishedAt':now(),'input':{'path':str(INPUT),'sha256':file_sha(INPUT),'originalDiagnosticRows':32,'candidateRows':10,'candidates':90,'originalSuiteResult':raw['result'],'originalSmokeCounts':raw['counts']},'environment':{'python':platform.python_version(),'baseURL':BASE,'repository':str(REPO),'transport':'direct loopback urllib GET; proxies disabled','browserUsed':False},'tools':{'reviewScript':{'path':__file__,'sha256':file_sha(__file__)},'reusedHtmlParser':{'path':str(SMOKE),'sha256':file_sha(SMOKE)},'nodeAliasLoader':{'path':str(REPO/'scripts/register-test-aliases.mjs'),'sha256':file_sha(REPO/'scripts/register-test-aliases.mjs')}},'dto':{'path':str(OUT/'dto.json'),'sha256':file_sha(OUT/'dto.json'),'nodeCommand':node_command,'nodeExitCode':result.returncode,'nodeStderr':result.stderr,'selectedSourceFiles':{str(p.relative_to(REPO)):file_sha(p) for p in [REPO/'src/lib/design-collection/content.ts',*sorted((REPO/'src/config').glob('*.ts'))]}},'sourceBridge':{'path':str(BRIDGE),'sha256':file_sha(BRIDGE),'refs':bridge['refs'],'styleCompositionAndCssFilesMatched':len(style_bridge),'use':'Version corroboration only; every one of90 candidates still receives actual fresh HTML/DTO evidence.'},'httpObservations':observations,'counts':dict(counts),'unresolvedTestIds':unresolved,'results':report_rows,'scope':['Exactly the90 input candidates on10 affected style pages;18 unique actual Modern/variant HTML routes retrieved. The22 zero-candidate diagnostic rows are not relabeled as a new full content audit.','Closed native details and aria-hidden ancestors are recorded. This is SSR semantic-text review, not a claim of CSS/browser visibility, disclosure keyboard behavior or complete DTO-field coverage.','Ordinals are treated explicitly as presentation; no source fact, limitation or price is discarded by a blanket ignore or normalization. Actual leaf words and DTO paths remain recorded.','No app source, server, build, Git or outbound contact action was changed/executed.'], 'completionMarker':'DC006_PARITY_90_EVIDENCE_COMPLETE'}
    save_json(OUT/'result.json',report)
    for row in report_rows:
        print(row['testId'],row['variantPath'],row['candidateIndex'],len(row['fragments']),row['disposition'],json.dumps(row['unresolvedFragments'],ensure_ascii=False))
    print('COUNTS',json.dumps(dict(counts)), 'UNRESOLVED',len(unresolved))
    return 2 if unresolved else 0

if __name__=='__main__':
    STARTED=now()
    sys.exit(main())
