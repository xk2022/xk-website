import ast
import hashlib
import json
from pathlib import Path
import runpy
import subprocess
from types import SimpleNamespace

root = Path('/tmp/xk-merge-luxury')
files = ['scripts/build-github-pages.mjs', 'scripts/smoke-website.py', 'scripts/fixtures/design-collection-contract.json', 'scripts/test-design-collection-routes.mjs', 'scripts/test-design-collection-metadata.mjs']
checks = 0

def check(condition):
    global checks
    assert condition
    checks += 1

for name in files:
    raw = (root / name).read_bytes()
    check(raw.endswith(b'\n') and not raw.endswith(b'\n\n'))
    check(not any(line.startswith((b'<<<<<<<', b'=======', b'>>>>>>>')) for line in raw.splitlines()))
    check(not any(line.endswith((b' ', b'\t')) for line in raw.splitlines()))
for name in [files[0], files[3], files[4]]:
    subprocess.run(['node', '--check', name], cwd=root, check=True)
    checks += 1
ast.parse((root / files[1]).read_text())
checks += 1
fixture = json.loads((root / files[2]).read_text())
check(len(fixture['publishedPaths']) == len(set(fixture['publishedPaths'])) == 49)
check(fixture['styleStatus'] == dict.fromkeys(('modern', 'heritage', 'luxury'), 'implemented'))
check(all(len(fixture[style + 'Routes']) == 16 for style in ('modern', 'heritage', 'luxury')))
check(set(fixture['publishedPaths']) == {fixture['collectionRoute']['path'], *(row['path'] for style in ('modern', 'heritage', 'luxury') for row in fixture[style + 'Routes'])})
for style in ('heritage', 'luxury'):
    for modern, variant in zip(fixture['modernRoutes'], fixture[style + 'Routes']):
        check((modern['pageKey'], modern.get('slug'), modern['path']) == (variant['pageKey'], variant.get('slug'), variant['canonicalPath']))

module = runpy.run_path(str(root / files[1]))
smoke = module['Smoke'](SimpleNamespace(base_url='http://127.0.0.1:3999/', check_external=False, check_source_assets=False))
for style in ('heritage', 'luxury'):
    prefix = '/design-collection/' + style
    for modern, variant in zip(fixture['modernRoutes'], fixture[style + 'Routes']):
        check(smoke.content_path(variant['path']) == modern['path'])
        check(smoke.design_identity(variant['path'])['pageKey'] == modern['pageKey'])
        check(smoke.presentation_href(modern['path'], prefix) == variant['path'])
        check(smoke.presentation_href(modern['path'], prefix + '/contact') == variant['path'])
    for suffix in ('/privacy', '/dev/design-system', '/portfolio/unknown', '/contact/unknown', '/quotation/unknown', '/contact?email=PRIVATE', '/contact//'):
        unknown = prefix + suffix
        check(smoke.design_identity(unknown) is None and smoke.content_path(unknown) == unknown)
        check(smoke.presentation_href('/contact', unknown) == '/contact')
check(smoke.presentation_href('/contact', '/design-collection/unknown') == '/contact')
check(smoke.content_path('/design-collection/modern/contact') == '/design-collection/modern/contact')
check(sum(smoke.content_path(path) == '/contact' for path in fixture['publishedPaths']) == 3)
check(sum(smoke.content_path(path) == '/quotation' for path in fixture['publishedPaths']) == 3)
check(sum(smoke.content_path(path) not in ('/contact', '/quotation') for path in fixture['publishedPaths']) == 43)
for expected in ('/', '/design-collection/heritage', '/design-collection/luxury'):
    accepted = [expected] + ([expected + '/'] if expected != '/' else [])
    for href in accepted:
        check(module['gallery_style_links']([href], [expected]) == [expected])
    for href in (expected + '//', expected + '?x=1', expected + '#main-content', 'https://www.xplorekaleidoscope.com' + expected, '//www.xplorekaleidoscope.com' + expected, expected + '/other'):
        check(module['gallery_style_links']([href], [expected]) != [expected])
    check(module['gallery_style_links']([expected, expected], [expected]) != [expected])

node_code = r'''
const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');
const source = fs.readFileSync('scripts/build-github-pages.mjs', 'utf8');
const designContract = JSON.parse(fs.readFileSync('scripts/fixtures/design-collection-contract.json', 'utf8'));
const routeHelpers = source.slice(source.indexOf('const presentationRoutes = ['), source.indexOf('for (const logo of Object.values('));
const galleryHelper = source.match(/function verifyStyleHomeLink\(links, expectedPath\) \{[\s\S]*?\n\}/)[0];
const sandbox = {assert, designContract};
vm.runInNewContext(routeHelpers + '\n' + galleryHelper + '\nthis.helpers = {contentPathFor, presentationHref, verifyStyleHomeLink};', sandbox);
const {contentPathFor, presentationHref, verifyStyleHomeLink} = sandbox.helpers;
for (const style of ['heritage', 'luxury']) {
  for (const row of designContract[style + 'Routes']) {
    assert.equal(contentPathFor(row.path), row.canonicalPath);
    assert.equal(presentationHref(row.canonicalPath, '/design-collection/' + style), row.path);
  }
  assert.equal(contentPathFor('/design-collection/' + style + '/contact/unknown'), '/design-collection/' + style + '/contact/unknown');
  assert.equal(presentationHref('/contact', '/design-collection/' + style + '/contact/unknown'), '/contact');
}
for (const path of Object.values(designContract.styleHomePaths)) {
  verifyStyleHomeLink([path], path);
  if (path !== '/') verifyStyleHomeLink([path + '/'], path);
  for (const href of [path + '//', path + '?x=1', path + '#main-content', 'https://www.xplorekaleidoscope.com' + path, '//www.xplorekaleidoscope.com' + path, path + '/other']) assert.throws(() => verifyStyleHomeLink([href], path));
  assert.throws(() => verifyStyleHomeLink([path, path], path));
}
assert.throws(() => verifyStyleHomeLink(['/design-collection/unapproved'], '/design-collection/unapproved'));
console.log('Builder exact-path and Gallery strict positive/negative checks PASS');
'''
subprocess.run(['node', '-e', node_code], cwd=root, check=True)
checks += 1
for logo in fixture['heritageLogos'].values():
    check(hashlib.sha256((root / 'public' / logo['src'].lstrip('/')).read_bytes()).hexdigest() == logo['sha256'])
print(json.dumps({'status':'PASS','checks':checks,'publicRoutes':49,'styles':[16,16,16],'galleryLinks':3,'contactScopes':3,'quotationScopes':3,'remainingNoControlPages':43,'networkOrBuildRun':False}))
