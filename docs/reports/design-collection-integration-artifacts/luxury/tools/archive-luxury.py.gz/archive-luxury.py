from pathlib import Path
import json,gzip,hashlib,shutil
repo=Path('/tmp/xk-merge-luxury');base=Path('/tmp/xk-dc006-merge/luxury');dst=repo/'docs/reports/design-collection-integration-artifacts/luxury';dst.mkdir(parents=True,exist_ok=True);rows=[]
def save(src,name,compressed=False):
 b=src.read_bytes();encoded=gzip.compress(b,mtime=0) if compressed else b;name+=('.gz' if compressed else '');p=dst/name;p.parent.mkdir(parents=True,exist_ok=True)
 if p.exists():assert p.read_bytes()==encoded,name
 else:p.write_bytes(encoded)
 rows.append({'path':name,'sha256':hashlib.sha256(encoded).hexdigest(),'decodedSha256':hashlib.sha256(b).hexdigest(),'bytes':len(encoded),'decodedBytes':len(b),'archiveEncoding':'gzip' if compressed else 'identity','originalEncoding':'gzip' if src.suffix=='.gz' else 'identity'})
for p in sorted(base.iterdir()):
 if p.is_file() and p.suffix in ['.json','.log'] and not p.name.startswith('server-'):
  save(p,p.name,p.suffix=='.log' or p.name in ['source-bridge.json'] or p.name.endswith('-result.json'))
tools=Path('/tmp/xk-dc006/merge2')
for p in sorted(tools.iterdir()):
 if p.is_file() and p.suffix in ['.json','.log','.cjs']:save(p,'tools/'+p.name,True)
for version in ['normal-final','normal-v2-tiny-preflight','normal-v2','pages-v2']:
 p=tools/version/'result.json';save(p,'browser/'+version+'/result.json',True)
# Keep every failed-screenshot mapping while archiving identical PNG bytes once.
first=json.loads((tools/'normal-final/result.json').read_text());mapping=[];seen={}
for e in first.get('failureScreenshots',[]):
 p=Path(e['path']);h=hashlib.sha256(p.read_bytes()).hexdigest();name='failures/'+h+'.png'
 if h not in seen:save(p,name);seen[h]=name
 mapping.append({'testId':e['testId'],'originalPath':str(p),'sha256':h,'archivedPath':name})
(dst/'failure-screenshot-map.json').write_text(json.dumps(mapping,ensure_ascii=False,indent=2)+'\n')
save(dst/'failure-screenshot-map.json','failure-screenshot-map.json')
for n in ['shared-byte-bridge.json','native-v1.json','native-v1.log','lint-v1.json','lint-v1.log','check.mjs']:
 p=Path('/tmp/xk-merge-luxury-checks')/n;save(p,'ui-owner/'+n,True)
for n in ['selfcheck-49.py','selfcheck-49-v2-receipt.json','selfcheck-49-v2.log','freeze-49.json']:
 p=Path('/tmp/xk-dc006-validator')/n;save(p,'validators/'+n,True)
for n in ['source-review.json','source-review.md']:
 p=Path('/tmp/xk-dc006-source')/n;save(p,'company/'+n,True)
parity=Path('/tmp/xk-dc006-merge/luxury-parity')
for p in sorted(parity.rglob('*')):
 if p.is_file():save(p,'parity/'+str(p.relative_to(parity)),p.suffix not in ['.png','.gz'])
remote=Path('/tmp/xk-dc006-merge/luxury-remote')
for n in ['inspect-ci-artifact.py','preparation.json','local-artifact-check.json','local-artifact-check.log','local-artifact-check.receipt.json','prepare-local-baseline.log','prepare-local-baseline.receipt.json','artifact-baseline/baseline.json']:
 save(remote/n,'artifact/'+n,True)
save(Path('/tmp/xk-dc006-merge/snapshot-luxury-source.py'),'tools/snapshot-luxury-source.py',True)
for n in ['check-luxury-docs.py','check-luxury-docs-v2.py','archive-luxury.py']:
 save(Path('/tmp/xk-dc006-merge')/n,'tools/'+n,True)
(dst/'manifest.json').write_text(json.dumps({'files':rows,'failureScreenshotRecords':len(mapping),'uniqueFailurePNGs':len(seen),'policy':'Immutable originals; gzip mtime0; no signed URL; actual browser v1 failure retained.'},ensure_ascii=False,indent=2)+'\n');print(json.dumps({'files':len(rows),'bytes':sum(e['bytes'] for e in rows),'failurePNGrecords':len(mapping),'uniqueFailurePNGs':len(seen)}))
