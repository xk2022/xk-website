from pathlib import Path
import subprocess,json,hashlib,datetime
r=Path('/tmp/xk-merge-luxury');refs={'luxury':'efd098a9a79667b29d5f0a8e71d2752941c30a0d','heritage':'0d41ecf495e55b792f966c9fe27bd07c27bc5647'}
paths=subprocess.check_output(['git','ls-files','-z'],cwd=r).decode().split('\0');paths=sorted({p for p in paths if p and (p.startswith(('src/','public/','scripts/')) or p in ['package.json','package-lock.json','next.config.ts','.github/workflows/ci.yml','.nvmrc','eslint.config.mjs','tsconfig.json']) and (r/p).is_file()})
def old(ref,p):
 t=subprocess.run(['git','show',f'{ref}:{p}'],cwd=r,capture_output=True);return hashlib.sha256(t.stdout).hexdigest() if t.returncode==0 else None
rows=[]
for p in paths:
 b=(r/p).read_bytes();rows.append({'path':p,'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b),'luxurySha256':old(refs['luxury'],p),'heritageSha256':old(refs['heritage'],p)})
by={x['path']:x for x in rows}
unchanged=[p for p in paths if p.startswith(('src/lib/quotation/','src/hooks/use-quotation','public/')) or p in ['src/config/quotation.ts','src/lib/contact-inquiry.ts','src/config/contact-inquiry.ts','src/components/sections/quotation/quotation-summary.tsx','src/components/sections/quotation/quotation.css','package.json','package-lock.json','next.config.ts','.github/workflows/ci.yml']]
assert all(by[p]['sha256']==by[p]['luxurySha256']==by[p]['heritageSha256'] for p in unchanged)
compositions=[]
for style in refs:
 for p in paths:
  if p.startswith(f'src/components/design-collection/{style}/') and not p.endswith(f'{style}-frame.tsx') or p.startswith(f'src/design-systems/{style}/'):
   assert by[p]['sha256']==by[p][style+'Sha256'],p;compositions.append(p)
data={'testId':'PR42-49-SOURCE-BRIDGE','createdAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'PASS','refs':refs,'files':rows,'sha256':hashlib.sha256(json.dumps([(x['path'],x['sha256']) for x in rows],separators=(',',':')).encode()).hexdigest(),'unchangedAcrossBoth':unchanged,'unchangedApprovedCompositions':compositions,'changeImpact':{'newAcceptance':'49 exact HTTP/SEO/link/anchor/assets/private paths;245 layouts per mode;allthreeFooters/dispatch/ContactQuote class and lifecycle/PII/IDs/printmedia','inheritedOnly':'Unchanged semantic business/pricing/native algorithms and standard A4 summary/print/QR/assets; prior exact fullPDF evidence remains historical, not rerun','controllers':'Compared to accepted Luxury only class/data recognition adds Heritage; its direct DOM cleanup logic preserved. Heritage obtains accepted stronger cleanup; fresh lifecycle/PII verification required.','routes':'Explicit two-style static params + validated server dispatcher to the existing unchanged separate compositions; no switcher yet.','publicURLs':'PR43 already merged Hub correction, main source retained and native exact expectations still enforced.'}}
Path('/tmp/xk-dc006-merge/luxury/source-bridge.json').write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'status':'PASS','files':len(rows),'unchangedAcrossBoth':len(unchanged),'approvedCompositions':len(compositions),'sha256':data['sha256']}))
