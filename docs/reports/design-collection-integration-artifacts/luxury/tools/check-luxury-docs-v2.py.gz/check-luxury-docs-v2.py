from pathlib import Path
import re,json,gzip,hashlib,subprocess,struct
r=Path('/tmp/xk-merge-luxury');base=r/'docs/reports/design-collection-integration-artifacts/luxury'
paths=['AGENTS.md','README.md','docs/01_design/README.md','docs/98_decisions/implementation-notes.md','docs/reports/README.md','docs/task/README.md','docs/task/ROADMAP.md','docs/reports/design-collection-integration.md','docs/screenshots/design-collection/integration-pr42/README.md']
for f in paths:
 p=r/f;s=p.read_text();assert not re.search(r'^(<<<<<<<|=======|>>>>>>>)',s,re.M),f
 for link in re.findall(r'\]\(([^)]+)\)',s):
  if re.match(r'^[a-zA-Z][a-zA-Z0-9+.-]*:',link) or link.startswith('#'):continue
  target=link.split('#')[0];assert not target or (p.parent/target).exists(),(f,link)
m=json.loads((base/'manifest.json').read_text())
for e in m['files']:
 b=(base/e['path']).read_bytes();assert hashlib.sha256(b).hexdigest()==e['sha256'];d=gzip.decompress(b) if e['archiveEncoding']=='gzip' else b;assert hashlib.sha256(d).hexdigest()==e['decodedSha256']
shots=json.loads((r/'docs/screenshots/design-collection/integration-pr42/visual-review.json').read_text());assert len(shots['files'])==14
for e in shots['files']:
 b=(r/'docs/screenshots/design-collection/integration-pr42'/e['path']).read_bytes();assert hashlib.sha256(b).hexdigest()==e['sha256'];assert struct.unpack('>I',b[16:20])[0]==e['width'];assert e['visuallyInspected']
bridge=json.loads(Path('/tmp/xk-dc006-merge/luxury/source-bridge.json').read_text())
for e in bridge['files']:assert hashlib.sha256((r/e['path']).read_bytes()).hexdigest()==e['sha256'],e['path']
for cmd in [['git','diff','--check'],['git','diff','--cached','--check']]:subprocess.run(cmd,cwd=r,check=True)
assert not subprocess.check_output(['git','diff','--name-only','--diff-filter=U'],cwd=r,text=True).strip()
assert not subprocess.check_output(['git','diff','HEAD','--name-only','--','package.json','package-lock.json','next.config.ts','.github/workflows/ci.yml'],cwd=r,text=True).strip()
files=subprocess.check_output(['git','ls-files'],cwd=r,text=True).splitlines();assert not any(f.startswith(('.next/','out/','node_modules/')) or f.startswith('.env.') for f in files)
print(json.dumps({'status':'PASS','docs':len(paths),'manifestFiles':len(m['files']),'screenshots':14,'runtimeFilesUnchangedSinceFreeze':len(bridge['files']),'conflicts':0,'missingLinks':0,'changedDependenciesOrDeployment':False}))
