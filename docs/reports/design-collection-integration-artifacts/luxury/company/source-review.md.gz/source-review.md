# DC-006 公司來源版本核對

最新 main仍為 `9213a3d8dacb8774d87c26cb736c4a4315779e95`，tree `195c5c8100b74513985e040f3ee6fc642571285e`，與DC005已讀版本完全相同；完整tree未截斷。**無實質變更、無本輪新增來源衝突。**

本輪全文讀取根AGENTS、05_brand/README、05_brand/overview、06_engineering/README、06_engineering/overview及官網專案入口；其餘同版本品牌／Logo／字體／分類／工程／網站發布正文沿用前輪閱讀，未重下載或冒稱重新全文閱讀。

| 本輪全文來源 | Blob |
| --- | --- |
| AGENTS.md | `a7ca443ddd1d1b847dc58152bbb56c1425c1b522` |
| 05_brand/README.md | `5bb4652153372b084de0e4f6c46c7ca94fe7674a` |
| 05_brand/overview.md | `3c3bb05d8d1505d07223bb5f8f482f7a2b923639` |
| 06_engineering/README.md | `6284317132c9b9002d1962cdb7075ce9f9632590` |
| 06_engineering/overview.md | `828cf4e5bf3ba8de12b115549c135451be87ac39` |
| 08_projects/official-website/overview.md | `b48d240230283e062b37fabb1422b9fac2bc41a8` |

AGENTS要求保持指定範圍及來源／歷史；公司文件metadata檢查不擴大website依賴或本次驗證範圍。品牌外框、正式Logo03與字體的既有規則未變。工程入口仍區分靜態網站與APP部署，實際路徑及發布證據依xk-website。

公司來源沒有新增規則阻礙已獲使用者授權的DC006及前置merge；本核對不另創核准門檻，也不擴張為新增業務／價格／Logo／法律／索引或部署承諾。詳見[source-review.json](source-review.json)。

只寫/tmp/xk-dc006-source版本紀錄；未改Repo/src/Git，未build、preview或操作PR/merge。
