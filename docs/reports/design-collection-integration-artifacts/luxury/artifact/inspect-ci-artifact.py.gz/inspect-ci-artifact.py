#!/usr/bin/env python3
"""Offline Luxury49 main-integration Pages artifact checks; never performs HTTP requests or builds."""
import argparse
import hashlib
import importlib.util
import io
import json
import mimetypes
from pathlib import Path, PurePosixPath
import re
import shutil
import tarfile
from types import SimpleNamespace
from urllib.parse import unquote, urljoin, urlsplit
import zipfile
from datetime import datetime, timezone

HERE = Path(__file__).resolve().parent
BASELINE = HERE / 'artifact-baseline'
INTERNAL_HTML = {'404.html', '404/index.html', '_not-found/index.html'}
MANIFESTS = {'_buildManifest.js', '_ssgManifest.js', '_clientMiddlewareManifest.js'}


def sha(data):
    return hashlib.sha256(data).hexdigest()


def load_helper(path, root):
    spec = importlib.util.spec_from_file_location('dc004_frozen_smoke', path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    module.ROOT = root
    module.CONTRACT_PATH = root / 'scripts/fixtures/showcase-contract.json'
    return module


def args_for_smoke():
    return SimpleNamespace(base_url='https://www.xplorekaleidoscope.com/', timeout=1,
                           check_external=False, check_source_assets=False, output=None)


def read_directory(root):
    files = {}
    for path in sorted(root.rglob('*')):
        if path.is_symlink():
            raise ValueError('Symlink in output: ' + str(path))
        if path.is_file():
            files[path.relative_to(root).as_posix()] = path.read_bytes()
    return files


def safe_name(name):
    path = PurePosixPath(name)
    if name.startswith('/') or '\\' in name or '..' in path.parts:
        raise ValueError('Unsafe archive path')
    return path.as_posix().removeprefix('./')


def read_zip(path):
    raw = path.read_bytes()
    with zipfile.ZipFile(io.BytesIO(raw)) as archive:
        entries = archive.infolist()
        if len(entries) != 1 or entries[0].filename != 'artifact.tar':
            raise ValueError('Expected exactly artifact.tar in ZIP')
        if entries[0].file_size > 100_000_000:
            raise ValueError('Oversized TAR')
        tar_bytes = archive.read(entries[0])
    files, seen, total = {}, set(), 0
    with tarfile.open(fileobj=io.BytesIO(tar_bytes), mode='r:*') as archive:
        for item in archive:
            name = safe_name(item.name)
            if name in seen:
                raise ValueError('Duplicate archive entry: ' + name)
            seen.add(name)
            if item.isdir():
                continue
            if not item.isfile() or item.issym() or item.islnk():
                raise ValueError('Nonregular archive entry: ' + name)
            total += item.size
            if len(files) >= 5000 or total > 100_000_000:
                raise ValueError('Oversized archive inventory')
            files[name] = archive.extractfile(item).read()
    return files, sha(raw), sha(tar_bytes)


def build_id(files):
    ids = [match[1] for name in files if (match := re.fullmatch(r'_next/static/([^/]+)/_buildManifest\.js', name))]
    if len(ids) != 1:
        raise ValueError('Expected exactly one actual Next BuildID manifest')
    return ids[0]


def normalized_name(name, actual_id):
    prefix = '_next/static/' + actual_id + '/'
    if name.startswith(prefix) and name[len(prefix):] in MANIFESTS:
        return '_next/static/<BUILD_ID>/' + name[len(prefix):]
    return name


def inventory(files):
    actual_id = build_id(files)
    return {'buildId': actual_id, 'files': {normalized_name(name, actual_id):
            {'path': name, 'bytes': len(data), 'sha256': sha(data)} for name, data in files.items()}}


def prepare(repo, root, build_receipt):
    if BASELINE.exists():
        raise ValueError('Refusing to overwrite frozen local baseline')
    receipt = json.loads(build_receipt.read_text())
    if receipt.get('status') != 'PASS' or receipt.get('exitCode') != 0:
        raise ValueError('Local Pages build receipt is not PASS/0')
    helper = load_helper(repo / 'scripts/smoke-website.py', repo)
    smoke = helper.Smoke(args_for_smoke())
    if not smoke.source_contract() or any(row['status'] == 'FAIL' for row in smoke.results):
        raise ValueError('Source contract failed')
    files = read_directory(root)
    BASELINE.mkdir()
    (BASELINE / 'scripts/fixtures').mkdir(parents=True)
    shutil.copyfile(repo / 'scripts/smoke-website.py', BASELINE / 'smoke-website.py')
    for fixture in ['showcase', 'contact', 'quotation', 'design-collection']:
        name = fixture + '-contract.json'
        shutil.copyfile(repo / 'scripts/fixtures' / name, BASELINE / 'scripts/fixtures' / name)
    record = {'createdAt': datetime.now(timezone.utc).isoformat(), 'localOut': str(root),
              'sourceData': smoke.data, 'sourceEnvironment': smoke.environment,
              'sourceAssertions': smoke.results, 'buildReceipt': receipt,
              'externalDestinations': sorted(smoke.external_destinations),
              'unavailableSourceDestinations': sorted(smoke.unavailable_source_destinations),
              'helperSha256': sha((repo / 'scripts/smoke-website.py').read_bytes()),
              'normalizedFileSha256': {normalized_name(name, build_id(files)): sha(data.replace(build_id(files).encode(), b'<ACTUAL_NEXT_BUILD_ID>')) if name.endswith(('.html', '.txt')) else sha(data) for name, data in files.items()},
              'inventory': inventory(files)}
    (BASELINE / 'baseline.json').write_text(json.dumps(record, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps({'status': 'PASS', 'baseline': str(BASELINE), 'files': len(files),
                      'publicRoutes': len(smoke.public_pages), 'buildId': build_id(files)}))


def inspect(files, evidence=None):
    frozen = json.loads((BASELINE / 'baseline.json').read_text())
    helper = load_helper(BASELINE / 'smoke-website.py', BASELINE)
    smoke = helper.Smoke(args_for_smoke())
    smoke.data = frozen['sourceData']
    smoke.public_pages = [page for page in smoke.data['seoPages'] if page['availability'] == 'public']
    smoke.external_destinations = set(frozen['externalDestinations'])
    smoke.unavailable_source_destinations = set(frozen['unavailableSourceDestinations'])
    checks = []
    def check(item, expected, actual):
        checks.append({'item': item, 'expected': expected, 'actual': actual,
                       'status': 'PASS' if expected == actual else 'FAIL'})
    paths = smoke.design_contract['publishedPaths']
    expected_html = {'index.html' if path == '/' else path.lstrip('/') + '/index.html' for path in paths}
    check('Independent exact published route count', 49, len(paths))
    check('Actual HTML inventory is exactly 49 public pages plus known Next error pages',
          sorted(expected_html | INTERNAL_HTML), sorted(name for name in files if name.endswith('.html')))
    actual_inventory = inventory(files)
    old = frozen['inventory']['files']
    current = actual_inventory['files']
    check('Entire artifact file inventory matches tested output; only three real BuildID manifest paths normalized',
          sorted(old), sorted(current))
    runtime = [name for name in old if not name.endswith(('.html', '.txt'))]
    mismatch = [name for name in runtime if name not in current or
                (old[name]['bytes'], old[name]['sha256']) != (current[name]['bytes'], current[name]['sha256'])]
    check('Every runtime/static asset matches tested local raw bytes', [], mismatch)
    actual_id = actual_inventory['buildId']
    normalized_hashes = {normalized_name(name, actual_id): sha(data.replace(actual_id.encode(), b'<ACTUAL_NEXT_BUILD_ID>')) if name.endswith(('.html', '.txt')) else sha(data) for name, data in files.items()}
    check('All file contents equal tested output with only the actual BuildID token normalized in HTML/RSC', [], [name for name, digest in frozen['normalizedFileSha256'].items() if normalized_hashes.get(name) != digest])
    check('Empty .nojekyll exists', b'', files.get('.nojekyll'))
    check('404 artifact exists', True, bool(files.get('404.html')))
    check('No private/planned/unknown or review-prototype output paths', [], [name for name in files if re.search(
          r'(^|/)(?:reviews|privacy|dev|unknown[^/]*)(?:/|\.|$)|(^|/)sitemap(?:\.|/)|(?:heritage|luxury)-v[0-9]+\.html', name)])
    public_payload_dirs = {path.lstrip('/') for path in paths} | {'', '404', '_not-found'}
    check('RSC payloads belong only to public/error routes', [], [name for name in files if name.endswith('.txt')
          and name != 'robots.txt' and ('' if str(PurePosixPath(name).parent) == '.' else str(PurePosixPath(name).parent)) not in public_payload_dirs])
    for path in paths:
        name = 'index.html' if path == '/' else path.lstrip('/') + '/index.html'
        if name in files:
            smoke.documents[path] = helper.Document(files[name].decode('utf-8')).root
    def offline_fetch(url):
        parsed = urlsplit(url)
        if (parsed.scheme, parsed.netloc) != smoke.origin:
            raise ValueError('Offline checker refuses external fetch')
        name = unquote(parsed.path).lstrip('/')
        candidates = [name, name.rstrip('/') + '/index.html'] if name else ['index.html']
        target = next((name for name in candidates if name in files), None)
        return {'status': 200 if target else 404, 'body': files[target] if target else files.get('404.html', b''),
                'headers': {'Content-Type': mimetypes.guess_type(target or '404.html')[0] or 'application/octet-stream'}}
    smoke.fetch = offline_fetch
    for path, doc in smoke.documents.items():
        smoke.metadata(path, doc)
        check(path + ' single complete frame and skip destination', [], helper.modern_frame_errors(doc))
        for tag in ['html', 'body']:
            check(path + ' exactly one ' + tag, 1, len(doc.all(tag)))
        smoke.links_and_resources(path, doc)
        identity = smoke.design_identity(path)
        anchors = smoke.design_contract['semanticAnchors'][identity['pageKey']] if identity else smoke.design_contract['collectionRoute']['anchors']
        for anchor in anchors:
            check(path + ' unique semantic #' + anchor, 1, sum(element.attrs.get('id') == anchor for element in doc.all()))
        footer_paths = {urlsplit(urljoin(smoke.route_url(path), anchor.attrs.get('href', ''))).path.rstrip('/') or '/'
                        for footer in doc.all('footer') for anchor in footer.all('a')
                        if (urlsplit(urljoin(smoke.route_url(path), anchor.attrs.get('href', ''))).scheme,
                            urlsplit(urljoin(smoke.route_url(path), anchor.attrs.get('href', ''))).netloc) == smoke.origin}
        check(path + ' Footer internal directory exactly covers 49 routes', sorted(paths), sorted(footer_paths))
        if identity and 'canonicalPath' in identity:
            for landmark, logo in smoke.design_contract.get('heritageLogos', {}).items():
                images = [image for element in doc.all(landmark) for image in element.all('img') if image.attrs.get('src') == logo['src']]
                check(path + ' original ' + landmark + ' Logo', 1, len(images))
                check(path + ' original ' + landmark + ' Logo bytes', logo['sha256'], sha(files.get(logo['src'].lstrip('/'), b'')))
    markers = [smoke.data['privacyDraftMarker'], *helper.PRIVATE_DESIGN_SYSTEM_MARKERS,
               *(text for section in smoke.data['privacyPolicy']['sections'] for text in section['paragraphs'])]
    leaked = []
    for name, data in files.items():
        if PurePosixPath(name).suffix in {'.html', '.txt', '.js', '.css', '.json', '.svg', '.md'}:
            found = helper.serialized_private_markers(data.decode('utf-8'), markers)
            if found:
                leaked.append({'path': name, 'markers': found})
    check('All public text including JS/RSC contains no private draft/design-system payload', [], leaked)
    rules = [re.sub(r'^([^:]+):\s*', lambda match: match[1].lower() + ': ', line.split('#')[0].strip())
             for line in files.get('robots.txt', b'').decode().splitlines() if line.split('#')[0].strip()]
    check('Protected robots root rules have no sitemap', sorted(['user-agent: *', 'allow: /', 'disallow: /dev/',
          *('disallow: ' + page['path'] for page in smoke.data['seoPages'] if page['availability'] == 'draft')]), sorted(rules))
    if evidence:
        check('Downloaded ZIP matches GitHub artifact digest', evidence['digest'].removeprefix('sha256:'), evidence['zipSha256'])
        if evidence.get('headSha') and evidence.get('expectedHeadSha'):
            check('Artifact exact requested head', evidence['expectedHeadSha'], evidence['headSha'])
    for row in smoke.results:
        row['notes'] = (row.get('notes', '') + ' Offline archive lookup only; HTTP labels inherited from the frozen helper do not prove live HTTP or browser behavior.').strip()
    all_checks = checks + smoke.results
    failures = [row for row in all_checks if row['status'] == 'FAIL']
    counts = {ext: sum(name.endswith(ext) for name in runtime) for ext in ['.css', '.js', '.woff2']}
    return {'status': 'FAIL' if failures else 'PASS', 'scope': 'Modern-Heritage-Luxury49-route offline artifact only; no live HTTP/browser/axe/interaction or merge/deployment claim',
            'checkedAt': datetime.now(timezone.utc).isoformat(), 'expectedRoutes': paths,
            'publicHtmlCount': len(smoke.documents), 'fileCount': len(files), 'runtimeFileCount': len(runtime),
            'runtimeCounts': counts, 'localBuildId': frozen['inventory']['buildId'], 'actualBuildId': actual_inventory['buildId'],
            'allowedNormalization': 'Only actual Next BuildID in the three manifest paths and actual BuildID token in HTML/RSC; no runtime asset bytes normalized',
            'helperSha256': frozen['helperSha256'], 'checkerSha256': sha(Path(__file__).read_bytes()),
            'assertionCount': len(all_checks), 'passed': len(all_checks) - len(failures), 'failures': failures,
            'checks': all_checks, 'githubArtifact': evidence}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--prepare', action='store_true')
    parser.add_argument('--build-receipt', type=Path)
    parser.add_argument('--expected-head')
    parser.add_argument('--repo', type=Path, default=Path('/workspace/xk-website'))
    parser.add_argument('--directory', type=Path)
    parser.add_argument('--zip', type=Path)
    parser.add_argument('--github-metadata', type=Path)
    parser.add_argument('--report', type=Path)
    args = parser.parse_args()
    if args.prepare:
        if not args.build_receipt:
            parser.error('--prepare requires the actual final --build-receipt')
        prepare(args.repo, args.directory or args.repo / 'out', args.build_receipt)
        return 0
    if not args.report or bool(args.directory) == bool(args.zip):
        parser.error('Provide exactly one of --directory/--zip and a fresh --report')
    if args.report.exists():
        parser.error('Refusing to overwrite report')
    evidence = json.loads(args.github_metadata.read_text()) if args.github_metadata else None
    if args.zip:
        files, zip_sha, tar_sha = read_zip(args.zip)
        if evidence is None:
            parser.error('Actual ZIP inspection requires --github-metadata with digest/head/run/artifact evidence')
        if not args.expected_head or evidence.get('headSha') != args.expected_head:
            parser.error('Candidate artifact metadata must match --expected-head')
        evidence.update(expectedHeadSha=args.expected_head, zipSha256=zip_sha, tarSha256=tar_sha)
    else:
        files = read_directory(args.directory)
    report = inspect(files, evidence)
    args.report.write_text(json.dumps(report, ensure_ascii=False, indent=2, default=lambda value: value.decode() if isinstance(value, bytes) else str(value)) + '\n')
    print(json.dumps({key: report[key] for key in ['status', 'publicHtmlCount', 'fileCount', 'runtimeFileCount', 'runtimeCounts', 'assertionCount', 'passed', 'failures']}, ensure_ascii=False))
    return 0 if report['status'] == 'PASS' else 1


if __name__ == '__main__':
    raise SystemExit(main())
