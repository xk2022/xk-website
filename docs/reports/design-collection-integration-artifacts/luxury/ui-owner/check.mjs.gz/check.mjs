import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {createRequire} from 'node:module';
import {getPublishedDesignRoutes} from '/tmp/xk-merge-luxury/src/lib/design-collection/routes.ts';
const root='/tmp/xk-merge-luxury/';
const require=createRequire(root+'package.json');
const ts=require('typescript');
const files=[
 'src/components/sections/contact/contact-inquiry-form.tsx',
 'src/components/sections/quotation/quotation-estimator.tsx',
 'src/components/sections/quotation/quotation-summary.tsx',
 'src/components/layout/site-footer.tsx',
 'src/components/design-collection/heritage/heritage-frame.tsx',
 'src/components/design-collection/luxury/luxury-frame.tsx',
];
for(const path of files){const source=readFileSync(root+path,'utf8');assert(!/^(?:<<<<<<<|=======|>>>>>>>)/m.test(source),path);const out=ts.transpileModule(source,{fileName:path,reportDiagnostics:true,compilerOptions:{jsx:ts.JsxEmit.ReactJSX,target:ts.ScriptTarget.ES2017,module:ts.ModuleKind.ESNext}});assert.deepEqual(out.diagnostics.filter(d=>d.category===ts.DiagnosticCategory.Error),[],path);}
const routes=getPublishedDesignRoutes();assert.equal(routes.length,49);assert.equal(new Set(routes.map(r=>r.presentationPath)).size,49);
for(const style of ['modern','heritage','luxury'])assert.equal(routes.filter(r=>r.styleId===style).length,16);
assert.equal(routes.filter(r=>r.pageKey==='collection').length,1);
for(const path of files.slice(3)){const source=readFileSync(root+path,'utf8');for(const style of ['modern','heritage','luxury'])assert(source.includes(`=== "${style}"`),`${path}:${style}`);assert(source.includes('=== "collection"'),path);assert(source.includes('getPublishedDesignRoutes()'),path);}
for(const path of files.slice(0,2)){
 const source=readFileSync(root+path,'utf8'),old=readFileSync('/workspace/xk-website/'+path,'utf8');
 const controls=s=>[...s.matchAll(/\b(?:id|htmlFor|name|maxLength|type)=(?:"[^"\n]*"|\{[^}\n]*\})/g)].map(m=>m[0]);
 assert.deepEqual(controls(source),controls(old),`stable control contract ${path}`);
 assert(source.includes('field.defaultValue = ""'));
 assert(source.includes('event.persisted'));
 assert(source.includes('styleId === "heritage"')&&source.includes('styleId === "luxury"'));
}
assert.equal(readFileSync(root+files[2],'utf8'),readFileSync('/workspace/xk-website/'+files[2],'utf8'),'A4 Summary unchanged from tested Luxury implementation');
console.log(JSON.stringify({ownedFiles:6,syntax:'PASS',published:49,styleCounts:{modern:16,heritage:16,luxury:16,collection:1},stableControls:'PASS',A4Summary:'UNCHANGED',scope:'static merge-contract review only, not runtime/PII/PDF acceptance'}));
console.log('MERGE_LUXURY_OWNED_FILES_COMPLETE PASS');
