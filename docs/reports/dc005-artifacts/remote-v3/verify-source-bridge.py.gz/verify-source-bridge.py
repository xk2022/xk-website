from pathlib import Path
import hashlib,json
root=Path('/tmp/xk-dc005-full-remote/v3');oldpath=root.parent/'tested-source.json';newpath=Path('/tmp/xk-dc005-full/source.json')
old=json.loads(oldpath.read_text());new=json.loads(newpath.read_text());a={x['path']:x['sha256'] for x in old['files']};b={x['path']:x['sha256'] for x in new['files']}
expectedOld='41c6ff4de2ebc88b1940aba4b53d6758931499dcafc66a566355352aa6b21ea5';expectedNew='c45eda25642ef1a236c5cbcaa2acbca6a6c01d6b92870fd63e50e3aeda7db1e2'
allowed=['src/components/design-collection/luxury/luxury-pages.tsx','src/design-systems/luxury/luxury.css'];changes=sorted(n for n in a.keys()&b.keys() if a[n]!=b[n]);missing=sorted(a.keys()-b.keys());extra=sorted(b.keys()-a.keys());mismatch=[]
for directory in [Path('/workspace/xk-website'),Path('/tmp/xk-dc005-build')]:
 for name,digest in b.items():
  p=directory/name
  if not p.is_file() or hashlib.sha256(p.read_bytes()).hexdigest()!=digest:mismatch.append(str(p))
repo=Path('/workspace/xk-website');label='<ul className="lx-index">{home.hero.serviceLabels.map((label) => <li key={label}>{label}</li>)}</ul>'
backplate='@media screen {\n  .lx-theme [data-luxury-interaction="quotation"] #quotation-introduction img { background: #FFFFFF; padding: 0.75rem; }'
currentAssertions={'Home retains DTO-derived labels in the approved ul.lx-index':(repo/allowed[0]).read_text().count(label)==1,'Quotation Logo white backplate is inside screen-only media':(repo/allowed[1]).read_text().count(backplate)==1}
passed=old['sha256']==expectedOld and new['sha256']==expectedNew and changes==allowed and not missing and not extra and not mismatch and all(currentAssertions.values())
record={'status':'PASS' if passed else 'FAIL','stage':'Independent v2→v3 source hash bridge and current-syntax inspection; not browser acceptance','beforeFingerprint':old['sha256'],'afterFingerprint':new['sha256'],'sourceFileCount':len(b),'unchangedFiles':len(a)-len(changes),'changes':[{'path':n,'before':a[n],'after':b[n]} for n in changes],'missing':missing,'extra':extra,'currentCopiesMismatch':mismatch,'currentSyntaxAssertions':currentAssertions,'limitation':'Old file bodies are not reconstructed. This proves the exact changed path/hash boundary; it does not relabel older full browser tests or assert output geometry equivalence.'}
with (root/'source-bridge.json').open('x') as out:json.dump(record,out,indent=2);out.write('\n')
for name,data in [('v2-source.json',old),('tested-source.json',new)]:
 with (root/name).open('x') as out:json.dump(data,out,indent=2);out.write('\n')
print(json.dumps(record))
raise SystemExit(0 if passed else 1)
