#!/usr/bin/env python3
"""Package an explicit DC005 selection. Default: preflight only; --apply writes repo files."""

import argparse
from datetime import datetime, timezone
import gzip
import hashlib
import json
from pathlib import Path
import sys


CODE_SUFFIXES = {".py", ".cjs", ".mjs", ".js", ".sh"}
TEXT_SUFFIXES = CODE_SUFFIXES | {".log", ".txt", ".patch"}
FORBIDDEN_PARTS = {"__pycache__", "node_modules", ".cache", "cache", ".git"}
JSON_COMPRESSION_THRESHOLD = 32 * 1024


def digest(data):
    return hashlib.sha256(data).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source-root", default="/tmp/xk-dc005-full")
    parser.add_argument("--repo", default="/workspace/xk-website")
    parser.add_argument("--selection", default="/tmp/xk-dc005-full/package-selection.json")
    parser.add_argument("--artifacts", default="docs/reports/dc005-artifacts")
    parser.add_argument("--media", default="docs/screenshots/design-collection/dc005")
    parser.add_argument("--report", help="Preflight JSON; defaults to source-root/package-preflight.json")
    parser.add_argument("--apply", action="store_true", help="Write the complete preflighted selection; never overwrite different bytes")
    args = parser.parse_args()
    source_root, repo = Path(args.source_root).resolve(), Path(args.repo).resolve()
    selection_path = Path(args.selection).resolve()
    if not selection_path.is_relative_to(source_root):
        parser.error("selection must be inside source-root")
    report_path = Path(args.report).resolve() if args.report else source_root / "package-preflight.json"
    if not report_path.is_relative_to(source_root):
        parser.error("preflight report must stay inside source-root")
    artifact_dir, media_dir = (repo / args.artifacts).resolve(), (repo / args.media).resolve()
    if not artifact_dir.is_relative_to(repo) or not media_dir.is_relative_to(repo):
        parser.error("artifact and media destinations must stay inside repo")
    selection_raw = selection_path.read_bytes()
    selection = json.loads(selection_raw)
    errors, missing, unfinished, files, media, payloads = [], [], [], [], [], {}
    evidence_paths = list(selection["evidence"])
    browser_paths = list(selection["browserResults"])
    review_paths = list(selection["pdfReviews"])
    required_receipts = list(selection["requiredReceipts"])
    loaded, raw_files = {}, {}
    overrides, used_overrides, prior_bug_pngs = {}, set(), {}
    for item in selection.get("screenshotOverrides", []):
        key = (item["route"].rstrip("/") or "/", item["width"])
        if key in overrides:
            errors.append(f"Duplicate screenshot override: {key}")
        overrides[key] = item
    if "screenshotOverrides" in selection and not overrides:
        errors.append("Fill screenshotOverrides with the completed route/width replacement records")

    def source_file(reference):
        candidate = Path(reference)
        candidate = source_root / candidate if not candidate.is_absolute() else candidate
        if candidate.is_symlink():
            raise ValueError(f"Symlink source is not permitted: {reference}")
        path = candidate.resolve()
        if not path.is_relative_to(source_root) or any(part in FORBIDDEN_PARTS for part in path.parts):
            raise ValueError(f"Disallowed source path: {reference}")
        return path

    def read(reference):
        path = source_file(reference)
        relative = path.relative_to(source_root).as_posix()
        if relative in raw_files:
            return relative, raw_files[relative]
        if not path.is_file():
            missing.append(relative)
            return relative, None
        before = path.stat()
        raw = path.read_bytes()
        after = path.stat()
        if (before.st_size, before.st_mtime_ns) != (after.st_size, after.st_mtime_ns):
            raise ValueError(f"Source changed during preflight: {relative}")
        raw_files[relative] = raw
        return relative, raw

    def document(reference):
        relative, raw = read(reference)
        if raw is None:
            return None
        if relative not in loaded:
            loaded[relative] = json.loads(raw)
        return loaded[relative]

    def add_media(reference, destination, kind, expected_sha=None):
        relative, raw = read(reference)
        if raw is None:
            return
        if expected_sha and digest(raw) != expected_sha:
            errors.append(f"Recorded media SHA mismatch: {relative}")
        if kind == "pdf" and not raw.startswith(b"%PDF-"):
            errors.append(f"Not an original PDF: {relative}")
        if kind != "pdf" and not raw.startswith(b"\x89PNG\r\n\x1a\n"):
            errors.append(f"Not a PNG: {relative}")
        target = (media_dir / destination).resolve()
        if not target.is_relative_to(media_dir):
            raise ValueError("Media destination escapes its directory")
        if target in payloads and payloads[target] != raw:
            errors.append(f"Conflicting media basename: {destination}")
        if any(row["path"] == target.relative_to(repo).as_posix() for row in media):
            errors.append(f"Duplicate media destination: {destination}")
        payloads[target] = raw
        row = {"source": relative, "path": target.relative_to(repo).as_posix(), "kind": kind,
               "bytes": len(raw), "sha256": digest(raw)}
        media.append(row)
        return row

    pdfs = {}
    for reference in browser_paths:
        suite = document(reference)
        evidence_paths.append(reference)
        if suite is None:
            continue
        if not suite.get("finishedAt") or "counters" not in suite:
            unfinished.append(reference)
        mode = suite.get("mode")
        if mode not in {"normal", "pages"}:
            errors.append(f"Unexpected browser mode: {reference}")
            continue
        for shot in suite.get("screenshots", []):
            if mode != "pages":
                errors.append("Representative screenshots must come from the selected Pages suite")
            key = (shot["route"].rstrip("/") or "/", shot["width"])
            override = overrides.get(key)
            if override:
                used_overrides.add(key)
                prior_relative, prior_raw = read(shot["path"])
                if prior_raw is not None and digest(prior_raw) != shot.get("sha256"):
                    errors.append(f"Prior screenshot SHA mismatch: {prior_relative}")
                if key in {("/design-collection/luxury", 375), ("/design-collection/luxury/quotation", 375)}:
                    page_label = "quotation" if key[0].endswith("/quotation") else "home"
                    prior_bug_pngs[prior_relative] = f"prior-{page_label}-375-bug-evidence-not-delivery"
                override_result = document(override["evidence"])
                evidence_paths.append(override["evidence"])
                if override_result is not None and not override_result.get("finishedAt"):
                    unfinished.append(override["evidence"])
                if not override.get("sha256"):
                    errors.append(f"Screenshot override requires an exact SHA: {key}")
                row = add_media(override["path"], Path(shot["path"]).name, "screenshot", override.get("sha256"))
                if row:
                    row["screenshotOverride"] = {
                        "route": shot["route"], "width": shot["width"],
                        "priorSource": prior_relative, "priorSha256": shot.get("sha256"),
                        "priorBrowserResult": source_file(reference).relative_to(source_root).as_posix(),
                        "evidence": source_file(override["evidence"]).relative_to(source_root).as_posix(),
                        "evidenceSha256": digest(raw_files[source_file(override["evidence"]).relative_to(source_root).as_posix()]) if override_result is not None else None,
                    }
            else:
                add_media(shot["path"], Path(shot["path"]).name, "screenshot", shot.get("sha256"))
        for item in suite.get("business", []):
            if item.get("type") == "pdf":
                path = source_file(item["path"])
                if path in pdfs:
                    errors.append(f"Duplicate original PDF: {path.name}")
                pdfs[path] = {"mode": mode, "sha256": item.get("sha256")}
                add_media(item["path"], mode + "-" + path.name, "pdf", item.get("sha256"))
    for key in set(overrides) - used_overrides:
        errors.append(f"Screenshot override did not match a selected Pages screenshot: {key}")

    reviewed_pdfs = set()
    for reference in review_paths:
        review = document(reference)
        evidence_paths.append(reference)
        if review is None:
            continue
        if not review.get("finishedAt"):
            unfinished.append(reference)
        pdf_path = source_file(review["sourcePdf"])
        if pdf_path not in pdfs or pdfs.get(pdf_path, {}).get("sha256") != review.get("sourceSha256"):
            errors.append(f"Verifier PDF is not one of the selected originals: {reference}")
            continue
        if pdf_path in reviewed_pdfs:
            errors.append(f"Duplicate PDF review: {reference}")
        reviewed_pdfs.add(pdf_path)
        preview = [item for item in review.get("renders", []) if item.get("dpi") == 150 and item.get("page") == 1]
        if len(preview) != 1 or len(review.get("pages", [])) != 1:
            errors.append(f"Expected one page and one 150dpi preview: {reference}")
        else:
            item = preview[0]
            add_media(item["path"], pdfs[pdf_path]["mode"] + "-" + pdf_path.stem + "-150dpi.png", "pdf-render", item.get("sha256"))
        # Only the verifier's precise underlying text/span/canvas evidence; no directory scan.
        for page in review.get("pages", []):
            evidence_paths.extend(page[key] for key in ("text", "spans") if page.get(key))
        for test in review.get("tests", []):
            if test.get("canvasClassification"):
                evidence_paths.append(test["canvasClassification"])

    evidence_paths.extend(required_receipts)
    evidence_paths.extend([selection_path.as_posix(), Path(__file__).resolve().as_posix()])
    for reference in dict.fromkeys(evidence_paths):
        relative, raw = read(reference)
        if raw is None:
            continue
        suffix = Path(relative).suffix.lower()
        if suffix == ".png" and relative not in prior_bug_pngs:
            errors.append(f"Only the exact overridden prior Home375/Quotation375 PNGs may be additional bug evidence: {relative}")
            continue
        if suffix == ".png" and not raw.startswith(b"\x89PNG\r\n\x1a\n"):
            errors.append(f"Bug evidence is not a PNG: {relative}")
        if suffix not in TEXT_SUFFIXES | {".json", ".png"}:
            errors.append(f"Unsupported evidence type; media must come from selected results: {relative}")
            continue
        record = None
        if suffix == ".json":
            record = document(reference)
            if isinstance(record, dict) and "command" in record and "observationMethod" in record:
                if record.get("finishedAt") is None or record.get("exitCode") is None:
                    unfinished.append(relative)
                if record.get("logFile") and record.get("logSha256"):
                    _, log_raw = read(record["logFile"])
                    if log_raw is not None and digest(log_raw) != record["logSha256"]:
                        errors.append(f"Receipt log SHA mismatch: {relative}")
        compressed = suffix in TEXT_SUFFIXES or (suffix == ".json" and len(raw) >= JSON_COMPRESSION_THRESHOLD)
        archive_relative = (Path("tools") / relative if suffix in CODE_SUFFIXES else Path(relative)).as_posix() + (".gz" if compressed else "")
        data = gzip.compress(raw, compresslevel=9, mtime=0) if compressed else raw
        if compressed and gzip.decompress(data) != raw:
            raise ValueError("Compression failed to preserve bytes")
        target = artifact_dir / archive_relative
        payloads[target] = data
        row = {"source": relative, "path": target.relative_to(repo).as_posix(), "compression": "gzip" if compressed else "identity",
               "rawBytes": len(raw), "rawSha256": digest(raw), "archiveBytes": len(data), "archiveSha256": digest(data)}
        if isinstance(record, dict):
            row["originalOutcome"] = {key: record[key] for key in ("status", "result", "automatedResult", "exitCode", "returnCode", "finishedAt") if key in record}
        if relative in prior_bug_pngs:
            row["role"] = prior_bug_pngs[relative]
        files.append(row)

    counts = {kind: sum(row["kind"] == kind for row in media) for kind in ("screenshot", "pdf", "pdf-render")}
    for kind, expected in {"screenshot": 17, "pdf": 4, "pdf-render": 4}.items():
        if counts[kind] != expected:
            errors.append(f"Expected {expected} {kind} files; selected {counts[kind]}")
    if len(reviewed_pdfs) != 4:
        errors.append("All four selected original PDFs require their exact completed verifier results")
    missing, unfinished = sorted(set(missing)), sorted(set(unfinished))
    conflicts = [str(path.relative_to(repo)) for path, data in payloads.items() if path.exists() and path.read_bytes() != data]
    manifest_path = artifact_dir / "manifest.json"
    if manifest_path.exists():
        conflicts.append(manifest_path.relative_to(repo).as_posix())
    ready = not (errors or missing or unfinished or conflicts)
    report = {"mode": "apply" if args.apply else "preflight-only", "ready": ready,
              "selection": str(selection_path), "selectionSha256": digest(selection_raw),
              "evidenceFiles": len(files), "mediaCounts": counts, "missing": missing,
              "screenshotOverridesUsed": len(used_overrides),
              "unfinished": unfinished, "errors": errors, "existingConflicts": conflicts,
              "repositoryWrites": False, "outcomePolicy": "Archive completed FAIL and nonzero exits unchanged. Pending/missing receipts are never PASS. No original evidence is deleted or overwritten."}
    report_path.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n")
    if args.apply:
        if not ready:
            print(json.dumps(report, ensure_ascii=False, indent=2))
            return 1
        manifest = {"schemaVersion": 1, "task": "DC-005 full Luxury implementation", "createdAtUtc": datetime.now(timezone.utc).isoformat(),
                    "selectionSha256": digest(selection_raw), "files": files, "media": media, "mediaCounts": counts,
                    "policy": report["outcomePolicy"], "compression": "All tools/logs/text/patches gzip with mtime=0; JSON >=32KiB gzip; rawSha256 verifies decompressed bytes.",
                    "limits": "Allowlisted file preservation only. Packaging does not turn a test, manual review, CI or deployment into PASS. Explicit screenshot replacements retain prior source/SHA and override evidence; only prior Home375/Quotation375 may be separate bug PNG evidence. 300dpi QR diagnostic images and caches are excluded."}
        for path, data in payloads.items():
            path.parent.mkdir(parents=True, exist_ok=True)
            if not path.exists():
                path.write_bytes(data)
        artifact_dir.mkdir(parents=True, exist_ok=True)
        manifest_path.write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n")
        report["repositoryWrites"] = True
        report["manifest"] = manifest_path.relative_to(repo).as_posix()
        report_path.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n")
    print(json.dumps(report, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    try:
        sys.exit(main())
    except (OSError, ValueError, KeyError, TypeError) as error:
        print(f"Evidence packaging stopped: {error}", file=sys.stderr)
        sys.exit(1)
