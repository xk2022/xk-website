from pathlib import Path
p=Path('/tmp/xk-dc005-full/verify-theme-runtime.cjs');s=p.read_text().replace("if(/Actual autofill synthetic value|Actual autofill text contrast|deep-equal/.test(String(e)))throw e;","if(e.code==='ERR_ASSERTION')throw e;")
p.write_text(s)
p=Path('/tmp/xk-dc005-full/browser.cjs');s=p.read_text()
needle="const out={testId:"
i=s.index(needle)
s=s[:i]+"const sourceData=JSON.parse(fs.readFileSync(sourceArg||path.join(root,'source.json')));assert(contract.rootFingerprint,'Root contract fingerprint is required');assert.equal(sourceData.sha256||sourceData.fingerprint,contract.rootFingerprint,'Root source/contract fingerprint');\n"+s[i:]
needle='async function assertPersonalEmpty(type)'
i=s.index(needle)
helper="""async function usableInquiryAfterReturn(type){if(type==='contact'){await page.locator('#contact-inquiry-name').fill('DC005_QA_NAME');await page.locator('#contact-inquiry-email').fill('dc005.qa@example.invalid');await page.locator('#contact-inquiry-message').fill('DC005_MESSAGE_CANARY 返回後草稿仍可使用，只測試不寄送。');await page.getByRole('button',{name:'預覽詢問內容',exact:true}).click();await page.locator('#contact-inquiry-preview').waitFor();const a=page.locator('[data-contact-draft-link=true]');assert.equal(await a.count(),1);const href=await a.getAttribute('href');assert.equal(new URL(href).pathname,'system.xk2022@gmail.com');assert.deepEqual([...new URL(href).searchParams.keys()],['subject','body']);await a.click();assert((await page.evaluate(()=>window.__dc005Mail||[])).some(e=>e.href===href&&e.prevented));await page.getByRole('button',{name:'清除內容',exact:true}).click();await assertPersonalEmpty('contact');return{rebuiltDraft:true,mailDefaultPrevented:true};}const a=page.getByRole('link',{name:'取得正式報價',exact:true});assert.equal(await a.count(),1);const href=await a.getAttribute('href');assert(href&&!containsPII(href),'Restored non-personal formal quote href');if(href.startsWith('mailto:')){assert.equal(new URL(href).pathname,'system.xk2022@gmail.com');await a.click();assert((await page.evaluate(()=>window.__dc005Mail||[])).some(e=>e.href===href&&e.prevented));}else{const u=new URL(href,base);assert.equal(u.origin,base.origin);assert.equal(routeKey(u.href),'/contact');assert.equal(u.hash,'#contact-channels');assert.equal(u.search,'');}return{restoredInquiryAvailable:true,href};}\n"""
s=s[:i]+helper+s[i:]
old="await palette('modern');return{forward,reverse,historyIDs:true,personalFieldsEmpty:true,price:'NT$26,000–58,000'};"
new="await palette('modern');const restoredInquiry=await usableInquiryAfterReturn('quotation');return{forward,reverse,historyIDs:true,personalFieldsEmpty:true,restoredInquiry,price:'NT$26,000–58,000'};"
assert old in s;s=s.replace(old,new)
# Contact ends after Modern keyboard reentry; keep original row count.
start=s.index("await test('CROSS-STYLE-CONTACT-BACK-FORWARD-NO-PII'")
end=s.index("await test('CROSS-STYLE-QUOTATION",start)
block=s[start:end]
old="return{forward,reverse,history:true,personalFieldsEmpty:true,modernMenuRestored:true};"
if old not in block:
 print('CONTACT_RETURN_REQUIRES_INSPECTION',block[-700:])
else:
 block=block.replace(old,"const restoredInquiry=await usableInquiryAfterReturn('contact');return{forward,reverse,history:true,personalFieldsEmpty:true,modernMenuRestored:true,restoredInquiry};")
 s=s[:start]+block+s[end:]
p.write_text(s)
