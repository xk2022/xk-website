import assert from 'node:assert/strict';
import {readFileSync,writeFileSync} from 'node:fs';
import {createRequire} from 'node:module';
import {luxuryTokens,luxuryThemeStyle} from '/workspace/xk-website/src/design-systems/luxury/index.ts';
import {requiredDesignTokenSchema,validateDesignSemanticTokens} from '/workspace/xk-website/src/lib/design-collection/tokens.ts';
const require=createRequire('/workspace/xk-website/package.json');
const postcss=require('postcss');
assert.deepEqual(validateDesignSemanticTokens(luxuryTokens),{valid:true,errors:[]});
const roles=Object.values(requiredDesignTokenSchema).reduce((sum,group)=>sum+Object.keys(group).length,0);
assert.equal(roles,72);assert.equal(Object.keys(luxuryThemeStyle).length,73);
assert.equal(luxuryThemeStyle['--lx-color-background'],'#0C1017');
assert.equal(luxuryThemeStyle['--lx-color-error-text'],'#FDA4AF');
assert.equal(luxuryThemeStyle['--lx-motion-reduced-duration'],'0ms');
assert.equal(luxuryThemeStyle['--lx-decoration-gold'],'#C8A96B');
assert(luxuryTokens.typography.bodyFont.includes('var(--font-inter), var(--font-noto-sans-tc)'));
assert(!luxuryTokens.typography.bodyFont.includes('var(--font-sans)'));
const css=readFileSync('/workspace/xk-website/src/design-systems/luxury/luxury.css','utf8');
const tree=postcss.parse(css);let selectors=0;
tree.walkRules(rule=>{for(const selector of postcss.list.comma(rule.selector)){assert(selector.startsWith('.lx-theme'),selector);assert(!/^\.lx-theme\s+(?:h[1-6]|p|ul|ol|a|input)\b/.test(selector),selector);if(selector.includes('.quotation-paper'))assert(selector.includes(':not(:where(.quotation-paper, .quotation-paper *))'));selectors++;}});
tree.walkAtRules(rule=>assert.notEqual(rule.name,'page'));
const defined=new Set([...Object.keys(luxuryThemeStyle),...[...css.matchAll(/(--lx-[\w-]+)\s*:/g)].map(match=>match[1])]);
for(const match of css.matchAll(/var\((--lx-[\w-]+)/g))assert(defined.has(match[1]),match[1]);
assert.equal([...css.matchAll(/var\(--lx-decoration-gold\)/g)].length,1,'gold is decoration only');
assert(css.includes(':has([data-quotation-page="true"])'));
const frame=readFileSync('/workspace/xk-website/src/components/design-collection/luxury/luxury-frame.tsx','utf8');
assert(frame.includes('style={luxuryThemeStyle}'));assert(frame.includes('<InquiryButton'));
assert(css.indexOf('[data-slot="button"]:disabled',css.indexOf('[data-luxury-interaction="quotation"]'))>css.indexOf('[data-variant="outline"]',css.indexOf('[data-luxury-interaction="quotation"]')));
const luminance=hex=>{const c=hex.slice(1).match(/../g).map(x=>parseInt(x,16)/255).map(x=>x<=.04045?x/12.92:((x+.055)/1.055)**2.4);return c[0]*.2126+c[1]*.7152+c[2]*.0722;};
const pairs=[
 ['foreground/background','#F5F1E8','#0C1017',4.5],['foreground/surface','#F5F1E8','#151B24',4.5],
 ['muted/background','#B8B1A5','#0C1017',4.5],['muted/surface','#B8B1A5','#151B24',4.5],
 ['button/cyan','#0C1017','#06B6D4',4.5],['hover-button/ivory','#0C1017','#F5F1E8',4.5],
 ['cyan/background','#06B6D4','#0C1017',4.5],['cyan/surface','#06B6D4','#151B24',4.5],
 ['error/background','#FDA4AF','#0C1017',4.5],['error/surface','#FDA4AF','#151B24',4.5],
 ['success/background','#86EFAC','#0C1017',4.5],['success/surface','#86EFAC','#151B24',4.5],
 ['disabled/surface','#B8B1A5','#151B24',4.5],['input/background','#8B95A5','#0C1017',3],
 ['input/surface','#8B95A5','#151B24',3],['focus/background','#06B6D4','#0C1017',3],
 ['focus/surface','#06B6D4','#151B24',3],['header-button/blue','#FFFFFF','#2563EB',4.5],
 ['header-focus/white','#2563EB','#FFFFFF',3],['footer/official','#FFFFFF','#101828',4.5],
].map(([name,foreground,background,minimum])=>{const a=luminance(foreground),b=luminance(background),ratio=(Math.max(a,b)+.05)/(Math.min(a,b)+.05);assert(ratio>=minimum,`${name} ${ratio}`);return{name,foreground,background,minimum,ratio};});
writeFileSync('/tmp/xk-dc005-full/ds/contrast-v3.json',JSON.stringify({scope:'literal palette candidates, not rendered full-site acceptance',pairs},null,2)+'\n');
console.log(JSON.stringify({requiredRoles:roles,emittedVariables:Object.keys(luxuryThemeStyle).length,scopedSelectors:selectors,literalContrastPairs:pairs.length,status:'PASS'}));
console.log('LUXURY_DS_TARGETED_COMPLETE PASS');
