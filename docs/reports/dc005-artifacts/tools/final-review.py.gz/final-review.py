#!/usr/bin/env python3
"""Read-only DC-005 final review; preflight never queries Git or runs site tools."""
import argparse
from datetime import datetime, timezone
import gzip
import hashlib
import html
import json
from pathlib import Path
import re
import subprocess
import sys
from urllib.parse import unquote, urlsplit

BASE = "74369376a0dbeeb0a17b5ee34557059c8e2a9491"
PREFIXES = ("src/", "public/", "scripts/", ".github/")
GENERATED = {".git", ".next", "out", "node_modules", "__pycache__", ".cache", ".pytest_cache"}
TEXT = {".md", ".html", ".ts", ".tsx", ".js", ".jsx", ".mjs", ".cjs", ".css", ".json", ".py", ".yml", ".yaml", ".txt", ".svg", ".xml"}
BINARY = {".png", ".jpg", ".jpeg", ".webp", ".gif", ".ico", ".pdf", ".woff", ".woff2", ".ttf"}
SECRET = re.compile(rb"-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----|github_pat_[A-Za-z0-9_]{20,}|gh[pousr]_[A-Za-z0-9_]{20,}|[?&](?:X-Amz-Signature|sig|access_token)=", re.I)

def sha(data):
    return hashlib.sha256(data).hexdigest()

def group(name):
    return "documentOnly" if "/" not in name and name.lower().endswith(".md") else "runtime"

def generated(name):
    return bool(set(Path(name).parts) & GENERATED) or name.endswith((".pyc", ".tsbuildinfo"))

def git(repo, *args):
    result = subprocess.run(["git", "--no-optional-locks", *args], cwd=repo, capture_output=True)
    if result.returncode:
        raise RuntimeError("Read-only Git inspection failed; exit " + str(result.returncode))
    return result.stdout

def names(repo, *args):
    return set(filter(None, git(repo, *args).decode().split("\0")))

def visible(text):
    lines, fence = [], None
    for number, line in enumerate(text.splitlines(), 1):
        match = re.match(r"^ {0,3}(`{3,}|~{3,})(.*)$", line)
        if fence:
            if match and match[1][0] == fence[0] and len(match[1]) >= fence[1] and not match[2].strip():
                fence = None
            continue
        if match:
            fence = (match[1][0], len(match[1]))
        else:
            lines.append((number, line))
    return lines, fence is not None

def destinations(body):
    result = []
    for match in re.finditer(r"!?\[(?:\\.|[^\]\\])*\]\(", body):
        index, value, depth = match.end(), [], 0
        while index < len(body) and body[index].isspace():
            index += 1
        if index < len(body) and body[index] == "<":
            end = body.find(">", index + 1)
            if end >= 0:
                result.append(body[index+1:end])
            continue
        while index < len(body):
            char = body[index]
            if char == "\\" and index+1 < len(body):
                value.append(body[index+1]); index += 2; continue
            if char == "(":
                depth += 1
            elif char == ")":
                if not depth:
                    break
                depth -= 1
            elif char.isspace() and not depth:
                break
            value.append(char); index += 1
        if value:
            result.append("".join(value))
    result += [match[1] or match[2] for match in re.finditer(r"^ {0,3}\[[^\]]+\]:\s*(?:<([^>]+)>|(\S+))", body, re.M)]
    result += re.findall(r"<(?:a|img)\b[^>]*\b(?:href|src)\s*=\s*['\"]([^'\"]+)['\"]", body)
    return result

def anchors(text, markdown=True):
    result = set(re.findall(r"\b(?:id|name)\s*=\s*['\"]([^'\"]+)['\"]", text))
    if markdown:
        rows, _ = visible(text)
        used = set()
        for _, line in rows:
            match = re.match(r"^ {0,3}#{1,6}[ \t]+(.+?)(?:[ \t]+#+[ \t]*)?$", line)
            if not match:
                continue
            title = re.sub(r"!?\[([^\]]+)\]\([^)]*\)", r"\1", match[1])
            title = html.unescape(re.sub(r"<[^>]*>", "", title)).strip().lower()
            stem = re.sub(r"[^\w\- ]", "", title).replace(" ", "-")
            candidate, suffix = stem, 0
            while candidate in used:
                suffix += 1; candidate = stem + "-" + str(suffix)
            used.add(candidate)
        result |= used
    return result

def table_cells(line):
    line = re.sub(r"(`+).*?\1", "CODE", line.strip())
    line = line.replace(r"\|", "ESCAPED_PIPE")
    if line.startswith("|"):
        line = line[1:]
    if line.endswith("|"):
        line = line[:-1]
    return [cell.strip() for cell in line.split("|")]

def markdown_errors(text):
    rows, unclosed = visible(text)
    errors = [{"error": "unclosed fence"}] if unclosed else []
    for number, line in rows:
        if re.match(r"^ {0,3}#{1,6}[^#\s]", line):
            errors.append({"line": number, "error": "heading needs a space after #"})
    for index, (number, line) in enumerate(rows):
        cells = table_cells(line)
        if "|" not in line or not cells or not all(re.fullmatch(r":?-{3,}:?", cell) for cell in cells):
            continue
        if not index or len(table_cells(rows[index-1][1])) != len(cells):
            errors.append({"line": number, "error": "table header/separator cell count differs"})
        cursor = index + 1
        while cursor < len(rows) and "|" in rows[cursor][1] and rows[cursor][1].strip():
            if len(table_cells(rows[cursor][1])) != len(cells):
                errors.append({"line": rows[cursor][0], "error": "table body cell count differs"})
            cursor += 1
    return errors

def runtime_inventory(directory, roots):
    found = set()
    for prefix in PREFIXES:
        for path in (directory/prefix).rglob("*"):
            if path.is_file() and not generated(str(path.relative_to(directory))):
                found.add(str(path.relative_to(directory)))
    for name in roots:
        if (directory/name).is_file():
            found.add(name)
    # Detect extra root engineering configuration without treating generated files
    # or mutable README/AGENTS documents as runtime changes.
    for path in directory.iterdir():
        if path.is_file() and not generated(path.name) and path.name != "next-env.d.ts" and path.suffix.lower() in {".json", ".mjs", ".cjs", ".js", ".ts"}:
            found.add(path.name)
    return found

def bridge(repo, build, source_path, contract_path):
    source = json.loads(source_path.read_text())
    records = source["files"]
    expected = {record["path"]: record["sha256"] for record in records}
    if len(expected) != len(records):
        raise ValueError("Duplicate source inventory paths")
    fingerprint = sha(json.dumps(records, sort_keys=True).encode())
    runtime, docs, errors = [], [], []
    for record in records:
        name, digest = record["path"], record["sha256"]
        a, b = (repo/name).resolve(), (build/name).resolve()
        if not a.is_relative_to(repo) or not b.is_relative_to(build):
            raise ValueError("Source path escapes declared roots")
        root_hash = sha(a.read_bytes()) if a.is_file() else None
        build_hash = sha(b.read_bytes()) if b.is_file() else None
        row = {"path": name, "manifestSha256": digest, "rootSha256": root_hash, "buildSha256": build_hash}
        if group(name) == "documentOnly":
            docs.append({**row, "rootChangedSinceSnapshot": root_hash != digest, "buildChangedSinceSnapshot": build_hash != digest})
        else:
            runtime.append(row)
            if root_hash != digest or build_hash != digest or root_hash != build_hash:
                errors.append(row)
    expected_runtime = {row["path"] for row in runtime}
    roots = {name for name in expected_runtime if "/" not in name}
    inventories = {"root": runtime_inventory(repo, roots), "build": runtime_inventory(build, roots)}
    inventory_errors = {name: {"extra": sorted(values-expected_runtime), "missing": sorted(expected_runtime-values)} for name, values in inventories.items()}
    contract = json.loads(contract_path.read_text())
    ok = source.get("base") == BASE and fingerprint == source.get("sha256") == contract.get("rootFingerprint") and not errors and all(not value["extra"] and not value["missing"] for value in inventory_errors.values())
    return ok, {"source": str(source_path), "sourceFileSha256": sha(source_path.read_bytes()), "manifestFingerprint": fingerprint, "declaredFingerprint": source.get("sha256"), "contractFingerprint": contract.get("rootFingerprint"), "sourceRecords": len(records), "runtimeFiles": len(runtime), "runtimeMismatches": errors, "runtimeInventory": inventory_errors, "documentOnly": docs,
                "notes": "No byte normalization. README/AGENTS root documents are explicitly reported outside runtime equality; all src/public/scripts/.github and root engineering files are strict. Runtime edits require new source identity and corresponding acceptance evidence."}

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo", type=Path, default=Path("/workspace/xk-website"))
    parser.add_argument("--build", type=Path, default=Path("/tmp/xk-dc005-build"))
    parser.add_argument("--source", type=Path, default=Path("/tmp/xk-dc005-full/source.json"))
    parser.add_argument("--contract", type=Path, default=Path("/tmp/xk-dc005-full/contract.json"))
    parser.add_argument("--output", type=Path)
    parser.add_argument("--preflight", action="store_true", help="In-memory algorithm fixtures only; real links/source/Git checks stay PENDING")
    args = parser.parse_args()
    repo, build = args.repo.resolve(), args.build.resolve()
    output = (args.output or Path("/tmp/xk-dc005-full/final-review-preflight-result.json" if args.preflight else "/tmp/xk-dc005-full/final-review-result.json")).resolve()
    if output.exists() or output.is_relative_to(repo) or output.is_relative_to(build):
        parser.error("Use a fresh output outside repository/build; evidence is never overwritten")
    checks = []
    def add(test_id, ok, actual, status=None):
        checks.append({"testId": test_id, "status": status or ("PASS" if ok else "FAIL"), "actual": actual})
    if args.preflight:
        fixtures = [destinations('[a](src/app/(modern)/page.tsx) [b](<with space.md#章節>)') == ['src/app/(modern)/page.tsx', 'with space.md#章節'],
                    {'章節', '章節-1', 'explicit'} <= anchors('# 章節\n# 章節\n<a id="explicit"></a>\n'),
                    not markdown_errors('| A | B |\n| --- | --- |\n| `a|b` | x |\n'),
                    bool(markdown_errors('| A | B |\n| --- | --- |\n| one |\n')),
                    bool(markdown_errors('##Missing space\n')),
                    group('README.md') == group('AGENTS.md') == 'documentOnly' and group('public/brand/source/README.md') == group('src/components/contact.tsx') == 'runtime',
                    bool(SECRET.search(('ghp_'+'x'*24).encode())) and not SECRET.search(b'public owner Email'),
                    generated('scripts/__pycache__/a.pyc') and not generated('scripts/test-example.mjs')]
        add("PREFLIGHT-IN-MEMORY-FIXTURES", all(fixtures), {"cases": len(fixtures), "failedCaseIndexes": [index for index, passed in enumerate(fixtures) if not passed]})
        for item in ['CHANGED-MARKDOWN-LOCAL-LINKS', 'SOURCE-ROOT-ISOLATED-BUILD-BRIDGE', 'STAGED-DELIVERY-SECRET-CACHE-CHECK']:
            add(item, False, "PENDING until final report, source version and isolated build are ready; preflight performs no Git/repository checks", "PENDING")
    else:
        try:
            changed = names(repo, "diff", "--name-only", "-z", BASE, "--") | names(repo, "ls-files", "-z", "--others", "--exclude-standard")
            staged = names(repo, "diff", "--cached", "--name-only", "-z", "--")
            changed |= staged
            add("SOURCE-ROOT-ISOLATED-BUILD-BRIDGE", *bridge(repo, build, args.source.resolve(), args.contract.resolve()))
            format_errors, link_errors, documents, links = [], [], [], 0
            for name in sorted(changed):
                path = (repo/name).resolve()
                if not path.is_relative_to(repo) or not path.is_file() or path.suffix.lower() not in TEXT:
                    continue
                text = path.read_text()
                if text and (not text.endswith('\n') or text.endswith('\n\n')):
                    format_errors.append({"path": name, "error": "expected one final LF"})
                for number, line in enumerate(text.splitlines(), 1):
                    if line.rstrip() != line or re.match(r"^(?:<{7}(?: |$)|={7}$|>{7}(?: |$))", line):
                        format_errors.append({"path": name, "line": number, "error": "trailing whitespace or conflict marker"})
                if path.suffix.lower() != '.md':
                    continue
                documents.append(name)
                format_errors += [{"path": name, **error} for error in markdown_errors(text)]
                rows, _ = visible(text)
                for destination in destinations('\n'.join(line for _, line in rows)):
                    parts = urlsplit(html.unescape(destination))
                    if parts.scheme or parts.netloc:
                        continue
                    links += 1
                    target = (repo/unquote(parts.path).lstrip('/')).resolve() if parts.path.startswith('/') else (path.parent/unquote(parts.path)).resolve() if parts.path else path
                    if not target.is_relative_to(repo) or not target.exists():
                        link_errors.append({"path": name, "link": destination, "error": "missing/escaping local target"})
                    elif parts.fragment and target.is_file() and target.suffix.lower() in {'.md', '.html', '.svg'} and unquote(parts.fragment) not in anchors(target.read_text(), target.suffix.lower()=='.md'):
                        link_errors.append({"path": name, "link": destination, "error": "missing local anchor"})
            add("CHANGED-MARKDOWN-LOCAL-LINKS-ANCHORS", not link_errors, {"documents": documents, "localLinks": links, "errors": link_errors, "scope": "Only changed/untracked/staged Markdown, never a recursive historical-document audit"})
            add("CHANGED-TEXT-EOF-HEADINGS-TABLES-FORMAT", not format_errors, {"errors": format_errors})
            for label, command in [('ALL', ['diff', '--check', BASE, '--']), ('STAGED', ['diff', '--cached', '--check', '--'])]:
                result = subprocess.run(['git', '--no-optional-locks', *command], cwd=repo, capture_output=True)
                add('DIFF-WHITESPACE-'+label, result.returncode == 0, {"exitCode": result.returncode, "detailsSuppressed": bool(result.stdout or result.stderr)})
            banned, secret_files, unsafe_paths = [], [], []
            for name in sorted(changed):
                path = (repo/name).resolve()
                if generated(name) or any(part.startswith('.env') for part in Path(name).parts):
                    banned.append({"path": name, "staged": name in staged})
                if not path.is_relative_to(repo):
                    unsafe_paths.append(name)
                elif path.is_file() and path.suffix.lower() not in BINARY:
                    data = path.read_bytes()
                    if path.suffix == '.gz':
                        data = gzip.decompress(data)
                    if SECRET.search(data):
                        secret_files.append(name)
            add("DELIVERY-NO-SECRETS-BUILD-CACHE", not banned and not secret_files and not unsafe_paths, {"changedFiles": len(changed), "stagedFiles": len(staged), "forbiddenPaths": banned, "suspectedSecretFiles": secret_files, "escapingPaths": unsafe_paths, "notes": "Only filenames/counts are reported. Matched secret text and Git diff contents are never printed or saved."})
        except Exception as error:
            add("FINAL-REVIEW-COMPLETES", False, {"errorType": type(error).__name__, "message": "Read-only final check encountered an error; no source or build mutation performed"})
    failed = any(item['status'] == 'FAIL' for item in checks)
    status = 'FAIL' if failed else 'PREFLIGHT_PASS' if args.preflight else 'PASS'
    result = {"status": status, "exitCode": 1 if failed else 0, "testedAt": datetime.now(timezone.utc).isoformat(), "preflight": args.preflight, "base": BASE, "repo": str(repo), "isolatedBuild": str(build), "source": str(args.source), "contract": str(args.contract), "command": [sys.executable, *sys.argv], "checks": checks,
              "scope": "Read-only source/document/delivery review. No build/server/browser/install/Git mutation. Runtime byte differences are never normalized or waived as documentation changes."}
    output.parent.mkdir(parents=True, exist_ok=True)
    with output.open('x') as file:
        json.dump(result, file, ensure_ascii=False, indent=2); file.write('\n')
    print(json.dumps({"status": status, "exitCode": result['exitCode'], "result": str(output), "checks": [{"testId": item['testId'], "status": item['status']} for item in checks]}, ensure_ascii=False))
    return result['exitCode']

if __name__ == '__main__':
    sys.exit(main())
