from pathlib import Path
import subprocess, shutil, json, hashlib
root=Path('/workspace/xk-website'); dest=Path('/tmp/xk-dc005-build')
paths=set(subprocess.check_output(['git','ls-files','-z'],cwd=root).decode().split('\0'))|set(subprocess.check_output(['git','ls-files','--others','--exclude-standard','-z'],cwd=root).decode().split('\0'))
records=[]
for name in sorted(paths-{''}):
 p=root/name
 if not p.is_file(): continue
 if name.startswith(('src/','public/','scripts/')) or ('/' not in name and not name.endswith('.md')) or name.startswith('.github/'):
  q=dest/name;q.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,q)
  b=p.read_bytes();assert b==q.read_bytes();records.append({'path':name,'sha256':hashlib.sha256(b).hexdigest()})
data={'base':'74369376a0dbeeb0a17b5ee34557059c8e2a9491','branch':'feature/design-collection-luxury','files':records,'scope':'Runtime, tests, root configuration; docs are not runtime fingerprint. Same-byte isolated build copy.'}
data['sha256']=hashlib.sha256(json.dumps(records,sort_keys=True).encode()).hexdigest()
Path('/tmp/xk-dc005-full/source.json').write_text(json.dumps(data,indent=2)+'\n')
cpath=Path('/tmp/xk-dc005-full/contract.json');c=json.loads(cpath.read_text());c['status']='READY_ROOT_FREEZE';c['rootFingerprint']=data['sha256'];cpath.write_text(json.dumps(c,indent=2)+'\n')
print(json.dumps({'files':len(records),'sha256':data['sha256']}))
