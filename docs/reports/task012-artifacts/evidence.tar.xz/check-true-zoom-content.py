from pathlib import Path
from html.parser import HTMLParser
from urllib.parse import urlsplit
import json,re
class MainText(HTMLParser):
 def __init__(self):super().__init__();self.inside=False;self.text=[];self.svgDepth=0;self.titleDepth=0
 def handle_starttag(self,tag,attrs):
  if tag=='main':self.inside=True
  if tag=='svg':self.svgDepth+=1
  if self.svgDepth and tag in ('title','desc'):self.titleDepth+=1
 def handle_endtag(self,tag):
  if tag=='main':self.inside=False
  if tag in ('title','desc') and self.titleDepth:self.titleDepth-=1
  if tag=='svg':self.svgDepth-=1
 def handle_data(self,data):
  if self.inside and not self.titleDepth:self.text.append(data)
j=json.loads(Path('/workspace/shared/xk-task012-at/pages-true-zoom-200.json').read_text());observed=[]
for row in j['rows']:
 p=urlsplit(row['url']).path.removeprefix('/xk-website/'); f=Path('out')/p/'index.html';parser=MainText();parser.feed(f.read_text());a=re.sub(r'\s+','',''.join(parser.text));b=re.sub(r'\s+','',row['mainText']);observed.append({'url':row['url'],'equalAllMainText':a==b,'expectedChars':len(a),'actualChars':len(b),'documentHasHorizontalOverflow':row['scrollWidth']>row['clientWidth'],'clippedLeaves':len(row['clippedLeaves'])});assert a==b,(p,a[:100],b[:100]);assert row['innerWidth']==590 and row['cssZoom']=='1' and row['devicePixelRatio']==2;assert row['scrollWidth']==row['clientWidth'];assert not row['clippedLeaves']
Path('/tmp/xk-task012/true-zoom-content-comparison.json').write_text(json.dumps({'status':'PASS','sourceFingerprint':j['sourceFingerprint'],'method':'All actual main innerText at native Chrome200%, whitespace normalized vs final exported HTML main visible text (SVG title/desc are accessible names, not painted text; excluded only those tags); no CSS zoom/DPR change; document overflow and clipped leaves checks','rows':observed},indent=2));print('Nine actual 200% pages retained all main text; no measured horizontal overflow or clipped leaves')
