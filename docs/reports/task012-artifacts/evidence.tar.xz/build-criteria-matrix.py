from pathlib import Path
import json,datetime
w=Path('/tmp/xk-task012');source=json.loads((w/'wcag22-normative-criteria.json').read_text())
# This is an initial source-inventory applicability plan, never a rendered-test result.
plan={
'1.1.1':('Required','站內含Logo、裝飾幾何與介面icons；須區分等價文字、可忽略裝飾與連結名稱。','以DOM/AX tree及真AT檢查Logo/可見品牌字不重複朗讀，Menu/X icons不產生雜訊；不以Logo例外免除Link名稱。'),
'1.2.1':('Not Applicable','Source inventory沒有預錄純音訊或純影片；待最終DOM/Network確認未新增媒體。','盤點audio/video/embed/iframe與外部媒體；若出現預錄純媒體則改Required驗等價替代。'),
'1.2.2':('Not Applicable','Source未見預錄同步影音；媒體缺席是暫定適用性，非已完成驗收。','確認最終頁無同步影音；如有則逐段核對字幕，不以影片標題代替字幕。'),
'1.2.3':('Not Applicable','Source未見預錄同步影片；最終DOM仍需核對。','如新增同步影片，改Required核對音訊描述或等價媒體替代及適用例外。'),
'1.2.4':('Not Applicable','Source未見直播同步影音或播放器。','確認無live stream；有直播音訊時改Required核對即時字幕。'),
'1.2.5':('Not Applicable','Source未見預錄同步影片。','有預錄影片時改Required驗AA音訊描述，不能僅用1.2.3替代文字推定通過。'),
'1.3.1':('Required','各頁有多層標題、服務/流程/技術清單、具名landmarks與多個nav。','逐頁比對可見結構/DOM/AX/AT的headings、lists、nav names、Main/Header/Footer及標籤關聯。'),
'1.3.2':('Required','Responsive grids與共享導航需保留語意閱讀順序。','在五寬、zoom/reflow、樣式停用或AX/AT線性閱讀時核對內容與focus順序。'),
'1.3.3':('Required','說明、CTA與圖樣不能只靠顏色/方位/形狀表達。','人工讀取所有操作說明，確認文字本身描述目的；若依位置/色彩說明須另有可理解文字。'),
'1.3.4':('Required','Responsive內容/手機選單不得鎖定portrait或landscape。','在直/橫向視窗實際完成導航與閱讀，確認無orientation限制；正常scroll不是限制。'),
'1.3.5':('Not Applicable','目前無蒐集使用者資訊的input fields；Contact清單空且無表單。','最終DOM重新盤點姓名/email/其他user-data欄位；若有則改Required驗標準input purposes/autocomplete。'),
'1.4.1':('Required','連結、按鈕、狀態badge與focus/hover不能只靠顏色辨識。','逐頁各狀態核對文字/形狀/underline/語意替代，含Portfolio PLANNED及Contact unavailable。'),
'1.4.2':('Not Applicable','Source沒有自動播放音訊。','最終確認無自動超過3秒音訊；若出現須驗獨立控制音量/停止或暫停。'),
'1.4.3':('Required','各背景、opacity文字與按鈕均有可見內容。','量實際合成前景/背景對比：一般4.5:1/大字3:1；inactive/Logo例外逐項記錄，不泛用。'),
'1.4.4':('Required','中文長文/導航/CTA必須在真實200% browser zoom可閱讀操作。','執行真browser zoom並記CSS viewport；全部公開頁及開/關選單不丟內容/功能。'),
'1.4.5':('Required','主要內容為HTML文字，但Logo字標為向量輪廓，需記essential logotype例外。','確認未把正文做成圖片，Logo例外限品牌字標，不延伸到CTA/服務說明。'),
'1.4.10':('Required','靜態中文頁面/卡片/技術長標籤須320 CSS px reflow。','在320 CSS px或1280/400%真zoom驗無非必要二維scroll、裁切與內容丟失；例外逐內容說明。'),
'1.4.11':('Required','Menu按鈕、focus指示與有意義圖形/邊界需可辨識。','量必要UI/state/graphics與鄰色至少3:1，含focus/hover/open；非必要border或Logo例外單列。'),
'1.4.12':('Required','HTML中文及必要英文支援文字間距覆寫。','只覆寫line-height1.5/paragraph2/letter.12/word.16倍字級，驗各頁無loss；語言例外需按W3C說明。'),
'1.4.13':('Not Applicable','Source沒有以hover/focus觸發的額外tooltip/submenu；手機menu由click開，SkipLink自己顯現不屬本準則額外內容。','最終DOM/互動確認無hover/focus額外內容；有則改Required驗dismissible/hoverable/persistent與例外。'),
'2.1.1':('Required','Link、Button、disclosure與頁內anchors都需鍵盤操作。','Tab/ShiftTab/Enter/Space/Escape完成真實主要旅程，不以pointer測試取代。'),
'2.1.2':('Required','Disclosure型手機menu不應focus trap，所有頁可鍵盤離開。','在開/關選單與跨頁狀態遍歷focus、可往返並Escape；不任加modal trap。'),
'2.1.4':('Not Applicable','Source只見Escape等非字元按鍵，無單字母/數字/符號快捷鍵。','最終事件與真操作確認無character-only shortcuts；有則驗關閉/重映射/僅focus時啟用。'),
'2.2.1':('Not Applicable','目前沒有內容設定的時間限制/登入session或限時任務。','確認沒有倒數/強制逾時流程；測試harness timeout不是網站內容時限。'),
'2.2.2':('Not Applicable','Source圖樣靜態、過渡短暫，無自啟超過5秒moving/blinking/scrolling或自動更新資訊。','人工與CSS/Runtime確認無相關持續內容；有則改Required驗pause/stop/hide或頻率控制。'),
'2.3.1':('Required','全頁不得有超過閾值閃爍；靜態來源不能取代實際運行觀察。','人工檢視頁面與menu/hover/transition有無閃爍，若有依閾值量測；不以無影片直接免除。'),
'2.4.1':('Required','每頁有重複Header/nav，既有SkipLink需真有效。','真鍵盤/AT啟用skip，驗focus與scroll進main；不只檢href或元素存在。'),
'2.4.2':('Required','九公開頁與三Portfolio details各有topic/purpose title。','讀最終document.title/AT視窗標題並對exact metadata，不以SVG<title>混淆。'),
'2.4.3':('Required','menu/links/CTA/cross-page與anchors的focus順序影響操作。','核對DOM與Tab順序、menu關閉/跨頁/斷點後不遺留hidden focus，驗閱讀與操作一致。'),
'2.4.4':('Required','每頁含多個CTA/card/footer/related-service連結。','比對可見文字+程式關聯context/accessible name與真目的地，不只比文字是否存在。'),
'2.4.5':('Required','九公開內容頁屬同一set；三個Portfolio深頁不能只依同一列表入口。','逐頁確認多於一種定位方式；Header/Footer重複同一導航不自動算兩機制，無搜尋不能虛構搜尋。'),
'2.4.6':('Required','中文headings/nav/CTA labels須描述內容與目的。','人工/AT讀標題清單與labels，保留清楚topic，避免僅裝飾英文序號充當標題。'),
'2.4.7':('Required','全部keyboard-operable UI須有可見focus模式。','真鍵盤在各背景/hover/open/zoom狀態量/截focus；不靠滑鼠點擊取代keyboard focus。'),
'2.4.11':('Required','sticky Header/絕對定位menu可能遮住focused component。','真Tab與anchors/zoom/reflow驗focused UI未完全被作者內容遮住；AA minimum不是AAA enhanced。'),
'2.5.1':('Not Applicable','Source沒有作者定義的multipoint/path-based gesture；一般scroll/zoom屬UA。','觸控盤點確認無pinch/swipe-path功能；如有則改Required驗single-pointer替代及essential例外。'),
'2.5.2':('Required','Links/Button/touch-menu支援single-pointer，outside pointerdown行為需核對。','測pointer-down移出取消/up完成等真操作，確認不意外導航/不可逆啟動；必要例外說明。'),
'2.5.3':('Required','可見Link/Button文字需在accessible name中；icon-only menu另有辨識名稱。','比對rendered text與AX/AT name，含brandLink/menu/CTA，不只檢aria-label存在。'),
'2.5.4':('Not Applicable','Source沒有shake/device-motion/user-motion啟動功能。','確認未用devicemotion/gesture camera控制；有則驗UI替代及motion關閉機制。'),
'2.5.7':('Not Applicable','Source無作者dragging功能。','最終DOM/互動核對無drag；若有則改Required驗不拖曳single-pointer替代/essential與UA例外。'),
'2.5.8':('Required','全部pointer targets需≥24×24或標準spacing/例外，現Button contract≥44px須保留。','量boundingboxes/target間距含nav/footer/內文anchors；inline/equivalent/essential例外逐項，不一概降44px。'),
'3.1.1':('Required','頁面主語言需程式可判為zh-TW。','最終HTML/AX/AT核對lang=zh-TW，不只source或meta。'),
'3.1.2':('Required','中文頁含英文品牌/標語及技術詞。','人工/AT檢英文passages lang，proper names/technical terms例外逐項，不要求每技術單字另lang。'),
'3.2.1':('Required','keyboard focus不可自動導航或打開改context的UI。','Tab/ShiftTab巡覽，focus本身不觸發route/頁面/焦點突變。'),
'3.2.2':('Required','需核對任何可設定UI狀態是否自動改context；目前主要是disclosure，無資料表單。','實際改可用control狀態確認不意外跳頁/移focus；明確Link/Button activation與改setting分清，不創造form。'),
'3.2.3':('Required','Header/Footer/MobileNav在同一set重複。','同viewport/zoom/orientation逐頁核對相對順序；不能跨不同responsive variation誤判。'),
'3.2.4':('Required','相同功能的menu/CTA/services/contact應一致辨識。','跨頁核對name/label/role及圖示意義，功能相同但名稱矛盾須修。'),
'3.2.6':('Required','Contact/需求準備可作self-help入口且跨頁重複；保守納入一致help位置檢查，沒有email不構成全面免除。','依normative四類help及直接Link判定，於同頁面variation核對相對順序；如實際非help再附清楚排除理由。'),
'3.3.1':('Not Applicable','Source無使用者資料輸入或自動檢測input errors。','最終確認無表單/error狀態；如有則改Required驗文字識別錯誤項。'),
'3.3.2':('Not Applicable','Source無需輸入資料的fields/forms。','最終核對無輸入；若新增則驗labels/instructions/required，不用Button name取代form標籤要求。'),
'3.3.3':('Not Applicable','無資料輸入/自動error detection與可提供修正的流程。','如出現資料輸入則改Required驗錯誤建議與安全/目的例外。'),
'3.3.4':('Not Applicable','沒有法律/財務交易、user-data修改刪除或測驗答案提交。','最終流程盤點無上述風險；存在時改Required驗reversible/checked/confirmed其中適用機制。'),
'3.3.7':('Not Applicable','沒有同一流程重複要求先前輸入資料。','最終確認無多步重複資料；若出現驗autopopulate/select及essential/security/obsolete例外。'),
'3.3.8':('Not Applicable','沒有auth或cognitive-function登入測試。','最終確認無登入；若出現改Required驗替代/協助/passwordmanager/paste及標準例外。'),
'4.1.2':('Required','原生links/buttons與scripted disclosure具有name/role/expanded/controls狀態。','DOM/AX與真AT核對name/role/value及狀態通知，IDs關聯/hidden內容與focus一致。'),
'4.1.3':('Not Applicable','公開頁沒有不移focus的動態成功/進度/結果/錯誤status messages；Contact pending/Portfolio狀態是靜態，menu展開狀態由4.1.2核對。','最終觀察是否新增status updates；若有改Required驗role/properties可由AT讀取，不為測試新增假alerts。')
}
assert set(plan)=={x['id']for x in source['criteria']}
rows=[]
for r in source['criteria']:
 app,why,how=plan[r['id']];rows.append({**r,'testId':'A11Y-SC-'+r['id'],'applicability':app,'applicabilityRationale':why,'applicabilityBasis':'Source inventory only, final rendered DOM/state inventory confirmation PENDING. Not Applicable does not mean a completed N/A test.','procedure':how,'verificationMethods':['manual rendered inspection','keyboard/pointer/zoom/contrast where applicable','real screen reader for semantic/name/state claims','axe supplemental only; never standalone conformance evidence'],'status':'PENDING','actualResult':None,'exitCode':None,'evidence':[],'issueIds':[]})
x={'task':'Task012 initial full WCAG2.2 A/AA applicability matrix','createdAtUtc':datetime.datetime.now(timezone.utc).isoformat() if False else datetime.datetime.now(datetime.timezone.utc).isoformat(),'websiteBase':'8e42c647646d20873789c54367132901746a58bf','standardSource':json.loads((w/'wcag22-source.json').read_text()),'datedNormativeVersion':source['datedVersionLinks'],'criteriaCount':55,'levelCounts':source['levels'],'applicabilityCounts':{a:sum(r['applicability']==a for r in rows)for a in ['Required','Not Applicable']},'statusCounts':{'PENDING':55},'scope':'All current public pages/components/states, plus impacted controlled content modes per final inventory; no site tests performed by source auditor. No full-conformance claim.','removedCriterion':{'id':'4.1.1','title':'Parsing','statusInWcag22':'Obsolete and removed; not one of55 A/AA requirements. Preserve valid semantic/ID/legacy-tool checks separately.'},'newA':['3.2.6','3.3.7'],'newAA':['2.4.11','2.5.7','2.5.8','3.3.8'],'criteria':rows,'conformanceBoundary':'Whole-page/process scope, accessibility-supported technology and non-interference requirements also matter;55row completion or zeroaxe alone is not certification. Real AT Required in Task012; environment absence BLOCKED, not N/A.'}
(w/'wcag22-criteria-matrix.json').write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:x[k]for k in ['criteriaCount','levelCounts','applicabilityCounts','statusCounts']},ensure_ascii=False))
