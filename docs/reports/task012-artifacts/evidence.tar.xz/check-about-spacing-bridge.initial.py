#!/usr/bin/env python3
"""Strict artifact impact bridge. No browser tests are run or relabeled."""
import hashlib,json,pathlib,re,sys
from datetime import datetime,timezone
from html.parser import HTMLParser
W=pathlib.Path('/tmp/xk-task012');OLD=W/'final-pages-root/xk-website';NEW=pathlib.Path('/workspace/xk-website/out');OUT=W/'about-spacing-artifact-bridge.json';checks=[];result={'status':'PENDING','startedAt':datetime.now(timezone.utc).isoformat(),'oldRoot':str(OLD),'newRoot':str(NEW),'sourceVersionsAsProvidedByRoot':{'oldFingerprintPrefix':'979a9799','newFingerprintPrefix':'5d242341'},'checks':checks}
sha=lambda b:hashlib.sha256(b).hexdigest()
def check(name,ok,details=None):
 checks.append({'name':name,'status':'PASS'if ok else'FAIL','details':details})
 if not ok:raise AssertionError(name)
class ClassNames(HTMLParser):
 def __init__(self):super().__init__();self.values=set()
 def handle_starttag(self,t,attrs):self.values.update(dict(attrs).get('class','').split())
try:
 receipt_path=W/'checks/build-pages-after-spacing.json';receipt=json.loads(receipt_path.read_text());check('NewBuildActuallyCompleted',receipt['status']=='PASS'and receipt['returnCode']==receipt['exitCode']==0);result['buildReceipt']=str(receipt_path)
 files={side:{str(p.relative_to(root)):p.read_bytes()for p in sorted(root.rglob('*'))if p.is_file()}for side,root in [('old',OLD),('new',NEW)]};check('Both204Files',len(files['old'])==len(files['new'])==204)
 ids={side:[m[1]for p in fs if(m:=re.fullmatch(r'_next/static/([^/]+)/_buildManifest\.js',p))]for side,fs in files.items()};check('OneExplicitBuildIdPerArtifact',all(len(v)==1 for v in ids.values()));ids={k:v[0]for k,v in ids.items()};result['buildIds']=ids
 paths={side:set(fs)for side,fs in files.items()};removed=paths['old']-paths['new'];added=paths['new']-paths['old'];css={side:[p for p in difference if p.endswith('.css')]for side,difference in [('old',removed),('new',added)]};check('ExactlyOneRenamedCssAsset',all(len(v)==1 for v in css.values()));css={k:v[0]for k,v in css.items()};result['cssAssetPaths']=css
 rule=b'.min-h-max{min-height:max-content}';old_css=files['old'][css['old']];new_css=files['new'][css['new']];check('OnlyExactNewCssRule',old_css.count(rule)==0 and new_css.count(rule)==1 and new_css.replace(rule,b'',1)==old_css,{'oldBytes':len(old_css),'newBytes':len(new_css),'addedRule':rule.decode(),'addedBytes':len(rule)});result['cssDelta']={'oldSha256':sha(old_css),'newSha256':sha(new_css),'oldBytes':len(old_css),'newBytes':len(new_css),'exactAddedRule':rule.decode()}
 def path_key(p,side):return p.replace('_next/static/'+ids[side]+'/', '_next/static/<BUILD_ID>/').replace(css[side],'<GLOBAL_CSS_ASSET>')
 def norm(b,side):return b.replace(ids[side].encode(),b'<BUILD_ID>').replace(pathlib.PurePosixPath(css[side]).name.encode(),b'<GLOBAL_CSS_NAME>')
 maps={side:{path_key(p,side):p for p in fs}for side,fs in files.items()};check('Canonical204PathSetsExact',set(maps['old'])==set(maps['new'])and all(len(v)==204 for v in maps.values()))
 result['normalizationAllowlist']={'path':'Only known _next/static/<actualBuildId>/ and the single actual CSS asset path','content':'Only exact actual Build ID and exact renamed CSS basename, no other replacement','aboutClass':'NOT part of general normalization; preserved as an explicit independently checked About-only class delta below'}
 old_class=b'relative mx-auto flex aspect-square w-full max-w-sm flex-col items-center justify-center overflow-hidden rounded-2xl border bg-background p-6 shadow-subtle sm:p-8';new_class=old_class.replace(b'aspect-square ',b'aspect-square min-h-max ');rows=[];about=[];counts={'fontFiles':0,'javascriptFiles':0,'cssFiles':0,'nonAboutFiles':0,'aboutFiles':0}
 for key in sorted(maps['old']):
  op=maps['old'][key];np=maps['new'][key];a=files['old'][op];b=files['new'][np];an=norm(a,'old');bn=norm(b,'new');row={'canonicalPath':key,'oldPath':op,'newPath':np,'oldSha256':sha(a),'newSha256':sha(b),'oldBytes':len(a),'newBytes':len(b),'rawByteIdentical':a==b,'buildIdCssNameNormalizedByteIdentical':an==bn}
  if op.endswith(('.woff','.woff2','.ttf','.otf')):counts['fontFiles']+=1;check('FontRawBytes '+op,a==b)
  if op.endswith('.js'):counts['javascriptFiles']+=1;check('JavascriptRawBytes '+op,a==b)
  if op.endswith('.css'):
   counts['cssFiles']+=1
   if key!='<GLOBAL_CSS_ASSET>':check('OtherCssRawBytes '+op,a==b)
  if key.startswith('about/'):
   counts['aboutFiles']+=1;occurrences=an.count(old_class);expected=an.replace(old_class,new_class);check('ExplicitAboutClassOnly '+op,bn==expected,{'expectedClassAddition':'min-h-max','oldFigureClassOccurrences':occurrences,'newMinHMaxOccurrences':bn.count(b'min-h-max'),'generalNormalizedEquivalent':an==bn});row['aboutExpectedClassDelta']={'oldClass':old_class.decode(),'newClass':new_class.decode(),'classOccurrenceCount':occurrences,'explicitExpectedNewBytesMatch':bn==expected,'generalNormalizedDifferencePreserved':an!=bn};about.append(row)
  elif key!='<GLOBAL_CSS_ASSET>':counts['nonAboutFiles']+=1;check('NonAboutOnlyAllowedIdentifiers '+op,an==bn)
  rows.append(row)
 result['counts']=counts;result['allFileComparisons']=rows;result['aboutSeparateEvidence']=about
 routes=['','services','solutions','portfolio','portfolio/corporate-website','portfolio/enterprise-management','portfolio/integration-hub','contact'];route_rows=[]
 for route in routes:
  html=(route+'/'if route else'')+'index.html';subset=[row for row in rows if str(pathlib.PurePosixPath(row['oldPath']).parent)==(route or'.')and(row['oldPath'].endswith(('.html','.txt')))and(pathlib.PurePosixPath(row['oldPath']).name.startswith(('index.','__next.')))];parser=ClassNames();parser.feed(files['new'][html].decode());check('EightRouteHtmlPayloadExact '+(route or'/'),len(subset)>=2 and all(r['buildIdCssNameNormalizedByteIdentical']for r in subset));check('NewUtilityNotAppliedOutsideAbout '+(route or'/'),'min-h-max'not in parser.values);route_rows.append({'route':'/'+route if route else'/','html':html,'htmlAndPayloadFiles':[r['oldPath']for r in subset],'count':len(subset),'onlyBuildIdCssNameDiff':True,'newMinHMaxClassAbsentFromRenderedHtml':True})
 result['eightNonAboutRouteEvidence']=route_rows;result['oldManifestSha256']=sha(json.dumps({p:sha(b)for p,b in files['old'].items()},sort_keys=True,separators=(',',':')).encode());result['newManifestSha256']=sha(json.dumps({p:sha(b)for p,b in files['new'].items()},sort_keys=True,separators=(',',':')).encode());result['status']='PASS';result['impactConclusion']={'eightNonAboutRoutes':'Existing8-route observations may be retained only with this explicit artifact/selector impact bridge; no new axe/browser execution claimed.','about':'About artifact class change is real and separately accepted structurally; affected About geometry/spacing/state tests require Root fresh retest. This helper does not mark them PASS.','fontsAndJavascript':'All actual exported font and JS bytes unchanged, including build-ID-directory JS manifests after path pairing.','css':'Only34-byte .min-h-max rule addition;2 other CSS assets unchanged. New utility is absent from the8 non-About rendered HTML class sets.','notNewTests':'Not57 new axe results and not a new browser baseline.'}
except Exception as e:result.update(status='FAIL',error=str(e));raise
finally:result['finishedAt']=datetime.now(timezone.utc).isoformat();OUT.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'status':result['status'],'output':str(OUT),'sha256':sha(OUT.read_bytes()),'checks':len(checks),'counts':result.get('counts')}))
