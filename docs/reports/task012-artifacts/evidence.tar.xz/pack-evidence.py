from pathlib import Path
import tarfile,json,hashlib,lzma,datetime
T=Path('/tmp/xk-task012');A=Path('/workspace/xk-website/docs/reports/task012-artifacts');items={}
exclude={'session-environment-paths.json','at-runtime-env.json','at-environment.json','report-draft.md','report-evidence-template.json','artifact-pack-process.json','artifact-pack-process.log','artifact-pack-final-process.json','artifact-pack-final-process.log'}
allowed={'.json','.log','.cjs','.py','.md','.txt','.html','.png','.jpg','.ndjson','.tsx'}
for p in T.iterdir():
 if p.is_file()and p.suffix in allowed and p.name not in exclude and not p.name.startswith(('tts-preflight.initial','tts-preflight.attempt2')):items[p.name]=p
for name in ['checks','runs','contrast-evidence','about-spacing-clip','native-at','contrast-source-before']:
 for p in (T/name).rglob('*'):
  if p.is_file()and p.suffix in allowed:items[p.relative_to(T).as_posix()]=p
# Only synthetic preflight outcome; no private session/profile or package runtime dump.
items['tts-preflight.final.json']=T/'tts-preflight.final.json'
manifest=[]
for rel,p in sorted(items.items()):
 data=p.read_bytes();manifest.append({'path':rel,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
with lzma.open(A/'evidence.tar.xz','wb',preset=3)as stream:
 with tarfile.open(fileobj=stream,mode='w|')as tar:
  for row in manifest:tar.add(items[row['path']],arcname=row['path'],recursive=False)
m={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'archive':'evidence.tar.xz','archiveBytes':(A/'evidence.tar.xz').stat().st_size,'archiveSha256':hashlib.sha256((A/'evidence.tar.xz').read_bytes()).hexdigest(),'rawBytes':sum(x['bytes']for x in manifest),'fileCount':len(manifest),'files':manifest,'excluded':'Private profiles/environment/auth data, runtimepackages/node_modules/buildoutputs excluded. NativeAT only filteredspeech, actions and explicit nonprivate results.'};(A/'manifest.json').write_text(json.dumps(m,indent=2)+'\n');print({k:v for k,v in m.items()if k!='files'})
