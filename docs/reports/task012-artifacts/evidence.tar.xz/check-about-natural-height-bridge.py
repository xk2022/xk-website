#!/usr/bin/env python3
"""Strict8-route impact bridge; About DOM change and opaque Flight changes stay separate."""
import argparse,hashlib,json,pathlib,re
from datetime import datetime,timezone
from html.parser import HTMLParser
p=argparse.ArgumentParser();p.add_argument('--receipt',required=True);a=p.parse_args();W=pathlib.Path('/tmp/xk-task012');OLD=W/'final-pages-root/xk-website';NEW=pathlib.Path('/workspace/xk-website/out');OUT=W/'natural-height-runtime-bridge.json';checks=[];result={'status':'PENDING','startedAt':datetime.now(timezone.utc).isoformat(),'oldRoot':str(OLD),'newRoot':str(NEW),'oldSourceFingerprintPrefix':'979a9799','newSourceFingerprint':'76d5651f5ae79d435d22791393b0802b70ce5cc468a0d1ae799f1bea2761afeb','checks':checks};sha=lambda b:hashlib.sha256(b).hexdigest()
def check(name,ok,details=None):
 checks.append({'name':name,'status':'PASS'if ok else'FAIL','details':details})
 if not ok:raise AssertionError(name)
class Dom(HTMLParser):
 def __init__(self):super().__init__(convert_charrefs=True);self.tokens=[];self.script=None;self.scriptData='';self.flight=[];self.classes=set();self.scriptTokenIndex=None
 def handle_starttag(self,t,attrs):
  self.tokens.append(['start',t,attrs]);self.classes.update(dict(attrs).get('class','').split())
  if t=='script':self.script=attrs;self.scriptData='';self.scriptTokenIndex=len(self.tokens)-1
 def handle_endtag(self,t):
  if t=='script'and self.script is not None:
   body=self.scriptData
   if body.lstrip().startswith(('self.__next_f.push','(self.__next_f=')):
    self.flight.append({'sha256':sha(body.encode()),'bytes':len(body.encode())});del self.tokens[self.scriptTokenIndex:];self.script=None;return
   else:self.tokens.append(['script-data',body])
   self.script=None
  self.tokens.append(['end',t])
 def handle_data(self,d):
  if self.script is not None:self.scriptData+=d
  else:self.tokens.append(['text',d])
try:
 receipt=json.loads(pathlib.Path(a.receipt).read_text());check('NewBuildActualExitZero',receipt['status']=='PASS'and receipt['returnCode']==receipt['exitCode']==0);result['buildReceipt']=a.receipt
 files={s:{str(p.relative_to(root)):p.read_bytes()for p in sorted(root.rglob('*'))if p.is_file()}for s,root in [('old',OLD),('new',NEW)]};check('Both204Files',len(files['old'])==len(files['new'])==204)
 ids={s:[m[1]for path in fs if(m:=re.fullmatch(r'_next/static/([^/]+)/_buildManifest\.js',path))]for s,fs in files.items()};check('OneActualBuildIdEach',all(len(v)==1 for v in ids.values()));ids={s:v[0]for s,v in ids.items()};result['actualBuildIds']=ids
 key=lambda path,s:path.replace('_next/static/'+ids[s]+'/', '_next/static/<BUILD_ID>/');norm=lambda b,s:b.replace(ids[s].encode(),b'<BUILD_ID>');maps={s:{key(p,s):p for p in fs}for s,fs in files.items()};check('204PathSetsMatchOnlyBuildId',len(maps['old'])==len(maps['new'])==204 and set(maps['old'])==set(maps['new']))
 rows=[];about=[];counts={'fonts':0,'javascript':0,'css':0,'nonAboutFiles':0,'aboutFiles':0}
 for k in sorted(maps['old']):
  op=maps['old'][k];np=maps['new'][k];old=files['old'][op];new=files['new'][np];same=old==new;equal=norm(old,'old')==norm(new,'new');row={'canonicalPath':k,'oldPath':op,'newPath':np,'oldSha256':sha(old),'newSha256':sha(new),'oldBytes':len(old),'newBytes':len(new),'rawByteIdentical':same,'buildIdOnlyNormalizedByteIdentical':equal}
  if op.endswith(('.woff','.woff2','.ttf','.otf')):counts['fonts']+=1;check('FontRawBytes '+op,same)
  if op.endswith('.js'):counts['javascript']+=1;check('JavascriptRawBytes '+op,same)
  if op.endswith('.css'):counts['css']+=1;check('CssRawBytes '+op,same)
  if k.startswith('about/'):counts['aboutFiles']+=1;about.append(row)
  else:counts['nonAboutFiles']+=1;check('NonAboutOnlyBuildId '+op,equal)
  rows.append(row)
 check('AllThreeCssRawBytes',counts['css']==3);result['counts']=counts;result['all204Comparisons']=rows;result['aboutOpaqueFileDifferencesPreserved']=about
 old_class='relative mx-auto flex aspect-square w-full max-w-sm flex-col items-center justify-center overflow-hidden rounded-2xl border bg-background p-6 shadow-subtle sm:p-8';new_class=old_class.replace('aspect-square ','');doms={}
 for s in ['old','new']:
  parser=Dom();parser.feed(norm(files[s]['about/index.html'],s).decode());doms[s]=parser
 expected=[];class_occurrences=0
 for token in doms['old'].tokens:
  if token[0]=='start'and token[1]=='figure':
   attrs=[]
   for name,value in token[2]:
    if name=='class'and value==old_class:value=new_class;class_occurrences+=1
    attrs.append((name,value))
   token=['start','figure',attrs]
  expected.append(token)
 check('ExactlyOneAboutFigureClassChange',class_occurrences==1);check('AboutRenderedDomOnlyExpectedFigureClass',expected==doms['new'].tokens);check('NoMinHMaxInNewAboutDom','min-h-max'not in doms['new'].classes)
 result['aboutSeparateEvidence']={'oldFigureClass':old_class,'newFigureClass':new_class,'actualExpectedChange':'Remove aspect-square; no min-h-max class','classOccurrences':class_occurrences,'renderedDomMatchesOnlyExpectedClassChange':True,'domViewDefinition':'Independent About rendered-DOM view keeps tag/attribute/text and non-Flight scripts, including JSON-LD. Next Flight transport script elements are excluded only from this rendered-content view, and their actual bodies/counts are retained separately as opaque hashes. This is not a global normalizer and does not assert About payload equality.','oldFlightScriptContent':doms['old'].flight,'newFlightScriptContent':doms['new'].flight,'rawPayloadEquivalenceClaimed':False,'requiresFreshAboutAffectedRetest':True}
 routes=['','services','solutions','portfolio','portfolio/corporate-website','portfolio/enterprise-management','portfolio/integration-hub','contact'];route_rows=[]
 for route in routes:
  html=(route+'/'if route else'')+'index.html';subset=[r for r in rows if str(pathlib.PurePosixPath(r['oldPath']).parent)==(route or'.')and r['oldPath'].endswith(('.html','.txt'))and pathlib.PurePosixPath(r['oldPath']).name.startswith(('index.','__next.'))];check('EightRouteHtmlPayload '+(route or'/'),len(subset)>=2 and all(r['buildIdOnlyNormalizedByteIdentical']for r in subset));parser=Dom();parser.feed(files['new'][html].decode());check('NoNewMinHMaxOnEightRoutes '+(route or'/'),'min-h-max'not in parser.classes);route_rows.append({'route':'/'+route if route else'/','files':[r['oldPath']for r in subset],'count':len(subset),'onlyBuildIdDiff':True})
 result['eightNonAboutRouteEvidence']=route_rows;result['normalizationAllowlist']={'paths':'Only actual _next/static/<BuildID>/ directory','content':'Only exact actual Build ID bytes. CSS names and contents are identical; no CSS name normalization used.','About':'No About class/payload changes normalized away in the main byte comparison; independent rendered-DOM expectation and full hashes are separately recorded.'};result['manifests']={s:{'root':str(OLD if s=='old'else NEW),'sha256':sha(json.dumps({p:sha(b)for p,b in fs.items()},sort_keys=True,separators=(',',':')).encode()),'files':{p:{'sha256':sha(b),'bytes':len(b)}for p,b in fs.items()}}for s,fs in files.items()};result['status']='PASS';result['impactConclusion']={'retainedEightRouteObservations':'Explicit unchanged-assets/8-route HTML+payload impact bridge permits retaining prior observations only; no new axe/browser run is claimed.','About':'Changed About geometry is not covered by old About PASS; Root must perform fresh affected tests.','notNewTests':'Not57 fresh axe results, not an additional browser suite.'}
except Exception as e:result.update(status='FAIL',error=str(e));raise
finally:result['finishedAt']=datetime.now(timezone.utc).isoformat();OUT.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'status':result['status'],'output':str(OUT),'sha256':sha(OUT.read_bytes()),'checks':len(checks),'counts':result.get('counts')}))
