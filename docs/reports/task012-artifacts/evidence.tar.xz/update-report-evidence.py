import json, re, hashlib
from pathlib import Path
from datetime import datetime, timezone
root=Path('/tmp/xk-task012');p=root/'report-draft.md';s=p.read_text()
now=datetime.now(timezone.utc).isoformat()
checks={}
for tid,name in [('A11Y-C01','npm-ci-final'),('A11Y-C02','tsc-final'),('A11Y-C03','lint-final'),('A11Y-C04','build-final')]:
 q=root/'checks'/f'{name}.json';d=json.loads(q.read_text());assert d['exitCode']==0 and d['status']=='PASS'
 checks[tid]={'status':'PASS','actual':'指定命令完整結束，OS exit 0','exitCode':d['exitCode'],'startedAt':d['startedAt'],'finishedAt':d['finishedAt'],'evidence':[str(q),d['logFile']],'procedure':d['command'],'versionEvidence':str(root/'general-final-summary.json')}
summary=json.loads((root/'general-final-summary.json').read_text());assert summary['actualProcessExitCode']==0 and summary['counts']['PASS']==21 and summary['actualCount']==21
base=json.loads((root/'base-pages-result.json').read_text());assert base['actualExitCode']==0 and base['baseCommit']=='8e42c647646d20873789c54367132901746a58bf'
s=s.replace('以下保留已取得的 baseline／Source／文件修復事實，其餘 final 驗收一律 PENDING，不代表 Task 012 已通過或已完成發布。','以下保留已取得的 baseline／Source／文件修復事實，並補入四個 final 品質命令及 General 21 項真實結果；尚未完成的驗收維持 PENDING，不代表 Task 012 已全數通過或已完成發布。')
s=s.replace('Final fingerprint、完整 source diff、對應編譯產物與受測版本：PENDING。','General final fingerprint：`'+summary['sourceFingerprint']+'`；最終 Pages／完整 source diff、對應編譯產物與受測版本需各自記錄，後續變更不可挪用此結果。')
s=s.replace('**所有 final 狀態目前均 PENDING**。','**四項品質命令有真回執而為 PASS，其餘 final 狀態目前均 PENDING**。')
for tid,d in checks.items():
 s=re.sub(r'(?m)^(\| '+re.escape(tid)+r' \|[^\n]*?\| )PENDING／null／null／待實際證據 \|$',lambda m:m[1]+'PASS／命令完整結束／0／`'+Path(d['evidence'][0]).name+'`＋log |',s)
s=s.replace('PENDING；精確重現＋所有共享頁面、正反向鍵盤及五種指定寬度','General 本輪 PASS：九 route 的 focus-leave／blur；Pages、完整人工鍵盤與五種指定寬度仍 PENDING')
s=s.replace('PENDING；final DOM graph、實際兩條路徑、keyboard／AT／Base Path','General 本輪 PASS：九頁目錄各有九目標、三次 Footer 鍵盤詳頁旅程及 Portfolio 分類；Pages／AT／Base Path 最終判定仍 PENDING')
s=s.replace('PENDING：實際 URL／port／Base Path、start/end、buildMode、true receipt／exit、版本 map、完整結束標記與 expected count','General 已真 Exit 0、21/21；Pages 與受控 Preview 仍待實際 URL／Base Path／回執／版本 map，詳見下方分階段證據')
s=s.replace('PENDING：Root 實際鍵盤／閱讀操作、真正 speech/debug／焦點觀察；工具啟動、TTS preflight、AX dump 不作網站 PASS','Root 已實際操作 Home h／h／m／k、Enter 至 Services、H1／麵包屑、手機 menu collapsed／expanded／Tab／Escape 並聽取 speech；完整 manual evidence 與驗收覆蓋仍 PENDING')
s=s.replace('PENDING：真 browser zoom、CSS viewport、方向／視覺與功能；deviceScaleFactor 不代替 browser zoom','Root 已在原生 Chromium 以五次 Ctrl+Plus 取得真 200% UI；實際 CSS viewport／方向／功能／Pages 證據仍 PENDING，未將此觀察擴為 R01／R02 PASS')
insert='''## 本輪已取得的修正後證據（分階段）

- 四個 final 品質命令有 `subprocess.Popen.wait()` 真回執：`npm ci`、`npx tsc --noEmit`、`npm run lint`、`npm run build` 全部 Exit 0；時段與原始 logs 見 `checks/*-final.json`。這只覆蓋 A11Y-C01–C04，不代替 Pages build 或網站人工驗收。
- General fresh run 為 `2026-11-19T10:12:55.121Z`–`10:13:47.053Z`，真 Exit 0、expected/actual 21/21、21 PASS。九頁 metadata、robots／Sitemap protected guards、站內連結與旅程、Footer Multiple Ways、九頁 focus-exit／blur、storage／requests／Network 規則通過；28 個資源、raw request failures 0、unexpected 0。此輪不是 responsive／axe／真 AT／zoom 的全套結果。
- General 受測 fingerprint：`979a979925237f16c5f1c6eef5e13a9e1fb9d08a891c424503084df6f3e48560`；原始結果及真 receipt 在 `general-final-summary.json` 指定位置。不得以 AX snapshot 當螢幕閱讀器結果。
- `base-pages-result.json` 是隔離的原 base `8e42c647…` Pages build，fingerprint `67780be37bcd8fee4b5497c1d78ae8d04bd698484b01920c1068d616761a1eae`，真 Exit 0、九公開 route／Privacy、dev 排除／404／`.nojekyll` 檢查通過；這是 baseline 比較樣本，**不是本次修正後 A11Y-C05 結果**。原外部 node_modules symlink build Exit 1 與實際複製依賴後重驗 Exit 0 均保存。
- `mobile-navigation-focus-leave-self-check.json` 與 `contrast-source-self-check.json` 是 source owner 的聚焦自查；新增 blur handler／12 個 Section class 變更與 TypeScript 語意診斷零錯誤，不擴充為 runtime 或對比 PASS。
- Root 本輪實際 AT 觀察：Home 以 h／h／m／k 導覽、Enter「了解完整服務」至 Services、閱讀 H1／麵包屑；以 b 定位 collapsed 導覽按鈕、Space 聽取 expanded、Tab 逐個名稱、離開後主內容可見、Escape 回 trigger 並聽取 collapsed。原生 Chromium 五次 Ctrl+Plus 真實顯示 200%。這些是實際完成的局部觀察，待 Root 補 speech／操作紀錄與所需流程覆蓋；目前不把 AT01／R01／R02 或其全部關聯 SC 預填 PASS。

'''
s=s.replace('## 33 項 Task 驗收對照',insert+'## 33 項 Task 驗收對照')
# Record already observed partial evidence without promoting the broad final matrix status.
partials={
'A11Y-K01':'General focus-exit／blur PASS；Root 實作 AT menu 局部觀察，Pages／完整鍵盤仍待補',
'A11Y-K02':'General 九 route 遮蔽重現已 PASS；Root menu 離開可見，Pages／完整情境待補',
'A11Y-AT01':'Root 已實際 AT 局部旅程；待原始 manual evidence／覆蓋核對',
'A11Y-R01':'原生 Chromium 真 200% UI 已觀察；CSS viewport／全頁功能與紀錄待補',
'A11Y-F02':'General 全 links／journeys／Multiple Ways PASS；Pages 仍待補',
'A11Y-G01':'General protected guards PASS；Pages 匯出及 Preview 矩陣待補',
'A11Y-F03':'General 28 resources、0 request failure／unexpected；Pages 待補',
'A11Y-G02':'General 九頁 exact metadata／robots／Sitemap guards PASS；Pages 待補',
'A11Y-C05':'僅隔離 base Pages build 真 0；current final 不沿用，待真回執',
}
for tid,note in partials.items():
 s=re.sub(r'(?m)^(\| '+re.escape(tid)+r' \|[^\n]*?\| )PENDING／null／null／待實際證據 \|$',lambda m:m[1]+'PENDING／'+note+'／null／待完整證據 |',s)
criterionNotes={
'2.4.5':'General 真 DOM／兩種定位及三次鍵盤詳頁旅程 PASS；Pages／AT 待補',
'2.4.11':'General 九 route focus-exit PASS；Root AT menu 局部觀察，完整狀態待補',
'2.4.3':'General blur／focus-exit PASS；Root AT focus 局部觀察，全路徑待補',
'4.1.2':'Root 實聽 menu collapsed／expanded，待 speech／全控件紀錄',
'1.4.4':'真 200% UI 已觀察；CSS viewport／全頁功能驗收待補',
'1.4.3':'baseline 4.294 FAIL／12 Section 修正；最終實際對比待補',
}
for sc,note in criterionNotes.items():
 s=re.sub(r'(?m)^(\| '+re.escape(sc)+r'／[^\n]*?\| )PENDING／待實際對應紀錄 \|$',lambda m:m[1]+'PENDING／'+note+' |',s)
s=s.replace('草稿時點：2026-11-19T10:13:33.502826+00:00。','草稿更新時點：'+now+'。')
p.write_text(s)
# Keep original initial matrices immutable; provide a separate ready-to-fill schema.
a=json.loads((root/'acceptance-matrix.json').read_text());w=json.loads((root/'wcag22-criteria-matrix.json').read_text())
items=a['items'];criteria=w['criteria']
for row in items:
 tid=row.get('id',row.get('testId'))
 row['finalEvidence']={'status':'PENDING','expected':row.get('expected'),'actual':None,'startedAt':None,'finishedAt':None,'environment':None,'sourceFingerprint':None,'exitCode':None,'receipt':None,'evidence':[],'issueIds':[],'retestOf':[],'notes':[]}
 if tid in checks:row['finalEvidence'].update(checks[tid])
 elif tid in partials:row['finalEvidence']['notes'].append(partials[tid])
for row in criteria:
 row['finalEvidence']={'status':'PENDING','actual':None,'environment':None,'sourceFingerprint':None,'procedure':row.get('procedure'),'evidence':[],'issueIds':[],'manualJudgment':None,'applicabilityConfirmed':False,'notes':[criterionNotes[row['id']]] if row['id'] in criterionNotes else []}
out={'task':'Task 012','createdAt':now,'kind':'report-authoring evidence template, not final acceptance','initialMatricesPreserved':True,'partialGeneralRun':summary,'baselinePagesBuild':base,'finalQualityReceipts':checks,'items':items,'criteria':criteria,'remoteStages':{'status':'PENDING','evidenceLocation':'same PR body, actual events only'}}
(root/'report-evidence-template.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
# Validate only our new drafts, not an app check.
lines=s.splitlines();scrows=[x for x in lines if re.match(r'^\| \d\.\d\.\d+／',x)]
trows=[x for x in lines if re.match(r'^\| A11Y-(?:C|F|S|T|K|V|AT|O|X|R|G)\d{2} \|',x)]
assert len(scrows)==55,len(scrows)
assert len(trows)==33,len(trows)
assert sum(' | PASS／' in x for x in trows)==4
assert all(' | PENDING／' in x for x in scrows)
print(json.dumps({'report':str(p),'lines':len(lines),'taskRows':len(trows),'taskStatuses':{'PASS':4,'PENDING':29},'criterionRows':55,'criterionStatuses':{'PENDING':55},'templateItems':len(items),'templateCriteria':len(criteria),'reportSha256':hashlib.sha256(p.read_bytes()).hexdigest()},ensure_ascii=False))
