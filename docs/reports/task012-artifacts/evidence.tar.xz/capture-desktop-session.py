#!/usr/bin/python3
"""Run inside the authorized desktop terminal; record only session paths, never cookies."""
import json,os,pathlib
keys=['DISPLAY','XAUTHORITY','DBUS_SESSION_BUS_ADDRESS','XDG_RUNTIME_DIR','XDG_CURRENT_DESKTOP']
p=pathlib.Path('/tmp/xk-task012/desktop-session.json');p.write_text(json.dumps({k:os.environ.get(k)for k in keys},indent=2)+'\n');p.chmod(0o600)
print('Desktop session paths saved to '+str(p))
