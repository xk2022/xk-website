from pathlib import Path
from urllib.parse import unquote
import hashlib,json,re,subprocess,datetime
R=Path('/workspace/xk-website');T=Path('/tmp/xk-task012');m=json.loads((T/'final-code-natural-height.json').read_text())
for f,h in m['files'].items():assert hashlib.sha256((R/f).read_bytes()).hexdigest()==h,f
assert subprocess.run(['git','diff','--check'],cwd=R).returncode==0
changed=subprocess.check_output(['git','diff','--name-only'],cwd=R,text=True).splitlines();new=subprocess.check_output(['git','ls-files','--others','--exclude-standard'],cwd=R,text=True).splitlines();files=changed+new
assert not any(x.startswith(('.next/','out/','node_modules/','.env','.git/'))for x in files)
for name in ['package.json','package-lock.json','next.config.ts','tsconfig.json','.github/workflows/ci.yml']:assert name not in changed
assert not any(x.startswith(('src/config/','public/'))for x in changed)
known=json.loads((T/'doc-link-fix-verification.json').read_text())['remainingBrokenLinks'];known={(x['path'],x['target'])for x in known};broken=[];checked=0
for file in files:
 if not file.endswith('.md'):continue
 for match in re.finditer(r'!?\[[^\]]*\]\((?:<([^>]+)>|([^\s)]+))(?:\s+"[^"]*")?\)',(R/file).read_text()):
  href=match[1]or match[2]
  if re.match(r'^(https?:|mailto:|tel:|#|app:|plugin:)',href):continue
  target=unquote(href.split('#')[0]);targetpath=(R/file).parent/target
  if not targetpath.exists():broken.append({'path':file,'target':href});assert(file,href)in known,(file,href)
  checked+=1
assert len(broken)==14,broken
v=json.loads((R/'docs/reports/task012-artifacts/verification.json').read_text());assert v['acceptanceCounts']=={'PASS':25,'PENDING':2,'N/A':6};assert v['criteriaCounts']=={'PASS':34,'N/A':21};assert v['source']['fingerprint']==m['fingerprint']
secret=re.compile(rb'(?:gh[pousr]_[A-Za-z0-9]{25,}|github_pat_[A-Za-z0-9_]{30,}|-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----|Authorization: (?:Bearer|token) [A-Za-z0-9_\-]{30,})')
for file in files:
 p=R/file
 if p.is_file()and p.suffix not in {'.png','.xz'}:assert not secret.search(p.read_bytes()),file
assert '# Task 012' in (R/'docs/reports/task012-implementation.md').read_text()
r={'status':'PASS','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'sourceFingerprint':m['fingerprint'],'runtimeFilesVerified':len(m['files']),'changedTracked':len(changed),'newFiles':len(new),'allFiles':files,'localMarkdownPathsChecked':checked,'knownPreexistingMissingOriginalLinks':broken,'unexpectedMissingLinks':0,'diffCheckExitCode':0,'protectedSourceUnchanged':True,'secretScan':'No high-confidence token/private-key pattern in submittednonbinaryfiles; archive members checked separately','markdownAPI':'Six actual string inputs /zeroerrors in final-markdown-retest-validation.json; original fragment-MD041 failure retained'};(T/'final-local-review.json').write_text(json.dumps(r,ensure_ascii=False,indent=2));print({k:v for k,v in r.items()if k not in ['allFiles','knownPreexistingMissingOriginalLinks']})
