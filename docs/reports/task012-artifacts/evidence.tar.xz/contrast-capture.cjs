const fs=require('node:fs');
const path=require('node:path');
const crypto=require('node:crypto');
const assert=require('node:assert/strict');
const {chromium}=require('/tmp/xk-browser-check/node_modules/playwright-core');
const out='/tmp/xk-task012/contrast-evidence';fs.mkdirSync(out,{recursive:true});
const inventory=JSON.parse(fs.readFileSync('/tmp/xk-task012/contrast-node-inventory.json','utf8'));
const selected=inventory.filter(row=>row.foreground==='rgb(102, 112, 133)'&&row.patterns.length);
const norm=s=>s.replace(/\s+/g,' ').trim();
(async()=>{
 const browser=await chromium.launch({executablePath:'/usr/bin/chromium',headless:true,args:['--no-sandbox']});
 const context=await browser.newContext({viewport:{width:375,height:1000},deviceScaleFactor:1});
 const page=await context.newPage();const rows=[];const errors=[];const runtime=[];
 page.on('pageerror',error=>runtime.push(error.message));
 let current='';
 try{
  for(let index=0;index<selected.length;index++){
   const baseline=selected[index];const width=Number(baseline.scan.endsWith('1440')?1440:375);const key=baseline.url+'|'+width;
   if(key!==current){await page.setViewportSize({width,height:1000});const response=await page.goto(baseline.url,{waitUntil:'load'});assert.equal(response.status(),200);await page.evaluate(()=>document.fonts.ready);current=key;}
   try{
    const locator=page.locator(baseline.selector);assert.equal(await locator.count(),1,'Unique axe target');assert.equal(norm(await locator.innerText()),norm(baseline.text),'Exact actual baseline node text');
    const file=path.join(out,`${String(index+1).padStart(3,'0')}-${baseline.scan}.png`);
    await locator.screenshot({path:file,animations:'disabled'});
    const observed=await locator.evaluate(el=>{
     const rect=e=>{const r=e.getBoundingClientRect();return{x:r.x,y:r.y,width:r.width,height:r.height,pageX:r.x+scrollX,pageY:r.y+scrollY};};
     const describe=e=>({tag:e.tagName.toLowerCase(),id:e.id||null,className:typeof e.className==='string'?e.className:null});
     const ancestry=[];let node=el;while(node){const s=getComputedStyle(node);ancestry.push({node,element:describe(node),color:s.color,backgroundColor:s.backgroundColor,backgroundImage:s.backgroundImage,opacity:s.opacity,filter:s.filter,backdropFilter:s.backdropFilter,mixBlendMode:s.mixBlendMode,rect:rect(node)});node=node.parentElement;}
     const baseIndex=ancestry.findIndex(a=>a.backgroundColor!=='rgba(0, 0, 0, 0)'&&a.backgroundColor!=='transparent');
     const layers=[];for(const ancestor of ancestry.slice(0,baseIndex+1)){for(const sibling of ancestor.node.children){if(typeof sibling.className!=='string'||!sibling.className.includes('brand-pattern-'))continue;const s=getComputedStyle(sibling);layers.push({element:describe(sibling),backgroundImage:s.backgroundImage,maskImage:s.maskImage,opacity:s.opacity,zIndex:s.zIndex,position:s.position,rect:rect(sibling)});}}
     const s=getComputedStyle(el);return{url:location.href,viewport:{width:innerWidth,height:innerHeight,devicePixelRatio},scroll:{x:scrollX,y:scrollY},element:describe(el),rect:rect(el),color:s.color,fontSize:s.fontSize,fontWeight:s.fontWeight,lineHeight:s.lineHeight,opacity:s.opacity,textFillColor:s.webkitTextFillColor,textShadow:s.textShadow,base:baseIndex<0?null:((({node,...rest})=>rest)(ancestry[baseIndex])),ancestry:ancestry.map(({node,...rest})=>rest),layers,styleSheets:[...document.querySelectorAll('link[rel=stylesheet]')].map(link=>link.href)};
    });
    const bytes=fs.readFileSync(file);rows.push({index:index+1,baseline,observed,screenshot:{file,width:bytes.readUInt32BE(16),height:bytes.readUInt32BE(20),sha256:crypto.createHash('sha256').update(bytes).digest('hex')}});
   }catch(error){errors.push({index:index+1,scan:baseline.scan,selector:baseline.selector,message:error.message});}
   if((index+1)%10===0)process.stdout.write(`Captured ${index+1}/${selected.length}\n`);
  }
 }finally{await context.close();await browser.close();}
 const result={purpose:'Unmodified native node screenshots and computed styles for inconclusive gradient contrast groups; no axe scan or DOM mutation',observedAt:new Date().toISOString(),source:'Existing normal production server 3090, baseline CSS',requested:selected.length,captured:rows.length,rows,errors,runtime,status:errors.length||runtime.length?'INCOMPLETE':'COMPLETE'};
 fs.writeFileSync(path.join(out,'captures.json'),JSON.stringify(result,null,2)+'\n');
 process.stdout.write(JSON.stringify({status:result.status,requested:selected.length,captured:rows.length,errors,runtime,result:path.join(out,'captures.json')})+'\n');
 if(result.status!=='COMPLETE')process.exitCode=1;
})().catch(error=>{process.stderr.write(error.stack+'\n');process.exitCode=1;});
