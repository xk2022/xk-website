const fs=require('node:fs'),assert=require('node:assert/strict');
const{chromium}=require('/tmp/xk-browser-check/node_modules/playwright-core');
function snapshot(el){
 const rect=e=>{const r=e.getBoundingClientRect();return{x:r.x,y:r.y,width:r.width,height:r.height,right:r.right,bottom:r.bottom};};
 const rgba=color=>{const c=new OffscreenCanvas(1,1),ctx=c.getContext('2d');ctx.clearRect(0,0,1,1);ctx.fillStyle=color;ctx.fillRect(0,0,1,1);return[...ctx.getImageData(0,0,1,1).data];};
 const style=e=>{const s=getComputedStyle(e);return{tag:e.tagName,id:e.id,className:typeof e.className==='string'?e.className:null,color:s.color,rgba:rgba(s.color),backgroundColor:s.backgroundColor,backgroundRgba:rgba(s.backgroundColor),backgroundImage:s.backgroundImage,fontSize:s.fontSize,fontWeight:s.fontWeight,opacity:s.opacity,textShadow:s.textShadow,filter:s.filter,backdropFilter:s.backdropFilter,mixBlendMode:s.mixBlendMode,borderColor:s.borderColor,borderRgba:rgba(s.borderColor),outlineColor:s.outlineColor,outlineRgba:rgba(s.outlineColor),outlineWidth:s.outlineWidth,outlineOffset:s.outlineOffset,outlineStyle:s.outlineStyle,boxShadow:s.boxShadow,focusVisible:e.matches(':focus-visible'),rect:rect(e)};};
 const ancestors=[];for(let node=el;node;node=node.parentElement)ancestors.push(style(node));
 const nearestOpaque=ancestors.find(s=>s.backgroundRgba[3]===255);
 const r=el.getBoundingClientRect(),points=[[.1,.1],[.5,.1],[.9,.1],[.1,.5],[.5,.5],[.9,.5],[.1,.9],[.5,.9],[.9,.9]].map(([x,y])=>{x=r.left+r.width*x;y=r.top+r.height*y;const hit=document.elementFromPoint(x,y);return{x,y,inViewport:x>=0&&x<innerWidth&&y>=0&&y<innerHeight,hit:hit?{tag:hit.tagName,id:hit.id,className:typeof hit.className==='string'?hit.className:null,insideDisclosure:!!hit.closest('header [id]'),disclosureAncestorId:hit.closest('header [id]')?.id||null}:null};});
 return{url:location.href,text:el.textContent,element:style(el),ancestors,nearestOpaque,hitPoints:points,active:document.activeElement===el};
}
const items=[
   {name:'desktop navigation',url:'/',width:1440,selector:'header nav[aria-label="主要導覽"] a',index:1},
   {name:'primary CTA',url:'/',width:1440,selector:'header > .xk-container > a[data-slot="button"]'},
   {name:'outline CTA',url:'/',width:1440,selector:'section[aria-labelledby="home-title"] a[data-variant="outline"]'},
   {name:'Footer link',url:'/',width:1440,selector:'footer nav[aria-label="頁尾導覽"] a',index:1},
   {name:'interactive Card',url:'/portfolio',width:1440,selector:'#portfolio-projects a[data-slot="card"]',index:0},
   {name:'mobile disclosure trigger',url:'/',width:375,selector:'header button[aria-controls]'},
   {name:'mobile navigation link',url:'/',width:375,selector:'nav[aria-label="手機導覽"] a',index:1,open:true},
];

(async()=>{
 const browser=await chromium.launch({executablePath:'/usr/bin/chromium',headless:true,args:['--no-sandbox']});const context=await browser.newContext({viewport:{width:1440,height:1000},deviceScaleFactor:1});const page=await context.newPage();const rows=[],overlap=[],errors=[];page.on('pageerror',e=>errors.push(e.message));
 const go=async(route,width)=>{await page.setViewportSize({width,height:1000});const url='http://127.0.0.1:3091/xk-website'+(route==='/'?'/':route+'/');const response=await page.goto(url,{waitUntil:'load'});assert.equal(response.status(),200);await page.evaluate(()=>document.fonts.ready);};
 try{
 for(const item of items){await go(item.url,item.width);if(item.open)await page.getByRole('button',{name:'開啟導覽',exact:true}).click();let target=page.locator(item.selector);if(item.index!==undefined)target=target.nth(item.index);assert.equal(await target.count(),1,item.name+' exact preflight target');await target.scrollIntoViewIfNeeded();
 for(const state of ['normal','hover','focus']){if(state==='hover')await target.hover();if(state==='focus'){await page.mouse.move(0,0);await page.keyboard.press('Tab');await target.focus();}await page.waitForTimeout(200);const observed=await target.evaluate(snapshot);const children=await target.locator('h3,p,svg').evaluateAll(nodes=>nodes.map(el=>{const s=getComputedStyle(el);return{tag:el.tagName,text:el.textContent,color:s.color,fontSize:s.fontSize,fontWeight:s.fontWeight};}));rows.push({name:item.name,viewport:item.width,state,selector:item.selector,observed,children});fs.writeFileSync('/tmp/xk-task012/contrast-ui-pages-checkpoint.json',JSON.stringify({rows,errors},null,2)+'\n');}
 }
 await go('/',375);await page.getByRole('button',{name:'開啟導覽',exact:true}).click();for(const selector of ['.mb-6','#home-title','.mt-6.max-w-xl.type-body-lg']){const target=page.locator(selector);assert.equal(await target.count(),1);const observed=await target.evaluate(snapshot);assert.ok(observed.hitPoints.every(p=>p.inViewport&&p.hit?.insideDisclosure),'All9 actual hits belong to panel, including padding');overlap.push({selector,observed});}
 }finally{await context.close();await browser.close();}
 const frozen=JSON.parse(fs.readFileSync('/tmp/xk-task012/frozen-code.json','utf8'));const result={purpose:'Finite7UI normal/hover/focus actual color observations and3 known overlay ancestry checks; no axe/fullsuite',observedAt:new Date().toISOString(),mode:'final Pages',base:'http://127.0.0.1:3091/xk-website/',sourceFingerprint:frozen.fingerprint,expectedUiStates:21,actualUiStates:rows.length,rows,overlap,errors,status:errors.length?'FAIL':'COMPLETE'};assert.equal(rows.length,21);assert.equal(overlap.length,3);fs.writeFileSync('/tmp/xk-task012/contrast-ui-pages-observations.json',JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify({status:result.status,uiStates:rows.length,overlap:overlap.length,errors}));if(errors.length)process.exitCode=1;
})().catch(e=>{console.error(e.stack);process.exitCode=1;});
