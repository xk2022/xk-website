from pathlib import Path
import json,re,os,hashlib,difflib,datetime
root=Path('/workspace/xk-website');w=Path('/tmp/xk-task012')
moveNames=['brand-design-system.md','homepage-implementation.md','about-implementation.md','services-implementation.md','github-pages-deployment.md']
moveMap={str((root/'docs'/n).resolve()):(root/'docs/reports'/n).resolve()for n in moveNames}
prior=json.loads((w/'doc-move-link-audit.json').read_text())
explicit={(r['path'],r['target']):r['suggestedCurrentTarget']for r in prior['broken']if r['suggestedCurrentTarget']}
files=[root/'README.md',root/'AGENTS.md',root/'docs/implementation-notes.md',root/'docs/task/README.md']+sorted((root/'docs/task').glob('task[0-9][0-9][0-9].md'))+sorted((root/'docs/reports').glob('*.md'))+[root/'docs/performance-measurement.md',root/'docs/seo-operations.md',root/'docs/subagent-workflow.md']
changes=[];pattern=re.compile(r'\[[^\]]*\]\(([^)\n]*)\)')
for p in dict.fromkeys(files):
 if not p.exists():continue
 before=p.read_text();edited=[];code=False;afterLines=[];relative=p.relative_to(root).as_posix()
 for lineNo,line in enumerate(before.splitlines(keepends=True),1):
  if line.lstrip().startswith('```'):code=not code;afterLines.append(line);continue
  if code:afterLines.append(line);continue
  def sub(m):
   raw=m.group(1)
   if not raw or raw.startswith(('#','/'))or re.match(r'^[A-Za-z][A-Za-z0-9+.-]*:',raw):return m.group(0)
   # All known moved references are plain local targets; do not rewrite titles/URLs.
   if any(c in raw for c in ['<','>','"',"'"]):return m.group(0)
   target,sep,fragment=raw.partition('#');candidate=explicit.get((relative,raw))
   resolved=(p.parent/target).resolve()
   if candidate is None and str(resolved)in moveMap:
    candidate=os.path.relpath(moveMap[str(resolved)],p.parent)+(sep+fragment if sep else'')
   if candidate is None:return m.group(0)
   actual=(p.parent/candidate.split('#')[0]).resolve()
   assert actual.exists(),(relative,raw,candidate)
   if candidate==raw:return m.group(0)
   edited.append({'line':lineNo,'before':raw,'after':candidate})
   return m.group(0)[:m.start(1)-m.start()]+candidate+m.group(0)[m.end(1)-m.start():]
  afterLines.append(pattern.sub(sub,line))
 after=''.join(afterLines)
 if after!=before:
  # Only href payloads change; no prose/spacing/fences/status edits.
  assert pattern.sub(lambda m:m.group(0)[:m.start(1)-m.start()]+'__HREF__'+m.group(0)[m.end(1)-m.start():],before)==pattern.sub(lambda m:m.group(0)[:m.start(1)-m.start()]+'__HREF__'+m.group(0)[m.end(1)-m.start():],after)
  b=w/'doc-link-fix-before'/relative;b.parent.mkdir(parents=True,exist_ok=True);b.write_text(before)
  changes.append({'path':relative,'beforeSha256':hashlib.sha256(before.encode()).hexdigest(),'afterSha256':hashlib.sha256(after.encode()).hexdigest(),'before':before,'after':after,'edits':edited})
patch=['*** Begin Patch\n']
for c in changes:
 patch.append('*** Update File: '+str(root/c['path'])+'\n')
 d=list(difflib.unified_diff(c['before'].splitlines(keepends=True),c['after'].splitlines(keepends=True),n=2))
 for l in d[2:]:patch.append('@@\n'if l.startswith('@@')else l)
patch.append('*** End Patch\n')
(w/'doc-link-fix.patch').write_text(''.join(patch))
(w/'doc-link-fix-plan.json').write_text(json.dumps({'createdAtUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'changes':changes},ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'files':len(changes),'hrefEdits':sum(len(c['edits'])for c in changes),'paths':[{ 'path':c['path'],'edits':len(c['edits'])}for c in changes]},ensure_ascii=False))
