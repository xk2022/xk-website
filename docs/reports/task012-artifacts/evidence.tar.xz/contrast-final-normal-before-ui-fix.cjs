const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
const{chromium}=require('/tmp/xk-browser-check/node_modules/playwright-core');
const base='/tmp/xk-task012',inventory=JSON.parse(fs.readFileSync(base+'/contrast-node-inventory.json','utf8')),analysis=JSON.parse(fs.readFileSync(base+'/contrast-analysis.json','utf8')),frozen=JSON.parse(fs.readFileSync(base+'/frozen-code.json','utf8'));
const replacements=new Map(analysis.resolutions94.map(r=>[r.scan+'|'+r.baselineSelector,r]));
const norm=s=>s.replace(/\s+/g,' ').trim();
function snapshot(el){
 const rect=e=>{const r=e.getBoundingClientRect();return{x:r.x,y:r.y,width:r.width,height:r.height,right:r.right,bottom:r.bottom};};
 const rgba=color=>{const c=new OffscreenCanvas(1,1),ctx=c.getContext('2d');ctx.clearRect(0,0,1,1);ctx.fillStyle=color;ctx.fillRect(0,0,1,1);return[...ctx.getImageData(0,0,1,1).data];};
 const style=e=>{const s=getComputedStyle(e);return{tag:e.tagName,id:e.id,className:typeof e.className==='string'?e.className:null,color:s.color,rgba:rgba(s.color),backgroundColor:s.backgroundColor,backgroundRgba:rgba(s.backgroundColor),backgroundImage:s.backgroundImage,fontSize:s.fontSize,fontWeight:s.fontWeight,opacity:s.opacity,textShadow:s.textShadow,filter:s.filter,backdropFilter:s.backdropFilter,mixBlendMode:s.mixBlendMode,borderColor:s.borderColor,borderRgba:rgba(s.borderColor),outlineColor:s.outlineColor,outlineRgba:rgba(s.outlineColor),outlineWidth:s.outlineWidth,outlineOffset:s.outlineOffset,outlineStyle:s.outlineStyle,boxShadow:s.boxShadow,focusVisible:e.matches(':focus-visible'),rect:rect(e)};};
 const ancestors=[];for(let node=el;node;node=node.parentElement)ancestors.push(style(node));
 const nearestOpaque=ancestors.find(s=>s.backgroundRgba[3]===255);
 const r=el.getBoundingClientRect(),points=[[.1,.1],[.5,.1],[.9,.1],[.1,.5],[.5,.5],[.9,.5],[.1,.9],[.5,.9],[.9,.9]].map(([x,y])=>{x=r.left+r.width*x;y=r.top+r.height*y;const hit=document.elementFromPoint(x,y);return{x,y,inViewport:x>=0&&x<innerWidth&&y>=0&&y<innerHeight,hit:hit?{tag:hit.tagName,id:hit.id,className:typeof hit.className==='string'?hit.className:null,insideDisclosure:!!hit.closest('header [aria-controls]')||!!hit.closest('nav[aria-label="手機導覽"]')}:null};});
 return{url:location.href,text:el.textContent,element:style(el),ancestors,nearestOpaque,hitPoints:points,active:document.activeElement===el};
}
(async()=>{const browser=await chromium.launch({executablePath:'/usr/bin/chromium',headless:true,args:['--no-sandbox']});const context=await browser.newContext({viewport:{width:375,height:1000},deviceScaleFactor:1});const page=await context.newPage();const errors=[],rows=[],ui=[];page.on('pageerror',e=>errors.push(e.message));let key='';
 const go=async(url,width)=>{await page.setViewportSize({width,height:1000});const response=await page.goto(url,{waitUntil:'load'});assert.equal(response.status(),200);await page.evaluate(()=>document.fonts.ready);};
 try{
  for(const baseline of inventory){const width=baseline.scan.endsWith('1440')?1440:375,next=baseline.scan;if(next!==key){await go(baseline.url,width);if(next==='home-menu-open')await page.getByRole('button',{name:'開啟導覽',exact:true}).click();key=next;}
   const replacement=replacements.get(baseline.scan+'|'+baseline.selector);let selector=replacement?.afterStableSelector||baseline.selector;const indexed=selector.match(/ \(index([01])\)$/);if(indexed)selector=selector.replace(/ \(index[01]\)$/,'');let locator=page.locator(selector);if(indexed)locator=locator.nth(Number(indexed[1]));assert.equal(await locator.count(),1,baseline.scan+' '+selector);assert.equal(norm(await locator.innerText()),norm(baseline.text));const observed=await locator.evaluate(snapshot);if(replacement)assert.deepEqual(observed.element.rgba,[23,32,51,255],'Intended existing foreground Token');
   let overlay=null;if(!baseline.patterns.length){overlay=await page.locator('header nav[aria-label="手機導覽"]').evaluate(el=>{const panel=el.closest('[id]'),s=getComputedStyle(panel),r=panel.getBoundingClientRect();return{expanded:document.querySelector('header button[aria-controls]').getAttribute('aria-expanded'),color:s.backgroundColor,opacity:s.opacity,rect:{x:r.x,y:r.y,width:r.width,height:r.height,right:r.right,bottom:r.bottom}};});}
   rows.push({scan:baseline.scan,baselineSelector:baseline.selector,finalSelector:selector,indexed:indexed?Number(indexed[1]):null,sourceResolutionIndex:replacement?.index||null,baselineForeground:baseline.foreground,observed,overlay});
  }
  for(const item of[
   {name:'desktop navigation',url:'/',width:1440,selector:'header nav[aria-label="主要導覽"] a',index:1},
   {name:'primary CTA',url:'/',width:1440,selector:'header a[data-slot="button"]'},
   {name:'outline CTA',url:'/',width:1440,selector:'section[aria-labelledby="home-title"] a[data-variant="outline"]'},
   {name:'Footer link',url:'/',width:1440,selector:'footer nav[aria-label="頁尾導覽"] a',index:1},
   {name:'interactive Card',url:'/portfolio',width:1440,selector:'#portfolio-projects a[data-slot="card"]',index:0},
   {name:'mobile disclosure trigger',url:'/',width:375,selector:'header button[aria-controls]'},
   {name:'mobile navigation link',url:'/',width:375,selector:'nav[aria-label="手機導覽"] a',index:1,open:true},
  ]){
   await go('http://127.0.0.1:3090'+item.url,item.width);if(item.open)await page.getByRole('button',{name:'開啟導覽',exact:true}).click();let target=page.locator(item.selector);if(item.index!==undefined)target=target.nth(item.index);assert.equal(await target.count(),1);await target.scrollIntoViewIfNeeded();
   for(const state of ['normal','hover','focus']){if(state==='hover')await target.hover();if(state==='focus'){await page.mouse.move(0,0);await page.keyboard.press('Tab');await target.focus();}await page.waitForTimeout(200);const observed=await target.evaluate(snapshot);const children=await target.locator('h3,p,svg').evaluateAll(nodes=>nodes.map(el=>{const s=getComputedStyle(el);return{tag:el.tagName,text:el.textContent,color:s.color,fontSize:s.fontSize,fontWeight:s.fontWeight};}));ui.push({name:item.name,viewport:item.width,state,selector:item.selector,observed,children});}
  }
 }finally{await context.close();await browser.close();}
 const output={purpose:'Finite final-normal computed contrast/overlay inventory, not axe/AT/full QA',capturedAt:new Date().toISOString(),sourceFingerprint:frozen.fingerprint,sourceManifest:base+'/frozen-code.json',nodes:rows.length,expectedNodes:237,sourceResolutionsObserved:rows.filter(r=>r.sourceResolutionIndex).length,uiPairObservations:ui.length,rows,ui,errors,status:errors.length?'FAIL':'COMPLETE'};assert.equal(rows.length,237);assert.equal(output.sourceResolutionsObserved,94);fs.writeFileSync(base+'/contrast-final-normal-observations.json',JSON.stringify(output,null,2)+'\n');console.log(JSON.stringify({status:output.status,nodes:rows.length,changed94Verified:output.sourceResolutionsObserved,uiStates:ui.length,errors}));if(errors.length)process.exitCode=1;
})().catch(e=>{console.error(e.stack);process.exitCode=1;});
