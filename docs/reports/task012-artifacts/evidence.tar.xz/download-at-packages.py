import json,pathlib,re,subprocess,hashlib
w=pathlib.Path('/tmp/xk-task012');p=w/'packages';p.mkdir(exist_ok=True)
items=[]
for line in (w/'apt-simulation.log').read_text().splitlines():
 m=re.match(r'^Inst (\S+) \((\S+) ',line)
 if m:items.append({'name':m[1],'version':m[2]})
items.append({'name':'espeak-ng','version':'1.52.0+dfsg-5'})
(w/'at-package-pins.json').write_text(json.dumps(items,indent=2)+'\n')
cmd=['env','APT_CONFIG='+str(w/'apt/apt.conf'),'/usr/bin/apt-get','download',*[x['name']+'='+x['version']for x in items]]
r=subprocess.run(cmd,cwd=p);r.check_returncode()
runtime=w/'runtime';runtime.mkdir(exist_ok=True);files=[]
for f in sorted(p.glob('*.deb')):
 subprocess.run(['/usr/bin/dpkg-deb','--extract',str(f),str(runtime)],check=True)
 files.append({'name':f.name,'bytes':f.stat().st_size,'sha256':hashlib.sha256(f.read_bytes()).hexdigest()})
(w/'at-package-downloads.json').write_text(json.dumps({'source':'Official Debian trixie HTTPS apt repository, apt signed metadata','command':cmd,'packages':files,'runtime':str(runtime),'systemInstall':False},indent=2)+'\n');print(json.dumps({'downloadedPackages':len(files),'runtime':str(runtime)}))
