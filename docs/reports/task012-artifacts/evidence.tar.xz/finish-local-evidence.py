from pathlib import Path
from html.parser import HTMLParser
from collections import Counter
import json,re,datetime,hashlib,shutil
T=Path('/tmp/xk-task012');S=Path('/workspace/shared/xk-task012-at');R=Path('/workspace/xk-website');now=datetime.datetime.now(datetime.timezone.utc).isoformat()
class P(HTMLParser):
 def __init__(self):super().__init__();self.main=False;self.svg=0;self.title=0;self.text=[];self.count=Counter();self.disabled=0
 def handle_starttag(self,t,a):
  self.count[t]+=1
  if t=='main':self.main=True
  if t=='svg':self.svg+=1
  if self.svg and t in ('title','desc'):self.title+=1
  d=dict(a)
  if 'disabled'in d or d.get('aria-disabled')=='true':self.disabled+=1
 def handle_endtag(self,t):
  if t=='main':self.main=False
  if t in ('title','desc')and self.title:self.title-=1
  if t=='svg':self.svg-=1
 def handle_data(self,d):
  if self.main and not self.title:self.text.append(d)
j=json.loads((S/'pages-true-zoom-200.json').read_text());new=json.loads((S/'natural-about-true-zoom-200.json').read_text());bridge=json.loads((T/'natural-height-runtime-bridge.json').read_text());assert bridge['status']=='PASS';rows=[];inventory=[]
for old in j['rows']:
 row=new['actual']if old['url'].endswith('/about/')else old;rel=row['url'].split('/xk-website/',1)[1];p=P();p.feed((R/'out'/rel/'index.html').read_text());a=re.sub(r'\s+','',''.join(p.text));b=re.sub(r'\s+','',row['mainText']);assert a==b;assert row['scrollWidth']==row['clientWidth']and row['innerWidth']==590 and row['cssZoom']=='1'and row['devicePixelRatio']==2
 if rel=='about/':assert row['figure']['aspectRatio']=='auto'and row['figure']['linkInside']
 rows.append({'url':row['url'],'allMainTextEqual':True,'innerWidth':590,'innerHeight':378,'documentClientWidth':row['clientWidth'],'documentScrollWidth':row['scrollWidth'],'actualObservationVersion':'76d5651f'if rel=='about/'else'979a9799, exact unaffected runtime bridge proven','cssZoom':'1','devicePixelRatio':2})
 inventory.append({'url':row['url'],'counts':{t:p.count[t]for t in ['form','input','textarea','select','audio','video','iframe','embed','button']},'disabled':p.disabled})
assert all(all(x['counts'][t]==0 for t in ['form','input','textarea','select','audio','video','iframe','embed'])and x['disabled']==0 for x in inventory)
(T/'natural-true-zoom-verification.json').write_text(json.dumps({'testId':'A11Y-R01-final','status':'PASS','at':now,'sourceFingerprint':new['sourceFingerprint'],'procedure':'NativeChrome200%UI observed; readonly actualCSS590x378 withCSSzoom1; finalAbout fresh, eight unchanged routes via exact rawCSS/fonts/JS plusHTML/payload BuildID-only bridge; actual main visibletext vs finalHTML equal. Only non-paintedSVG title/desc excluded; original failed comparison retained.','rows':rows,'manualExitCode':None},indent=2))
(T/'public-ui-inventory.json').write_text(json.dumps({'status':'PASS','at':now,'sourceFingerprint':new['sourceFingerprint'],'basis':'Final exportednine HTML plus corresponding actualbrowserDOM/AX/network snapshots. No synthetic controls added. No application single-character shortcuts, timed content, drag/auth/payment/multistep flow in actualscope.','routes':inventory},indent=2))
for name in ['pages-true-zoom-200.json','natural-about-true-zoom-200.json','task012-zoom-200-original.jpg']:
 d=T/'native-at'/name;d.parent.mkdir(exist_ok=True);shutil.copyfile(S/name,d)
(T/'final-contrast-coverage.json').write_text(json.dumps({'status':'PASS','at':now,'finalSource':new['sourceFingerprint'],'oldSnapshot':'979a9799','oldUnaffectedStates':51,'oldUnaffectedNodes':630,'oldUnchangedPASS':618,'oldOccludedStateOnlyNA':12,'newAboutStates':6,'newAboutNodes':78,'newAboutPASS':78,'bridge':'natural-height-runtime-bridge.json','oldRaw':'contrast-final-pages-resolution.json','newRaw':'contrast-about-natural-resolution.json','meaning':'Versionedcoverage only; does not relabel all57 scans as freshlyrerun onfinalsource.'},indent=2))
for name in ['task012-keyboard-focus-desktop.png','task012-mobile-navigation.png','task012-reflow-320.png','task012-contrast-states.png']:
 src=T/'runs/pages-final-2026-11-19T10-20-27-370Z'/name;shutil.copyfile(src,R/'docs/screenshots'/name)
print('Finalzoomtext/geometry/inventory and four original screenshot byte copies completed')
