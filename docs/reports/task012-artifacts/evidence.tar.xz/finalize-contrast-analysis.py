from pathlib import Path
from datetime import datetime,timezone
from collections import defaultdict,Counter
import json,re,hashlib,itertools
base=Path('/tmp/xk-task012');root=Path('/workspace/xk-website');inventory=json.loads((base/'contrast-node-inventory.json').read_text());captures=json.loads((base/'contrast-evidence/captures.json').read_text());pixels=json.loads((base/'contrast-evidence/pixel-adjacent-background-samples.json').read_text());by_pixel={r['index']:r for r in pixels['rows']};selfcheck=json.loads((base/'contrast-source-self-check.json').read_text())
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def rgb(s):return tuple(float(x)for x in re.findall(r'[\d.]+',s)[:3])
def lum(c):return sum((v/255/12.92 if v/255<=.04045 else((v/255+.055)/1.055)**2.4)*w for v,w in zip(c,(.2126,.7152,.0722)))
def blend(bg,fg,a):return tuple(b*(1-a)+f*a for b,f in zip(bg,fg))
def bound(fg,bg,patterns):
 layers=[((25,184,213),.12)]if patterns==('brand-pattern-gradient',)else[((49,87,213),.07)]
 if bg=='rgb(16, 26, 51)':layers=[((49,87,213),.09),((25,184,213),.12)]
 colors=[]
 for bits in itertools.product((0,1),repeat=len(layers)):
  color=rgb(bg)
  for bit,(stop,alpha)in zip(bits,layers):color=blend(color,stop,bit*alpha)
  colors.append(color)
 if fg.startswith('oklab'):
  # The source is white/80. 254 is a conservative lower channel bound for
  # its near-white computed OKLab serialization; use independent extrema.
  foreground_min=min(lum(blend(c,(254,254,254),.8))for c in colors)
  value=(foreground_min+.05)/(max(lum(c)for c in colors)+.05)
 else:
  value=(min(lum(c)for c in colors)+.05)/(lum(rgb(fg))+.05)if lum(rgb(fg))<min(lum(c)for c in colors)else(lum(rgb(fg))+.05)/(max(lum(c)for c in colors)+.05)
 return value,{'layers':layers,'backgroundEndpointRgb':colors,'method':'Continuous alpha bounded by full source stops; masks can only reduce opacity. Monotone channel/luminance extrema bound the complete layer range. Alpha foreground uses independent worst foreground/background extrema.'}
groups=defaultdict(list)
for row in inventory:groups[(row['foreground'],row['base'],tuple(row['patterns']),row['threshold'])].append(row)
group_rows=[];node_group={}
for n,(key,rows)in enumerate(groups.items(),1):
 fg,bg,patterns,threshold=key;gid=f'CONTRAST-G{n:02}';required=float(threshold.split(':')[0])
 if not patterns:
  group_rows.append({'id':gid,'nodes':len(rows),'reason':'bgOverlap, not bgGradient','status':'PENDING','manualDisposition':'Separate opaque-disclosure visibility review; not incorrectly counted as gradient contrast. Normal visible counterparts are covered by the gradient bounds.'});continue
 lower,proof=bound(fg,bg,patterns);covered=lower>=required
 entry={'id':gid,'nodes':len(rows),'foreground':fg,'base':bg,'patterns':patterns,'requiredRatio':required,'baselineLowerBound':lower,'baselineDisposition':'PASS_BY_CONSERVATIVE_COMPOSITION'if covered else'INCONCLUSIVE_BY_GLOBAL_BOUND','proof':proof,'members':[{'scan':r['scan'],'selector':r['selector'],'computedSource':r['source']}for r in rows]}
 if not covered:
  after_lower,_=bound('rgb(23, 32, 51)',bg,patterns);entry.update({'sourceResolution':'Use existing foreground only at these gradient-exposed instances','predictedAfterForeground':'rgb(23, 32, 51)','predictedAfterLowerBound':after_lower,'afterRuntimeAcceptance':'PENDING fresh actual computed styles/build'})
 group_rows.append(entry)
 for r in rows:node_group[(r['scan'],r['selector'])]=gid

def mapping(record):
 b=record['baseline'];scan=b['scan'];s=b['selector'];route=scan.rsplit('-',1)[0]if scan.endswith(('-375','-1440'))else'home';p='src/components/sections/';role='';selector=''
 if route=='home':
  cta=s=='.max-w-2xl';file=p+('home-contact-cta.tsx'if cta else'home-hero.tsx');role='CTA description'if cta else'Hero description';selector='#contact p.type-body-lg'if cta else'section[aria-labelledby="home-title"] p.type-body'
 elif route=='about':
  cta=s=='.max-w-2xl.mt-5.type-body-lg';file=p+('about/about-cta.tsx'if cta else'about/about-hero.tsx');scope='#about-next-step'if cta else'section[aria-labelledby="about-page-title"]';role='CTA description'if cta else'Hero breadcrumb'if'aria-current'in s or'href='in s else'Hero description';selector=scope+(' p.type-body-lg'if cta else' [aria-current="page"]'if'aria-current'in s else' nav a[href]'if'href='in s else' p.type-body')
 elif route in ['corporate-website','enterprise-management','integration-hub']:
  file=p+'portfolio/project-detail.tsx'
  if'aria-current'in s:role='Project breadcrumb current item';selector='#project-overview [aria-current="page"]'
  elif'href'in s:role='Project breadcrumb link';selector='#project-overview nav a[href]'+(' (index1)'if'portfolio'in s else' (index0)')
  elif s=='.mt-6.type-body-lg.text-muted-foreground':role='Project summary';selector='#project-overview p.type-body-lg.mt-6'
  elif s=='.text-muted-foreground.type-body-sm[lang="en"]':role='ProjectTypeLabel scoped consumer';selector='#project-overview .mt-6.flex > p'
  elif s.startswith('.sm\\:mb-6'):role='Project overview Heading description scoped consumer';selector='#project-overview-title + p'
  else:role='Project next-step Heading description scoped consumer';selector='#project-next-step-title + p'
 else:
  folders={'services':'services/services-hero.tsx','solutions':'solutions/solutions-hero.tsx','portfolio':'portfolio/portfolio-hero.tsx','contact':'contact/contact-hero.tsx'}
  cta=(route in ['solutions','portfolio']and s=='.max-w-2xl.mt-5.type-body-lg')or(route=='contact'and s=='.mt-5.max-w-3xl.type-body-lg')
  if cta:file=p+route+'/'+route+'-cta.tsx';role='CTA description';selector={'solutions':'#solutions-next-step p.type-body-lg','portfolio':'#portfolio-next-step p.type-body-lg','contact':'#contact-next-step p.type-body-lg'}[route]
  else:
   file=p+folders[route];scope={'services':'section[aria-labelledby="services-page-title"]','solutions':'#solutions-hero','portfolio':'#portfolio-hero','contact':'#contact-hero'}[route]
   if s=='.max-w-64':role='Figure slogan';selector=scope+' figcaption p.type-body-sm'
   elif'aria-current'in s:role='Hero breadcrumb current item';selector=scope+' [aria-current="page"]'
   elif'href='in s:role='Hero breadcrumb link';selector=scope+' nav a[href]'
   else:role='Hero description';selector=scope+(' p.type-body-lg'if route=='services'else' > .xk-container > div > p.type-body-lg')
 assert (root/file).exists();return{'sourceFile':file,'role':role,'afterStableSelector':selector,'change':'local className only: text-muted-foreground to existing text-foreground; shared-label/Heading descriptions use existing className direct-child override','sharedApiChange':False}
resolutions=[]
for r in captures['rows']:
 m=mapping(r);gid=node_group[(r['baseline']['scan'],r['baseline']['selector'])];g=next(g for g in group_rows if g['id']==gid);resolutions.append({'index':r['index'],'groupId':gid,'scan':r['baseline']['scan'],'baselineSelector':r['baseline']['selector'],'text':r['baseline']['text'],'baselineColor':r['observed']['color'],'baselineFontSize':r['observed']['fontSize'],'baselineFontWeight':r['observed']['fontWeight'],'baselineCapture':r['screenshot'],'baselineAdjacentBackgroundSample':by_pixel[r['index']],**m,'predictedAfterColor':'rgb(23, 32, 51)','predictedAfterLowerBound':g['predictedAfterLowerBound'],'sourceChangeStatus':'COMPLETE','finalRenderedAcceptance':'PENDING'})
assert len(resolutions)==94 and len({r['index']for r in resolutions})==94
assert set(r['sourceFile']for r in resolutions)==set(r['file']for r in selfcheck['files'])
summary={'totalIncompleteNodes':237,'bgGradientNodes':234,'bgOverlapNodes':3,'styleGroups':18,'gradientGroups':15,'baselineCoveredByConservativeGroupBounds':sum(g['nodes']for g in group_rows if g.get('baselineDisposition')=='PASS_BY_CONSERVATIVE_COMPOSITION'),'baselineGlobalBoundInconclusive':94,'actualOriginalCaptures':94,'adjacentPixelSamplesBelow4_5':sum(r['baselineAdjacentBackgroundSample'].get('below4_5',False)for r in resolutions),'rootManuallyConfirmedBaselineFailure':'Portfolio Hero375 sample018: foreground102/112/133 against original adjacent background225/241/247, ratio4.2940902823533005, normal17px/400 text. Root confirmed on actual PNG.','sourceFilesModified':12,'all94SourceMappedAndPatched':True,'minimumPredictedAfterBoundFor94':min(r['predictedAfterLowerBound']for r in resolutions),'afterRenderedAcceptance':'PENDING'}
report={'task':'Task012 gradient contrast','issue':'A11Y-CONTRAST-GRADIENT-MUTED','analysisUpdatedAt':datetime.now(timezone.utc).isoformat(),'reviewer':'/root/ui_components','status':'PENDING','baselineIssueStatus':'FAIL','sourceFixStatus':'COMPLETE_FROZEN','finalRuntimeAcceptance':'PENDING','base':'8e42c647646d20873789c54367132901746a58bf','summary':summary,'baselineSources':{'summary':str(base/'baseline-summary.json'),'nodeInventory':str(base/'contrast-node-inventory.json'),'originalComputedAncestry':'Each node points to its immutable baseline needs-review JSON; these are actual foreground/font/opacity/ancestry observations, not token-only assumptions.','brandPatternSource':str(root/'src/app/globals.css'),'brandPatternSourceSha256':sha(root/'src/app/globals.css')},'boundMethod':{'stopColors':{'gradient':'accent rgb25,184,213 alpha0..0.12; transparent at65%','kaleidoscope':'secondary rgb49,87,213 alpha0..0.07; opacity mask can only reduce this','grid':'secondary rgb49,87,213 alpha0..0.09; conservatively included together with cyan for dark Home figure'},'foregroundOpacity':'Actual baseline cumulative opacity1, no text shadow/filter/blend override observed. White/80 uses conservative near-white channel254 and independent extrema.','notRoundedIntoPass':'4.496416 and4.477256 are below4.5 and remain inconclusive, never rounded to PASS.','newForeground':'Existing foreground Token #172033 only at affected Hero/CTA instances; no HEX or global styles changed.'},'groups':group_rows,'resolutions94':resolutions,'sourceSelfCheck':{'file':str(base/'contrast-source-self-check.json'),'sha256':sha(base/'contrast-source-self-check.json'),'result':selfcheck},'actualCaptureEvidence':{'manifest':str(base/'contrast-evidence/captures.json'),'sha256':sha(base/'contrast-evidence/captures.json'),'requested':94,'captured':94,'nativeUnmodifiedPng':True,'domMutation':False,'axeRescan':False,'firstAttempt':{'receipt':str(base/'contrast-capture-process.json'),'status':'FAIL','cause':'Sandbox setsockopt denied Chromium launch, before any website capture; retained as tooling/environment failure.'},'actualCompletedAttempt':{'receipt':str(base/'contrast-capture-process-retry.json'),'status':'PASS','actualExitCode':0},'pixelEvidence':str(base/'contrast-evidence/pixel-adjacent-background-samples.json'),'pixelMethod':'Original screenshot clean5x5 gradient-color patch adjacent to observed solid foreground ink; coordinates preserved. Root manually confirmed018. Other low samples are retained as observations, not automatically all declared violations.'},'manualViewsPerformed':['018-portfolio-375.png','009-services-375.png'],'untouched':['MobileNavigation frozen blur handler','globals.css/BrandPattern rules/8HEX/Logo/font','SectionHeading and ProjectTypeLabel APIs/shared code','All text/content/links/ARIA/markup geometry and component logic; source AST equality after removingclassName verified'],'followup':'Fresh final production/Pages computed values and incomplete-node coverage remain required. This file does not substitute source prediction for final rendered acceptance.','limits':['94 new screenshots used closed disclosure;10 originally listed under home-menu-open are equivalent underlying gradient nodes when offscreen/visible, not proof of the3 overlapped nodes.','Three bgOverlap nodes remain separately scoped to disclosure visibility/manual review, not folded into gradient bounds.','No further sampling was done after root authorized the focused12file source fix.']}
p=base/'contrast-analysis.json';p.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'file':str(p),'sha256':sha(p),'summary':summary,'sourceModifiedFiles':sorted(set(r['sourceFile']for r in resolutions))},ensure_ascii=False,indent=2))
