import collections,datetime,json,pathlib
root=pathlib.Path('/tmp/xk-task012');entries=[]
for receipt in sorted(root.glob('*process.json')):
 e=json.loads(receipt.read_text());command=e.get('command',[])
 if '/tmp/xk-task012/browser.cjs' not in command:continue
 matches=[]
 for p in (root/'runs').glob('*/results.json'):
  r=json.loads(p.read_text())
  if r.get('command')==command:matches.append((p,r))
 assert len(matches)==1,(str(receipt),len(matches))
 p,r=matches[0];scope='plan-only' if r.get('planOnly') else 'baseline' if '--audit=baseline' in command else 'final'
 entries.append({'scope':scope,'mode':r['mode'],'command':command,'receipt':str(receipt),'log':e['logFile'],'actualProcessExitCode':e['exitCode'],'startedAt':e['startedAt'],'finishedAt':e['finishedAt'],'sourceFingerprint':r.get('sourceFingerprint'),'resultFile':str(p),'complete':bool(r.get('completionToken') and r.get('finishedAt') and r.get('expectedTests')==len(r['tests'])),'expectedCount':r.get('expectedTests'),'actualCount':len(r['tests']),'status':r['status'],'technicalStatus':r['technicalStatus'],'taskStatus':r['taskStatus'],'auditExecutionStatus':r.get('auditExecutionStatus'),'counts':r.get('counts'),'coverage':r.get('coverage'),'toolSources':r.get('toolSources')})
index={'task':'Task012 Accessibility','generatedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'executions':entries,'note':'Collector exit0/completion is distinct from website criteria status;baseline failures/raw incomplete remain unchanged. Real AT/zoom and incomplete adjudication are separate Root evidence.'};(root/'execution-record.json').write_text(json.dumps(index,ensure_ascii=False,indent=2)+'\n')
finals=[e for e in entries if e['scope']=='final'];summary={'sourceFingerprint':json.loads((root/'frozen-code.json').read_text())['fingerprint'],'baselineSummary':str(root/'baseline-summary.json'),'modes':{},'manualEvidence':'Root owns real AT/native zoom and contrast incomplete adjudication;these automatic results are not a complete certification'}
for mode in ['general','pages']:
 subset=sorted([e for e in finals if e['mode']==mode],key=lambda e:e['startedAt']);selected={}
 for e in subset:
  if e['sourceFingerprint']!=summary['sourceFingerprint']:continue
  for t in json.loads(pathlib.Path(e['resultFile']).read_text())['tests']:selected[t['testId']]={**t,'resultFile':e['resultFile'],'receipt':e['receipt'],'actualProcessExitCode':e['actualProcessExitCode']}
 counts=dict(collections.Counter(t['status'] for t in selected.values()));summary['modes'][mode]={'technicalStatus':'PENDING' if not subset else 'FAIL' if any(t['status']=='FAIL' for t in selected.values()) else 'PASS','counts':counts,'assertions':list(selected.values()),'latestResult':subset[-1]['resultFile'] if subset else None}
(root/'acceptance-summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n');print(json.dumps({m:{'status':v['technicalStatus'],'counts':v['counts']} for m,v in summary['modes'].items()}))
