from pathlib import Path
from datetime import datetime,timezone
from collections import defaultdict,Counter
import json,itertools,hashlib
base=Path('/tmp/xk-task012');original=json.loads((base/'contrast-final-pages-observations.json').read_text());spacing=json.loads((base/'contrast-final-pages-spacing-observations.json').read_text());idx=json.loads((base/'final-pages-incomplete-index.json').read_text());replace={(r['testId'],r['selector']):r for r in spacing['rows']};observations=[replace.get((r['testId'],r['selector']),r)for r in original['rows']];assert len(observations)==708

def lum(c):return sum((v/255/12.92 if v/255<=.04045 else((v/255+.055)/1.055)**2.4)*w for v,w in zip(c,(.2126,.7152,.0722)))
def blend(bg,fg,a):return tuple(b*(1-a)+f*a for b,f in zip(bg,fg))
def full_bound(o):
 layers=[];patternNames=[]
 for p in o['patterns']:
  assert p['opacity']=='1'and p['filter']=='none'and p['backdropFilter']=='none'and p['mixBlendMode']=='normal'
  classes=p['className'].split();name=next(c for c in classes if c.startswith('brand-pattern-'));patternNames.append(name)
  if name=='brand-pattern-grid':layers.extend([((49,87,213),.09),((49,87,213),.09)]);assert p['backgroundImage'].count('linear-gradient(')==2
  elif name=='brand-pattern-gradient':layers.append(((25,184,213),.12));assert '/ 0.12)' in p['backgroundImage']
  elif name=='brand-pattern-kaleidoscope':layers.append(((49,87,213),.07));assert '/ 0.07)' in p['backgroundImage']
  else:raise AssertionError(name)
 assert layers
 assert all(a['opacity']=='1'and a['filter']=='none'and a['backdropFilter']=='none'and a['mixBlendMode']=='normal'and a['textShadow']=='none'for a in o['ancestors'])
 bg=tuple(o['nearestOpaque']['backgroundRgba'][:3]);assert o['nearestOpaque']['backgroundRgba'][3]==255
 colors=[]
 for bits in itertools.product((0,1),repeat=len(layers)):
  color=bg
  for bit,(stop,alpha)in zip(bits,layers):color=blend(color,stop,bit*alpha)
  colors.append(color)
 # Per-channel box bounds conservatively cover all continuous alpha values,
 # not only sample pixels or the extrema at a particular viewport.
 bgMin=tuple(min(c[k]for c in colors)for k in range(3));bgMax=tuple(max(c[k]for c in colors)for k in range(3))
 e=o['element'];alpha=e['rgba'][3]/255;fg=tuple(e['rgba'][:3]);
 if e['color'].startswith('oklab'):fg=(254,254,254) # source white/80; conservative rounding bound
 fgMin=blend(bgMin,fg,alpha);fgMax=blend(bgMax,fg,alpha)
 if lum(fgMin)>=lum(bgMax):value=(lum(fgMin)+.05)/(lum(bgMax)+.05)
 elif lum(bgMin)>=lum(fgMax):value=(lum(bgMin)+.05)/(lum(fgMax)+.05)
 else:value=1
 return value,{'patternNames':patternNames,'layers':layers,'baseRgb':bg,'backgroundChannelLowerBound':bgMin,'backgroundChannelUpperBound':bgMax,'actualForegroundRgba':e['rgba'],'foregroundConservativeRgb':fg,'foregroundAlpha':alpha,'method':'Actual computed foreground, opacity, ancestry and paint-ordered source stops. Continuous alpha/masks bounded by composited per-channel extrema; both grid gradients included; alpha foreground uses independent worst foreground/background extrema.'}

resolved=[];groups=defaultdict(list)
for n,r in enumerate(observations,1):
 o=r['observed'];e=o['element'];value,proof=full_bound(o);assert value>=4.5,(r['testId'],r['selector'],value)
 entry={'index':n,'testId':r['testId'],'width':r['width'],'url':r['url'],'rawAxe':r['raw'],'rawDom':r['dom'],'selector':r['selector'],'actualText':o['text'],'actualColor':e['color'],'actualForegroundRgba':e['rgba'],'actualFontSize':e['fontSize'],'actualFontWeight':e['fontWeight'],'actualTextRect':e['rect'],'rawReason':r['messageKeys'],'originalAxeRequiredRatio':r['expectedContrastRatio'],'evaluatedRequiredRatio':4.5,'lowerBound':value,'proof':proof,'spacingOverrideApplied':r['testId'].find('spacing')>=0,'observationSource':str(base/('contrast-final-pages-spacing-observations.json'if'spacing'in r['testId']else'contrast-final-pages-observations.json'))}
 if r['messageKeys']==['bgGradient']:
  entry.update(status='PASS',decision='All visible text passes the stricter4.5 ratio using complete continuous gradient bounds, including large text; no token-only or screenshot-only assumption.')
 else:
  assert r['messageKeys']==['bgOverlap'];p=o['panel'];assert p and p['expanded']=='true'and p['opacity']=='1'and p['backgroundRgba']==[255,255,255,255]and p['filter']=='none'and p['backdropFilter']=='none'and not o['focused']
  t=e['rect'];pr=p['rect'];complete=pr['x']<=t['x']and pr['y']<=t['y']and pr['right']>=t['right']and pr['bottom']>=t['bottom'];hits=sum(h['disclosure']for h in o['hits']);entry.update({'actualPanel':p,'actualNineHits':o['hits'],'nineDisclosureHits':hits,'completeOpaqueContainment':complete,'focused':o['focused']})
  if complete:
   assert hits==9
   entry.update(status='N/A',decision='Only this completely occluded underlying text in expanded Contact disclosure state is not a visible contrast target. Actual opaque panel contains the full text rect and all9 top hits belong to disclosure. Closed visible counterpart passes same complete gradient bound. Not a page-level N/A.')
  else:
   assert t['y']<pr['bottom']<t['bottom']and 0<hits<9
   entry.update(status='PASS',decision='Partially occluded description remains applicable: visible remainder below panel passes4.5 under the full gradient bound; occluded portion is not visible. This entire node is not marked N/A.',visibleRemainderBelowPanel={'x':t['x'],'y':pr['bottom'],'width':t['width'],'height':t['bottom']-pr['bottom']})
 key=(e['color'],o['nearestOpaque']['backgroundColor'],tuple(proof['patternNames']),entry['status']);groups[key].append(entry);resolved.append(entry)
counts=Counter(r['status']for r in resolved);assert counts=={'PASS':696,'N/A':12};assert sum('spacing'in r['testId']for r in resolved)==len(spacing['rows']);groupRows=[]
for n,(k,members)in enumerate(groups.items(),1):
 gid=f'FINAL-CONTRAST-{n:02}';row={'groupId':gid,'color':k[0],'base':k[1],'patterns':k[2],'status':k[3],'count':len(members),'minimumLowerBound':min(r['lowerBound']for r in members),'members':[r['index']for r in members]};groupRows.append(row)
 for m in members:m['groupId']=gid
result={'task':'Task012 final Pages manual/math contrast resolution','resolvedAt':datetime.now(timezone.utc).isoformat(),'status':'PASS','sourceFingerprint':original['sourceFingerprint'],'scope':'All57 fresh axe raw scans /708 color-contrast incomplete targets resolved; raw axe remains unchanged. This contrast resolution is not full WCAG certification or substitute for Root AT/zoom/manual review.','originalIndex':str(base/'final-pages-incomplete-index.json'),'originalRawScans':57,'originalIncompleteNodes':708,'reasonCounts':dict(Counter(r['rawReason'][0]for r in resolved)),'resolutionCounts':dict(counts),'visibleGradientPASS':694,'partiallyOccludedVisibleRemainderPASS':2,'completelyOccludedStateOnlyNA':12,'minimumAllApplicableLowerBound':min(r['lowerBound']for r in resolved if r['status']=='PASS'),'minimumChangedForegroundLowerBound':min(r['lowerBound']for r in resolved if r['actualForegroundRgba']==[23,32,51,255]),'actualProcesses':[{'receipt':str(base/'contrast-final-pages-process.json'),'exitCode':0},{'receipt':str(base/'contrast-final-pages-spacing-process.json'),'exitCode':0}],'spacingEvidence':'The9 text-spacing scans were separately recollected with the exact QA CSS override. Those actual observations replace corresponding normal-layout records; no contrast inference depends on untested spacing geometry.','gridCorrection':'Two9% grid linear-gradient layers, not a single9% layer, are conservatively composed before12% cyan. This fixes an underconservative earlier darkHome bound; all darkHome text still passes, and all-applicable minimum remains5.13330658. Earlier baseline/final-normal files preserved.','boundMethod':groupRows[0]and resolved[0]['proof']['method'],'groups':groupRows,'nodes':resolved,'limits':['N/A is exactly12 fully occluded Contact menu-state text nodes at320/375/768; normal visible text and all menu text remain applicable.','Two Contact description nodes at375/768 are partially visible and explicitly PASS for their visible remainder, never blanket N/A.','No source code, raw axe, screenshot pixels, brand tokens or runtime behavior changed during this analysis.','Pointer cancellation/viewport orientation and7UI finite state colors are separate actual evidence files.']}
p=base/'contrast-final-pages-resolution.json';p.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items()if k not in ['nodes','groups','limits']},ensure_ascii=False,indent=2));print('SHA256',hashlib.sha256(p.read_bytes()).hexdigest())
a=json.loads((base/'contrast-analysis.json').read_text());a['finalPagesResolution']={k:v for k,v in result.items()if k not in ['nodes','groups']};a['finalPagesResolution']['file']=str(p);a['finalPagesResolution']['sha256']=hashlib.sha256(p.read_bytes()).hexdigest();a['finiteUiPairResolution']=str(base/'contrast-ui-pairs.json');a['pointerCancellationAndOrientation']=str(base/'pointer-orientation-pages.json');a['finalRuntimeAcceptance']='PASS for all original237 normal nodes and all final708 Pages incomplete nodes, with explicitly scoped occluded-state N/A and finite UI color observations; complete WCAG/AT acceptance remains Root scope.';a['status']='PASS';(base/'contrast-analysis.json').write_text(json.dumps(a,ensure_ascii=False,indent=2)+'\n')
