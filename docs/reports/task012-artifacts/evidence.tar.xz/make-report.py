from pathlib import Path
from datetime import datetime,timezone
from collections import Counter
import json,hashlib,subprocess
T=Path('/tmp/xk-task012'); R=Path('/workspace/xk-website'); A=R/'docs/reports/task012-artifacts'
def read(p):return json.loads(Path(p).read_text())
def j(name):return read(T/name)
source=j('final-code-natural-height.json'); fp=source['fingerprint']
quality=[j('checks/'+n+'-natural-height.json')for n in ['npm-ci','tsc','lint','build','build-pages']]
assert all(x['exitCode']==0 and x['finishedAt'] for x in quality)
general=j('general-final-summary.json'); pages=j('pages-final-summary.json')
ng=read(sorted((T/'runs').glob('about-natural-general-*/results.json'))[-1]);np=read(sorted((T/'runs').glob('about-natural-pages-*/results.json'))[-1])
assert ng['technicalStatus']=='PASS' and np['technicalStatus']=='PASS' and len(ng['tests'])==6 and len(np['tests'])==12
assert j('about-natural-general-process.json')['exitCode']==0 and j('about-natural-pages-process.json')['exitCode']==0
bridge=j('natural-height-runtime-bridge.json');assert bridge['status']=='PASS'
contrast=j('contrast-about-natural-resolution.json');assert contrast['status']=='PASS'
zoom=j('natural-true-zoom-verification.json');assert zoom['status']=='PASS'
at=j('manual-at-verification.json');assert at['status']=='PASS'
original=j('acceptance-matrix.json');cm=j('wcag22-criteria-matrix.json')
now=datetime.now(timezone.utc).isoformat()
common={'os':'Linux;native desktopDebian13/X11','node':'24.22.1','npm':'11.9.0','browser':'Chromium156.0.8078.79','playwright':'1.65.1','axe':'4.14.1','sourceFingerprint':fp,'websiteBase':source['base'],'ordinaryUrl':'http://127.0.0.1:3090/','pagesUrl':'http://127.0.0.1:3091/xk-website/'}
observations={
'A11Y-F01':'九個公開路由／各自 Header、Footer、disclosure、錨點與互動清冊已實測；draft/dev/未知路由受保護。',
'A11Y-S01':'九頁單一 H1、適當 heading／具名 landmarks、zh-TW／英文區段與 DOM/AX；真 Orca 讀取代表旅程。',
'A11Y-T01':'979a 的57次 axe零violations；最後About定向6次零violations；原incomplete另有逐項判讀，未改寫原JSON。',
'A11Y-T02':'axe4.14.1實際tag含wcag22aa，raw passes含target-size；其餘2.2準則另作人工判斷。',
'A11Y-T03':'55項＝31A＋24AA，34 Required PASS、21有據N/A；不含已移除Parsing4.1.1，非整體認證。',
'A11Y-K01':'九頁skip/Tab/ShiftTab/Enter/Space/Escape、disclosure內外焦點、null blur與目錄旅程實測；新About320錨點補驗。',
'A11Y-K02':'原三頁遮蔽FAIL已保留；九頁離開選單自動關閉，不劫持新焦點，真200%／AT狀態亦可見。',
'A11Y-K03':'實際target geometry/axe target-size，九頁維持44px設計；無小於24px候選，未泛用例外。',
'A11Y-V01':'舊708 incomplete逐項＝696 PASS＋12僅完全遮蓋狀態N/A；新About另判讀。gradient最低5.1333，21 UI狀態最低4.9748。',
'A11Y-AT01':'真Orca48.1＋Chromium156＋Debian13：headings/landmarks/link/menu/CTA及Pages目錄開作品詳頁，225行真speech。',
'A11Y-S02':'原Logo幾何／SVG bytes不變；實際裝飾可忽略、品牌連結具名稱，原Provisional狀態保留。',
'A11Y-R01':'原生Chrome200%UI＋實際CSSviewport590×378、CSS zoom=1、DPR2；九頁文字完整／無水平溢出，最後About另補。',
'A11Y-R02':'九頁320 CSS px無頁面水平溢出；About自然高度修正後glyph/連結完整，無必要二維捲動。',
'A11Y-R03':'九頁1.5行高／2段距／.12字距／.16詞距；About兩次FAIL保留，最終320原斷言通過，無裁切候選。',
'A11Y-R04':'979a九頁×五寬45例；新About再五寬，明確依產物bridge沿用其他八頁，不冒稱全新45例。',
'A11Y-R05':'九頁reduce下scrollauto、過渡／動畫無長時效果；內容／導覽保持，未建立新的動態內容。',
'A11Y-F02':'所有實際站內links／anchors與BasePath、HTTP200、404/.nojekyll，目錄兩條真旅程；新Aboutanchor與目錄補驗。',
'A11Y-G01':'一般production dev/draft404，Pages排除dev/draft HTML與payload，未知slug404。',
'A11Y-F03':'完整原始network/console/runtime/storage，僅同源GET/HEAD、無未處理錯誤；HEAD原始cancel嚴格分類未忽略。',
'A11Y-G02':'九頁exact Title/Description/Canonical/OG/Twitter/minimalWebSite，noindex/nofollow、robots與Sitemap不發布保護不變。'}
evidence={
'A11Y-F01':['source-audit.json','pages-final-summary.json','public-ui-inventory.json'],
'A11Y-S01':['source-a11y-audit.json','section-heading-source-inventory.json','manual-at-verification.json','runs/ DOM/AX snapshots'],
'A11Y-T01':['pages-final-summary.json','contrast-final-pages-resolution.json','contrast-about-natural-resolution.json','runs/ axe-*.json'],
'A11Y-T02':['tool-preflight.json','runs/ raw axe passes/target-size'],
'A11Y-T03':['verification.json#criteria','wcag22-source.json'],
'A11Y-K01':['pages-final-summary.json','manual-at-verification.json','about-natural-pages-process.json'],
'A11Y-K02':['baseline-summary.json','pages-final-summary.json','manual-at-verification.json'],
'A11Y-K03':['runs/ audit/*-dom.json targets','runs/ axe-*.json target-size'],
'A11Y-V01':['contrast-final-pages-resolution.json','contrast-about-natural-resolution.json','contrast-ui-pairs.json'],
'A11Y-AT01':['manual-at-verification.json','at-observed-speech.log','manual-actions.jsonl'],
'A11Y-S02':['protected-source-check.json','runs/ DOM/AX snapshots','manual-at-verification.json'],
'A11Y-R01':['natural-true-zoom-verification.json','native-at/natural-about-true-zoom-200.json','zoom-screenshot-provenance.json'],
'A11Y-R02':['pages-final-summary.json','about-natural-pages-process.json','runs/ About geometry/glyph evidence'],
'A11Y-R03':['issue-about-spacing-clip.json','about-fix-pages-process.json','about-natural-pages-process.json'],
'A11Y-R04':['pages-final-summary.json','natural-height-runtime-bridge.json','about-natural-pages-process.json'],
'A11Y-R05':['runs/ A11Y-REG-A04-pages-motion'],
'A11Y-F02':['pages-final-summary.json','runs/ actuallinks anddirectoryjourneys'],
'A11Y-G01':['checks/build-pages-natural-height.log','runs/ protectionHTTP/export assertions'],
'A11Y-F03':['pages-final-summary.json','runs/ network-classification.json','runs/ network-raw.ndjson','about-natural-pages-process.json'],
'A11Y-G02':['runs/ exactmetadata/robots/protection assertions','checks/build-pages-natural-height.log']}
for i,row in enumerate(original['items']):
 row.update(environment=common,verifiedAt=now,commandProcedure=row.get('testItem'),exitCode=None,evidence=evidence.get(row['testId'],[]))
 if i<5:
  q=quality[i];row.update(status='PASS',actualResult='真實returnCode/exitCode0；未修改套件／lockfile。',commandProcedure=' '.join(q['command']),exitCode=q['exitCode'],evidence=['checks/'+['npm-ci','tsc','lint','build','build-pages'][i]+'-natural-height.json'])
 elif row['applicability']=='Optional':row.update(status='PENDING',actualResult='未選本輪行動AT／其他平台或受控Dev停用範例；不改稱N/A。')
 elif row['applicability']=='Not Applicable':row.update(status='N/A',actualResult='本輪九頁production清冊確認無該真實功能；未建立假表單／auth／drag／disabled／認證。',evidence=['public-ui-inventory.json','source-audit.json','runs/ actualDOM/controls/network'])
 else:row.update(status='PASS',actualResult=observations[row['testId']])
 row['exitCodeReason']='Actual command process exit above; manual/group observations have no independent command exit.'
criterionActual={
'1.1.1':'Logo等價名稱與裝飾aria-hidden經DOM/AX及真AT檢查，介面icons無雜訊。',
'1.3.1':'九頁heading/list/nav/section標記與AX具名稱，真AT能按heading／landmark定位。',
'1.3.2':'DOM/AX順序及真AT代表旅程一致；布局換欄不改內容閱讀順序。',
'1.3.3':'CTA／導覽有文字名稱，操作不僅以形狀、位置或方向指示。',
'1.3.4':'portrait/landscape布局可讀；Contact375×812／812×375真viewport轉換無鎖定／水平溢出。',
'1.4.1':'Planned／未確認狀態皆有實際文字；連結、按鈕、focus並非只靠顏色傳訊。',
'1.4.3':'原4.2941FAIL已修；最終gradient保守下界≥5.1333，UI文字≥4.9748，全部incomplete逐項。',
'1.4.4':'真Chrome200%與CSSviewport590×378，九頁main全文比對；新About高度／功能完整。',
'1.4.5':'正文為HTML文字；Logo屬品牌圖樣例外，無正文圖片文字或虛構作品圖。',
'1.4.10':'九頁320CSSpx無水平溢出；最終Aboutcard／文字／錨點可完整操作。',
'1.4.11':'Menu/X icons與適用focus輪廓具足對比；21狀態實測，裝飾淡邊線非必要識別資訊。',
'1.4.12':'實際覆寫四項間距；About保留初FAIL及min-h-maxFAIL，naturalheight最終glyph／clip／hit斷言通過。',
'2.1.1':'實際Tab/ShiftTab/Enter/Space/Escape、skip、anchors及目錄／CTA旅程可用。',
'2.1.2':'disclosure無trap，內部Tab保留展開，Tab離開保留原生新焦點、Escape回trigger。',
'2.3.1':'實際靜態內容無閃爍／頻閃；ReducedMotion與動畫清冊確認。',
'2.4.1':'首個可操作skiplink具可見focus、Enter至main，真AT亦能定位main。',
'2.4.2':'九頁Title各自精確唯一且描述目的，實際HTTP/DOM與真AT跨頁title確認。',
'2.4.3':'九頁焦點順序及About320新錨點實測，未改原生順序或造成隱藏tabstop。',
'2.4.4':'實際linknames結合section／article語境可理解，真AT選單及三作品連結名稱／URL確認。',
'2.4.5':'Footer完整網站目錄＋Portfolio分類overview；九頁實際完整9URL、兩種定位與鍵盤／AT真旅程。',
'2.4.6':'heading/label內容與實際purpose一致；九頁DOM/AX／真AT代表heading已讀。',
'2.4.7':'實測focus-visible／outline與鍵盤，五張真圖及native200% focus可見。',
'2.4.11':'原焦點全遮蔽FAIL已修，九頁Tab離開選單閉合，真200%／AT時主焦點可見。',
'2.5.2':'可信pointerdown後移出再pointerup沒有意外開啟或導航；正常click/tap仍可用。',
'2.5.3':'可見link文字及menu button名稱一致；icons decorative，不以aria-label覆蓋真文字。',
'2.5.8':'實際geometry及axe target-size覆蓋，維持44px控制項，沒有小於24px候選。',
'3.1.1':'最終九頁html lang=zh-TW，HTTP／DOM／AX確認。',
'3.1.2':'明確英文brand／headings有lang標示，技術詞依語境；source及DOM／真AT代表英文heading確認。',
'3.2.1':'Tab／focus只改focus視覺，不自動跨頁；真正Enter/Space或點擊才啟動操作。',
'3.2.2':'disclosure展開不意外改上下文；無表單輸入／自動提交流程。',
'3.2.3':'九頁共用header／footer／mobile順序一致，完整directory固定位置。',
'3.2.4':'共用相同labels與控制項名稱，menu開啟／關閉狀態語意可理解。',
'3.2.6':'所有頁面Contact入口位置／名稱一致，未確認管道不偽裝可收件；無漂移help機制。',
'4.1.2':'原生link/button與aria-expanded/controls/names，DOM/AX及真Orca collapsed/expanded朗讀實測。'}
for row in cm['criteria']:
 row.update(environment=common,verifiedAt=now,exitCode=None,applicabilityBasis='Actual public export/DOM/AX/control/network inventory plus targeted final About verification; original source rationale retained.')
 if row['applicability']=='Not Applicable':row.update(status='N/A',actualResult='最終九頁HTML／實際DOM／Network確認無此對應功能；依保留的適用性理由，本輪無媒體、表單／個資輸入、auth、drag、多手勢／motion、單字鍵捷徑、內容計時／自動更新、hover新增內容或status message。',evidence=['public-ui-inventory.json','source-audit.json','runs/ DOM/AX/network'])
 else:row.update(status='PASS',actualResult=criterionActual[row['id']],evidence=['verification.json#acceptance','manual-at-verification.json','pages-final-summary.json','natural-height-runtime-bridge.json','about-natural-pages-process.json','contrast-about-natural-resolution.json','natural-true-zoom-verification.json'])
assert len(cm['criteria'])==55 and Counter(x['status']for x in cm['criteria'])=={'PASS':34,'N/A':21}
verification={'task':'Task012 Accessibility','createdAt':now,'status':'PASS','scope':'Current local required acceptance complete, bounded by tested pages/states/tools; no certification or deployment inference','source':source,'environment':common,'acceptance':original['items'],'acceptanceCounts':dict(Counter(x['status']for x in original['items'])),'criteria':cm['criteria'],'criteriaCounts':dict(Counter(x['status']for x in cm['criteria'])),'versions':{'baseline':'3d00df42565635715b36078fb9a244bdac5fb001388dc26b0d40cef3989061eb','broadAudit':'979a979925237f16c5f1c6eef5e13a9e1fb9d08a891c424503084df6f3e48560','failedIntrinsicHeight':'5d2423411c3257f6fd84bce4f5dfe3797ddaa4877e4db2da0e8758f0f1c45385','final':fp},'qualityReceipts':quality,'broadGeneral':general,'broadPages':pages,'finalAboutGeneral':{'actualTests':len(ng['tests']),'counts':ng['counts'],'startedAt':ng['startedAt'],'finishedAt':ng['finishedAt']},'finalAboutPages':{'actualTests':len(np['tests']),'counts':np['counts'],'coverage':np['coverage'],'startedAt':np['startedAt'],'finishedAt':np['finishedAt']},'bridge':'natural-height-runtime-bridge.json','remoteAtReportTime':{'prCI':'PENDING','review':'PENDING','userMergeAuthorization':'Explicit currentuser request','merge':'PENDING','mainCI':'PENDING','deployment':'PENDING','publicSmoke':'PENDING'},'remotePolicy':'Actual later identifiers/results updated in the same PR body, no self-referential report commit.'}
A.mkdir(parents=True,exist_ok=True);(A/'verification.json').write_text(json.dumps(verification,ensure_ascii=False,indent=2)+'\n')
sourceSection=(T/'report-draft.md').read_text().split('## 來源、標準與新決議\n',1)[1].split('## Baseline 的實際結果',1)[0]
lines=['# Task 012 — Accessibility 實作與驗證報告','',f'報告時點：{now}。本機 Required 驗收完成；結果限於本報告的頁面、狀態及工具，不是完整無障礙認證。PR／合併／部署尚未發生的階段保留 PENDING，後續實際證據更新於同一 PR。','', '## 成果與版本','',f'- Base：`{source["base"]}`；分支：`feature/website-accessibility`。Task 011 已合併，初始工作目錄乾淨。使用者明確授權本次 Push／PR、CI 通過後合併及確認部署。',f'- 最終107檔 runtime map：`{fp}`；[逐項驗證](task012-artifacts/verification.json) 保存每檔SHA、指令、環境、預期／實際、Exit Code、狀態與證據。','- 四類最小修正：disclosure在焦點離開時關閉；Footer完整九頁網站目錄；十二個Hero／CTA的漸層小字改用既有foreground；About卡片移除比例高度限制，內容自然撐高。','- 保留既有八個Tokens、原Logo／字體、Next.js16.4.6／React19.3.1／strict TypeScript5.9.3／Tailwind4.3.3／shadcn／Lucide。package、lockfile、Next/TS設定、workflow及所有src/config、public素材均未改。','- 公開九頁：Home、About、Services、Solutions、Portfolio與三個registry詳頁、Contact。Contact無正式管道／表單，Portfolio三案仍PLANNED，Privacy草案／dev／Sitemap不公開，noindex/nofollow政策不變。','', '## 來源及規格','',sourceSection.strip(),'','## 問題、修正與失敗政策','', '| Issue／準則 | 原問題及嚴重度（人工分類） | 修正／實際結果 |','| --- | --- | --- |','| A11Y-FOCUS-OBSCURED-DISCLOSURE／2.4.11 | High；About、Services、Contact的Tab離開仍被白panel全遮，原三FAIL保留 | wrapper focus-leave關閉且不劫持新焦點；九頁鍵盤／真200%／AT重驗通過 |','| A11Y-NAV-245-01／2.4.5 | Moderate；三作品詳頁只有Portfolio分類card一個入口 | Footer完整網站目錄＋分類overview；九頁9URL、三詳頁鍵盤及真AT開Corporate成功 |','| A11Y-CONTRAST-GRADIENT／1.4.3 | Serious；17px/400小字foreground(102,112,133)對實際背景(225,241,247)為4.29409<4.5 | 既有foreground(23,32,51)對同樣本14.04257；保守全stop下界13.73833，Tokens不改 |','| A11Y-SPACING-ABOUT-CLIP／1.4.12 | Serious；320文字覆寫時figure底1068、link底1091.5，裁切23.5px，四字glyph超界 | 第一版min-h-max仍FAIL；最後移除aspect-square，以內容決定高度，五寬／spacing／glyph/hit／鍵盤錨點新驗通過 |','', 'Baseline collector30項／Exit0，網站為8PASS＋3FAIL＋19PENDING；19次axe零violations但237incomplete。這不是整站PASS。隔離git archive原base的Pages build真Exit0，失敗symlink fallback原Exit1另存；未修改目前repo產物來偽裝baseline。','', '後續979a完整普通21PASS，Pages41項＝40PASS＋1Disabled N/A，45響應式／57axe零violations，但Root沒有把About候選的collector PASS當最終驗收。Root實看裁切後建立FAIL；5d242修正的Pages12項10PASS＋2FAIL／真Exit1，僅實跑4axe，未補造為6次。最終76d565普通6PASS、Pages12PASS／真Exit0，包含5寬、6次新axe、320文字間距與實際glyph/target/clip/anchor。','', '最後一次修改只影響AboutHero。353項離線bridge確認204檔清冊、115fonts／13JS／3CSS逐byte同，其他8頁48份HTML／payload僅BuildID不同；About四份Flight/HTML真變動獨立保存，僅rendered-content view證實class移除、其他語意／文案／JSONLD不變。這是明確影響範圍與全新About補驗，沒有把舊57axe改稱新版本量測。','', '## 實際品質、Browser 與人工驗收','', '| 命令 | 最終實際Exit Code | 回執（封存相對路徑） |','| --- | --- | --- |']
for q in quality:lines.append('| `'+ ' '.join(q['command']) +'` | '+str(q['exitCode'])+' | `checks/'+Path(q['logFile']).name.replace('.log','.json')+'` |')
lines+=['','普通先建置／3090驗收，再建Pages／3091靜態預覽，避免混用.next。Node24.22.1、npm11.9.0、Playwright1.65.1、Chromium156.0.8078.79、axe4.14.1；受測URLs為loopback，BasePath為/xk-website。每個run保存開始／結束、真程序回執、count及completionToken。','', '57次原axe的708incomplete：694gradient＋2部分可見Contact文字PASS、12僅被opaque panel完全遮蓋且非focused之狀態N/A；不是整頁N/A。最終About六次axe另有當下computed styles逐項判讀，見contrast-about-natural-resolution.json。全gradient最低下界5.13331；雙9%grid白80%文字保守下界7.89493。七類UI的normal／hover／focus共21狀態，最低文字／子元素4.97475、focus輪廓下界5.13331。沒有停用規則、隱藏錯誤或改寫原incomplete。','', '真實AT為Debian13/X11＋Orca48.1＋AT-SPI2 2.56.2＋Chromium156＋SpeechDispatcher0.12/espeak-ng1.52。實際操作Home/Services headings、main／named landmarks、CTA跨頁、200% disclosure collapsed/expanded與焦點離開／Escape；Pages目錄與Orca32連結清單能讀三詳頁名稱／URL，鍵盤Activate後讀到Corporate heading1。保留225行當次SPEECH OUTPUT及逐步操作，不用AX Tree冒充AT。','', '原生Chrome200% UI已實看，實際CSSviewport590×378、DPR2、CSS zoom=1；九頁全文與最終HTML比對、無水平溢出／clipped leaf。最終About另讀實際aspectRatio auto、44px連結完整與全文。320CSSpx是獨立reflow／spacing測試；沒有以DPR或CSS zoom假充瀏覽器縮放。指標down後移出再up不意外啟動；Contact375×812／812×375／回portrait真viewport驗收通過。','', '完整九頁context40/40真after、123份document-before；216資源成功、606原始HEAD cancel經嚴格document/loader機制分類，unexpected0。最終About補驗另有fresh context/network記錄，沒有因標記為HEAD就忽略任意錯誤。所有請求同源GET/HEAD，沒有新增收件、Cookie/Storage寫入、外部媒體、Analytics或API。','', '## 33項規格驗收','', '| Test ID | 項目 | 適用性 | 狀態 |','| --- | --- | --- | --- |']
for row in original['items']:lines.append('| '+row['testId']+' | '+row['testItem']+' | '+row['applicability']+' | '+row['status']+' |')
lines+=['','25 Required PASS、6有據N/A、2 Optional PENDING。每列的程序／環境／預期／實際／真Exit或手動不適用原因／證據／限制見verification.json，沒有只用「測試通過」代替依據。','', '## WCAG 2.2 A／AA完整矩陣','', '| 準則／等級 | 結果 | 本輪判定依據 |','| --- | --- | --- |']
for row in cm['criteria']:lines.append('| '+row['id']+' '+row['title']+'／'+row['level']+' | '+row['status']+' | '+row['actualResult'].replace('|','／')+' |')
lines+=['','34項Required PASS、21項N/A。N/A基於實際無媒體／表單／auth／多步輸入／drag／motion／單字鍵捷徑／內容時間限制／hover新增內容／status message等清冊，不代表沒環境或沒測。標準全文段落、唯一Test ID、原判定理由與證據映射存verification.json。','', '## 截圖與人工視覺檢查','', 'Root實看指定五張與About修正前後：焦點可辨、320換行完整、展開menu可操作、漸層文字可讀、Logo比例及Footer目錄未失真。Screenshot輔助視覺，不替代AT／數值證據。','']
for name,label in [('keyboard-focus-desktop','桌面keyboard focus'),('mobile-navigation','手機disclosure'),('zoom-200','原生Chrome200% UI'),('reflow-320','320 CSS px'),('contrast-states','對比與Footer focus')]:lines.append(f'- [{label}](../screenshots/task012-{name}.png)')
lines+=['', '原生截圖原始JPEG封存；指定PNG為相同解碼像素的無損格式轉存，未裁切、縮放或修圖。四張其他PNG來自實際Pages狀態。它們的Home／Contact／Footer在最終bridge保持相同runtime／CSS，沒有把不同頁舊圖冒充新About；About另有本輪真實前後診斷PNG。','', '## 檔案、文件與完整性','']
files=subprocess.check_output(['git','diff','--name-only',source['base']],cwd=R,text=True).splitlines();files+=['docs/reports/task012-implementation.md','docs/reports/task012-artifacts/{README.md,verification.json,manifest.json,evidence.tar.xz}','docs/screenshots/task012-{keyboard-focus-desktop,mobile-navigation,zoom-200,reflow-320,contrast-states}.png']
for p in files:lines.append('- `'+p+'`')
lines+=['','22份Markdown／118個href機械rebasing因應main文件搬移；原正文／標題／歷史數據保持，有剝除href後全文比對證據。保留根目錄完整implementation history與reports內舊前綴快照。AGENTS更新Task012規則、README／task索引／根notes追加本次入口。未重初始化或修改文件Repository。','', '## Known Issues及後續責任','', '- 沒有未解決的本次Required驗收FAIL／BLOCKED。保留所有原始網站FAIL、工具FAIL與修正重驗，不改寫或刪除。','- 行動VoiceOver/TalkBack、NVDA/Firefox／其他平台、受控Dev disabled範例與真實使用者研究未執行，兩個Optional項目保持PENDING；這個範圍不是全面認證或全裝置保證。','- Owner需另行處理最新品牌中文名、Logo03核准／Provisional與經營模式文案差異；本次只讀並記錄，不改品牌決策。法律/controller/effectiveDate/rightsContact仍無核准，不開放Privacy或Contact收件。','- main已刪除alternate originals造成14個歷史relative link缺口；固定版本參考保留，本次不復原使用者移除的檔案。其餘本輪新增連結須實際存在。','- DevTools UI受組織政策阻擋，沒有繞過；以原生UI真zoom＋支援的Browser只讀DOM取得viewport。初次bs4工具缺失改標準庫；SVG title僅accessible name非painted text，全文比較修正精確排除此類標記後重驗，未排除真正文。','- 對比定位工具兩次FAIL、隔離Turbopack symlink失敗、舊About診斷未分類HEAD原Exit1等原始限制皆保留。QA network classifier未放寬。','- 原生專屬browser清理實際return0；Orca/SD child0，但AT launcher因外部停止核心程序真exit1。這是工具生命週期結果，不冒作網站失敗或憑空改成0；伺服器由owned group停止的143亦另列。','', '## PR、合併及部署界線','', '本報告與本機證據先於PR完成。完整Diff、格式／路徑／連結／機密與產物檢查後，Commit／Push feature，建立main為base的PR。當時PR CI、Review、merge、main CI、部署、公開Smoke仍為PENDING；使用者本輪合併授權已明確，不再要求相同確認。','', '依同一PR後續實際紀錄核對最終head、jobs、下載artifact與本機受測CSS／font／頁面；CI成功不等於人工Review批准。獲授權合併後，另外確認mergeSHA對應main CI／github-pages部署及公開九頁／資源／BasePath／metadata／noindex／保護。沒有改workflow、DNS、Secrets或發布未審feature preview；不把本報告完成或PR artifact當正式部署成功。','', '[原始證據操作說明](task012-artifacts/README.md)提供真實logs、JSON與工具快照；後續遠端識別碼更新同PR，不為記錄自身SHA再提交循環文件。','']
(R/'docs/reports/task012-implementation.md').write_text('\n'.join(lines))
print(json.dumps({'status':'PASS','sourceFingerprint':fp,'acceptance':verification['acceptanceCounts'],'criteria':verification['criteriaCounts'],'reportLines':len(lines)},ensure_ascii=False))
