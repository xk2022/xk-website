import os,pathlib,json,subprocess,time,threading,wave,socket
w=pathlib.Path('/tmp/xk-task012');env=os.environ.copy();env.update(json.loads((w/'at-runtime-env.json').read_text()));command=[str(w/'runtime/usr/bin/speech-dispatcher'),'-s','-c','unix_socket','-S',str(w/'speechd.sock'),'-C',str(w/'speech-config'),'-m',str(w/'runtime/usr/lib/speech-dispatcher-modules'),'-P',str(w/'speechd.pid'),'-t','0'];log=open(w/'tts-preflight-final-server.log','w');p=subprocess.Popen(command,env=env,stdout=log,stderr=subprocess.STDOUT);result={'scope':'Real SpeechDispatcher/espeak-ng engine preflight only, not website/AT acceptance','command':command,'pid':p.pid,'spokenDiagnostic':'Runtime audio preflight.','status':'PENDING'}
try:
 for _ in range(100):
  try:
   probe=socket.socket(socket.AF_UNIX);probe.connect(str(w/'speechd.sock'));probe.close();break
  except OSError:probe.close()
  if p.poll()is not None:raise RuntimeError('SpeechDispatcher exited '+str(p.returncode))
  time.sleep(.05)
 else:raise RuntimeError('SpeechDispatcher socket not accepting within5s')
 os.environ.update(json.loads((w/'at-runtime-env.json').read_text()));import sys;sys.path.insert(0,env['PYTHONPATH']);import speechd
 c=speechd.SSIPClient('xk-runtime-preflight',autospawn=False);c.set_language('en');result['outputModules']=c.list_output_modules();c.set_output_module('espeak-ng');done=threading.Event();events=[]
 def callback(kind,**kw):
  events.append(kind)
  if kind in ['end','cancel']:done.set()
 result['sayResult']=c.speak(result['spokenDiagnostic'],callback=callback);assert done.wait(10),'No real speech completion event';result['speechEvents']=events;assert 'end'in events;c.close();p.terminate();p.wait(timeout=5);log.close()
 raw=(w/'speech-audio.pcm').read_bytes();f=w/'tts-preflight-retest.wav'
 with wave.open(str(f),'wb')as out:out.setnchannels(1);out.setsampwidth(2);out.setframerate(22050);out.writeframes(raw)
 result['audioBytes']=f.stat().st_size;result['sourcePcmBytes']=len(raw);result['audioNote']='Actual espeak-ng ALSA PCM; WAV wrapper only adds format header, does not synthesize or change PCM.'
 with wave.open(str(f),'rb')as a:result['audio']={'channels':a.getnchannels(),'sampleWidth':a.getsampwidth(),'sampleRate':a.getframerate(),'frames':a.getnframes()};data=a.readframes(a.getnframes());result['audio']['nonZeroPcmBytes']=sum(v!=0 for v in data)
 assert result['audio']['frames']>0 and result['audio']['nonZeroPcmBytes']>0;result['status']='PASS'
finally:
 if p.poll()is None:p.terminate();p.wait(timeout=5)
 result['serverTerminationReturnCode']=p.returncode;(w/'tts-preflight.final.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
