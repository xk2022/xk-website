import json,re,datetime,hashlib
from pathlib import Path
base=Path('/tmp/xk-task012');d=json.loads((base/'contrast-ui-pages-observations.json').read_text())
def lum(c):return sum((v/255/12.92 if v/255<=.04045 else((v/255+.055)/1.055)**2.4)*w for v,w in zip(c,(.2126,.7152,.0722)))
def ratio(a,b):return(max(lum(a),lum(b))+.05)/(min(lum(a),lum(b))+.05)
def comp(bg,rgba):return[b*(1-rgba[3]/255)+f*rgba[3]/255 for b,f in zip(bg,rgba[:3])]
def bgstack(ancestors):
 bg=[255,255,255]
 for a in reversed(ancestors):bg=comp(bg,a['backgroundRgba'])
 return bg
rows=[]
for item in d['rows']:
 o=item['observed'];e=o['element'];bg=bgstack(o['ancestors']);fg=comp(bg,e['rgba']);text=ratio(fg,bg);assert text>=4.5
 children=[]
 for child in item['children']:
  c=[float(x)for x in re.findall(r'[\d.]+',child['color'])[:3]];value=ratio(c,bg);assert value>=4.5;children.append({**child,'ratio':value,'requiredRatio':3 if child['tag'].lower()=='svg' else 4.5,'status':'PASS'})
 focus=None
 if item['state']=='focus':
  assert e['focusVisible'] and e['outlineStyle']=='solid' and float(e['outlineWidth'][:-2])>=2
  external=bgstack(o['ancestors'][1:]);outline=comp(external,e['outlineRgba']);lower=ratio(outline,external)
  if item['name']=='outline CTA':lower=min(lower,5.1333065802155575) # complete cyan stop bound outside the white outline CTA
  assert lower>=3;focus={'computedOutlineColor':e['outlineColor'],'outlineWidth':e['outlineWidth'],'outlineOffset':e['outlineOffset'],'focusVisible':e['focusVisible'],'againstActualOpaqueOutsideBackground':ratio(outline,external),'completeOutsideGradientLowerBound':lower,'requiredRatio':3,'status':'PASS'}
 border=comp(bg,e['borderRgba']);rows.append({'name':item['name'],'state':item['state'],'width':item['viewport'],'selector':item['selector'],'actualForegroundRGBA':e['rgba'],'actualCompositedBackgroundRGB':bg,'textRatio':text,'textRequired':4.5,'textStatus':'PASS','children':children,'focus':focus,'borderContrastAgainstFill':ratio(border,bg),'borderInterpretation':'The visible text/icon identifies the native button/link. The decorative pale normal-state border is not the sole information needed to identify a component. Hover/focus state is additionally indicated by actual foreground/background/ring changes.','observations':str(base/'contrast-ui-pages-observations.json')})
for r in d['overlap']:
 assert all(p['inViewport']and p['hit']['insideDisclosure']for p in r['observed']['hitPoints'])
result={'observedAt':d['observedAt'],'resolvedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'sourceFingerprint':d['sourceFingerprint'],'status':'PASS','processReceipt':str(base/'contrast-ui-pages-process.json'),'actualExitCode':0,'finiteScope':'7 real component categories × normal/hover/focus=21 actual observations; no full UI state certification','rows':rows,'minimumTextOrChildRatio':min([r['textRatio']for r in rows]+[c['ratio']for r in rows for c in r['children']]),'minimumFocusRingOutsideLowerBound':min(r['focus']['completeOutsideGradientLowerBound']for r in rows if r['focus']),'expandedHomeOverlapEvidence':{'nodes':3,'allNineHitPointsConfirmedActualPanelDescendants':True,'source':str(base/'contrast-ui-pages-observations.json'),'decision':'Strengthens only the existing375 Home expanded-state occlusion classification. Does not classify all Pages Contact overlay cases.'},'limits':['Disabled controls and actual AT handled separately by Root/QA; not inferred from this finite pairing table.','Control outline borders that are not needed for identification are not treated as required contrast information; text/icon and focus indicators are evaluated separately.']}
p=base/'contrast-ui-pairs.json';p.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items()if k not in ['rows','limits','expandedHomeOverlapEvidence']},ensure_ascii=False));print('SHA256',hashlib.sha256(p.read_bytes()).hexdigest())
