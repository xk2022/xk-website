import assert from "node:assert/strict";
import { readFileSync, writeFileSync } from "node:fs";
import { verifiedContactChannels } from "/workspace/xk-website/src/config/contact.ts";
import { getInquiryAction, inquiryAction } from "/workspace/xk-website/src/config/inquiry.ts";

const contract = JSON.parse(readFileSync("/workspace/xk-website/scripts/fixtures/contact-contract.json"));
const rows = [];
function test(id, run) { const actual = run(); rows.push({ id, status: "PASS", actual }); }
function check(action, context = "") {
  assert.equal(action.state, "direct");
  assert.equal(action.label, "立即詢價");
  const url = new URL(action.href);
  assert.equal(url.protocol, "mailto:");
  assert.equal(decodeURIComponent(url.pathname), "system.xk2022@gmail.com");
  assert.deepEqual([...url.searchParams.keys()].sort(), ["body", "subject"]);
  assert.equal(url.searchParams.get("subject"), context ? `XK 專案詢價｜${context}` : "XK 專案詢價");
  const body = [...contract.mailtoBody];
  if (context) body.splice(1, 0, `參考方案：${context}`);
  assert.equal(url.searchParams.get("body"), body.join("\r\n"));
  assert(action.href.length < 2000);
  return { recipient: url.pathname, subject: url.searchParams.get("subject"), fields: contract.mailtoFields.length, queryKeys: [...url.searchParams.keys()], uriLength: action.href.length };
}
test("OWNER_REGISTRY", () => { assert.deepEqual(verifiedContactChannels, [{ label: "Email 專案詢價", href: "mailto:system.xk2022@gmail.com" }]); return verifiedContactChannels; });
test("EMPTY_STAYS_PREPARATION", () => { const action = getInquiryAction([]); assert.equal(action.state, "preparation"); assert.equal(action.label, "詢價前準備"); assert.equal(action.href, "/contact#contact-preparation"); return action; });
test("DEFAULT_EMAIL_DRAFT", () => check(inquiryAction));
for (const context of ["一頁式服務推廣", "企業與品牌官網", "網站功能與流程整合"]) test(`PLAN_${context}`, () => check(getInquiryAction(verifiedContactChannels, context), context));
test("HTTPS_STAYS_EXTERNAL", () => { const href = "https://contact.example.invalid/"; const action = getInquiryAction([{ label: "Fixture", href }]); assert.equal(action.href, href); assert.equal(action.state, "direct"); return { href, requested: false }; });
test("MULTIPLE_ALLOW_CHOICE", () => { const action = getInquiryAction([...verifiedContactChannels, { label: "Fixture", href: "https://contact.example.invalid/" }]); assert.equal(action.state, "choose-channel"); assert.equal(action.href, "/contact#contact-channels"); return action; });
test("NO_CC_OR_BCC", () => check(getInquiryAction([{ label: "Fixture", href: "mailto:system.xk2022@gmail.com?bcc=fixture@example.invalid&subject=unapproved" }])));
const result = { status: "PASS", cases: rows.length, mailSent: false, deliveryTested: false, syntheticDestinationsRequested: false, rows };
writeFileSync("/tmp/xk-contact-plans/contact-contract.json", JSON.stringify(result, null, 2) + "\n");
console.log({ status: result.status, cases: result.cases });
