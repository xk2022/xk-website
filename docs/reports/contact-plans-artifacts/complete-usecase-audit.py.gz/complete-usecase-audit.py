import concurrent.futures,hashlib,json,pathlib,urllib.request,urllib.error,urllib.parse
from datetime import datetime,timezone
from html.parser import HTMLParser
W=pathlib.Path('/tmp/xk-contact-plans');x=json.loads((W/'usecase-audit.initial.json').read_text())
class Title(HTMLParser):
 def __init__(self):super().__init__();self.head=False;self.capture=False;self.text=''
 def handle_starttag(self,t,a):
  if t=='head':self.head=True
  if t=='title'and self.head:self.capture=True
 def handle_endtag(self,t):
  if t=='title':self.capture=False
  if t=='head':self.head=False
 def handle_data(self,t):
  if self.capture:self.text+=t
class Redirects(urllib.request.HTTPRedirectHandler):
 def __init__(self):super().__init__();self.chain=[]
 def redirect_request(self,req,fp,code,msg,headers,url):self.chain.append({'status':code,'from':req.full_url,'to':urllib.parse.urljoin(req.full_url,url)});return super().redirect_request(req,fp,code,msg,headers,url)
def probe(record):
 u=record.get('pagesApi',{}).get('data',{}).get('html_url')
 if not u or u==record['originalPublicGet']['requestedUrl']:return record
 d=Redirects();out={'requestedUrl':u,'method':'GET','startedAt':datetime.now(timezone.utc).isoformat()}
 try:
  try:r=urllib.request.build_opener(d).open(urllib.request.Request(u,headers={'User-Agent':'XK-ReadOnly-Link-Audit/1.0'}),timeout=15)
  except urllib.error.HTTPError as e:r=e
  with r:b=r.read(1024*1024);p=Title();p.feed(b.decode('utf-8',errors='replace'));out.update(status=r.code,finalUrl=r.url,contentType=r.headers.get('Content-Type'),title=p.text.strip(),bodyBytesRead=len(b),bodySha256=hashlib.sha256(b).hexdigest(),redirects=d.chain)
 except Exception as e:out.update(status=None,errorType=type(e).__name__,error=str(e)[:200],redirects=d.chain)
 out['finishedAt']=datetime.now(timezone.utc).isoformat();record['declaredPagesTargetPublicGet']=out;return record
with concurrent.futures.ThreadPoolExecutor(max_workers=4)as pool:x['records']=list(pool.map(probe,x['records']))
for r in x['records']:
 old=r['href']or r['sourceHref'];meta=r.get('pagesApi',{}).get('data',{});declared=meta.get('html_url');observed=r.get('declaredPagesTargetPublicGet');field='href'if r['href']is not None else'sourceHref';candidate=None;action='retain-current-until-verified';basis=[]
 if observed and observed.get('status')==200 and urllib.parse.urlsplit(observed['finalUrl']).scheme=='https'and urllib.parse.urlsplit(observed['finalUrl']).netloc==urllib.parse.urlsplit(declared).netloc:
  candidate=observed['finalUrl'];action='update-current-field-to-confirmed-pages-domain';basis=['Source repository Pages API explicitly publishes this HTTPS URL.','Independent GET reached HTTP200 at the declared host; no path was invented.']
 elif r['originalPublicGet'].get('status')==200:
  candidate=r['originalPublicGet']['finalUrl'];action='retain-current-verified-url';basis=['Current configured public URL was independently GET200; no usecase migration verified.']
 usecase_candidate=candidate if candidate and urllib.parse.urlsplit(candidate).scheme+'://'+urllib.parse.urlsplit(candidate).netloc==x['proposedUsecaseOrigin']else None
 r['updateConclusion']={'technicalUpdateSupported':candidate is not None,'field':field,'currentValue':old,'candidate':candidate,'requiresChange':bool(candidate and candidate!=old),'supportedAction':action,'basis':basis or['No verified reachable candidate; retain fields and ask owner.'],'usecaseOriginCandidate':usecase_candidate,'availabilityPreserved':r['availability'],'hrefMustRemainNull':r['href']is None,'thirdPartyAttributionUnchanged':True,'ownerTargetConfirmation':'PendingRoot/user scope confirmation; this read-only evidence is not publication authorization.'}
x['finishedAt']=datetime.now(timezone.utc).isoformat();x['interpretation']={'usecaseOriginConfigured':False,'reason':'Both Google andCloudflare report NXDOMAIN for usecase CNAME/A/AAAA; user-site root404 and no user-site Pages metadata/CNAME confirmed. No inherited usecase project paths established.','existingBrandDomainChangeCount':sum(r['updateConclusion']['requiresChange']for r in x['records']),'existingUrlsRetainedCount':sum(r['updateConclusion']['supportedAction']=='retain-current-verified-url'for r in x['records']),'initialOldGithub404BrandCount':sum(r['kind']=='brand-demo'and r['originalPublicGet'].get('status')==404 for r in x['records']),'proposedUsecaseCandidateCount':sum(r['updateConclusion']['usecaseOriginCandidate']is not None for r in x['records']),'safeContentBoundary':'Update only the existing href/sourceHref field to an authoritative GET200 URL if owner confirms. Keep reference-only href:null and original attribution. Never change corporatewww canonical to usecase.'};x['evidenceHistory']={'initialAudit':str(W/'usecase-audit.initial.json'),'initialReceipt':str(W/'usecase-audit-process.json'),'note':'Initial audit checked the proposed usecase origin; final adds GET probes of actual source-repository Pages URLs to identify existing distinct brand subdomains.'};(W/'usecase-audit.json').write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'path':str(W/'usecase-audit.json'),'interpretation':x['interpretation'],'records':[{'id':r['id'],'candidate':r['updateConclusion']['candidate'],'requiresChange':r['updateConclusion']['requiresChange'],'field':r['updateConclusion']['field'],'httpStatus':(r['declaredPagesTargetPublicGet']or r['originalPublicGet']).get('status')}for r in x['records']]},ensure_ascii=False))
