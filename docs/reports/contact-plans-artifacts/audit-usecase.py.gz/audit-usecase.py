import base64,concurrent.futures,hashlib,json,pathlib,re,subprocess,time,urllib.request,urllib.error,urllib.parse
from datetime import datetime,timezone
from html.parser import HTMLParser
W=pathlib.Path('/tmp/xk-contact-plans');TARGET='https://usecase.xplorekaleidoscope.com';entries=json.loads((W/'usecase-entries.json').read_text());assert len(entries)==10
class Title(HTMLParser):
 def __init__(self):super().__init__(convert_charrefs=True);self.head=False;self.capture=False;self.text=''
 def handle_starttag(self,t,a):
  if t=='head':self.head=True
  if t=='title'and self.head:self.capture=True
 def handle_endtag(self,t):
  if t=='title':self.capture=False
  if t=='head':self.head=False
 def handle_data(self,t):
  if self.capture:self.text+=t
class Redirects(urllib.request.HTTPRedirectHandler):
 def __init__(self):super().__init__();self.chain=[]
 def redirect_request(self,req,fp,code,msg,headers,url):
  dest=urllib.parse.urljoin(req.full_url,url);self.chain.append({'status':code,'from':req.full_url,'to':dest})
  if urllib.parse.urlsplit(dest).scheme not in ['https','http']:raise ValueError('Non-HTTP redirect refused')
  return super().redirect_request(req,fp,code,msg,headers,dest)
def get(url):
 d=Redirects();start=datetime.now(timezone.utc).isoformat();out={'requestedUrl':url,'method':'GET','startedAt':start}
 try:
  try:r=urllib.request.build_opener(d).open(urllib.request.Request(url,headers={'User-Agent':'XK-ReadOnly-Link-Audit/1.0'}),timeout=15)
  except urllib.error.HTTPError as e:r=e
  with r:
   data=r.read(1024*1024);title=Title();title.feed(data.decode('utf-8',errors='replace'));out.update(status=r.code,finalUrl=r.url,contentType=r.headers.get('Content-Type'),title=title.text.strip(),bodyBytesRead=len(data),bodySha256=hashlib.sha256(data).hexdigest(),headers={k:r.headers.get(k)for k in ['Location','Server','Content-Type']},redirects=d.chain)
 except Exception as e:out.update(status=None,errorType=type(e).__name__,error=str(e)[:240],redirects=d.chain)
 out['finishedAt']=datetime.now(timezone.utc).isoformat();return out
def api(path):
 try:
  r=subprocess.run(['gh','api',path],capture_output=True,text=True,timeout=15)
  if r.returncode==0:return {'status':'available','data':json.loads(r.stdout)}
  m=re.search(r'HTTP (\d+)',r.stderr);return {'status':'unavailable','httpStatus':int(m[1])if m else None,'error':r.stderr.strip()[:220]}
 except Exception as e:return {'status':'unavailable','errorType':type(e).__name__}
def page_meta(value):
 if value['status']!='available':return value
 d=value['data'];return {'status':'available','data':{k:d.get(k)for k in ['status','cname','html_url','build_type','https_enforced','https_certificate','source']}}
def dns(args):
 provider,typ=args;u=('https://dns.google/resolve?'if provider=='Google'else'https://cloudflare-dns.com/dns-query?')+urllib.parse.urlencode({'name':'usecase.xplorekaleidoscope.com','type':typ})
 try:
  with urllib.request.urlopen(urllib.request.Request(u,headers={'Accept':'application/dns-json'}),timeout=12)as r:d=json.load(r)
  return {'provider':provider,'type':typ,'status':d.get('Status'),'answers':d.get('Answer',[])}
 except Exception as e:return {'provider':provider,'type':typ,'status':None,'errorType':type(e).__name__}
def record(entry):
 original=entry['href']or entry['sourceHref'];path=urllib.parse.urlsplit(original).path;slug=path.strip('/').split('/')[0];repo='xk2022/'+slug;metadata=page_meta(api('repos/'+repo+'/pages'));observed=get(original);additional=None;candidate=None;basis=[]
 if observed.get('status')==200 and observed.get('finalUrl'):
  f=urllib.parse.urlsplit(observed['finalUrl']);o=urllib.parse.urlsplit(original)
  if f.scheme+'://'+f.netloc==TARGET and f.path.rstrip('/')==o.path.rstrip('/')and not f.query and not f.fragment:candidate=observed['finalUrl'];basis.append('Existing configured URL actually redirects to HTTPS usecase with the same project path and HTTP200.')
 declared=metadata.get('data',{}).get('html_url')
 if not candidate and declared and urllib.parse.urlsplit(declared).scheme+'://'+urllib.parse.urlsplit(declared).netloc==TARGET:
  additional=get(declared)
  if additional.get('status')==200 and urllib.parse.urlsplit(additional['finalUrl']).scheme+'://'+urllib.parse.urlsplit(additional['finalUrl']).netloc==TARGET:candidate=additional['finalUrl'];basis.append('Exact target supplied by this repository Pages API and independently GET200; no path guessed.')
 field='href'if entry['href']is not None else'sourceHref';conclusion={'technicalUpdateSupported':bool(candidate),'field':field,'candidate':candidate,'basis':basis or['No successful same-project HTTPS usecase redirect or authoritative Pages target was verified. Keep current fields; do not infer paths from404.'],'availabilityPreserved':entry['availability'],'hrefMustRemainNull':entry['href']is None,'thirdPartyAttributionUnchanged':True,'targetDomainOwnerConfirmation':'PENDING Root/user confirmation; this audit does not authorize publication.'};return {**entry,'projectRepositoryIdentifiedFromExistingUrl':repo,'pagesApi':metadata,'originalPublicGet':observed,'declaredPagesTargetPublicGet':additional,'updateConclusion':conclusion}
started=datetime.now(timezone.utc).isoformat()
with concurrent.futures.ThreadPoolExecutor(max_workers=4)as pool:
 records=list(pool.map(record,entries));dns_data=list(pool.map(dns,[(p,t)for p in ['Google','Cloudflare']for t in ['CNAME','A','AAAA']]))
root=get(TARGET+'/');github_root=get('https://xk2022.github.io/');userpages=page_meta(api('repos/xk2022/xk2022.github.io/pages'));branch=userpages.get('data',{}).get('source',{}).get('branch')if isinstance(userpages.get('data',{}).get('source'),dict)else None
if not branch:
 info=api('repos/xk2022/xk2022.github.io');branch=info.get('data',{}).get('default_branch')
cname={'status':'unavailable','reason':'No confirmed user-site repository/default branch; no CNAME path guessed'}
if branch:
 raw=api('repos/xk2022/xk2022.github.io/contents/CNAME?ref='+urllib.parse.quote(branch,safe=''))
 if raw['status']=='available':
  d=raw['data'];cname={'status':'available','branch':branch,'blob':d.get('sha'),'value':base64.b64decode(d['content']).decode().strip()}
 else:cname=raw
inherited=userpages.get('data',{}).get('cname')=='usecase.xplorekaleidoscope.com'or cname.get('value')=='usecase.xplorekaleidoscope.com'
result={'status':'READ_ONLY_AUDIT_COMPLETED','startedAt':started,'finishedAt':datetime.now(timezone.utc).isoformat(),'source':json.loads((W/'usecase-source.json').read_text()),'proposedUsecaseOrigin':TARGET,'recordCount':len(records),'dns':dns_data,'rootPublicGet':root,'githubUserRootPublicGet':github_root,'userSitePagesApi':userpages,'userSiteRepositoryCname':cname,'userSiteInheritanceConclusion':{'userSiteCustomDomainDirectlyConfirmed':inherited,'sameProjectPathUsecase200Records':sum(bool(r['updateConclusion']['candidate'])for r in records),'note':'User-site metadata/CNAME plus each actual redirect can establish inherited project routes. DNS CNAME alone cannot prove10 project paths.'},'records':records,'boundaries':{'companyCanonical':'https://www.xplorekaleidoscope.com','companyCanonicalMustNotBecomeUsecase':True,'repositoryDnsPagesDeployMutations':False,'formSubmissions':False,'browserLoginOrPrivateSession':False,'unavailableCardsRemainUnavailable':True,'thirdPartyAttributionPreserved':True}};(W/'usecase-audit.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'path':str(W/'usecase-audit.json'),'status':result['status'],'records':len(records),'supportedUpdates':sum(r['updateConclusion']['technicalUpdateSupported']for r in records),'userSiteCustomDomainConfirmed':inherited,'rootStatus':root.get('status'),'summaries':[{'id':r['id'],'field':r['updateConclusion']['field'],'httpStatus':r['originalPublicGet'].get('status'),'finalUrl':r['originalPublicGet'].get('finalUrl'),'candidate':r['updateConclusion']['candidate']}for r in records]},ensure_ascii=False))
