import datetime
import hashlib
import html
import io
import json
import re
import tarfile
import zipfile
from pathlib import Path

root = Path('/workspace/xk-website')
base = Path('/tmp/xk-contact-plans')
archive = zipfile.ZipFile(base / 'github-pages.zip')
tars = [n for n in archive.namelist() if n.endswith('.tar')]
assert len(tars) == 1
actual = {}
with tarfile.open(fileobj=io.BytesIO(archive.read(tars[0]))) as tar:
    for member in tar:
        name = member.name.removeprefix('./')
        assert not Path(name).is_absolute() and '..' not in Path(name).parts
        if member.isfile():
            assert name not in actual
            actual[name] = tar.extractfile(member).read()
expected = json.loads((base / 'local-artifact.json').read_text())
assert len(actual) == expected['fileCount'], (len(actual), expected['fileCount'])
rows = []
for name, data in actual.items():
    if name.startswith(('_next/static/', 'images/', 'brand/')):
        local = root / 'out' / name
        bridge = None
        if not local.exists():
            assert re.fullmatch(r'_next/static/[^/]+/_(?:ssg|build|clientMiddleware)Manifest\.js', name), name
            candidates = list((root / 'out/_next/static').glob('*/' + Path(name).name))
            assert len(candidates) == 1
            local = candidates[0]
            bridge = 'Unique Next generated manifest basename across BuildID directory; bytes still identical.'
        assert data == local.read_bytes(), name
        rows.append({'path': name, 'sha256': hashlib.sha256(data).hexdigest(), 'bytes': len(data), 'bridge': bridge})
specs = json.loads((base / 'seo.json').read_text())
public_html = set()
for spec in specs:
    name = (spec['path'].strip('/') + '/index.html').lstrip('/')
    public_html.add(name)
    text = actual[name].decode()
    head = text.split('</head>')[0]
    assert html.unescape(re.search(r'<title>(.*?)</title>', head).group(1)) == spec['title'], spec['path']
    assert 'name="robots" content="noindex, nofollow"' in head
    assert 'property="og:title"' in head and 'rel="canonical"' in head
    canonical = html.unescape(re.search(r'<link[^>]*rel="canonical"[^>]*href="([^"]+)"', head).group(1))
    og_url = html.unescape(re.search(r'<meta[^>]*property="og:url"[^>]*content="([^"]+)"', head).group(1))
    expected_url = 'https://www.xplorekaleidoscope.com' + spec['path']
    assert canonical.rstrip('/') == expected_url.rstrip('/') and og_url.rstrip('/') == expected_url.rstrip('/'), spec['path']
    assert not re.search(r'(?:href|src)="/xk-website(?:/|["?])', text), spec['path']
    if spec['path'] == '/portfolio':
        visible = re.sub(r'<script\b[^>]*>[\s\S]*?</script>', '', text)
        previous = -1
        for entry in json.loads((base / 'showcases.json').read_text()):
            cards = re.findall(r'<article\b[^>]*>[\s\S]*?</article>', visible)
            card = next(c for c in cards if 'data-showcase-id="' + entry['id'] + '"' in c)
            state = entry.get('availability', 'available')
            assert 'data-showcase-state="' + state + '"' in card
            if state != 'available':
                assert entry['href'] is None and entry['image'] is None
                assert '<img' not in card
                assert 'href="' + entry['sourceHref'] + '"' not in card
            else:
                assert 'href="' + entry['href'] + '"' in card
                assert 'src="' + entry['image']['src'] + '"' in card
            if entry['kind'] == 'brand-demo':
                position = visible.index('data-showcase-id="' + entry['id'] + '"')
                assert position > previous
                previous = position
                assert '/portfolio/showcases/' + entry['id'] in card
actual_html = {n for n in actual if n.endswith('.html')}
assert actual_html == public_html | {'404.html', '404/index.html', '_not-found/index.html'}, actual_html ^ public_html
assert not any(n.startswith(('privacy/', 'dev/')) or n == 'sitemap.xml' for n in actual)
result = {
    'status': 'PASS', 'checkedAt': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'artifactFiles': len(actual), 'byteComparedRuntimeAndImages': len(rows),
    'publicHtml': len(public_html), 'noindex': True, 'protection': True,
    'archiveSha256': hashlib.sha256((base / 'github-pages.zip').read_bytes()).hexdigest(), 'rows': rows,
}
(base / 'artifact-verification.json').write_text(json.dumps(result, indent=2) + '\n')
print({k: v for k, v in result.items() if k != 'rows'})
