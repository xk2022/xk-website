import argparse, datetime, html, json, os, pathlib, runpy, subprocess
from urllib.parse import parse_qsl, urlsplit, urlunsplit, urlencode
root = pathlib.Path('/workspace/xk-website')
os.chdir(root)
checks = []
def record(name, expected, actual, notes=''):
    checks.append({'testId':f'CONTACT-TOOL-{len(checks)+1:03}', 'item':name, 'expected':expected, 'actual':actual, 'status':'PASS' if expected == actual else 'FAIL', 'notes':notes})
m = runpy.run_path('scripts/smoke-website.py')
c = json.loads((root/'scripts/fixtures/contact-contract.json').read_text())
script = "import {createInquiryHref,inquiryAction} from './src/config/inquiry.ts';console.log(JSON.stringify({default:inquiryAction.href,contexts:Object.fromEntries(" + json.dumps(list(c['servicePlanContexts'].values()), ensure_ascii=False) + ".map(x=>[x,createInquiryHref('mailto:system.xk2022@gmail.com',x)]))}));"
r = subprocess.run(['node','--input-type=module','-e',script], capture_output=True, text=True)
assert r.returncode == 0, r.stderr
urls = json.loads(r.stdout)
default = urls['default']
u = urlsplit(default)
pairs = parse_qsl(u.query, keep_blank_values=True)
def variant(path=None, query=None, fragment=''):
    return urlunsplit((u.scheme,u.netloc,u.path if path is None else path,urlencode(pairs if query is None else query),fragment))
cases = [('default draft',default,True,None)]
cases += [('plan '+context,url,True,context) for context,url in urls['contexts'].items()]
cases += [
 ('wrong recipient',variant(path='other@example.com'),False,None),
 ('comma recipient',variant(path=c['ownerEmail']+',other@example.com'),False,None),
 ('bcc',variant(query=pairs+[('bcc','other@example.com')]),False,None),
 ('cc',variant(query=pairs+[('cc','other@example.com')]),False,None),
 ('duplicate body',variant(query=pairs+[('body',dict(pairs)['body'])]),False,None),
 ('duplicate subject',variant(query=pairs+[('subject',c['mailtoSubject'])]),False,None),
 ('missing body',variant(query=[('subject',c['mailtoSubject'])]),False,None),
 ('raw address without prompts','mailto:'+c['ownerEmail'],False,None),
 ('visitor body',variant(query=[(k,'visitor data' if k=='body' else v) for k,v in pairs]),False,None),
 ('LF-only body',variant(query=[(k,v.replace('\r\n','\n') if k=='body' else v) for k,v in pairs]),False,None),
 ('unknown context',variant(query=[(k,c['mailtoSubject']+'｜unknown' if k=='subject' else v) for k,v in pairs]),False,None),
 ('fragment',variant(fragment='sent'),False,None),
 ('wrong rendered context',default,False,list(c['servicePlanContexts'].values())[1]),
]
for name,url,expected,context in cases:
    errors = m['mailto_errors'](url,c,context)
    record('Python mailto: '+name,expected,not errors,str(errors))
def anchor(url=default,context='',state='direct',label=None):
    attrs = ' data-inquiry-state="'+state+'"'
    if context:
        attrs += ' data-inquiry-context="'+context+'" aria-label="詢問方案：'+context+'"'
    return '<a href="'+html.escape(url,quote=True)+'"'+attrs+'>'+(label if label is not None else ('詢問方案' if context else '立即詢價'))+'</a>'
def plans(extra='',swap=False):
    cards=[]
    for i,item in enumerate(c['servicePlanIds']):
        context=c['servicePlanContexts'][item]
        if swap and i==0:context=c['servicePlanContexts'][c['servicePlanIds'][1]]
        cards.append('<div role="article" data-service-plan-id="'+item+'"><h3>'+c['servicePlanContexts'][item]+'</h3><p>依需求報價</p>'+extra+anchor(urls['contexts'][context],context)+'</div>')
    return '<section id="service-plans">'+''.join(cards)+'</section><section id="pricing-guide"><h2>報價評估</h2></section>'
def suite():
    return m['Smoke'](argparse.Namespace(base_url='https://www.xplorekaleidoscope.com/',timeout=1,output='/tmp/unused-contact.json',check_external=False,check_source_assets=False))
markup_cases=[
 ('default and plan actions',anchor()+plans(),True),
 ('form',anchor()+'<form></form>',False),
 ('input',anchor()+'<input>',False),
 ('submit',anchor()+'<button type="submit">send</button>',False),
 ('delivery claim',anchor()+'<p>信件已成功送達</p>',False),
 ('automatic reply',anchor()+'<p>自動回覆已啟用</p>',False),
 ('SLA',anchor()+'<p>24小時內回覆</p>',False),
 ('truthful draft disclaimer',anchor()+'<p>'+c['requiredDataNotes'][0]+'</p>',True),
 ('wrong label',anchor(label='送出詢價'),False),
 ('wrong state',anchor(state='preparation'),False),
 ('wrong rendered context',anchor(default,list(c['servicePlanContexts'].values())[1]),False),
]
for name,markup,expected in markup_cases:
    s=suite();s.enquiry_markup('/',m['Document']('<html>'+markup+'</html>').root)
    errors=[x['item'] for x in s.results if x['status']=='FAIL']
    record('Python markup: '+name,expected,not errors,str(errors))
plan_cases=[
 ('case/version/year numbers',plans('<p>Case 01 / Java 17 / 2026</p>'),True),
 ('NT currency',plans('<p>NT$8,000</p>'),False),
 ('Yuan price',plans('<p>8000元</p>'),False),
 ('Chinese price',plans('<p>五千元</p>'),False),
 ('numeric price label',plans('<p>價格：8000</p>'),False),
 ('swapped context',plans(swap=True),False),
]
for name,markup,expected in plan_cases:
    s=suite();s.service_plans('/services',m['Document']('<html>'+markup+'</html>').root)
    errors=[x['item'] for x in s.results if x['status']=='FAIL']
    record('Python pricing scope: '+name,expected,not errors,str(errors))
contact='<main><h1>'+c['contactHeading']+'</h1><section id="contact-channels" data-contact-availability="channels-only"><a href="'+html.escape(default,quote=True)+'">'+c['ownerEmail']+'</a></section><section id="contact-process">'+''.join('<h3>'+x+'</h3>' for x in c['processSteps'])+'</section><section id="contact-data-note">'+''.join('<p>'+x+'</p>' for x in c['requiredDataNotes'])+'</section></main>'
s=suite();s.contact_page(m['Document']('<html>'+contact+'</html>').root)
record('Python Contact structure',[],[x['item'] for x in s.results if x['status']=='FAIL'])
node_fixture=r"""
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
const contract=JSON.parse(readFileSync('./scripts/fixtures/contact-contract.json','utf8'));
const source=readFileSync('./scripts/build-github-pages.mjs','utf8');
const helpers=source.slice(source.indexOf('function verifyMailtoHref'),source.indexOf('function verifyBrandUrl'));
const tag=source.slice(source.indexOf('function tagAttribute'),source.indexOf('function metadataAttribute'));
const start=source.indexOf('function decodePublicText');
const decode=source.slice(start,source.indexOf('\nif (!privacyApproved)',start));
const {verifyMailtoHref,verifyEnquiryMarkup,verifyServicePlans}=new Function('assert','contactContract',tag+decode+helpers+';return {verifyMailtoHref,verifyEnquiryMarkup,verifyServicePlans};')(assert,contract);
const payload=JSON.parse(process.env.CONTACT_FIXTURE_PAYLOAD), results=[];
for(const t of payload.mailtos){let actual=true;try{verifyMailtoHref(t.html,'fixture');}catch{actual=false;}results.push({item:'Builder mailto: '+t.name,expected:t.expected,actual});}
for(const t of payload.markup){let actual=true;try{verifyEnquiryMarkup(t.html,'fixture');}catch{actual=false;}results.push({item:'Builder markup: '+t.name,expected:t.expected,actual});}
for(const t of payload.plans){let actual=true;try{verifyServicePlans(t.html,'/services');}catch{actual=false;}results.push({item:'Builder pricing scope: '+t.name,expected:t.expected,actual});}
console.log(JSON.stringify(results));
"""
payload={'mailtos':[{'name':name,'html':url,'expected':expected} for name,url,expected,context in cases if context is None or expected], 'markup':[{'name':name,'html':markup,'expected':expected} for name,markup,expected in markup_cases], 'plans':[{'name':name,'html':markup,'expected':expected} for name,markup,expected in plan_cases]}
r=subprocess.run(['node','--input-type=module','-e',node_fixture],capture_output=True,text=True,env={**os.environ,'CONTACT_FIXTURE_PAYLOAD':json.dumps(payload,ensure_ascii=False)})
assert r.returncode==0,r.stderr
for item in json.loads(r.stdout):record(item['item'],item['expected'],item['actual'])
s=suite();assert s.source_contract()
record('Native source/contact/inquiry/SEO/showcase/deployment contracts',[],[x['item'] for x in s.results if x['status']=='FAIL'])
failed=[x for x in checks if x['status']=='FAIL']
report={'testedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Pure native imports/mailto/HTML fixtures; no formal build, server, HTTP, mail client, SMTP or send','result':'FAIL' if failed else 'PASS','counts':{'PASS':len(checks)-len(failed),'FAIL':len(failed)},'checks':checks,'harnessHistory':'The first inline tool harness failed because Python expanded a JavaScript newline escape; this standalone raw-string harness corrects that tooling error. No application source failed in that attempt.'}
out=pathlib.Path('/tmp/xk-pr26-contact-tool-fixtures-20261124.json');out.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'result':report['result'],'counts':report['counts'],'evidence':str(out),'failures':failed},ensure_ascii=False))
assert not failed
