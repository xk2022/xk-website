import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {createRequire} from 'node:module';
const root='/tmp/xk-dc006-build/';
const require=createRequire(root+'package.json'),ts=require('typescript'),postcss=require('postcss');
const files=[
 'src/components/design-collection/shared/style-switcher-client.tsx',
 'src/components/design-collection/modern/modern-frame.tsx',
 'src/components/design-collection/heritage/heritage-frame.tsx',
 'src/components/design-collection/luxury/luxury-frame.tsx',
 'src/components/layout/site-header.tsx','src/components/layout/mobile-navigation.tsx','src/components/layout/site-footer.tsx',
 'src/components/design-collection/heritage/heritage-navigation.tsx','src/components/design-collection/luxury/luxury-navigation.tsx',
];
for(const path of files){const code=readFileSync(root+path,'utf8');assert(!/^(?:<<<<<<<|=======|>>>>>>>)/m.test(code));const out=ts.transpileModule(code,{fileName:path,reportDiagnostics:true,compilerOptions:{jsx:ts.JsxEmit.ReactJSX,target:ts.ScriptTarget.ES2017,module:ts.ModuleKind.ESNext}});assert.deepEqual(out.diagnostics.filter(d=>d.category===ts.DiagnosticCategory.Error),[],path);}
for(const path of files.slice(1,4)){const code=readFileSync(root+path,'utf8');assert.equal((code.match(/<StyleSwitcher\s*\/>/g)||[]).length,1,path);assert(code.indexOf('<StyleSwitcher')<code.indexOf('<main'),path);}
const client=readFileSync(root+files[0],'utf8');assert(client.includes('window.location.pathname, window.location.hash'));assert(!/useSearchParams|localStorage|sessionStorage|document\.cookie|history\.(?:pushState|replaceState)|setInterval/.test(client));assert(client.includes('requestAnimationFrame'));assert(client.includes('aria-current="page"'));assert(client.includes('onContextMenu=')&&client.includes('onPointerDown=')&&client.includes('onFocus='));
for(const path of files.slice(7)){const code=readFileSync(root+path,'utf8');assert(code.includes('!inStyleSwitcher(event.target)')&&code.includes('!inStyleSwitcher(event.relatedTarget)'));assert(code.includes('addEventListener("click"')&&code.includes('addEventListener("focusin"'));}
const css=postcss.parse(readFileSync(root+'src/components/design-collection/shared/style-switcher.css','utf8'));let selectors=0,printHidden=false;
css.walkRules(rule=>{for(const selector of postcss.list.comma(rule.selector)){assert(selector.startsWith('.design-style-switcher')||selector==='.lx-theme .design-switcher-inquiry-only',selector);selectors++;}if(rule.parent?.name==='media'&&rule.parent.params==='print'&&rule.nodes.some(d=>d.prop==='display'&&d.value==='none'&&d.important))printHidden=true;});
css.walkAtRules(rule=>assert.notEqual(rule.name,'page'));assert(printHidden);
console.log(JSON.stringify({syntaxFiles:files.length,scopedSelectors:selectors,switcherPerFrame:1,printHidden,queryOrPersistenceAdded:false,scope:'static UI contract only, actual click/hash/SSR/a11y awaits integrated QA'}));
console.log('DC006_UI_STATIC_COMPLETE PASS');
