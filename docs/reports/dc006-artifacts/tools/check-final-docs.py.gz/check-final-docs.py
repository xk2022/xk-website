from pathlib import Path
import hashlib,json,gzip,re,subprocess,urllib.parse,datetime
r=Path('/tmp/xk-dc006-build');s=Path('/tmp/xk-dc006-final');checks=[]
def ck(name,ok,actual):
 checks.append({'testId':name,'status':'PASS' if ok else 'FAIL','actual':actual})
def sha(b):return hashlib.sha256(b).hexdigest()
freeze=json.loads((s/'source-bridge-v2.json').read_text());bad=[x['path'] for x in freeze['files'] if sha((r/x['path']).read_bytes())!=x['sha256']]
ck('DC6-FINAL-218-SOURCE-BYTES',len(freeze['files'])==218 and not bad,{'fingerprint':freeze['sha256'],'mismatches':bad})
base=freeze['base'];pkg=json.loads((r/'package.json').read_text());old=json.loads(subprocess.check_output(['git','show',base+':package.json'],cwd=r));depkeys=['dependencies','devDependencies','engines','name','version']
ck('DC6-FINAL-NO-DEPENDENCY-CHANGE',all(pkg[k]==old[k] for k in depkeys),depkeys)
unchanged=['package-lock.json','next.config.ts','.github/workflows/ci.yml','scripts/build-github-pages.mjs']
ck('DC6-FINAL-PRESERVE-DEPLOY-LOCK',all((r/p).read_bytes()==subprocess.check_output(['git','show',base+':'+p],cwd=r) for p in unchanged),unchanged)
manifest=json.loads((r/'docs/reports/dc006-artifacts/manifest.json').read_text());bad=[]
for item in manifest['files']:
 p=r/'docs/reports/dc006-artifacts'/item['path'];b=p.read_bytes();decoded=gzip.decompress(b) if item['archiveEncoding']=='gzip' else b
 if sha(b)!=item['sha256'] or sha(decoded)!=item['decodedSha256'] or len(b)!=item['bytes'] or len(decoded)!=item['decodedBytes']:bad.append(item['path'])
ck('DC6-FINAL-ARCHIVE-MANIFEST',not bad,{'files':len(manifest['files']),'mismatches':bad})
visual=json.loads((r/'docs/screenshots/design-collection/dc006/visual-review.json').read_text());bad=[x['path'] for x in visual['images'] if sha((r/'docs/screenshots/design-collection/dc006'/x['path']).read_bytes())!=x['sha256']]
ck('DC6-FINAL-18-ACTUAL-IMAGES',len(visual['images'])==18 and not bad,{'images':len(visual['images']),'mismatches':bad})
changed=subprocess.check_output(['git','diff','--name-only',base],cwd=r,text=True).splitlines();new=subprocess.check_output(['git','ls-files','--others','--exclude-standard'],cwd=r,text=True).splitlines();paths=sorted(set(changed+new))
md=[p for p in paths if p.endswith('.md')];links=[];errors=[]
def anchors(text):
 slugs=set(re.findall(r'<a\s+(?:id|name)=[\"\']([^\"\']+)',text));seen={}
 for head in re.findall(r'^#{1,6}\s+(.+?)\s*#*$',text,re.M):
  head=re.sub(r'!?\[([^\]]+)\]\([^)]*\)',r'\1',head);head=re.sub(r'<[^>]+>','',head);slug=re.sub(r'[^\w\-\s]','',head.lower()).replace('_','_');slug=re.sub(r'\s','-',slug);n=seen.get(slug,0);seen[slug]=n+1;slugs.add(slug+('-'+str(n) if n else ''))
 return slugs
for name in md:
 p=r/name;text=p.read_text();ck('MD-FORMAT-'+name,not re.search(r'[ \t]+$',text,re.M) and text.endswith('\n') and not text.endswith('\n\n'),{'path':name})
 # Balanced fenced blocks; link parser ignores fenced literal examples.
 ck('MD-FENCES-'+name,len(re.findall(r'^```',text,re.M))%2==0,name)
 active=re.sub(r'^```[^\n]*\n.*?^```[^\n]*$', '',text,flags=re.S|re.M)
 for raw in re.findall(r'!?\[[^\]]*\]\(([^\n)]+)\)',active):
  target=raw.strip().strip('<>');url=urllib.parse.urlsplit(target)
  if url.scheme or target.startswith('//'):continue
  dest=(p.parent/urllib.parse.unquote(url.path)).resolve() if url.path else p.resolve()
  ok=dest.exists()
  if ok and url.fragment and dest.is_file() and dest.suffix=='.md':ok=urllib.parse.unquote(url.fragment) in anchors(dest.read_text())
  row={'source':name,'target':target,'existsAndAnchor':ok};links.append(row)
  if not ok:errors.append(row)
ck('DC6-FINAL-LOCAL-MARKDOWN-LINKS',not errors,{'documents':len(md),'links':len(links),'errors':errors})
forbidden=[p for p in paths if any(seg in ['.next','out','node_modules','.env','.env.local'] for seg in p.split('/'))]
ck('DC6-FINAL-NO-GENERATED-OR-ENV-FILES',not forbidden,forbidden)
secret=[]
for name in paths:
 p=r/name
 if p.suffix not in ['.ts','.tsx','.js','.mjs','.css','.json','.md','.yml','.yaml']:continue
 if re.search(rb'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----|gh[pousr]_[A-Za-z0-9]{35,}|github_pat_[A-Za-z0-9_]{60,}',p.read_bytes()):secret.append(name)
ck('DC6-FINAL-SECRET-PATTERN-CHECK',not secret,secret)
diff=subprocess.run(['git','diff','--check'],cwd=r,capture_output=True,text=True);ck('DC6-FINAL-DIFF-CHECK',diff.returncode==0,diff.stdout+diff.stderr)
receipts=['npm-ci-v2','typegen-v2','typescript-v2','lint-v2','test-v2','build-normal-v2','build-pages-v2','http-normal-v2','http-pages-v2','neutral-query-fixtures-v5-command','neutral-query-retest-v5-command','visual-parity-final']
bad=[]
for key in receipts:
 p=s/(key+'.json');d=json.loads(p.read_text())
 if d.get('exitCode')!=0 or d.get('terminationReason')!='completed':bad.append(key)
ck('DC6-FINAL-REQUIRED-TRUE-EXITS',not bad,{'receipts':receipts,'bad':bad})
for mode in ['normal','pages']:
 d=json.loads((s/f'{mode}-v2/result.json').read_text());c=d['counters'];ck('DC6-FINAL-BROWSER-COMPLETE-'+mode,c['tests']==417 and c['layouts']==245 and c['axeScans']==20 and c['switcherIdentityCases']==96 and c['selectedBusinessAssertions']==24 and c['printMediaCases']==3 and c['violations']==0 and c['incompleteNodes']==10 and c['failures']==(1 if mode=='pages' else 0),c)
q=json.loads((s/'pages-query-v5/result.json').read_text());ck('DC6-FINAL-FOCUSED-QUERY-4',q['status']=='PASS' and q['counters']['tests']==4 and q['counters']['queryScenarios']==3 and q['counters']['actualNeutralRSCResponses']==3 and q['counters']['actualNeutralExpectedHeads']==3 and not any(q[k] for k in ['networkErrors','consoleErrors','runtimeErrors','privacyLeaks']),q['counters'])
result={'testId':'DC6-FINAL-DOCS-SOURCE-EVIDENCE','status':'FAIL' if any(x['status']=='FAIL' for x in checks) else 'PASS','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'sourceFingerprint':freeze['sha256'],'checks':checks,'counts':{'checks':len(checks),'failed':sum(x['status']=='FAIL' for x in checks)},'changedFiles':paths,'markdownLinks':links,'scope':'Final documentation/attachment/source and receipt consistency. Not a new build/browser result or remote CI claim.'}
(s/'final-doc-check-result.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'status':result['status'],'counts':result['counts'],'failures':[x for x in checks if x['status']=='FAIL']},ensure_ascii=False));raise SystemExit(0 if result['status']=='PASS' else 1)
