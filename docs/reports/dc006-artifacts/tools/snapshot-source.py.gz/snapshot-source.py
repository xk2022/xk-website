from pathlib import Path
import subprocess,json,hashlib,datetime
r=Path('/tmp/xk-dc006-build');ref='9322810f27e74e5ed4faa35a3b3931b3719f0c9a'
tracked=subprocess.check_output(['git','ls-files','-z'],cwd=r).decode().split('\0');new=subprocess.check_output(['git','ls-files','--others','--exclude-standard','-z'],cwd=r).decode().split('\0')
paths=sorted({p for p in tracked+new if p and (p.startswith(('src/','public/','scripts/')) or p in ['package.json','package-lock.json','next.config.ts','.github/workflows/ci.yml','.nvmrc','eslint.config.mjs','tsconfig.json']) and (r/p).is_file()})
rows=[]
for p in paths:
 b=(r/p).read_bytes();old=subprocess.run(['git','show',f'{ref}:{p}'],cwd=r,capture_output=True);rows.append({'path':p,'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b),'baseSha256':hashlib.sha256(old.stdout).hexdigest() if old.returncode==0 else None})
by={x['path']:x for x in rows};same=[p for p in paths if p.startswith(('public/','src/lib/quotation/','src/hooks/use-quotation')) or p in ['src/config/quotation.ts','src/config/seo.ts','src/lib/contact-inquiry.ts','src/config/contact-inquiry.ts','src/components/sections/contact/contact-inquiry-form.tsx','src/components/sections/quotation/quotation-estimator.tsx','src/components/sections/quotation/quotation-summary.tsx','src/components/sections/quotation/quotation.css','package-lock.json','next.config.ts','.github/workflows/ci.yml']]
assert all(by[p]['sha256']==by[p]['baseSha256'] for p in same)
a=json.loads((r/'package.json').read_text());b=json.loads(subprocess.check_output(['git','show',f'{ref}:package.json'],cwd=r,text=True));assert all(a[k]==b[k] for k in ['dependencies','devDependencies','engines','name','version'])
import re
strip=lambda s:re.sub(r'^@source not .*\n','',s,flags=re.M)
assert strip((r/'src/app/globals.css').read_text())==strip(subprocess.check_output(['git','show',f'{ref}:src/app/globals.css'],cwd=r,text=True))
fingerprint=hashlib.sha256(json.dumps([(x['path'],x['sha256']) for x in rows],separators=(',',':')).encode()).hexdigest()
data={'testId':'DC6-SOURCE-FREEZE','status':'PASS','createdAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'base':ref,'sha256':fingerprint,'files':rows,'unchangedBoundaries':same,'dependencyChange':'None. package.json only registers meaningful native navigation tests; lockfile unchanged.','printBridge':'Summary/quotation.css/controllers/QR/assets unchanged; only separate navigation band print:none. Fresh printmedia must verify hidden band/oneactive whiteA4/no ordinary-page residue. Physical PDF/QR limited to unchanged prior reports, never claimed rerun.','contentBridge':'Business data/approved compositions preserved; adapters now share resolver. FreshHTTP parity diagnostics must match previously adjudicated90 candidates before reusing that semantic decision.','fullFreshRequired':'six quality;normal+Pages49HTTP/245layouts/affectedaxe/business plus96switchdirections/newtab/query/hash/fallback/menu/history/PII and screenshots'}
Path('/tmp/xk-dc006-final/source-bridge.json').write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'status':'PASS','files':len(rows),'unchangedBoundaries':len(same),'sha256':fingerprint}))
