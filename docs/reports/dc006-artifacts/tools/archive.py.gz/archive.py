from pathlib import Path
import json,gzip,hashlib
r=Path('/tmp/xk-dc006-build');src=Path('/tmp/xk-dc006-final');dst=r/'docs/reports/dc006-artifacts';dst.mkdir(parents=True,exist_ok=True);rows=[]
def put(p,name,compress=False):
 b=p.read_bytes();data=gzip.compress(b,mtime=0) if compress else b;name+=('.gz' if compress else '');target=dst/name;target.parent.mkdir(parents=True,exist_ok=True)
 if target.exists():assert target.read_bytes()==data,name
 else:target.write_bytes(data)
 rows.append({'path':name,'sha256':hashlib.sha256(data).hexdigest(),'decodedSha256':hashlib.sha256(b).hexdigest(),'bytes':len(data),'decodedBytes':len(b),'archiveEncoding':'gzip' if compress else 'identity'})
for p in sorted(src.iterdir()):
 if not p.is_file() or (p.name.startswith('server-') or p.name=='failure-map.json'):continue
 if p.suffix=='.json':put(p,'core/'+p.name,p.name in ['fixture.json','catalog.json'] or 'source-bridge' in p.name or p.name.endswith('-result.json'))
 elif p.suffix in ['.log','.cjs','.py'] or p.name.endswith('.diff.txt'):put(p,('logs/' if p.suffix=='.log' else 'tools/')+p.name,True)
versions=['normal-tiny-preflight','normal-tiny-preflight-v2','normal-tiny-preflight-v3','normal-tiny-preflight-v4','normal-final','normal-v2','pages-v2','pages-query-v5']
failed=[];unique={}
for v in versions:
 p=src/v/'result.json';put(p,'browser/'+v+'/result.json',True);d=json.loads(p.read_text())
 for e in d.get('failureScreenshots',[]):
  f=Path(e['path']);h=hashlib.sha256(f.read_bytes()).hexdigest();name='failures/'+h+'.png'
  if h not in unique:put(f,name);unique[h]=name
  failed.append({'version':v,'testId':e['testId'],'originalPath':str(f),'sha256':h,'archivedPath':name})
for mode in ['normal','pages']:
 folder=src/f'incomplete-{mode}-v2'
 for p in sorted(folder.iterdir()):
  if p.is_file():put(p,'overlap/'+mode+'/'+p.name,p.suffix!='.png')
for p in sorted(Path('/tmp/xk-dc006/ui').iterdir()):
 if p.is_file():put(p,'ui/'+p.name,True)
for n in ['source-review.json','source-review.md']:
 put(Path('/tmp/xk-dc006-source')/n,'company/'+n,True)
selection=json.loads((src/'remote/archive-selection-v2.json').read_text())
put(src/'remote/archive-selection-v2.json','artifact/archive-selection-v2.json',True)
for item in selection['files']:
 p=Path(item['path']);assert hashlib.sha256(p.read_bytes()).hexdigest()==item['sha256']
 put(p,'artifact/'+item['restoreRelativePath'],True)
# No remote signed download URL or post-push mutable files are copied.
mapping=json.dumps(failed,ensure_ascii=False,indent=2)+'\n';mp=src/'failure-map.json';mp.write_text(mapping);put(mp,'failure-map.json',True)
(dst/'manifest.json').write_text(json.dumps({'files':rows,'failureImages':len(failed),'uniqueFailureImages':len(unique),'policy':'Immutable raw bytes; explicit wrapper encoding; executed original failures and corrected versions retained. Actual remote CI events go to PR description, not a self-referential commit.'},ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'files':len(rows),'bytes':sum(x['bytes'] for x in rows),'failureImageRecords':len(failed),'uniqueFailureImages':len(unique)}))
