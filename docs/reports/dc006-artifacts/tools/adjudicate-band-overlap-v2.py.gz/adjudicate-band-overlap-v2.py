"""Per-target current band overlap review; never rewrites original axe/Exit2."""
import argparse,json,re,hashlib
from pathlib import Path
from datetime import datetime,timezone
from collections import Counter

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def color(v):
 m=re.fullmatch(r'(rgba?|color)\(([^()]+)\)',v);assert m,'Unsupported actual color '+v
 k,b=m.groups();a=b.replace(',',' ').replace('/',' ').split()
 if k=='color':assert a.pop(0)=='srgb';rgb=[float(x)*255 for x in a[:3]]
 else:rgb=[float(x)for x in a[:3]]
 return rgb,float(a[3])if len(a)>3 else 1.
def luminance(c):
 q=[x/255 for x in c];return sum(w*(x/12.92 if x<=.04045 else((x+.055)/1.055)**2.4)for w,x in zip([.2126,.7152,.0722],q))
def ratio(f,b):
 x,y=luminance(f),luminance(b);return(max(x,y)+.05)/(min(x,y)+.05)
def bound(f,b,shadow,a):
 bg=[b,[x*(1-a)+y*a for x,y in zip(b,shadow)]];fg=[f,[x*(1-a)+y*a for x,y in zip(f,shadow)]]
 lo=[min(c[i]for c in bg)for i in range(3)];hi=[max(c[i]for c in bg)for i in range(3)];fl=[min(c[i]for c in fg)for i in range(3)];fh=[max(c[i]for c in fg)for i in range(3)];x,y=luminance(lo),luminance(fh);return(x+.05)/(y+.05)if x>y else(luminance(fl)+.05)/(luminance(hi)+.05)if luminance(fl)>luminance(hi)else 1.
def closed_paint(n):
 for a in n['ancestors']:
  s=a['style'];assert s['opacity']=='1'and s['backgroundImage']=='none'and s['filter']=='none'and s['backdropFilter']=='none'and s['mixBlendMode']=='normal','Unresolved layered/group paint'
  assert all(p['content']in('none','normal')or p['display']=='none'or p['visibility']=='hidden'for p in a['pseudos']),'Painted pseudo needs separate review'
 fg,alpha=color(n['element']['style']['color']);assert alpha==1
 positive=[(a,*color(a['style']['backgroundColor']))for a in n['ancestors']if color(a['style']['backgroundColor'])[1]>0];assert positive and positive[0][2]==1;opaque,bg,_=positive[0]
 approved_foregrounds=[[16,24,40],[102,112,133],[37,99,235],[255,255,255]];approved_backgrounds=[[255,255,255],[16,24,40]]
 assert fg in approved_foregrounds and bg in approved_backgrounds,'Unknown band palette, do not inherit a generic white assumption'
 return{'foreground':fg,'opaqueBackground':bg,'opaqueAncestorPath':opaque['path'],'contrastRatio':ratio(fg,bg),'method':'Fresh opaque foreground and nearest actual opaque surface, all intervening backgrounds transparent and no image/filter/groupopacity/pseudo. Exact WCAGsRGB0.04045 formula, no rounded threshold.'}
parser=argparse.ArgumentParser();parser.add_argument('--evidence',required=True);parser.add_argument('--output',required=True);args=parser.parse_args();output=Path(args.output);assert not output.exists(),'Preserve existing adjudication'
ev=json.loads(Path(args.evidence).read_text());raw=json.loads(Path(ev['input']['path']).read_text());assert sha(ev['input']['path'])==ev['input']['sha256'];assert ev['status']=='CAPTURE_COMPLETE_NOT_ADJUDICATED'
for k in ['sourceCSS','switcherCSS']:assert sha(ev[k]['snapshot'])==ev[k]['sha256']
css=Path(ev['switcherCSS']['snapshot']).read_text();assert '#FFFFFF'in css and '#101828'in css and '#2563EB'in css and '#667085'in css
expected=Counter((g['route'],g['width'],g['state'],tuple(n['target']))for g in raw['manualStyles']for n in g['nodes']);observed=Counter();rows=[]
for gi,g in enumerate(ev['groups']):
 for ni,n in enumerate(g['actual']['nodes']):
  k=(g['route'],g['width'],g['state'],tuple(n['target']));observed[k]+=1;original=next(v for v in raw['manualStyles']if(v['route'],v['width'],v['state'])==k[:3])['nodes'][ni];assert original['target']==n['target']
  row={'testId':f'DC006-BAND-OVERLAP-{len(rows)+1:02d}','route':g['route'],'width':g['width'],'state':g['state'],'target':n['target'],'text':n.get('text'),'originalChecks':original['checks'],'evidenceGroupIndex':gi,'evidenceNodeIndex':ni,'status':'MANUAL_PENDING'}
  try:
   assert n['resolution']=='FOUND';assert original['rule']=='color-contrast';assert {c['data'].get('messageKey')for c in original['checks']}=={'bgOverlap'}
   closed=next(c for c in g['closed']['nodes']if c['target']==n['target']);assert closed['resolution']=='FOUND'and n['text']==closed['text']==original['computed']['text'];assert n['element']['style']['color']==closed['element']['style']['color']==original['computed']['ancestors'][0]['style']['color']
   calc=closed_paint(closed);required=max(float(c['data']['expectedContrastRatio'].split(':')[0])for c in original['checks']);assert calc['contrastRatio']>=required+.001
   panel=g['actual']['panel'];s=panel['style'];assert s['backgroundColor']=='rgb(255, 255, 255)'and s['opacity']=='1'and s['backgroundImage']=='none'and s['filter']=='none'and s['backdropFilter']=='none'and s['mixBlendMode']=='normal'and s['display']!='none'
   points=[p for p in n['hitTests']if p['inViewport']];assert len(points)==9 and all(p['stack']for p in points);covered=[p for p in points if p['stack'][0]['panelContains']];exposed=[p for p in points if not p['stack'][0]['panelContains']]
   row.update(requiredRatio=required,closedPaint=calc,panel=panel,coverageRatio=n['panelCoverageRatio'],hitTests={'inViewport':len(points),'topmostPanel':len(covered),'topmostExposedTarget':sum(p['stack'][0]['targetContains']for p in exposed)})
   if n['panelCoverageRatio']>=1-1e-9:assert len(covered)==9;row['status']='PASS_FULL_OPAQUE_OCCLUSION_AND_CLOSED_PAINT';row['reason']='Entire measured target box is under opaque white menu and9/9 actual hit tests end in panel descendants; closed exact same text/target has passing actual paint. Invisible underlying glyphs are not assigned a fake contrast.'
   else:
    assert 0<n['panelCoverageRatio']<1 and covered and exposed and all(p['stack'][0]['targetContains']for p in exposed);shadows=[color(c)for c in re.findall(r'(?:rgba?|color)\([^()]+\)',s['boxShadow'])if color(c)[1]>0];assert len(shadows)==1;rgb,alpha=shadows[0];assert abs(alpha-.08)<1e-9 and all(abs(x-y)<.001 for x,y in zip(rgb,[16,26,51]));minimum=bound(calc['foreground'],calc['opaqueBackground'],rgb,alpha);assert minimum>=required+.001;row['exposedShadowBound']={'rgb':rgb,'maximumAlpha':alpha,'minimumContrast':minimum,'foregroundAndBackgroundBothBounded':True};row['status']='PASS_PARTIAL_EXPOSED_SHADOW_BOUND';row['reason']='Measured panel portion covered, remaining target actually topmost at exposed points; full8%shadow conservative bound separately exceeds threshold.'
  except Exception as error:row['reason']=str(error)
  rows.append(row)
counts=Counter(x['status']for x in rows);coverage=expected==observed;report={'testId':'DC006-FINAL-BAND-OVERLAP-ADJUDICATION','status':'PASS_SCOPED_OVERLAP_REVIEW'if coverage and not counts['MANUAL_PENDING']else'MANUAL_PENDING','mode':ev['mode'],'generatedAt':datetime.now(timezone.utc).isoformat(),'original':ev['input'],'originalPolicy':'Original formal MANUAL_PENDING/actualExit2 and10incomplete remain untouched. This separate per-target paint/occlusion review does not claim axe0incomplete or fullWCAG/AT.','evidence':{'path':args.evidence,'sha256':sha(args.evidence)},'sourceCSS':{k:ev[k]for k in ['sourceCSS','switcherCSS']},'coverageExact':coverage,'counters':dict(counts),'targets':len(rows),'minimumClosedContrast':min(r.get('closedPaint',{}).get('contrastRatio',999)for r in rows),'screenshots':ev['screenshots'],'manualVisual':'Normal two actual375x1000 closed/open PNGs inspected: closed all3style items/current/note readable; open menu entirely covers underlying band. Pages screenshots require separate actual observation if this script is reused there.','rows':rows};output.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print(json.dumps({k:report[k]for k in ['status','mode','targets','coverageExact','counters','minimumClosedContrast']}));raise SystemExit(0 if report['status']=='PASS_SCOPED_OVERLAP_REVIEW'else 2)
