from pathlib import Path
import json,hashlib,shutil,datetime
r=Path('/tmp/xk-dc006-build');s=Path('/tmp/xk-dc006-final');dst=r/'docs/screenshots/design-collection/dc006';dst.mkdir(parents=True,exist_ok=True)
h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
d=json.loads((s/'pages-v2/result.json').read_text());rows=[]
for row in d['screenshots']:
 p=Path(row['path']);assert h(p)==row['sha256'];target=dst/p.name;shutil.copyfile(p,target)
 rows.append({**row,'originalPath':row['path'],'path':target.name,'mode':'Pages static export','humanReview':'Root actually inspected this image on 2026-11-26. Long full-page images were resized for composition overview; six original band closeups, two comparison viewports and two mobile-menu viewports inspected at readable detail. No claim of pixel-by-pixel reading of all long-page body text.'})
assert len(rows)==18
review={'testId':'DC6-VISUAL','status':'PASS_SCOPED_VISUAL_REVIEW','date':'2026-11-26','sourceFingerprint':'fa0e21576322d94fa7565c61a0b8ef36a1eba6bc3a3dd058f082e4ebe02decac','mode':'Pages, Chromium156, viewport height1000, deviceScaleFactor1','observations':['Three current-style states visibly distinguish current text/check and real alternative links. Desktop three columns and mobile wrapping remain readable.','Three brand home compositions and images retained; new white navigation band sits between Header and main without overlap.','Gallery seven-row comparison table remains readable in 375px viewport; three cards and long grouped Footer retain normal flow.','Heritage/Luxury deep-page mobile menus, visible focus and current band are in document flow with no clipped controls.','Full-page overviews support section order/overall composition only. Automated245 layouts in each mode independently cover320/375/768/1440/1920.'],'images':rows,'limitations':['Local acceptance screenshots, not public DC006 deployment evidence.','No physical PDF generated in DC006; unchanged A4/QR bytes bridge plus fresh print-media assertions are documented separately.']}
(dst/'visual-review.json').write_text(json.dumps(review,ensure_ascii=False,indent=2)+'\n')
lines=['# DC-006｜實際驗收截圖','','日期：2026-11-26。18 張皆為本輪最終 v2 原始 PNG；Pages 靜態預覽、Chromium 156、viewport height 1000／deviceScaleFactor 1。不是正式部署截圖。Root 已實際逐張開啟；長全頁以縮圖檢視整體組成，六張原尺寸切換列、兩張比較表與兩張選單 viewport 另檢查可讀性、目前狀態及 focus。','','三系列原有組成及圖片保留；切換列與展開選單沒有截斷、比較表沒有水平溢出。長圖縮覽不代表逐字閱讀全部內容或像素級全頁審核。精確 SHA、路徑及範圍見 [visual-review.json](visual-review.json)，測試與限制見 [報告](../../../reports/dc006-implementation.md)。','','| 圖片 | 路徑 | 寬度 | 形式 |','| --- | --- | --- | --- |']
lines += [f"| [{Path(x['path']).stem}]({x['path']}) | `{x['route']}` | {x['width']}px | {x['kind']} |" for x in rows]
(dst/'README.md').write_text('\n'.join(lines)+'\n')
old=s/'parity-bridge.json';prev=json.loads(Path('/tmp/xk-dc006-merge/luxury/http-normal-result.json').read_text())['contentParityDiagnostics'];a=json.loads(old.read_text());files=[]
for mode in ['normal','pages']:
 p=s/f'http-{mode}-v2-result.json';data=json.loads(p.read_text());assert data['complete'] and data['exitCode']==0;assert data['contentParityDiagnostics']==prev
 files.append({'path':str(p),'sha256':h(p),'rows':len(prev)})
a.update({'testId':'DC6-CONTENT-PARITY-DECISION-BRIDGE-V2','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'sourceFingerprint':review['sourceFingerprint'],'freshFinalModeEvidence':files,'previousBridgeSha256':h(old),'comparison':'Finalv2 normal and Pages each have exact decodedJSON equality of all32 diagnostic rows and90 candidates with previous independently reviewed integration. Only the previous90 semantic decisions are reused; all new runtime/HTTP/browser acceptance is fresh.'})
(s/'parity-bridge-v2.json').write_text(json.dumps(a,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'screenshots':len(rows),'parityRowsEachMode':len(prev),'status':'PASS'}))
