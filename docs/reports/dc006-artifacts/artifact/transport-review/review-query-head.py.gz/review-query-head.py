from pathlib import Path
from urllib.parse import urlsplit,parse_qs
from datetime import datetime,timezone
import hashlib,json,re
root=Path('/tmp/xk-dc006-final/transport-review');base=Path('/tmp/xk-dc006-final');repo=Path('/tmp/xk-dc006-build')
sha=lambda raw:hashlib.sha256(raw).hexdigest()
result_path=base/'pages-v2/result.json';data=json.loads(result_path.read_text());log_path=base/'server-pages-v2.log';log_raw=log_path.read_bytes();lines=log_raw.decode().splitlines()
cache_path=repo/'node_modules/next/dist/client/components/segment-cache/cache.js';cache=cache_path.read_text();cache_lines=cache.splitlines();head_index=next(i for i,line in enumerate(cache_lines) if "method: 'HEAD'" in line);function_start=max(i for i in range(head_index) if cache_lines[i].startswith('async function '));excerpt_start=max(function_start,head_index-58);excerpt_end=head_index+20
source_excerpt='\n'.join(f'{i+1}: {cache_lines[i]}' for i in range(excerpt_start,excerpt_end))+'\n'
with (root/'next-head-source-excerpt.txt').open('x') as out:out.write(source_excerpt)
fetch_path=repo/'node_modules/next/dist/client/components/segment-cache/fetch.js';fetch_text=fetch_path.read_text()
bundle=[]
for path in (repo/'out/_next').rglob('*.js'):
 raw=path.read_bytes();pos=raw.find(b'method:"HEAD"')
 if pos>=0:bundle.append({'path':str(path.relative_to(repo/'out')),'sha256':sha(raw),'byteOffset':pos,'excerpt':raw[max(0,pos-450):pos+650].decode('utf-8','replace')})
requests=data['requests'];errors=data['networkErrors'];rows=[];selected={}
for ident in [26986,27086,27182]:
 error=next(row for row in errors if row['requestId']==ident);u=urlsplit(error['url']);test=error['startedDuringTest'];tree_path=u.path.rstrip('/')+'/__next._tree.txt'
 tree=[row for row in requests if row.get('method')=='GET' and urlsplit(row['url']).path==tree_path and parse_qs(urlsplit(row['url']).query).get('source')==['qa'] and row.get('startedDuringTest')==test and row.get('headers',{}).get('referer')==error['headers']['referer'] and row.get('headers',{}).get('rsc')=='1' and row.get('headers',{}).get('next-router-prefetch')=='1' and row.get('headers',{}).get('next-router-segment-prefetch')=='/_tree']
 matching=[]
 for request in tree:
  parsed=urlsplit(request['url']);needle='"GET '+parsed.path+'?'+parsed.query+' HTTP/1.1" 200 '
  log_matches=[{'lineNumber':index+1,'raw':line} for index,line in enumerate(lines) if needle in line]
  for row in log_matches:selected[row['lineNumber']]=row['raw']
  matching.append({'request':request,'browserResponseStatus':None,'browserResponseStatusNote':'Original observer did not store the matching response; no value inferred.','serverLogExact200':log_matches})
 document_matches=[{'lineNumber':index+1,'raw':line} for index,line in enumerate(lines) if '"GET '+u.path+'?'+u.query+' HTTP/1.1" 200 ' in line]
 for row in document_matches:selected[row['lineNumber']]=row['raw']
 payload_matches=[{'lineNumber':index+1,'raw':line} for index,line in enumerate(lines) if '"GET '+u.path+'__next.' in line and '.__PAGE__.txt?source=qa&_rsc=' in line and ' HTTP/1.1" 200 ' in line]
 for row in payload_matches:selected[row['lineNumber']]=row['raw']
 rows.append({'headError':error,'headCompletionStatus':None,'headCompletionNote':'Original raw error retained. HEAD was not observed200; no status backfilled.','matchedTreePrefetch':matching,'documentGet200Log':document_matches,'pagePayloadGet200Log':payload_matches,'supportsLegitimateExportQueryPrefetch':len(tree)==1 and bool(matching[0]['serverLogExact200']) and bool(document_matches) and bool(payload_matches)})
selected_text='\n'.join(f'{number}: {line}' for number,line in sorted(selected.items()))+'\n'
with (root/'server-exact-query-get-excerpt.log').open('x') as out:out.write(selected_text)
proof={'status':'READ_ONLY_DIAGNOSIS_COMPLETED','observedAt':datetime.now(timezone.utc).isoformat(),'originalResult':{'path':str(result_path),'sha256':sha(result_path.read_bytes()),'status':data['status'],'unchanged':True,'networkFailures':len(errors)},'serverLog':{'path':str(log_path),'capturedBytes':len(log_raw),'capturedSha256':sha(log_raw),'note':'Server remains live; hash covers the bytes actually read at this observation.','selectedExcerptSha256':sha(selected_text.encode())},'next':{'version':json.loads((repo/'node_modules/next/package.json').read_text())['version'],'cachePath':str(cache_path),'cacheSha256':sha(cache_path.read_bytes()),'headFunctionLine':function_start+1,'headFunction':cache_lines[function_start],'headCallLine':head_index+1,'excerptSha256':sha(source_excerpt.encode()),'queryIncluded':"new URL(pathname + search, location.origin)" in cache,'headAwaitedBeforeTreeFetch':"const headResponse = await" in cache and "headResponse.status < 200 || headResponse.status >= 400" in cache,'headCallHasNoAbortSignal':"const headResponse = await (0, _fetch.fetch)(url, {\n                method: 'HEAD'\n            });" in cache,'fetchWrapperSha256':sha(fetch_path.read_bytes()),'wrapperReturnsNativeFetch':'return fetch(input, init);' in fetch_text,'actualExportBundles':bundle},'threeRows':rows,'conclusion':'All three are tightly matched to the legitimate Next static-export query prefetch protocol and exact server-side RSC/PAGE GET200s; there is no demonstrated CSS/JS/image or unavailable-route failure in these three events. The query exclusion in the old monitor misses this valid protocol case.','limitations':['No original HEAD200 or fulfilled promise was captured, so none is claimed.','The Next source does not explicitly abort this HEAD; do not assert that Next actively canceled it or establish the browser cancellation mechanism.','Original416PASS+finalNetworkFAIL stays immutable; this diagnosis does not relabel the suite PASS.','Original request records lack per-request CDP initiator/response proof; corresponding source and RSC headers establish protocol consistency, not a captured individual call stack.'],'recommendedNarrowRetestGuard':['Only the exact three contact/?source=qa paths, methodHEAD/typefetch/net::ERR_ABORTED, matching same origin/referrer/test/style/document window.','Require matching exact-query tree GET with rsc1/next-router-prefetch1/segment/_tree/next-url source-path and actual2xx response in the fresh observer; one-to-one/nearest pairing and no cross-document borrowing.','Retain raw HEAD errors as classified prefetch transport events, never fabricate their status200.','GET/image/CSS/JS/other queries/missing or failed tree response remain failures; preserve negative fixtures.']}
assert all(row['supportsLegitimateExportQueryPrefetch'] for row in rows)
with (root/'query-head-independent-review.json').open('x') as out:json.dump(proof,out,ensure_ascii=False,indent=2);out.write('\n')
print(json.dumps({'status':proof['status'],'matchedHeads':[row['headError']['requestId'] for row in rows],'allExactTreeGet200':True,'nextVersion':proof['next']['version'],'headFunctionLine':function_start+1,'headCallLine':head_index+1,'originalHeadsCompleted200':None,'originalSuiteRelabeled':False,'report':str(root/'query-head-independent-review.json')}))
