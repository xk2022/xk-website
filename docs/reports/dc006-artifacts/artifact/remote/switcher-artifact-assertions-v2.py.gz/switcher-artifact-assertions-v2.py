def inspect_switcher(path, doc, smoke, check):
    contract = smoke.design_contract
    styles = ['modern', 'heritage', 'luxury']
    groups = {style: contract[style + 'Routes'] for style in styles}
    identity = smoke.design_identity(path)
    current_style = identity.get('styleId', 'modern') if identity else None
    bands = [element for element in doc.all('nav') if 'data-design-switcher' in element.attrs]
    check(path + ' exactly one accessible switcher band', 1, len(bands))
    if len(bands) != 1:
        return
    band = bands[0]
    check(path + ' switcher navigation label', '網站設計風格', band.attrs.get('aria-label'))
    elements = doc.all()
    headers, mains = doc.all('header'), doc.all('main')
    ordered = len(headers) == len(mains) == 1 and elements.index(headers[0]) < elements.index(band) < elements.index(mains[0])
    check(path + ' switcher follows Header and precedes main without nesting in either', True,
          ordered and band not in headers[0].all() and band not in mains[0].all())
    items = [element for element in band.all() if 'data-design-switcher-target' in element.attrs]
    check(path + ' switcher independently ordered three style items', styles,
          [element.attrs.get('data-design-switcher-target') for element in items])
    currents = [element.attrs.get('data-design-switcher-target') for element in items if element.attrs.get('aria-current') == 'page']
    check(path + ' exact current style; Gallery has no false Modern current', [current_style] if identity else [], currents)
    note = '切換風格不帶入聯絡草稿、客戶稱呼與專案名稱'
    check(path + ' visible personal-data warning', True, note in band.text())
    check(path + ' visible option-restoration statement without implementation jargon', True, '已儲存的試算選項可還原' in band.text())
    collection = [element for element in band.all('a') if 'data-design-collection-link' in element.attrs]
    check(path + ' one native comparison link without query/hash/trailing slash', ['/design-collection'],
          [element.attrs.get('href') for element in collection])
    for element in items:
        style = element.attrs.get('data-design-switcher-target')
        if style not in groups:
            continue
        is_current = bool(identity and current_style == style)
        same = next((route for route in groups[style] if identity and route['pageKey'] == identity['pageKey']
                     and route.get('slug') == identity.get('slug')), None)
        target = same or next(route for route in groups[style] if route['pageKey'] == 'home')
        check(path + ' ' + style + ' visible style label', True, style.title() in element.text())
        if is_current:
            check(path + ' ' + style + ' current item is text, not a fake action', ['span', None, 'page'],
                  [element.tag, element.attrs.get('href'), element.attrs.get('aria-current')])
            check(path + ' ' + style + ' visible current wording', True, '目前版本' in element.text())
        else:
            # SSR has no browser hash. Only this published native anchor is checked;
            # hash preservation/query stripping on activation is a browser/unit concern.
            check(path + ' ' + style + ' exact native same-content/home-fallback href', ['a', target['path']],
                  [element.tag, element.attrs.get('href')])
            fallback = same is None
            check(path + ' ' + style + ' explicit fallback data state', 'true' if fallback else None,
                  element.attrs.get('data-style-fallback'))
            wording = '本頁無對應版本，前往首頁' if fallback else '查看此頁版本'
            check(path + ' ' + style + ' correct visible destination wording', True, wording in element.text())
            described = element.attrs.get('aria-describedby')
            matches = [node for node in band.all() if described and node.attrs.get('id') == described and note in node.text()]
            check(path + ' ' + style + ' links the visible personal-data warning', 1, len(matches))
    if path != contract['collectionRoute']['path']:
        return
    sections = [element for element in doc.all() if element.attrs.get('id') == 'compare-pages']
    check('Gallery exactly one comparison section', 1, len(sections))
    if len(sections) != 1:
        return
    tables = sections[0].all('table')
    check('Gallery exactly one comparison table', 1, len(tables))
    if len(tables) != 1:
        return
    table = tables[0]
    bodies = table.all('tbody')
    rows = bodies[0].all('tr') if len(bodies) == 1 else []
    keys = ['home', 'about', 'services', 'solutions', 'portfolio', 'contact', 'quotation']
    check('Gallery comparison has seven main-page rows', 7, len(rows))
    check('Gallery comparison has exactly21 real page anchors', 21, len(table.all('a')))
    for key, row in zip(keys, rows):
        destinations = [next(route['path'] for route in groups[style] if route['pageKey'] == key) for style in styles]
        # These are Next Link entries under Pages trailingSlash:true, deliberately
        # distinct from the switcher's native href contract above.
        expected = [value if value == '/' else value + '/' for value in destinations]
        check('Gallery ' + key + ' exact three published Next Link destinations', expected,
              [element.attrs.get('href') for element in row.all('a')])
