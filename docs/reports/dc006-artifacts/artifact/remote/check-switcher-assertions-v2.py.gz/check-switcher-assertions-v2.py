from pathlib import Path
from types import SimpleNamespace
import importlib.util,json,hashlib
root=Path('/tmp/xk-dc006-final/remote');source=Path('/tmp/xk-dc006-build')
def module(name,path):
 spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
sm=module('dc006_smoke',source/'scripts/smoke-website.py');m=module('dc006_band_assertions',root/'switcher-artifact-assertions-v2.py')
suite=sm.Smoke(SimpleNamespace(base_url='https://www.xplorekaleidoscope.com/',timeout=1,check_external=False,check_source_assets=False,output=None))
styles=['modern','heritage','luxury'];groups={key:suite.design_contract[key+'Routes'] for key in styles};note='切換風格不帶入聯絡草稿、客戶稱呼與專案名稱，也不會自動複製個人欄位；已儲存的試算選項可還原。'
def document(path):
 identity=suite.design_identity(path);current=identity.get('styleId','modern') if identity else None
 items=[]
 for style in styles:
  target=next((x for x in groups[style] if identity and x['pageKey']==identity['pageKey'] and x.get('slug')==identity.get('slug')),None)
  current_item=identity and style==current
  attrs=f'data-design-switcher-target="{style}"'
  if current_item:items.append(f'<li><span {attrs} aria-current="page">{style.title()} ✓ 目前版本</span></li>')
  else:
   fallback=target is None;target=target or next(x for x in groups[style] if x['pageKey']=='home')
   flag=' data-style-fallback="true"' if fallback else ''
   items.append(f'<li><a {attrs}{flag} href="{target["path"]}" aria-describedby="note">{style.title()} '+('本頁無對應版本，前往首頁' if fallback else '查看此頁版本')+'</a></li>')
 band='<nav data-design-switcher aria-label="網站設計風格"><a data-design-collection-link href="/design-collection">比較三套版面</a><ul>'+''.join(items)+'</ul><p id="note">'+note+'</p></nav>'
 extra=''
 if not identity:
  rows=[]
  for key in ['home','about','services','solutions','portfolio','contact','quotation']:
   links=[]
   for style in styles:
    p=next(x['path'] for x in groups[style] if x['pageKey']==key);href=p if p=='/' else p+'/'
    links.append('<td><a href="'+href+'">查看</a></td>')
   rows.append('<tr><th>'+key+'</th>'+''.join(links)+'</tr>')
  extra='<section id="compare-pages"><table><tbody>'+''.join(rows)+'</tbody></table></section>'
 return '<html><body><header></header>'+band+'<main>'+extra+'</main><footer></footer></body></html>'
results=[]
def run(name,path,html,expected):
 rows=[]
 m.inspect_switcher(path,sm.Document(html).root,suite,lambda label,want,actual: rows.append({'item':label,'expected':want,'actual':actual,'status':'PASS' if want==actual else 'FAIL'}))
 failures=[x['item'] for x in rows if x['status']=='FAIL'];actual='FAIL' if failures else 'PASS'
 results.append({'case':name,'expected':expected,'actual':actual,'status':'PASS' if expected==actual else 'FAIL','rejectedAssertions':failures})
home=document('/');gallery=document('/design-collection')
run('Valid SSR Modern current and two counterpart native links','/',home,'PASS')
path='/design-collection/heritage/portfolio/showcases/qiangang-windows';run('Valid deep identity preserves slug with Heritage current',path,document(path),'PASS')
run('Gallery has three explicit home fallbacks and21 Next links','/design-collection',gallery,'PASS')
run('Reject native band non-root trailing slash','/',home.replace('href="/design-collection/heritage"','href="/design-collection/heritage/"',1),'FAIL')
run('Reject query/personal field in native href','/',home.replace('href="/design-collection/luxury"','href="/design-collection/luxury?name=sample"',1),'FAIL')
run('Reject false current text','/',home.replace('目前版本','其他版本',1),'FAIL')
run('Reject duplicate/missing style target','/',home.replace('data-design-switcher-target="heritage"','data-design-switcher-target="luxury"',1),'FAIL')
run('Reject missing linked PII warning','/',home.replace('aria-describedby="note"','',1),'FAIL')
run('Reject switcher nested inside Header','/',home.replace('</header>','',1).replace('</nav>','</nav></header>',1),'FAIL')
run('Reject Gallery missing explicit fallback','/design-collection',gallery.replace('data-style-fallback="true"','',1),'FAIL')
run('Reject Gallery Next Link missing Pages slash','/design-collection',gallery.replace('href="/about/"','href="/about"',1),'FAIL')
run('Reject missing visible restoration statement','/',home.replace('已儲存的試算選項可還原','',1),'FAIL')
record={'status':'PASS' if all(x['status']=='PASS' for x in results) else 'FAIL','scope':'Offline synthetic positive/negative checker fixtures only; no website/browser/build/CI acceptance','caseCount':len(results),'cases':results,'assertionsSha256':hashlib.sha256((root/'switcher-artifact-assertions-v2.py').read_bytes()).hexdigest()}
with (root/'switcher-assertions-selfcheck-v2.json').open('x') as out:json.dump(record,out,ensure_ascii=False,indent=2);out.write('\n')
print(json.dumps(record,ensure_ascii=False));raise SystemExit(0 if record['status']=='PASS' else 1)
