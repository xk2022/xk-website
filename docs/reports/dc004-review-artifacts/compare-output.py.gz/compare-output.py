from pathlib import Path
import json,zipfile,tarfile,io,re,hashlib,collections,subprocess
r=Path.cwd();p=Path('/tmp/xk-dc004-review')
z=zipfile.ZipFile('/tmp/xk-dc003/ci-pages.zip');t=tarfile.open(fileobj=io.BytesIO(z.read(next(n for n in z.namelist() if n.endswith('.tar')))))
a={m.name.removeprefix('./'):t.extractfile(m).read() for m in t if m.isfile()};b={str(f.relative_to(r/'out')):f.read_bytes() for f in (r/'out').rglob('*') if f.is_file()}
def build_id(d):
 ids={n.split('/')[2] for n in d if re.match(r'^_next/static/[^/]+/_buildManifest\.js$',n)}
 assert len(ids)==1,ids
 return ids.pop()
def normalize(d):
 bid=build_id(d)
 return {n.replace('/'+bid+'/', '/BUILD_ID/'):v.replace(bid.encode(),b'BUILD_ID') if n.endswith(('.html','.txt','.js')) else v for n,v in d.items()}
x,y=normalize(a),normalize(b);diff=[n for n in x.keys()&y.keys() if x[n]!=y[n]];missing=sorted(x.keys()-y.keys());extra=sorted(y.keys()-x.keys())
exts={'.css','.js','.woff2','.woff','.ttf','.svg','.webp','.png','.ico','.jpg','.jpeg'}
def runtime(d):
 return collections.Counter((re.sub(r'^_next/static/[^/]+/(_(?:ssgManifest|clientMiddlewareManifest|buildManifest)\.js)$',r'_next/static/BUILD_ID/\1',n),hashlib.sha256(v).hexdigest()) for n,v in d.items() if Path(n).suffix in exts)
runtime_match=runtime(a)==runtime(b)
source=sorted(set(subprocess.check_output(['git','ls-files','src','public','scripts','package.json','package-lock.json','next.config.ts','tsconfig.json','.github'],text=True).splitlines()))
changes=[n for n in source if subprocess.check_output(['git','show','8ba299a:'+n])!=(r/n).read_bytes()]
basecss=subprocess.check_output(['git','show','8ba299a:src/app/globals.css']).decode();css=(r/'src/app/globals.css').read_text();added='''/* Local brand-review prototypes and evidence must not generate website utilities. */
@source not "../../docs/01_design/design-collection/reviews";
@source not "../../docs/reports/dc004-brand-review.md";
@source not "../../docs/reports/dc004-review-artifacts";
'''
source_ok=changes==['src/app/globals.css'] and css.replace(added,'',1)==basecss
result={'status':'PASS' if not diff and not missing and not extra and runtime_match and source_ok else 'FAIL','base':'main@8ba299a5a48da41ca7f4d88d9b2149d7c83f6584','comparisonArtifact':{'pr':39,'head':'0d2b05d4002637e26461519636eaccf21950cbe6','artifactId':15084662756,'zipSha256':hashlib.sha256(Path('/tmp/xk-dc003/ci-pages.zip').read_bytes()).hexdigest()},'comparedFiles':len(b),'runtimeCount':sum(runtime(b).values()),'runtimeBytesMatch':runtime_match,'normalization':'Only each actual Next Build ID and its directory. No CSS, JS logic, fonts, prices, HTML copy or structure normalization. Runtime byte hash comparison does not normalize content.','missing':missing,'extra':extra,'differences':diff,'appChanges':changes,'onlySourceDiscoveryExclusions':source_ok,'htmlCount':sum(n.endswith('.html') for n in b),'reviewExported':any('reviews' in n or 'heritage' in n for n in b)}
result['status']='PASS' if result['status']=='PASS' and not result['reviewExported'] and result['htmlCount']==20 else 'FAIL'
(p/'output-bridge-result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2));raise SystemExit(0 if result['status']=='PASS' else 1)
