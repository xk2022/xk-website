import assert from 'node:assert/strict';
import { readFileSync, existsSync } from 'node:fs';
import { dirname, resolve } from 'node:path';
import { homepageHero } from '/workspace/xk-website/src/config/homepage.ts';
import { serviceCategories, serviceProcessSteps, servicesPage } from '/workspace/xk-website/src/config/services.ts';
import { showcaseSettings, websiteShowcases } from '/workspace/xk-website/src/config/website-showcases.ts';

const path = '/workspace/xk-website/docs/01_design/design-collection/reviews/heritage-v1.html';
const html = readFileSync(path, 'utf8');
const decoded = html.replaceAll('&amp;', '&');
const ids = [...html.matchAll(/\bid="([^"]+)"/g)].map((match) => match[1]);
assert.equal(new Set(ids).size, ids.length, 'unique IDs');
assert.equal((html.match(/<h1\b/g) ?? []).length, 1, 'one H1');
for (const tag of ['header', 'main', 'footer']) assert.equal((html.match(new RegExp(`<${tag}\\b`, 'g')) ?? []).length, 1, `one ${tag}`);
assert.equal((html.match(/<section\b/g) ?? []).length, 5, 'five sections');
assert(!/<(?:script|form|input|button|iframe)\b/i.test(html), 'no script, form or fake button');
assert(!/@font-face|@import|url\(/i.test(html), 'no font, CSS or background network request');
for (const match of html.matchAll(/\bclass="([^"]+)"/g)) {
  assert(match[1].split(/\s+/).every((name) => name.startsWith('hr-')), `class namespace: ${match[1]}`);
}
let localAssets = 0;
let officialLinks = 0;
for (const match of html.matchAll(/\b(?:src|href)="([^"]+)"/g)) {
  const value = match[1];
  if (value.startsWith('#')) assert(ids.includes(value.slice(1)), `anchor ${value}`);
  else if (value.startsWith('https:')) {
    assert.equal(new URL(value).origin, 'https://www.xplorekaleidoscope.com', 'official external link');
    officialLinks++;
  } else {
    assert(existsSync(resolve(dirname(path), value)), `relative path ${value}`);
    if (value.endsWith('.svg') || value.endsWith('.webp')) localAssets++;
  }
}
assert.equal(localAssets, 5, 'two unchanged SVGs and three existing preview files');
for (const match of html.matchAll(/\baria-labelledby="([^"]+)"/g)) assert(ids.includes(match[1]), `label ${match[1]}`);
for (const value of [homepageHero.title, homepageHero.description, homepageHero.portfolioNote, servicesPage.overview.description, servicesPage.process.description, servicesPage.cta.title, servicesPage.cta.description]) {
  assert(decoded.replaceAll('<br>', '').includes(value), `exact source text: ${value}`);
}
for (const service of serviceCategories) for (const value of [service.title, service.englishTitle, service.summary]) assert(decoded.includes(value), `service text: ${value}`);
for (const step of serviceProcessSteps) for (const value of [step.title, step.description]) assert(decoded.includes(value), `process text: ${value}`);
const featuredIds = [...html.matchAll(/data-showcase-id="([^"]+)"/g)].map((match) => match[1]);
assert.deepEqual(featuredIds, [...showcaseSettings.featuredIds], 'unchanged featured order');
for (const id of featuredIds) {
  const item = websiteShowcases.find((candidate) => candidate.id === id);
  assert(item && item.presentation === 'brand-demo' && item.href && item.image, 'existing available brand demo');
  for (const value of [item.title, item.summary, item.note, item.image.alt, item.image.src]) assert(decoded.includes(value), `showcase source: ${id}`);
}
assert(html.includes('DRAFT — NOT APPROVED') && html.includes('未核准、未公開'), 'visible draft boundary');
assert(html.includes('d03cd673c10a8f7c0427c558c562112aa4d34a8c'), 'company source pin');
assert(html.includes("font-family: Inter, 'Noto Sans TC', 'Noto Sans CJK TC', sans-serif"), 'local font fallback');
assert(html.includes('prefers-reduced-motion') && html.includes(':focus-visible'), 'motion/focus recipes present');
console.log(JSON.stringify({status:'PASS',scope:'static structure, local paths, copied source consistency only',sections:5,h1:1,localAssets,officialLinks,featuredIds}));
console.log('HERITAGE_PROTOTYPE_STATIC_COMPLETE PASS');
