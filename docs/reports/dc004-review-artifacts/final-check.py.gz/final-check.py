from pathlib import Path
from urllib.parse import unquote
import subprocess,json,re,hashlib,gzip
r=Path.cwd();base='8ba299a5a48da41ca7f4d88d9b2149d7c83f6584';out=r/'docs/reports/dc004-review-artifacts';checks=[]
def add(id,ok,actual):checks.append({'testId':id,'status':'PASS' if ok else 'FAIL','actual':actual})
changed=set(subprocess.check_output(['git','diff',base,'--name-only'],text=True).splitlines()+subprocess.check_output(['git','ls-files','--others','--exclude-standard'],text=True).splitlines())
allowed={'README.md','AGENTS.md','docs/01_design/README.md','docs/reports/README.md','docs/task/ROADMAP.md','docs/98_decisions/implementation-notes.md','src/app/globals.css','docs/reports/dc004-brand-review.md'}
allowedprefix=['docs/01_design/design-collection/reviews/','docs/screenshots/design-collection/dc004-review/','docs/reports/dc004-review-artifacts/']
add('REVIEW-SCOPE',all(n in allowed or any(n.startswith(p) for p in allowedprefix) for n in changed),{'files':len(changed),'unexpected':[n for n in changed if n not in allowed and not any(n.startswith(p) for p in allowedprefix)]})
f=subprocess.run(['git','diff','--check',base],capture_output=True,text=True);add('DIFF-WHITESPACE',f.returncode==0,f.stdout+f.stderr)
broken=[];formatting=[];links=0;docs=[r/n for n in sorted(changed) if n.endswith('.md')]
for f in docs:
 text=f.read_text();inside=False;visible=[]
 if not text.endswith('\n') or text.endswith('\n\n'):formatting.append([str(f.relative_to(r)),'EOF'])
 for i,line in enumerate(text.splitlines(),1):
  if line.rstrip()!=line:formatting.append([str(f.relative_to(r)),i,'trailing whitespace'])
  if re.match(r'^(<<<<<<<|=======|>>>>>>>)',line):formatting.append([str(f.relative_to(r)),i,'conflict'])
  if line.startswith(('```','~~~')):inside=not inside;continue
  if not inside:visible.append(line)
 if inside:formatting.append([str(f.relative_to(r)),'unclosed fence'])
 for target in re.findall(r'!?\[[^\]]+\]\(([^)]+)\)','\n'.join(visible)):
  target=target.strip('<>')
  if re.match(r'^[A-Za-z][A-Za-z0-9+.-]*:',target) or target.startswith('/'):continue
  name,_,fragment=target.partition('#');p=(f.parent/unquote(name)).resolve() if name else f;links+=1
  if not p.exists():broken.append([str(f.relative_to(r)),target,'missing file']);continue
  if fragment and p.suffix=='.md':
   txt=p.read_text();anchors=re.findall(r'<a\s+id="([^"]+)"',txt)+[re.sub(r'[^\w\- ]','',x.strip().lower()).replace(' ','-') for x in re.findall(r'^#{1,6}\s+(.+)$',txt,re.M)]
   if unquote(fragment) not in anchors:broken.append([str(f.relative_to(r)),target,'missing fragment'])
add('MARKDOWN-LINKS-FORMAT',not broken and not formatting,{'documents':len(docs),'links':links,'broken':broken,'formatErrors':formatting})
snapshot=json.loads((out/'source-review.json').read_text());bad=[n for n,h in snapshot['files'].items() if hashlib.sha256((r/n).read_bytes()).hexdigest()!=h];add('SOURCE-FINGERPRINT',not bad,{'files':len(snapshot['files']),'mismatch':bad})
receipts=0;bad=[]
for f in out.glob('*.json.gz'):
 d=json.loads(gzip.decompress(f.read_bytes()))
 if isinstance(d,dict) and d.get('logSha256'):
  receipts+=1;name=Path(d['logFile']).name;log=out/(name+'.gz')
  if not log.exists() or hashlib.sha256(gzip.decompress(log.read_bytes())).hexdigest()!=d['logSha256']:bad.append(f.name)
add('RECEIPTS-LOG-INTEGRITY',not bad,{'receipts':receipts,'mismatch':bad})
secret=[];banned=[];pattern=re.compile(rb'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----|github_pat_[A-Za-z0-9_]{20,}|gh[pousr]_[A-Za-z0-9_]{20,}|[?&](?:X-Amz-Signature|sig|access_token)=',re.I)
for name in changed:
 f=r/name
 if not f.is_file():continue
 if any(p in {'.git','.next','out','node_modules'} or p.startswith('.env') for p in Path(name).parts):banned.append(name)
 if f.suffix in {'.png','.jpg','.pdf'}:continue
 data=gzip.decompress(f.read_bytes()) if f.suffix=='.gz' else f.read_bytes()
 if pattern.search(data):secret.append(name)
add('NO-SECRETS-BUILD-DIRS',not secret and not banned,{'secrets':secret,'banned':banned})
add('ACTUAL-PROTOTYPE-ADJUDICATION',json.loads(gzip.decompress((out/'prototype-adjudication.json.gz').read_bytes()))['status']=='PASS','Exact 3 incomplete bounded; original exit 2 unchanged')
add('WEBSITE-OUTPUT-UNCHANGED',json.loads(gzip.decompress((out/'output-bridge-result.json.gz').read_bytes()))['status']=='PASS','154 runtime bytes; 286 files only actual Next Build ID')
for n in ['heritage-375.png','heritage-1440.png']:
 p=r/'docs/screenshots/design-collection/dc004-review'/n
 add('SCREENSHOT-'+n,p.exists() and p.stat().st_size>10000,{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
result={'status':'PASS' if all(c['status']=='PASS' for c in checks) else 'FAIL','base':base,'changedFiles':sorted(changed),'checks':checks}
p=Path('/tmp/xk-dc004-review/final-check-result.json');assert not p.exists();p.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'status':result['status'],'checks':checks},indent=2));raise SystemExit(0 if result['status']=='PASS' else 1)
