from pathlib import Path
import gzip,hashlib,json,datetime
repo=Path('/workspace/xk-website');dest=repo/'docs/reports/dc005-review-artifacts';shots=repo/'docs/screenshots/design-collection/dc005-review';dest.mkdir(parents=True,exist_ok=True);shots.mkdir(parents=True,exist_ok=True)
inputs={'core':Path('/tmp/xk-dc005'),'source':Path('/tmp/xk-dc005-source'),'validation':Path('/tmp/xk-dc005-validator'),'actions':Path('/tmp/xk-dc005-actions')};rows=[];skipped=[]
sha=lambda b:hashlib.sha256(b).hexdigest()
for group,root in inputs.items():
 for f in sorted(root.rglob('*')):
  if not f.is_file() or '__pycache__' in f.parts:continue
  raw=f.read_bytes();relative=f.relative_to(root)
  if f.suffix=='.zip':skipped.append({'original':str(f),'sha256':sha(raw),'bytes':len(raw),'reason':'Downloaded GitHub main artifact; identifier/digest/download receipt retained, full ZIP remains in temporary directory and is reproducible from GitHub.'});continue
  if f.suffix=='.png':target=shots/f.name;data=raw;encoding='none'
  else:
   target=dest/group/relative;compress=f.suffix in {'.log','.py','.cjs','.mjs','.js','.md','.css'} or len(raw)>=4096;data=gzip.compress(raw,mtime=0) if compress else raw;encoding='gzip-mtime0' if compress else 'none'
   if compress:target=Path(str(target)+'.gz')
  target.parent.mkdir(parents=True,exist_ok=True)
  if target.exists():assert target.read_bytes()==data,('Never overwrite evidence',target)
  else:target.write_bytes(data)
  assert (gzip.decompress(data) if encoding.startswith('gzip') else data)==raw
  rows.append({'original':str(f),'originalSha256':sha(raw),'repositoryPath':str(target.relative_to(repo)),'archiveSha256':sha(data),'encoding':encoding})
manifest={'date':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Local Luxury brand-review evidence only; preserves actual raw values and exits, not brand/full-series/deployment approval.','entries':rows,'notDuplicated':skipped};(dest/'archive-manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
for directory in [dest,shots]:
 files=sorted(f for f in directory.rglob('*') if f.is_file() and f.name!='SHA256SUMS');(directory/'SHA256SUMS').write_text(''.join(sha(f.read_bytes())+'  '+str(f.relative_to(directory))+'\n' for f in files))
print(json.dumps({'operation':'ARCHIVE_COMPLETE','originalFiles':len(rows),'screenshots':len(list(shots.glob('*.png'))),'skippedZips':len(skipped),'testResultsNotRewritten':True}))
