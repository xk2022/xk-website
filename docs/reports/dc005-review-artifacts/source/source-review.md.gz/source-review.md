# DC-005 公司來源唯讀核對

公司 main `9213a3d8dacb8774d87c26cb736c4a4315779e95`；tree `195c5c8100b74513985e040f3ee6fc642571285e`。相對 `e0229b97acb2bf6c2d83f8155665f68b11c27d71` 多1commit。14組相關新舊完整檔案已比較：變更限英文檔名、Markdown目的地、source路徑及歷史來源檔名標籤，實質品牌／工程／價格條款未變。不是單憑檔名推論。

| 最新路徑 | Blob | 本輪讀取 |
| --- | --- | --- |
| AGENTS.md | `a7ca443ddd1d1b847dc58152bbb56c1425c1b522` | 全文重讀 |
| 05_brand/overview.md | `3c3bb05d8d1505d07223bb5f8f482f7a2b923639` | 全文重讀 |
| 05_brand/logo-guidelines.md | `0203423ddb1c25551f9dd557de8ce96dc8608f68` | 全文重讀 |
| 05_brand/brand-identity.md | `58d431e0b26a4500b26243bb1582ac8d0ac1db0c` | 全文重讀 |
| 05_brand/color-palette.md | `9c994fbf08e2367050ea969db6c5912fa5fea1d0` | 全文重讀 |
| 05_brand/typography.md | `edf921ffe91ae3238fefb7aea7134209b5c87042` | 全文重讀 |
| 03_services/pricing.md | `27eef7a0ee5d5ad8edcc16cb22dc6c94e91d1ad0` | 完整檔比較＋重讀適用段落 |
| 03_services/website-packages.md | `49399ca3ec8b081ed8bf60ad80dd3f6fa79423ea` | 全文重讀 |
| 06_engineering/development-workflow.md | `98fda4dfff56a5e5117f843880b5c9776412db1a` | 全文重讀 |
| 08_projects/official-website/overview.md | `b48d240230283e062b37fabb1422b9fac2bc41a8` | 全文重讀 |
| 10_decisions/2026-11-20.md | `8cec402c3bf88592edcb2a8b20df7d6fcc58eb92` | 完整檔比較＋重讀適用段落 |
| 06_engineering/architecture.md | `679c475e57258c69790101f1ceedb96f1575d5c6` | 同Blob沿用 |
| 06_engineering/testing-and-release.md | `7b525804e46753e9b45432c4ba05f387a9b46f6f` | 同Blob沿用 |
| 06_engineering/website-repository-naming.md | `02a8b6565b64d75e51316319fb6ef774ad87bc57` | 同Blob沿用 |
| 10_decisions/2026-11-25.md | `d1e52a425b301556d8138bcd3d16d401874ea3ae` | 同Blob沿用 |

根AGENTS已存在並全文讀取。全文重讀清冊與其餘來源／舊路徑／Blob／適用段落／比較方法，見 [source-review.json](source-review.json)。其餘同Blob的治理、分類、架構、驗收發布及APP決議沿用前輪紀錄，不重讀正文。APP部署規範只核對同Blob及不適用界線，未冒稱本輪全文閱讀。

公司品牌正文仍要求官網、提案、作品集外框／署名採正式規範；Logo03保留原比例與配色，可按實際深色背景選既有反白版；Inter／Noto Sans TC是字體基準。正式深色是Midnight #101828及Navy #172554，互動Electric Blue #2563EB；金色Logo、新字體及Luxury專用識別未獲本來源新增核准。

**本來源未找到Luxury專用palette／字體／Logo／外框例外核准或既定Luxury配色。** DC規格的#0C1017／#151B24／#C8A96B與64／36字階仍是展示提案。Heritage PR40的v1批准不轉作Luxury批准；如本次另有明確Owner批准，應另外記精確版本及範圍。這項來源核對不覆蓋當次使用者授權。

分類仍按交付目的使用LP／BRAND／CORP／SHOP／APP；風格不增加產品分類或高級版價格。參考／面議／第三方／維護月費界線、服務事實、收件與本機摘要、法律及索引門檻均不變。官網Pages靜態匯出與實作庫發布紀錄不因APP的Render／Neon／VPS規範改變。

DC005可從已核准DC003/main獨立規劃；未合併Heritage不得當成main既有實作整合。此句以Root提供的任務狀態為界，不冒稱另做PR驗證。

只寫/tmp/xk-dc005-source；未修改公司／網站Repo、Git、PR或merge，未執行build／preview。未複製公司全文或內部工時／營收數字。
