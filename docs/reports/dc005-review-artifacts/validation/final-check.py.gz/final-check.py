#!/usr/bin/env python3
"""Read-only final checks for DC-005 brand-review deliverables, not the full series."""
import argparse
from datetime import datetime, timezone
import gzip
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys
from urllib.parse import unquote, urlsplit

BASE = "8ba299a5a48da41ca7f4d88d9b2149d7c83f6584"
STACK = ["package.json", "package-lock.json", "next.config.ts", "tsconfig.json", "components.json", ".nvmrc", "eslint.config.mjs", "postcss.config.mjs"]
RUNTIME = ["src", "public", "scripts", ".github", *STACK]
EXCLUSIONS = '''/* Local design-review documents must not add production utilities. */
@source not "../../docs/01_design/design-collection/reviews";
@source not "../../docs/task/dc005.md";
@source not "../../docs/reports/dc005-brand-review.md";
@source not "../../docs/reports/dc005-review-artifacts";
'''
SECRET = re.compile(rb"-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----|github_pat_[A-Za-z0-9_]{20,}|gh[pousr]_[A-Za-z0-9_]{20,}|[?&](?:X-Amz-Signature|sig|access_token)=", re.I)

def sha(data):
    return hashlib.sha256(data).hexdigest()

def read(path):
    raw = path.read_bytes()
    return gzip.decompress(raw) if path.suffix == ".gz" else raw

def git(root, *args):
    result = subprocess.run(["git", "--no-optional-locks", *args], cwd=root, capture_output=True)
    if result.returncode:
        raise RuntimeError(result.stderr.decode(errors="replace"))
    return result.stdout

def names(root, *args):
    return set(filter(None, git(root, *args).decode().split("\0")))

def markdown_visible(text):
    visible, fence = [], None
    for line in text.splitlines():
        match = re.match(r"^ {0,3}(`{3,}|~{3,})(.*)$", line)
        if match:
            if fence is None:
                fence = (match[1][0], len(match[1]))
            elif match[1][0] == fence[0] and len(match[1]) >= fence[1] and not match[2].strip():
                fence = None
            continue
        if fence is None:
            visible.append(line)
    return "\n".join(visible), fence is not None

def manifest(directory):
    errors, rows = [], {}
    for line in (directory / "SHA256SUMS").read_text().splitlines():
        if not line.strip():
            continue
        match = re.fullmatch(r"([a-fA-F0-9]{64}) [ *](.+)", line)
        if not match:
            errors.append("invalid manifest row")
            continue
        digest, name = match[1].lower(), match[2]
        path = (directory / name).resolve()
        if name in rows or not path.is_relative_to(directory) or not path.is_file() or sha(path.read_bytes()) != digest:
            errors.append(name)
        rows[name] = digest
    actual = {str(path.relative_to(directory)) for path in directory.rglob("*") if path.is_file() and path.name != "SHA256SUMS"}
    return bool(rows) and not errors and actual == set(rows), {"files": len(rows), "errors": errors, "unlisted": sorted(actual-set(rows)), "missing": sorted(set(rows)-actual)}

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=Path("/workspace/xk-website"))
    parser.add_argument("--artifacts", default="docs/reports/dc005-review-artifacts")
    parser.add_argument("--screenshots", default="docs/screenshots/design-collection/dc005-review")
    parser.add_argument("--output", type=Path, default=Path("/tmp/xk-dc005-validator/final-check-result.json"))
    args = parser.parse_args()
    root, output = args.root.resolve(), args.output.resolve()
    if output.exists() or output.is_relative_to(root):
        parser.error("Use a fresh result path outside the repository")
    checks = []
    def add(test_id, ok, actual):
        checks.append({"testId": test_id, "status": "PASS" if ok else "FAIL", "expected": "all declared checks satisfied", "actual": actual})
    try:
        tracked = names(root, "diff", "--name-only", "-z", BASE, "--")
        untracked = names(root, "ls-files", "-z", "--others", "--exclude-standard")
        staged = names(root, "diff", "--cached", "--name-only", "-z", "--")
        changed = tracked | untracked | staged
        invalid_scope = [name for name in changed if not (name.endswith(".md") or name == "src/app/globals.css" or name == "docs/01_design/design-collection/reviews/luxury-v1.html" or name.startswith((args.artifacts.rstrip("/")+"/", args.screenshots.rstrip("/")+"/")))]
        add("LR-FINAL-REVIEW-ONLY-SCOPE", not invalid_scope, {"trackedChanges": len(tracked), "untrackedFiles": len(untracked), "stagedChanges": len(staged), "unexpected": sorted(invalid_scope)})
        for label, command in [("WORKTREE", ["diff", "--check", BASE, "--"]), ("STAGED", ["diff", "--cached", "--check", "--"])]:
            result = subprocess.run(["git", "--no-optional-locks", *command], cwd=root, capture_output=True, text=True)
            add("LR-FINAL-DIFF-"+label, result.returncode == 0, {"exitCode": result.returncode, "output": result.stdout+result.stderr})
        original = names(root, "ls-tree", "-r", "--name-only", "-z", BASE, "--", *RUNTIME)
        current = names(root, "ls-files", "-z", "--cached", "--others", "--exclude-standard", "--", *RUNTIME)
        differences, stack_changes = [], []
        for name in sorted(original):
            expected = git(root, "show", BASE+":"+name)
            path = root / name
            actual = path.read_bytes() if path.is_file() else None
            if name == "src/app/globals.css":
                block = EXCLUSIONS.encode()
                if actual is None or actual.count(block) != 1 or actual.replace(block, b"", 1) != expected:
                    differences.append(name)
            elif actual != expected:
                differences.append(name)
                if name in STACK or name.startswith(".github/"):
                    stack_changes.append(name)
        add("LR-FINAL-RUNTIME-ONLY-EXACT-DISCOVERY-EXCLUSION", not differences and original == current, {"base": BASE, "files": len(original), "invalidChanges": differences, "extra": sorted(current-original), "missing": sorted(original-current), "allowedCssAddition": EXCLUSIONS})
        add("LR-FINAL-STACK-LOCK-DEPS-WORKFLOW", not stack_changes, {"changed": stack_changes, "byteEquality": True if not stack_changes else False})
        broken, formatting, link_count, documents = [], [], 0, []
        for name in sorted(changed):
            path = root / name
            if not path.is_file() or path.suffix not in {".md", ".html"}:
                continue
            text = path.read_text()
            if not text.endswith("\n") or text.endswith("\n\n"):
                formatting.append([name, "expected one final LF"])
            for number, line in enumerate(text.splitlines(), 1):
                if line.rstrip() != line or re.match(r"^(?:<{7}(?: |$)|={7}$|>{7}(?: |$))", line):
                    formatting.append([name, number, "trailing whitespace/conflict"])
            if path.suffix != ".md":
                continue
            documents.append(name)
            visible, unclosed = markdown_visible(text)
            if unclosed:
                formatting.append([name, "unclosed fence"])
            if re.search(r"^ {0,3}#{1,6}[^#\s]", visible, re.M):
                formatting.append([name, "heading needs space after #"])
            for destination in re.findall(r"!?\[[^\]]*\]\((<[^>]+>|[^)\s]+)(?:\s+['\"][^)]*['\"])?\)", visible):
                destination = destination.strip("<>")
                parts = urlsplit(destination)
                if parts.scheme or parts.netloc:
                    continue
                link_count += 1
                target = (root / unquote(parts.path).lstrip("/")).resolve() if parts.path.startswith("/") else (path.parent / unquote(parts.path)).resolve() if parts.path else path
                if not target.is_relative_to(root) or not target.exists():
                    broken.append([name, destination, "missing/escaping local path"])
                elif parts.fragment and target.is_file() and target.suffix in {".md", ".html"}:
                    body = target.read_text()
                    explicit = re.findall(r"\b(?:id|name)\s*=\s*['\"]([^'\"]+)['\"]", body)
                    source, _ = markdown_visible(body)
                    heads = [re.sub(r"[^\w\- ]", "", title.strip().lower()).replace(" ", "-") for title in re.findall(r"^#{1,6}\s+(.+)$", source, re.M)] if target.suffix == ".md" else []
                    if unquote(parts.fragment) not in explicit+heads:
                        broken.append([name, destination, "missing anchor"])
        add("LR-FINAL-MARKDOWN-LINKS-FENCES-EOF", not broken and not formatting, {"documents": documents, "localLinks": link_count, "broken": broken, "formatErrors": formatting, "scope": "Only current changed Markdown/HTML; no full historical document audit."})
        artifacts = (root / args.artifacts).resolve()
        for label, directory in [("ARTIFACTS", artifacts), ("SCREENSHOTS", (root / args.screenshots).resolve())]:
            ok, actual = manifest(directory)
            add("LR-FINAL-MANIFEST-"+label, ok, actual)
        receipts, log_errors, raw_tools = 0, [], []
        for path in sorted(artifacts.rglob("*")):
            if not path.is_file():
                continue
            if path.suffix in {".py", ".js", ".mjs", ".cjs", ".log"}:
                raw_tools.append(str(path.relative_to(artifacts)))
            if not path.name.endswith((".json", ".json.gz")):
                continue
            data = json.loads(read(path))
            if not isinstance(data, dict) or not data.get("logSha256"):
                continue
            receipts += 1
            name = Path(data.get("logFile", "")).name
            candidates = [path.parent/name, path.parent/(name+".gz"), artifacts/name, artifacts/(name+".gz")]
            matches = [item for item in candidates if item.is_file() and sha(read(item)) == data["logSha256"]]
            if not name or not matches or not isinstance(data.get("exitCode"), int) or not isinstance(data.get("returnCode"), int) or not data.get("finishedAt"):
                log_errors.append(str(path.relative_to(artifacts)))
        add("LR-FINAL-RECEIPT-LOG-SHA-AND-GZIP-TOOLS", receipts > 0 and not log_errors and not raw_tools, {"receipts": receipts, "mismatches": log_errors, "uncompressedToolsOrLogs": raw_tools, "notes": "Original FAIL/TIMEOUT receipts remain failures; integrity does not imply successful tests."})
        secrets, banned = [], []
        for name in sorted(changed):
            if any(part in {".next", "out", "node_modules", ".git", "__pycache__", ".cache"} or part.startswith(".env") for part in Path(name).parts):
                banned.append(name)
            path = root / name
            if path.is_file() and path.suffix not in {".png", ".jpg", ".jpeg", ".webp", ".pdf", ".woff", ".woff2"} and SECRET.search(read(path)):
                secrets.append(name)
        add("LR-FINAL-NO-SECRETS-BUILD-CACHE", not secrets and not banned, {"suspectedSecretFiles": secrets, "forbiddenPaths": banned})
    except Exception as error:
        add("LR-FINAL-COMPLETE", False, type(error).__name__+": "+str(error))
    result = {"status": "PASS" if checks and all(item["status"] == "PASS" for item in checks) else "FAIL", "testedAt": datetime.now(timezone.utc).isoformat(), "base": BASE, "command": [sys.executable, *sys.argv], "checks": checks, "scope": "Read-only review delivery checks. No build/server/browser/dependency install/Git mutation; no brand or full-series acceptance."}
    output.parent.mkdir(parents=True, exist_ok=True)
    with output.open("x") as file:
        json.dump(result, file, ensure_ascii=False, indent=2)
        file.write("\n")
    print(json.dumps({"status": result["status"], "checks": len(checks), "failures": [item for item in checks if item["status"] == "FAIL"], "result": str(output)}, ensure_ascii=False))
    return 0 if result["status"] == "PASS" else 1

if __name__ == "__main__":
    sys.exit(main())
