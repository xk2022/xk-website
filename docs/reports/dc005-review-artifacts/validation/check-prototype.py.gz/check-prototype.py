#!/usr/bin/env python3
"""Static checks for the local Luxury v1 document; no browser or HTTP requests."""
import argparse
from datetime import datetime, timezone
import hashlib
from html.parser import HTMLParser
import json
from pathlib import Path
import re
import subprocess
import sys
from urllib.parse import unquote, urlsplit

HTML = "docs/01_design/design-collection/reviews/luxury-v1.html"
ORIGIN = "https://www.xplorekaleidoscope.com"
FEATURED = ["march-tangbao", "hongjia-birdnest", "honest-diecut"]
SERVICE_IDS = ["website-development", "java-enterprise", "system-integration", "ai-automation", "cloud-infrastructure"]
LOGOS = {
    "xk-logo-horizontal.svg": ("08b60bfba88d9598aaaf072bdb7b6e95658784598b8d132a4e3bcb2383446a5b", 850, 204),
    "xk-logo-white.svg": ("3ef6fe4c3968992e1c18df2f05233f39ffebd9da26dd9be91e7be81c02087250", 620, 410),
    "xk-logo-symbol.svg": ("b61e1a188bd5d043692780e058e24ad83ba6347dea3bdf3619b334ffae246119", 472, 472),
}
VOID = {"area", "base", "br", "col", "embed", "hr", "img", "input", "link", "meta", "param", "source", "track", "wbr"}

class Element:
    def __init__(self, tag, attrs=()):
        self.tag, self.attrs, self.children = tag, dict(attrs), []
    def all(self, tag=None):
        return [value for child in self.children if isinstance(child, Element) for value in ([child] if tag is None or child.tag == tag else []) + child.all(tag)]
    def text(self):
        return "" if self.tag in {"script", "style"} else "".join(child.text() if isinstance(child, Element) else child for child in self.children)
    def has_class(self, value):
        return value in self.attrs.get("class", "").split()

class Document(HTMLParser):
    def __init__(self, text):
        super().__init__(convert_charrefs=True)
        self.root, self.stack, self.duplicates = Element("document"), [], []
        self.stack = [self.root]
        self.feed(text)
        self.close()
    def handle_starttag(self, tag, attrs):
        if len(attrs) != len(dict(attrs)):
            self.duplicates.append(tag)
        element = Element(tag, attrs)
        self.stack[-1].children.append(element)
        if tag not in VOID:
            self.stack.append(element)
    def handle_startendtag(self, tag, attrs):
        self.handle_starttag(tag, attrs)
        if tag not in VOID:
            self.handle_endtag(tag)
    def handle_endtag(self, tag):
        for index in range(len(self.stack) - 1, 0, -1):
            if self.stack[index].tag == tag:
                self.stack = self.stack[:index]
                break
    def handle_data(self, value):
        self.stack[-1].children.append(value)

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=Path("/workspace/xk-website"))
    parser.add_argument("--output", type=Path, default=Path("/tmp/xk-dc005-validator/static-result.json"))
    args = parser.parse_args()
    root, output = args.root.resolve(), args.output.resolve()
    if output.exists() or output.is_relative_to(root):
        parser.error("Use a fresh result path outside the repository")
    checks = []
    def check(item, expected, actual):
        checks.append({"testId": f"LR-STATIC-{len(checks)+1:03d}", "item": item, "expected": expected, "actual": actual, "status": "PASS" if actual == expected else "FAIL"})
    try:
        path = root / HTML
        raw = path.read_text()
        parsed = Document(raw)
        doc = parsed.root
        script = """
import {homepageHero} from './src/config/homepage.ts';
import {serviceCategories,serviceProcessSteps,servicesPage} from './src/config/services.ts';
import {showcaseSettings,websiteShowcases} from './src/config/website-showcases.ts';
import {seoPages} from './src/config/seo.ts';
import {designCollectionRegistry} from './src/config/design-collection.ts';
console.log(JSON.stringify({homepageHero,serviceCategories,serviceProcessSteps,servicesPage,showcaseSettings,websiteShowcases,seoPages,designCollectionRegistry,node:process.versions.node}));
"""
        source = subprocess.run(["node", "--import", str(root / "scripts/register-test-aliases.mjs"), "--input-type=module", "-e", script], cwd=root, capture_output=True, text=True)
        check("Native source import exit", 0, source.returncode)
        if source.returncode:
            raise RuntimeError(source.stderr.strip())
        data = json.loads(source.stdout)
        ids = [element.attrs["id"] for element in doc.all() if "id" in element.attrs]
        check("Unique IDs", len(ids), len(set(ids)))
        check("No duplicate HTML attributes", [], parsed.duplicates)
        for tag in ["html", "head", "body", "header", "main", "footer", "h1"]:
            check("Single " + tag, 1, len(doc.all(tag)))
        check("HTML language", ["zh-TW"], [element.attrs.get("lang") for element in doc.all("html")])
        check("Main/skip destination", ["lx-main-content"], [element.attrs.get("id") for element in doc.all("main")])
        check("One skip link", 1, len([element for element in doc.all("a") if element.attrs.get("href") == "#lx-main-content"]))
        check("Class namespace", [], [value for element in doc.all() for value in element.attrs.get("class", "").split() if not value.startswith("lx-")])
        check("Required semantic section IDs", [], [value for value in ["lx-services", "lx-works", "lx-cooperation", "lx-next-step", "lx-state-review"] if value not in ids])
        for attribute in ["aria-labelledby", "aria-describedby", "aria-controls"]:
            check(attribute + " references", [], [value for element in doc.all() for value in element.attrs.get(attribute, "").split() if value not in ids])
        check("Label targets", [], [element.attrs.get("for") for element in doc.all("label") if element.attrs.get("for") not in ids])
        check("No executable/receiving containers", [], [element.tag for element in doc.all() if element.tag in {"script", "form", "select", "textarea", "iframe", "object", "embed", "base"}])
        check("No handlers or outbound submission attributes", [], [(element.tag, key) for element in doc.all() for key in element.attrs if key.startswith("on") or key in {"action", "formaction", "formmethod", "form", "method", "formtarget"}])
        check("No automatic navigation", [], [element.attrs for element in doc.all("meta") if element.attrs.get("http-equiv", "").lower() == "refresh"])
        check("No downloaded font/stylesheet/script network", [], re.findall(r"@font-face|@import|url\s*\(|\b(?:fetch|XMLHttpRequest|WebSocket|EventSource|sendBeacon|localStorage|sessionStorage|indexedDB)\s*[.(]", raw, re.I))
        check("Protected robots", ["nofollow", "noindex"], sorted(re.split(r"[,\s]+", next(element.attrs.get("content", "") for element in doc.all("meta") if element.attrs.get("name") == "robots"))))
        check("Visible unapproved boundary", True, "DRAFT / NOT APPROVED" in doc.text() and "未核准、未公開" in doc.text())
        check("Native samples clearly disclaimed", True, "視覺樣本" in doc.text() and "不會提交、記錄或傳送資料" in doc.text())
        controls = [element for element in doc.all() if element.tag in {"input", "button"}]
        expected_ids = ["lx-input-sample", "lx-error-sample", "lx-choice-a", "lx-choice-b", "lx-disabled-sample"]
        check("Exact declared visual controls", expected_ids, [element.attrs.get("id") for element in controls])
        samples = next(element for element in doc.all() if element.has_class("lx-state-samples"))
        check("Controls stay in review samples", True, all(element in samples.all() for element in controls))
        for element in controls:
            ident, attrs = element.attrs.get("id"), element.attrs
            if ident in {"lx-input-sample", "lx-error-sample"}:
                check(ident + " readonly unnamed text", ["text", True, None, "off"], [attrs.get("type"), "readonly" in attrs, attrs.get("name"), attrs.get("autocomplete")])
                check(ident + " fixed sample value", "這是色彩與邊界樣本" if ident == "lx-input-sample" else "靜態錯誤狀態示意", attrs.get("value"))
                check(ident + " error state", "true" if ident == "lx-error-sample" else None, attrs.get("aria-invalid"))
            elif ident in {"lx-choice-a", "lx-choice-b"}:
                check(ident + " native visual choice", ["radio", "luxury-review-choice", "sample-a" if ident.endswith("-a") else "sample-b", ident.endswith("-a")], [attrs.get("type"), attrs.get("name"), attrs.get("value"), "checked" in attrs])
            elif ident == "lx-disabled-sample":
                check("Inert disabled visual button", ["button", True, "停用狀態樣本"], [attrs.get("type"), "disabled" in attrs, element.text().strip()])
        for class_name, count in [("lx-mobile-menu", 1), ("lx-service-details", 5), ("lx-process-details", 5), ("lx-sources", 1)]:
            details = [element for element in doc.all("details") if element.has_class(class_name)]
            check(class_name + " native disclosures", count, len(details))
            check(class_name + " summary children", True, all(len([child for child in element.children if isinstance(child, Element) and child.tag == "summary"]) == 1 for element in details))
        hero = next(element for element in doc.all("section") if element.has_class("lx-hero"))
        check("Exact Hero title", [data["homepageHero"]["title"]], [element.text().strip() for element in hero.all("h1")])
        for value in [data["homepageHero"]["description"], data["homepageHero"]["portfolioNote"], data["servicesPage"]["overview"]["description"], data["servicesPage"]["process"]["description"], data["servicesPage"]["cta"]["title"], data["servicesPage"]["cta"]["description"]]:
            check("Exact public source sentence", True, value in doc.text())
        services = [element for element in doc.all("article") if element.has_class("lx-service")]
        check("Independent Services inventory", SERVICE_IDS, [entry["id"] for entry in data["serviceCategories"]])
        check("Five service cards", 5, len(services))
        for element, service in zip(services, data["serviceCategories"]):
            for value in [service["title"], service["englishTitle"], service["summary"], service["description"], service["scenario"], *service["items"]]:
                check("Service source " + service["id"], True, value in element.text())
        steps = [element for element in doc.all("details") if element.has_class("lx-process-details")]
        check("Five source process steps", 5, len(data["serviceProcessSteps"]))
        for element, step in zip(steps, data["serviceProcessSteps"]):
            for value in [step["name"], step["title"], step["description"]]:
                check("Exact process source", True, value in element.text())
        works = [element for element in doc.all("article") if "data-showcase-id" in element.attrs]
        check("Independent featured source order", FEATURED, data["showcaseSettings"]["featuredIds"])
        check("Three rendered featured IDs", FEATURED, [element.attrs["data-showcase-id"] for element in works])
        for element in works:
            item = next(entry for entry in data["websiteShowcases"] if entry["id"] == element.attrs["data-showcase-id"])
            check(item["id"] + " source is an available brand demo", ["brand-demo", "available"], [item["presentation"], item.get("availability", "available")])
            for value in [item["title"], item["summary"], item["note"]]:
                check(item["id"] + " exact visible source", True, value in element.text())
            check(item["id"] + " original preview alt", [item["image"]["alt"]], [image.attrs.get("alt") for image in element.all("img")])
            check(item["id"] + " original preview path", True, any((path.parent / image.attrs.get("src", "")).resolve() == (root / "public" / item["image"]["src"].lstrip("/")).resolve() for image in element.all("img")))
            check(item["id"] + " honest official reference", True, any(urlsplit(anchor.attrs.get("href", "")).path.rstrip("/") == "/portfolio/showcases/" + item["id"] for anchor in element.all("a")))
        local_assets, official = [], []
        public_paths = {page["path"] for page in data["seoPages"] if page["availability"] == "public"}
        for element in doc.all():
            for key in ["src", "href"]:
                if key not in element.attrs:
                    continue
                value = element.attrs[key]
                parsed_url = urlsplit(value)
                if value.startswith("#"):
                    check("Local anchor " + value, True, unquote(value[1:]) in ids)
                elif parsed_url.scheme or parsed_url.netloc:
                    normalized = parsed_url.path.rstrip("/") or "/"
                    check("Real www CTA " + value, True, value.startswith(ORIGIN + "/") and parsed_url.scheme == "https" and parsed_url.netloc == "www.xplorekaleidoscope.com" and not parsed_url.query and normalized in public_paths and "//" not in parsed_url.path)
                    if parsed_url.fragment:
                        identity = next((page for page in data["designCollectionRegistry"]["contentPages"] if page["path"] == normalized and page["kind"] == "simple"), None)
                        anchors = data["designCollectionRegistry"]["anchors"]["modern"].get(identity["pageKey"], []) if identity else data["designCollectionRegistry"]["collectionAnchors"] if normalized == "/design-collection" else []
                        check("Approved official semantic anchor", True, parsed_url.fragment in anchors)
                    official.append(value)
                else:
                    target = (path.parent / unquote(parsed_url.path)).resolve()
                    is_asset = key == "src" or element.tag == "link"
                    check("Existing relative resource " + value, True, not parsed_url.query and not parsed_url.fragment and target.is_file() and target.is_relative_to(root / "public" if is_asset else root))
                    if is_asset:
                        local_assets.append(str(target.relative_to(root)))
                    if target.name in LOGOS:
                        digest, width, height = LOGOS[target.name]
                        check("Original Logo bytes " + target.name, digest, hashlib.sha256(target.read_bytes()).hexdigest())
                        if element.tag == "img":
                            check("Original Logo aspect ratio", True, abs(float(element.attrs.get("width", 0)) / max(float(element.attrs.get("height", 0)), 1) - width / height) < 0.001)
        check("Review Logo usage", ["xk-logo-horizontal.svg", "xk-logo-symbol.svg", "xk-logo-white.svg"], sorted(Path(name).name for name in local_assets if Path(name).name in LOGOS))
        check("Visible working CTA to existing Contact/Quotation", True, any("/contact/" in value for value in official) and any("/quotation/" in value for value in official))
        check("Reduced Motion/focus recipes", True, "prefers-reduced-motion" in raw and ":focus-visible" in raw)
    except Exception as error:
        check("Static checker completes", "complete", type(error).__name__ + ": " + str(error))
    result = {"status": "PASS" if checks and all(item["status"] == "PASS" for item in checks) else "FAIL", "testedAt": datetime.now(timezone.utc).isoformat(), "prototype": HTML, "prototypeSha256": hashlib.sha256((root / HTML).read_bytes()).hexdigest() if (root / HTML).is_file() else None, "command": [sys.executable, *sys.argv], "checks": checks, "limits": "Static source/HTML checks only; not browser rendering, contrast, keyboard, storage/network observation, brand approval or full Luxury acceptance."}
    output.parent.mkdir(parents=True, exist_ok=True)
    with output.open("x") as file:
        json.dump(result, file, ensure_ascii=False, indent=2)
        file.write("\n")
    print(json.dumps({"status": result["status"], "checks": len(checks), "failures": [item for item in checks if item["status"] == "FAIL"], "result": str(output)}, ensure_ascii=False))
    return 0 if result["status"] == "PASS" else 1

if __name__ == "__main__":
    sys.exit(main())
