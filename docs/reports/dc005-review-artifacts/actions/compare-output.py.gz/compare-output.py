#!/usr/bin/env python3
"""DC-005 brand-review-only output bridge against the verified DC-003 main ZIP.
No builds, browser sessions, repository writes, Git operations or deployments.
A signed download URL is accepted only via stdin and is never logged/saved.
"""
import argparse
from collections import Counter
from datetime import datetime, timezone
import hashlib
from html.parser import HTMLParser
import io
import json
from pathlib import Path, PurePosixPath
import re
import sys
import tarfile
import urllib.request
import zipfile

ROOT=Path(__file__).resolve().parent
MAIN='8ba299a5a48da41ca7f4d88d9b2149d7c83f6584'
DIGEST='cc43318ca9b284e26dfa8d98da349e9f30f0579886307f4a62b29dd043a61cbe'
MANIFESTS={'_buildManifest.js','_ssgManifest.js','_clientMiddlewareManifest.js'}
ERROR_HTML={'404.html','404/index.html','_not-found/index.html'}
ORIGIN='https://www.xplorekaleidoscope.com'
EXTS={'.css','.js','.woff2','.woff','.ttf','.svg','.webp','.png','.ico','.jpg','.jpeg'}
EXCLUSIONS='''/* Local design-review documents must not add production utilities. */
@source not "../../docs/01_design/design-collection/reviews";
@source not "../../docs/task/dc005.md";
@source not "../../docs/reports/dc005-brand-review.md";
@source not "../../docs/reports/dc005-review-artifacts";
'''


def sha(data):return hashlib.sha256(data).hexdigest()

def safe_name(name):
 p=PurePosixPath(name)
 if name.startswith('/') or '\\' in name or '..' in p.parts:raise ValueError('Unsafe archive path')
 return p.as_posix()

def read_zip(path,expected=None):
 raw=path.read_bytes()
 if expected and sha(raw)!=expected:raise ValueError('ZIP digest mismatch')
 with zipfile.ZipFile(io.BytesIO(raw)) as z:
  members=z.infolist()
  if len(members)!=1 or members[0].filename!='artifact.tar' or members[0].file_size>100_000_000:raise ValueError('Unexpected ZIP inventory/size')
  tar=z.read(members[0])
 files={};seen=set();total=0
 with tarfile.open(fileobj=io.BytesIO(tar),mode='r:*') as t:
  for m in t:
   name=safe_name(m.name)
   if name in seen:raise ValueError('Duplicate archive member')
   seen.add(name)
   if m.isdir():continue
   if not m.isfile():raise ValueError('Archive link/special entry')
   total+=m.size
   if len(files)>=5000 or total>100_000_000:raise ValueError('Oversized artifact')
   files[name]=t.extractfile(m).read()
 return files,{'zipSha256':sha(raw),'tarSha256':sha(tar),'downloadedBytes':len(raw)}

def read_dir(root):
 files={}
 for p in sorted(root.rglob('*')):
  if p.is_symlink():raise ValueError('Output symlink')
  if p.is_file():files[p.relative_to(root).as_posix()]=p.read_bytes()
 return files

def build_id(files):
 ids=[m[1] for n in files if (m:=re.fullmatch(r'_next/static/([^/]+)/_buildManifest\.js',n))]
 if len(ids)!=1:raise ValueError('Expected one actual BuildID')
 return ids[0]

def norm_name(name,bid):
 prefix='_next/static/'+bid+'/'
 return '_next/static/BUILD_ID/'+name[len(prefix):] if name.startswith(prefix) and name[len(prefix):] in MANIFESTS else name

def normalize(files):
 bid=build_id(files)
 return {norm_name(n,bid):v.replace(bid.encode(),b'BUILD_ID') if n.endswith(('.html','.txt','.js')) else v for n,v in files.items()}

def runtime(files):
 bid=build_id(files)
 return {norm_name(n,bid):{'bytes':len(v),'sha256':sha(v)} for n,v in files.items() if PurePosixPath(n).suffix in EXTS}

class Head(HTMLParser):
 def __init__(self,raw):
  super().__init__();self.count=Counter();self.in_head=False;self.in_title=False;self.in_json=False;self.title='';self.jsonld=[];self.meta={};self.canonical=[];self.lang=[];self.feed(raw);self.close()
 def handle_starttag(self,tag,attrs):
  a=dict(attrs);self.count[tag]+=1
  if tag=='head':self.in_head=True
  if tag=='title' and self.in_head:self.in_title=True
  if tag=='html':self.lang.append(a.get('lang'))
  if tag=='link' and self.in_head and a.get('rel')=='canonical':self.canonical.append(a.get('href'))
  if tag=='meta' and self.in_head:self.meta.setdefault(a.get('name',a.get('property','')),[]).append(a.get('content'))
  if tag=='script' and a.get('type')=='application/ld+json':self.in_json=True;self.jsonld.append('')
  if tag=='a' and a.get('href')=='#main-content':self.count['skip']+=1
  if a.get('id')=='main-content':self.count['mainId']+=1
 def handle_endtag(self,tag):
  if tag=='head':self.in_head=False
  if tag=='title':self.in_title=False
  if tag=='script':self.in_json=False
 def handle_data(self,data):
  if self.in_title:self.title+=data
  if self.in_json:self.jsonld[-1]+=data

def check(files,baseline,fixture):
 a,b=normalize(baseline),normalize(files)
 paths=fixture['publishedPaths'];html={'index.html' if p=='/' else p.strip('/')+'/index.html' for p in paths}
 checks=[]
 def add(label,expected,actual):checks.append({'item':label,'expected':expected,'actual':actual,'status':'PASS' if expected==actual else 'FAIL'})
 add('Main baseline public route count',17,len(paths));add('Exact full inventory',sorted(a),sorted(b))
 add('All file contents equal after actual BuildID-only substitution',[],sorted(n for n in a.keys()&b.keys() if a[n]!=b[n]))
 add('Raw runtime hashes/sizes equal; only three manifest paths normalized',runtime(baseline),runtime(files))
 add('Exact 17 public plus three Next error HTMLs',sorted(html|ERROR_HTML),sorted(n for n in files if n.endswith('.html')))
 add('No review/private/planned/unpublished namespace output',[],[n for n in files if re.search(r'(^|/)(?:reviews|privacy|dev|api|heritage|luxury|unknown[^/]*)(?:/|\.|$)|(^|/)sitemap(?:\.|/)|(?:heritage|luxury)-v\d+\.html',n)])
 add('Empty .nojekyll',True,files.get('.nojekyll')==b'');add('404 exists',True,bool(files.get('404.html')))
 for p in paths:
  name='index.html' if p=='/' else p.strip('/')+'/index.html'
  if name not in files:continue
  doc,old=Head(files[name].decode()),Head(baseline[name].decode())
  add(p+' exact baseline title/description', [old.title,old.meta.get('description')],[doc.title,doc.meta.get('description')])
  add(p+' canonical/OG self',[[ORIGIN+('/' if p=='/' else p+'/')]]*2,[doc.canonical,doc.meta.get('og:url')])
  add(p+' protected robots',['noindex, nofollow'],doc.meta.get('robots'))
  add(p+' one complete root/frame/skip/h1',dict.fromkeys(['html','head','body','header','main','footer','h1','skip','mainId'],1),{k:doc.count[k] for k in ['html','head','body','header','main','footer','h1','skip','mainId']})
  add(p+' exact minimal JSONLD and zh-TW',[old.jsonld,['zh-TW']],[doc.jsonld,doc.lang])
 failures=[x for x in checks if x['status']=='FAIL']
 return {'status':'FAIL' if failures else 'PASS','scope':'DC005 brand review preparation only; formal Luxury16 pages remain unpublished. Offline artifact bridge, not new browser/AT/performance acceptance.','base':MAIN,'checkedAt':datetime.now(timezone.utc).isoformat(),'fileCount':len(files),'htmlCount':sum(n.endswith('.html') for n in files),'publicRoutes':paths,'staticFileCount':sum(not n.endswith(('.html','.txt')) for n in files),'runtimeAssetCount':len(runtime(files)),'runtimeCounts':dict(Counter(PurePosixPath(n).suffix for n in runtime(files))),'baseBuildId':build_id(baseline),'actualBuildId':build_id(files),'normalization':'Only each actual Next BuildID token in HTML/RSC/JS and the three manifest directory paths; runtime hashes never normalize content.','assertionCount':len(checks),'failures':failures,'checks':checks,'checkerSha256':sha(Path(__file__).read_bytes())}

def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--download-baseline',action='store_true');p.add_argument('--directory',type=Path);p.add_argument('--zip',type=Path);p.add_argument('--metadata',type=Path);p.add_argument('--report',type=Path);p.add_argument('--source-css',type=Path);args=p.parse_args()
 meta=json.loads((ROOT/'baseline-metadata.json').read_text())
 if meta['workflow_run']['head_sha']!=MAIN or meta['id']!=15085955305 or meta['digest']!='sha256:'+DIGEST:raise ValueError('Wrong main baseline metadata')
 if args.download_baseline:
  url=sys.stdin.readline().strip()
  try:
   with urllib.request.urlopen(url,timeout=60) as response:raw=response.read(100_000_001)
   if len(raw)>100_000_000 or sha(raw)!=DIGEST:raise ValueError('Baseline ZIP size/digest mismatch')
   with (ROOT/'baseline-main-pages.zip').open('xb') as out:out.write(raw)
   files,proof=read_zip(ROOT/'baseline-main-pages.zip',DIGEST)
   with (ROOT/'baseline-download.json').open('x') as out:json.dump({'status':'PASS','metadata':meta,'fileCount':len(files),**proof},out,indent=2);out.write('\n')
   print(json.dumps({'status':'PASS','fileCount':len(files),**proof}));return 0
  except Exception as error:print(json.dumps({'status':'FAIL','errorType':type(error).__name__,'httpStatus':getattr(error,'code',None)}));return 1
 if not args.report or args.report.exists() or bool(args.directory)==bool(args.zip):p.error('One --directory/--zip and a fresh --report required')
 base,baseproof=read_zip(ROOT/'baseline-main-pages.zip',DIGEST)
 fixture=json.loads((ROOT/'design-collection-contract.json').read_text())
 evidence=None
 if args.zip:
  if not args.metadata:p.error('Candidate ZIP requires API metadata')
  evidence=json.loads(args.metadata.read_text());files,proof=read_zip(args.zip,evidence['digest'].removeprefix('sha256:'))
  evidence.update(proof)
 else:files=read_dir(args.directory)
 result=check(files,base,fixture);result.update(baselineArtifact=meta,baselineArchive=baseproof,candidateArtifact=evidence)
 if args.source_css:
  original=(ROOT/'baseline-globals.css').read_bytes();actual=args.source_css.read_bytes();addition=EXCLUSIONS.encode()
  ok=actual.count(addition)==1 and actual.replace(addition,b'',1)==original
  repo=args.source_css.resolve().parents[2]
  source=json.loads((ROOT/'source-baseline.json').read_text())['files']
  actual_names={p.relative_to(repo).as_posix() for group in ['src','public','scripts','.github'] for p in (repo/group).rglob('*') if p.is_file() and '__pycache__' not in p.parts}
  actual_names.update(['components.json','next.config.ts','package-lock.json','package.json','tsconfig.json'])
  missing=sorted(set(source)-actual_names);extra=sorted(actual_names-set(source))
  changes=[name for name,digest in source.items() if (repo/name).is_file() and sha((repo/name).read_bytes())!=digest]
  ok=ok and not missing and not extra and changes==['src/app/globals.css'] and source['src/app/globals.css']==sha(original)
  result['sourceCssCheck']={'status':'PASS' if ok else 'FAIL','sourceFileCount':len(source),'changed':changes,'missing':missing,'extra':extra,'baselineManifest':'source-baseline.json; DC003 final source map, with main-pinned globals hash cross-check and actual main ZIP baseline','onlyExactDiscoveryExclusions':ok,'baseSha256':sha(original),'actualSha256':sha(actual),'allowedAddition':EXCLUSIONS}
  if not ok:result['status']='FAIL'
 with args.report.open('x') as out:json.dump(result,out,ensure_ascii=False,indent=2);out.write('\n')
 print(json.dumps({k:result[k] for k in ['status','fileCount','htmlCount','runtimeAssetCount','runtimeCounts','assertionCount','failures']},ensure_ascii=False))
 return 0 if result['status']=='PASS' else 1

if __name__=='__main__':raise SystemExit(main())
