'use strict';
const assert=require('node:assert/strict');
module.exports=async function nativeFontReadiness(page,label='native font readiness'){
 const startedAt=new Date().toISOString(),start=Date.now();let timer;
 try{await Promise.race([page.evaluate(async()=>{await document.fonts.ready;await new Promise(resolve=>requestAnimationFrame(()=>requestAnimationFrame(resolve)));await document.fonts.ready;}),new Promise((_,reject)=>timer=setTimeout(()=>reject(new Error(label+': native ready/2frames/ready exceeded45000ms')),45000))]);}finally{clearTimeout(timer);}
 const actual=await page.evaluate(()=>{const s=getComputedStyle(document.documentElement);return{url:location.href,fontStatus:document.fonts.status,activeFamily:s.getPropertyValue('--font-noto-sans-tc').trim(),bodyFont:getComputedStyle(document.body).fontFamily,faceCount:document.fonts.size};});
 assert.equal(actual.fontStatus,'loaded',label+': native font set still loading');
 return{kind:'NATIVE_CSS_READY_TWO_FRAMES_READY',label,startedAt,finishedAt:new Date().toISOString(),elapsedMs:Date.now()-start,...actual};
};
