#!/usr/bin/env python3
"""Bounded migration comparison; default exact mode permits only actual Next BuildID."""
import argparse
from datetime import datetime, timezone
import hashlib
from html.parser import HTMLParser
import io
import json
from pathlib import Path, PurePosixPath
import re
import tarfile
import zipfile

EXPECTED_FILES = 517
MANIFESTS = {'_buildManifest.js', '_ssgManifest.js', '_clientMiddlewareManifest.js'}
INTERNAL_HTML = {'404.html', '404/index.html', '_not-found/index.html'}
OLD_CSS = '_next/static/chunks/3w3rk4p8uol6i.css'
NEW_CSS = '_next/static/chunks/2lokuev6e6h3u.css'
OLD_CSS_SHA = '4f8b587777f624faffccc1c27b84ebd13f7470b47888b6cae9fa163e7826345a'
NEW_CSS_SHA = 'ef76f0552a4bfcc32e8a2b5bc2710524acd16db5e3cd103a03de2d59e71c1581'
UNUSED = ['collapse', 'isolate', 'contents', 'table', 'resize', 'bg-muted', 'transition', 'running']
CLASS_NAME = re.compile(r'"className"\s*:\s*("(?:[^"\\]|\\.)*")')


def sha(data):
    return hashlib.sha256(data).hexdigest()


def directory_files(root):
    files = {}
    for path in sorted(root.rglob('*')):
        if path.is_symlink():
            raise ValueError('Symlink in output: ' + str(path))
        if path.is_file():
            files[path.relative_to(root).as_posix()] = path.read_bytes()
    return files


def zip_files(path):
    raw = path.read_bytes()
    with zipfile.ZipFile(io.BytesIO(raw)) as archive:
        entries = archive.infolist()
        if len(entries) != 1 or entries[0].filename != 'artifact.tar' or entries[0].file_size > 100_000_000:
            raise ValueError('Expected exactly one bounded artifact.tar ZIP member')
        payload = archive.read(entries[0])
    files, seen, total = {}, set(), 0
    with tarfile.open(fileobj=io.BytesIO(payload), mode='r:*') as archive:
        for item in archive:
            name = item.name
            if name.startswith('/') or '\\' in name or '..' in PurePosixPath(name).parts:
                raise ValueError('Unsafe TAR path')
            name = PurePosixPath(name).as_posix().removeprefix('./')
            if name in seen:
                raise ValueError('Duplicate TAR entry')
            seen.add(name)
            if item.isdir():
                continue
            if not item.isfile() or item.issym() or item.islnk():
                raise ValueError('Nonregular TAR entry')
            total += item.size
            if len(files) >= 5000 or total > 100_000_000:
                raise ValueError('Oversized TAR inventory')
            files[name] = archive.extractfile(item).read()
    return files, sha(raw), sha(payload)


def build_id(files):
    ids = [match[1] for name in files if (match := re.fullmatch(r'_next/static/([^/]+)/_buildManifest\.js', name))]
    if len(ids) != 1:
        raise ValueError('Expected exactly one actual Next BuildID')
    actual = ids[0]
    if any('_next/static/' + actual + '/' + name not in files for name in MANIFESTS):
        raise ValueError('Missing one of the three actual BuildID manifest paths')
    return actual


def normalized_name(name, actual_id, migration=False):
    prefix = '_next/static/' + actual_id + '/'
    if name.startswith(prefix) and name[len(prefix):] in MANIFESTS:
        return '_next/static/<ACTUAL_BUILD_ID>/' + name[len(prefix):]
    return NEW_CSS if migration and name == OLD_CSS else name


def transformed_text(data, name, actual_id, migration=False):
    if not name.endswith(('.html', '.txt')):
        return data
    data = data.replace(actual_id.encode(), b'<ACTUAL_NEXT_BUILD_ID>')
    if migration:
        data = data.replace(OLD_CSS.encode(), NEW_CSS.encode())
    return data


def rsc_classes(text):
    for match in CLASS_NAME.finditer(text):
        yield json.loads(match[1])


class Classes(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.classes, self.scripts = [], []
        self.in_script = False

    def handle_starttag(self, tag, attrs):
        self.classes.extend(value for name, value in attrs if name == 'class' and value)
        if tag == 'script':
            self.in_script = True

    def handle_endtag(self, tag):
        if tag == 'script':
            self.in_script = False

    def handle_data(self, data):
        if self.in_script:
            self.scripts.append(data)


def class_usage(files):
    matches, class_attributes, class_names, embedded_payloads = [], 0, 0, 0
    public_html = [name for name in files if name.endswith('.html') and name not in INTERNAL_HTML]
    text_files = [name for name in files if name.endswith('.txt')]
    decoder = json.JSONDecoder()

    def inspect(name, values, kind):
        nonlocal class_attributes, class_names
        for value in values:
            if kind == 'HTML class':
                class_attributes += 1
            else:
                class_names += 1
            for token in value.split():
                if token in UNUSED:
                    matches.append({'path': name, 'kind': kind, 'token': token})

    for name in sorted(public_html):
        parser = Classes()
        parser.feed(files[name].decode('utf-8'))
        parser.close()
        inspect(name, parser.classes, 'HTML class')
        for script in parser.scripts:
            marker, position = 'self.__next_f.push(', 0
            while (start := script.find(marker, position)) != -1:
                start += len(marker)
                value, end = decoder.raw_decode(script[start:])
                position = start + end
                if isinstance(value, list):
                    for item in value:
                        if isinstance(item, str):
                            embedded_payloads += 1
                            inspect(name, rsc_classes(item), 'inline RSC className')
    for name in sorted(text_files):
        inspect(name, rsc_classes(files[name].decode('utf-8')), 'RSC TXT className')
    return {'publicHtml': len(public_html), 'txtFiles': len(text_files), 'classAttributes': class_attributes,
            'rscClassNameValues': class_names, 'inlineRscPayloadStrings': embedded_payloads, 'matches': matches}


def compare(before, after, migration, rules, usage, usage_receipt):
    checks = []
    def check(item, expected, actual):
        checks.append({'item': item, 'expected': expected, 'actual': actual, 'status': 'PASS' if expected == actual else 'FAIL'})
    before_id, after_id = build_id(before), build_id(after)
    check('Baseline exact file count', EXPECTED_FILES, len(before))
    check('Candidate exact file count', EXPECTED_FILES, len(after))
    css_bridge = None
    if migration:
        check('Pinned old CSS raw SHA256', OLD_CSS_SHA, sha(before.get(OLD_CSS, b'')))
        check('Pinned new CSS raw SHA256', NEW_CSS_SHA, sha(after.get(NEW_CSS, b'')))
        check('Exactly eight approved standalone utility deletions', len(UNUSED), len(rules['edits']))
        remaining, deletion_rows, names = before[OLD_CSS], [], []
        for edit in rules['edits']:
            if edit.get('op') != 'delete' or edit.get('new') != [] or len(edit.get('old', [])) != 1:
                raise ValueError('Only one complete literal CSS rule per delete edit is approved')
            rule = (edit['old'][0] + '}').encode()
            match = re.fullmatch(rb'\.([a-z-]+)\{[^{}]*\}', rule)
            if not match or match[1].decode() not in UNUSED:
                raise ValueError('CSS deletion is not an approved standalone utility rule')
            name = match[1].decode()
            names.append(name)
            check('Old CSS contains exactly one complete .' + name + ' rule', 1, remaining.count(rule))
            check('New CSS does not contain the deleted .' + name + ' rule', 0, after[NEW_CSS].count(rule))
            deletion_rows.append({'class': name, 'literal': rule.decode(), 'bytes': len(rule), 'sha256': sha(rule)})
            remaining = remaining.replace(rule, b'', 1)
        check('Deletion identities/order are independently approved', UNUSED, names)
        check('Declared old CSS byte length', rules['oldBytes'], len(before[OLD_CSS]))
        check('Declared new CSS byte length', rules['newBytes'], len(after[NEW_CSS]))
        check('Deleting each approved rule exactly once produces exact new CSS bytes', True, remaining == after[NEW_CSS])
        check('Existing TS AST literal check is PASS, complete171 and zero-match', ['PASS', 171, UNUSED, []],
              [usage.get('status'), usage.get('files'), usage.get('removedUtilityNames'), usage.get('matches')])
        check('Existing TS AST check actual process outcome', ['PASS', 0], [usage_receipt.get('status'), usage_receipt.get('exitCode')])
        css_bridge = {'oldPath': OLD_CSS, 'newPath': NEW_CSS, 'oldSha256': sha(before[OLD_CSS]), 'newSha256': sha(after[NEW_CSS]),
                      'deletedRules': deletion_rows, 'transformedOldSha256': sha(remaining)}
        for label, files in [('baseline', before), ('candidate', after)]:
            result = class_usage(files)
            check(label + ' includes exactly49 public HTML pages', 49, result['publicHtml'])
            check(label + ' has no removed utility in HTML class or serialized RSC className', [], result['matches'])
            css_bridge[label + 'ClassUsage'] = result
    old = {normalized_name(name, before_id, migration): name for name in before}
    new = {normalized_name(name, after_id): name for name in after}
    check('Name normalization introduces no collisions', [len(before), len(after)], [len(old), len(new)])
    check('Entire inventory equal with only three actual BuildID paths and approved CSS filename', sorted(old), sorted(new))
    compared, mismatches, raw_exact, content_normalized = [], [], 0, 0
    for name in sorted(set(old) & set(new)):
        old_name, new_name = old[name], new[name]
        left, right = before[old_name], after[new_name]
        method = 'raw-exact'
        if migration and old_name == OLD_CSS and new_name == NEW_CSS:
            left = remaining
            method = 'exact-eight-rule-deletion'
        elif old_name.endswith(('.html', '.txt')):
            left = transformed_text(left, old_name, before_id, migration)
            right = transformed_text(right, new_name, after_id)
            method = 'actual-BuildID' + ('+approved-CSS-filename' if migration else '')
            content_normalized += 1
        if method == 'raw-exact' and left == right:
            raw_exact += 1
        row = {'path': name, 'baselinePath': old_name, 'candidatePath': new_name, 'method': method,
               'baselineRawBytes': len(before[old_name]), 'candidateRawBytes': len(after[new_name]),
               'baselineRawSha256': sha(before[old_name]), 'candidateRawSha256': sha(after[new_name]),
               'comparedBaselineSha256': sha(left), 'comparedCandidateSha256': sha(right), 'equal': left == right}
        compared.append(row)
        if left != right:
            mismatches.append(row)
    check('Every paired file has exact bytes after only approved transformations', [], mismatches)
    failures = [row for row in checks if row['status'] == 'FAIL']
    return {'status': 'FAIL' if failures else 'PASS', 'mode': 'bounded-migration' if migration else 'exact-BuildID-only',
            'baselineBuildId': before_id, 'candidateBuildId': after_id, 'baselineFiles': len(before), 'candidateFiles': len(after),
            'comparedFiles': len(compared), 'rawExactFiles': raw_exact, 'htmlTxtNormalizedFiles': content_normalized,
            'allowedNormalization': 'Only actual BuildID in three manifest paths and HTML/TXT contents' + ('; one pinned CSS path/name plus exact one-time deletion of eight pinned standalone rules' if migration else ''),
            'cssBridge': css_bridge, 'assertions': len(checks), 'passed': len(checks) - len(failures), 'failures': failures,
            'checks': checks, 'fileComparisons': compared}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--baseline', type=Path, required=True)
    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument('--candidate', type=Path)
    group.add_argument('--zip', type=Path)
    parser.add_argument('--github-metadata', type=Path)
    parser.add_argument('--expected-head')
    parser.add_argument('--migration', action='store_true')
    parser.add_argument('--css-rule-delta', type=Path)
    parser.add_argument('--class-usage', type=Path)
    parser.add_argument('--class-usage-receipt', type=Path)
    parser.add_argument('--retained-strict-failure', type=Path)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    if args.output.exists():
        parser.error('Refusing to overwrite an existing report')
    if args.migration and (not all([args.css_rule_delta, args.class_usage, args.class_usage_receipt, args.retained_strict_failure]) or args.zip):
        parser.error('Migration requires explicit CSS/AST/receipt/retained-failure inputs and a candidate directory')
    report = {'status': 'FAIL', 'checkedAt': datetime.now(timezone.utc).isoformat(), 'checkerSha256': sha(Path(__file__).read_bytes()),
              'scope': 'Offline output-byte compatibility only; not browser, interaction, HTTP, deployment or accessibility acceptance'}
    try:
        before = directory_files(args.baseline)
        evidence = None
        if args.zip:
            if not args.github_metadata or not re.fullmatch(r'[0-9a-f]{40}', args.expected_head or ''):
                raise ValueError('ZIP comparison requires exact-head GitHub metadata')
            after, zip_sha, tar_sha = zip_files(args.zip)
            evidence = json.loads(args.github_metadata.read_text())
            if evidence.get('headSha') != args.expected_head or evidence.get('digest', '').removeprefix('sha256:') != zip_sha:
                raise ValueError('Actual ZIP digest or exact head differs from requested GitHub metadata')
            evidence.update(zipSha256=zip_sha, tarSha256=tar_sha, expectedHeadSha=args.expected_head)
        else:
            after = directory_files(args.candidate)
        data = [json.loads(path.read_text()) for path in (args.css_rule_delta, args.class_usage, args.class_usage_receipt)] if args.migration else [None] * 3
        report.update(compare(before, after, args.migration, *data))
        report['githubArtifact'] = evidence
        if args.migration:
            retained = json.loads(args.retained_strict_failure.read_text())
            report['retainedStrictFailure'] = {'path': str(args.retained_strict_failure), 'sha256': sha(args.retained_strict_failure.read_bytes()),
                                                'status': retained.get('status'), 'failures': len(retained.get('failures', []))}
            if report['retainedStrictFailure']['status'] != 'FAIL' or report['retainedStrictFailure']['failures'] != 3:
                raise ValueError('Original strict three-failure report must remain retained')
            report['inputEvidence'] = {str(path): sha(path.read_bytes()) for path in (args.css_rule_delta, args.class_usage, args.class_usage_receipt)}
    except (OSError, ValueError, KeyError, TypeError, zipfile.BadZipFile, tarfile.TarError) as error:
        report.update(status='FAIL', error=str(error))
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with args.output.open('x') as stream:
        stream.write(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps({key: report.get(key) for key in ['status', 'mode', 'comparedFiles', 'rawExactFiles', 'assertions', 'passed', 'error']}))
    return 0 if report['status'] == 'PASS' else 1


if __name__ == '__main__':
    raise SystemExit(main())
