from pathlib import Path
import ast,hashlib,json,runpy
r=Path('/tmp/xk-repo-organization-20261127')
p=r/'compare-output-compatibility.py'
ast.parse(p.read_text())
m=runpy.run_path(str(p));compare=m['compare'];read=m['directory_files']
old=read(r/'before/out');new=read(Path('/workspace/xk-website/frontend/out'))
results=[]
def check(name,value):
 assert value,name
 results.append(name)
check('exact mode accepts current new output without migration exceptions',compare(new,new,False,None,None,None)['status']=='PASS')
check('exact mode rejects old/new CSS filename and content differences',compare(old,new,False,None,None,None)['status']=='FAIL')
js=next(name for name in sorted(new) if name.endswith('.js') and '/chunks/' in name)
changed={**new,js:new[js]+b'\n'}
check('arbitrary JS runtime byte is rejected',compare(new,changed,False,None,None,None)['status']=='FAIL')
changed={**new,'index.html':new['index.html'].replace(b'<body',b'<body data-unapproved="1"',1)}
check('unapproved HTML markup is rejected',compare(new,changed,False,None,None,None)['status']=='FAIL')
text=json.dumps({'className':' '.join(m['UNUSED'])})
inline='<script>self.__next_f.push('+json.dumps([1,text])+')</script>'
sample={'index.html':('<main class="table"></main>'+inline).encode(),'__next._full.txt':text.encode()}
classes=m['class_usage'](sample)
check('exact utility tokens are detected in HTML, direct RSC and inline RSC',len(classes['matches'])==17)
check('substring class tokens are not confused with standalone rules',m['class_usage']({'index.html':b'<main class="table-fixed transition-all running-fast"></main>'})['matches']==[])
receipt=json.loads((r/'class-literal-usage-command.json').read_text())
check('original AST receipt log hash remains real and unchanged',hashlib.sha256(Path(receipt['logFile']).read_bytes()).hexdigest()==receipt['logSha256'])
old_failure=json.loads((r/'output-comparison.json').read_text())
check('initial exact comparison FAIL3 remains preserved',old_failure['status']=='FAIL' and len(old_failure['failures'])==3)
print(json.dumps({'status':'PASS','checks':len(results),'cases':results,'checkerSha256':hashlib.sha256(p.read_bytes()).hexdigest()}))
