from pathlib import Path
import hashlib,json,subprocess,platform,sys
root=Path('/workspace/xk-website');p=Path('/tmp/xk-repo-organization-20261127');checks=[]
def check(name,ok,detail):checks.append({'testId':name,'status':'PASS' if ok else 'FAIL','actual':detail})
def sha(b):return hashlib.sha256(b).hexdigest()
s=json.loads((p/'source.json').read_text());bad=[]
for row in s['files']:
 f=root/row['path'];b=f.read_bytes()
 if len(b)!=row['bytes'] or sha(b)!=row['sha256']:bad.append(row['path'])
check('ORG-SOURCE-340',len(s['files'])==340 and not bad,{'files':len(s['files']),'changed':bad,'declaredFingerprint':s['sha256']})
m=json.loads((p/'before/file-moves.json').read_text());same=[];changed=[]
for row in m['files']:
 b=(root/row['to']).read_bytes()
 (same if sha(b)==row['sha256'] and len(b)==row['bytes'] else changed).append(row['to'])
check('ORG-MOVES-335',len(same)==334 and changed==['frontend/src/app/globals.css'],{'identical':len(same),'changed':changed})
for name in ['package.json','package-lock.json','next.config.ts','tsconfig.json','eslint.config.mjs','components.json']:
 old=subprocess.check_output(['git','show',m['sourceCommit']+':'+name],cwd=root);new=(root/'frontend'/name).read_bytes();check('ORG-UNCHANGED-'+name,old==new,{'sha256':sha(new)})
changed_names=subprocess.check_output(['git','diff','--name-only','HEAD'],cwd=root,text=True).splitlines()
raw_changes=[x for x in changed_names if ('-artifacts/' in x or x.startswith('docs/screenshots/'))]
check('ORG-IMMUTABLE-OLD-EVIDENCE',not raw_changes,raw_changes)
for path in ['backend/.gitkeep','infrastructure/.gitkeep','tests/e2e/.gitkeep']:
 f=root/path;check('ORG-RESERVED-'+path,f.is_file() and f.read_bytes()==b'',{'bytes':f.stat().st_size})
ignored=['frontend/node_modules','frontend/.next','frontend/out','node_modules','.next','out']
for path in ignored:
 r=subprocess.run(['git','check-ignore',path],cwd=root,capture_output=True,text=True);check('ORG-IGNORE-'+path,r.returncode==0,r.stdout.strip())
for path in ['src','public','package.json','package-lock.json']:
 check('ORG-NO-LEGACY-'+path,not (root/path).exists(),str(root/path))
ci=(root/'.github/workflows/ci.yml').read_text()
check('ORG-CI-PATHS',ci.count('cache-dependency-path: frontend/package-lock.json')==2 and 'working-directory: frontend' in ci and 'path: frontend/out' in ci and 'frontend/.next/' in ci and ci.count('node-version-file: .nvmrc')==2,{'rootNode':(root/'.nvmrc').read_text().strip(),'domainGuard':'https://www.xplorekaleidoscope.com' in ci,'deployMainGuard':"github.ref == 'refs/heads/main'" in ci})
newbad=[]
for name in subprocess.check_output(['git','ls-files','--others','--exclude-standard'],cwd=root,text=True).splitlines():
 if any(k in name.split('/') for k in ['node_modules','.next','out','.env','.git']):newbad.append(name)
check('ORG-UNTRACKED-OUTPUT',not newbad,newbad)
result={'testId':'ORG-REPOSITORY-INTEGRITY','status':'FAIL' if any(x['status']=='FAIL' for x in checks) else 'PASS','environment':{'os':platform.platform(),'python':sys.version},'checks':checks}
(p/'repository-integrity.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'status':result['status'],'checks':len(checks),'failures':[x for x in checks if x['status']=='FAIL']}));sys.exit(result['status']!='PASS')
