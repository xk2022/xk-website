from pathlib import Path
import re,json,subprocess,os,urllib.parse
r=Path('/workspace/xk-website');m=json.loads((r/'docs/98_decisions/repository-path-map.json').read_text());changes=[]
paths=subprocess.check_output(['git','ls-files','*.md'],cwd=r,text=True).splitlines()
for name in paths:
 p=r/name
 if not p.exists()or '-artifacts/'in name or '/screenshots/'in name:continue
 text=p.read_text();fences=[(x.start(),x.end())for x in re.finditer(r'^```[^\n]*\n.*?^```[^\n]*$',text,re.M|re.S)];edits=[]
 for match in re.finditer(r'(?<!!)\[[^\]\n]+\]\(([^\n)]+)\)',text):
  if any(a<=match.start()<b for a,b in fences):continue
  raw=match.group(1);url=urllib.parse.urlsplit(raw.strip('<>'))
  if url.scheme or not url.path or raw.startswith('//'):continue
  dest=(p.parent/urllib.parse.unquote(url.path)).resolve()
  if dest.exists()or not dest.is_relative_to(r):continue
  old=dest.relative_to(r).as_posix();new=m['fileMoves'].get(old)
  if not new:
   for row in m['prefixMoves']:
    if old.startswith(row['from']):new=row['to']+old[len(row['from']):];break
  if not new or not(r/new).exists():continue
  target=os.path.relpath(r/new,p.parent).replace(os.sep,'/')+('#'+url.fragment if url.fragment else'');edits.append((match.start(1),match.end(1),target));changes.append({'file':name,'from':raw,'to':target})
 for a,b,v in reversed(edits):text=text[:a]+v+text[b:]
 if edits:p.write_text(text)
Path('/tmp/xk-repo-organization-20261127/markdown-link-moves.json').write_text(json.dumps(changes,ensure_ascii=False,indent=2)+'\n');print({'updatedLinks':len(changes),'documents':len(set(x['file']for x in changes))})
