#!/usr/bin/env python3
"""Append reviewed organization evidence; retain immutable raw snapshots and failures."""
from pathlib import Path
import argparse, datetime, gzip, hashlib, json, os, re, tempfile
R=Path('/tmp/xk-repo-organization-20261127')
REPO=Path('/workspace/xk-website')
D=REPO/'docs/reports/repository-organization-artifacts'
sha=lambda b:hashlib.sha256(b).hexdigest()
ROOT_NAMES=['source.json','before/file-moves.json','check-class-usage.cjs','class-literal-usage.json','class-literal-usage-command.json','class-literal-usage.log','http-normal.json','http-normal-command.json','http-normal.log','http-pages.json','http-pages-command.json','http-pages.log','browser-normal-final-command.json','browser-normal-final.log','browser-pages-final-command.json','browser-pages-final.log','browser-evidence-index.json','visual-review.json','pages-prefetch-readonly-review.json','markdown-link-moves.json','css-rule-delta.json','css-delta.json','output-comparison.json','output-comparison-command.json','output-comparison.log','quality.py','rewrite-links.py','archive-evidence.py']
QA=['browser-v2.cjs','monitor.cjs','business-v4.cjs','font-native-readiness-v4.cjs','quotation-total-view-v6.cjs','neutral-query-contract-v5.cjs','cv-render-v5.cjs','version-bridge-v2.json','prepare-preflight.json','prepare-preflight-v2.json','normal-final/result.json','pages-final/result.json','pages-final/failure-52.png']
def source_selection(extras):
 names=set(ROOT_NAMES+['qa/'+p for p in QA])
 names.update(p.relative_to(R).as_posix()for p in (R/'quality').iterdir()if p.is_file()and p.suffix in {'.json','.log'})
 for pattern in ['evidence-references*.json','evidence-references*.log','compatibility*.json','compatibility*.log','document-review*.json','document-review*.log']:
  names.update(p.name for p in R.glob(pattern)if p.is_file())
 for mode in ['normal','pages']:
  names.update(f'qa/{mode}-final/{style}-home-{width}-viewport.png'for style in ['modern','heritage','luxury']for width in [375,1440])
 names.update(extras)
 rows=[]
 for name in sorted(names):
  p=R/name
  if p.is_symlink()or not p.resolve().is_relative_to(R)or any(x in {'company','out','node_modules','.git'}for x in Path(name).parts):raise ValueError('Unapproved source path: '+name)
  if not p.is_file():raise FileNotFoundError(p)
  rows.append((name,p,'task-tmp'))
 rows.append(('tools/validate-evidence-references.py',REPO/'scripts/validate-evidence-references.py','repository-tool'))
 return rows

def secret_guard(raw):
 text=raw.decode('utf-8')
 if re.search(r'(?m)^[ \t]*-----BEGIN (?:RSA |EC |OPENSSH |DSA )?PRIVATE KEY-----[ \t]*$',text):raise ValueError('Private-key marker')
 if re.search(r'(?<![A-Za-z0-9_])(?:github_pat_[A-Za-z0-9_]{40,}|gh[pousr]_[A-Za-z0-9]{30,}|sk-(?:proj-)?[A-Za-z0-9_-]{32,})(?![A-Za-z0-9_])',text):raise ValueError('Credential-like token')
 if re.search(r'(?:X-Amz-Signature|X-Goog-Signature|access_token|refresh_token)=[A-Za-z0-9%_-]{24,}',text,re.I):raise ValueError('Signed URL/token')

def main():
 p=argparse.ArgumentParser();p.add_argument('--include',action='append',default=[]);a=p.parse_args();chosen=source_selection(a.include)
 D.mkdir(parents=True,exist_ok=True);manifest=D/'manifest.json';prior=json.loads(manifest.read_text())if manifest.exists()else None
 records=list(prior['files'])if prior else[];known={(r['logicalPath'],r['rawSha256'])for r in records};seen={r['rawSha256']:r for r in records};states=[];new=0;now=datetime.datetime.now(datetime.timezone.utc).isoformat()
 for logical,file,source_root in chosen:
  before=file.stat();raw=file.read_bytes();after=file.stat();assert(before.st_size,before.st_mtime_ns)==(after.st_size,after.st_mtime_ns),'Source changed during read'
  states.append((file,after.st_size,after.st_mtime_ns));digest=sha(raw)
  if(logical,digest)in known:continue
  if file.suffix!='.png':secret_guard(raw)
  row={'logicalPath':logical,'sourcePath':str(file),'sourceRoot':source_root,'rawBytes':len(raw),'rawSha256':digest,'capturedAt':now}
  if digest in seen:
   other=seen[digest];row.update({k:other[k]for k in ['path','encoding','encodedBytes','encodedSha256']});row['storage']='archive-reference'
  else:
   encoding='identity'if file.suffix=='.png'else'gzip';encoded=raw if encoding=='identity'else gzip.compress(raw,compresslevel=6,mtime=0);target=logical+(''if encoding=='identity'else'.gz')
   if any(r['logicalPath']==logical for r in records):target=logical+'.snapshot-'+digest+(''if encoding=='identity'else'.gz')
   path=D/target;path.parent.mkdir(parents=True,exist_ok=True)
   if path.exists():assert path.read_bytes()==encoded,'Existing payload differs'
   else:
    with path.open('xb')as stream:stream.write(encoded)
   row.update(storage='archive',path=target,encoding=encoding,encodedBytes=len(encoded),encodedSha256=sha(encoded))
  payload=(D/row['path']).read_bytes();assert sha(payload)==row['encodedSha256'];decoded=gzip.decompress(payload)if row['encoding']=='gzip'else payload;assert decoded==raw,'Raw roundtrip differs'
  records.append(row);known.add((logical,digest));seen.setdefault(digest,row);new+=1
 for file,size,mtime in states:
  st=file.stat();assert(st.st_size,st.st_mtime_ns)==(size,mtime),'Source changed during archive'
 assert[(x,str(y),z)for x,y,z in source_selection(a.include)]==[(x,str(y),z)for x,y,z in chosen],'Selected inventory changed'
 for row in records:
  payload=(D/row['path']).read_bytes();assert sha(payload)==row['encodedSha256'];decoded=gzip.decompress(payload)if row['encoding']=='gzip'else payload;assert sha(decoded)==row['rawSha256']and len(decoded)==row['rawBytes']
 actual_paths={r['path']for r in records};files=[D/name for name in sorted(actual_paths)]
 result={'archiveIntegrity':'PASS','qaAcceptance':'NOT_INFERRED_PRESERVE_ORIGINAL_RESULTS','createdAt':prior['createdAt']if prior else now,'updatedAt':now,'sourceRoots':{'task-tmp':str(R),'repository-tool':str(REPO)},'scope':'Selected organization receipts/results/tools and actual representative screenshots only; no company snapshot, generated out, dependency tree or old full acceptance archive.','secretGuard':'No detected key/token/signed URL in selected UTF-8 text.','inventoryStableThroughCompletion':True,'fileCount':len(records),'uniquePayloadFiles':len(files),'rawBytes':sum(r['rawBytes']for r in records),'storedPayloadBytes':sum(f.stat().st_size for f in files),'files':records,'appendHistory':(prior.get('appendHistory',[])if prior else[])+[{'capturedAt':now,'selectedFiles':len(chosen),'newRecords':new}],'normalScreenshotPolicy':'Normal6 matched Pages6 raw bytes at capture, retained as separate source records sharing the exact Pages payload.','pendingAdditions':'Root may authorize later compatibility/document-review output; current manifest does not infer completion of missing future evidence.'}
 fd,temp=tempfile.mkstemp(prefix='.manifest-',dir=D)
 with os.fdopen(fd,'w')as stream:json.dump(result,stream,ensure_ascii=False,indent=2);stream.write('\n');stream.flush();os.fsync(stream.fileno())
 os.replace(temp,manifest)
 print(json.dumps({k:result[k]for k in ['archiveIntegrity','fileCount','uniquePayloadFiles','rawBytes','storedPayloadBytes']}),flush=True)
if __name__=='__main__':main()
