#!/usr/bin/env python3
"""Append exact final-integration raw evidence without changing the old boundary."""
from pathlib import Path
import datetime,gzip,hashlib,json,os,re,tempfile
ROOT=Path('/tmp/xk-repo-organization-20261127');REPO=Path('/workspace/xk-website');D=REPO/'docs/reports/repository-organization-artifacts';BOUNDARY='final-integration-after-main48'
sha=lambda b:hashlib.sha256(b).hexdigest()
REMOTE={'prepare-command.json','prepare.log','frontend-source.json','inspect-ci-artifact-v2.py','download-pr45-artifact.py','artifact-baseline/baseline.json','artifact-baseline/smoke-website.py','artifact-baseline/source-manifest.json'}
REMOTE.update('artifact-baseline/scripts/fixtures/'+n for n in ['contact-contract.json','design-collection-contract.json','quotation-contract.json','showcase-contract.json'])
QA_NAMES=['browser-v2.cjs','browser-v3.cjs','monitor.cjs','neutral-query-contract-v5.cjs','business-v4.cjs','business-v5.cjs','cv-render-v5.cjs','cv-render-v6.cjs','font-native-readiness-v4.cjs','font-native-readiness-v5.cjs','quotation-total-view-v6.cjs','quotation-total-view-v7.cjs','version-bridge-v3.json']
def chosen():
 result=[]
 for folder,dirs,names in os.walk(ROOT/'integration'):
  dirs[:]=[x for x in dirs if x not in {'out','node_modules','.next','.git','company','__pycache__','extracted','artifact-output'}]
  for name in sorted(names):
   p=Path(folder)/name;rel=p.relative_to(ROOT/'integration')
   if p.is_symlink():raise ValueError('Source symlink')
   if rel.parts[0]=='remote'and rel.relative_to('remote').as_posix()not in REMOTE and not(name.startswith('local-check')and p.suffix in {'.json','.log'}):continue
   if p.suffix in {'.json','.log','.py','.cjs','.mjs','.txt','.png'}:result.append((p.relative_to(ROOT).as_posix(),p))
 for pattern in ['browser-normal-integrated*.json','browser-normal-integrated*.log','browser-pages-integrated*.json','browser-pages-integrated*.log']:
  result.extend(('integration/root-browser/'+p.name,p)for p in ROOT.glob(pattern)if p.is_file())
 for name in QA_NAMES:
  p=ROOT/'qa'/name;assert p.is_file();result.append(('integration/qa-tools/'+name,p))
 for folder in (ROOT/'qa').glob('*integrated*'):
  if folder.is_dir():result.extend(('integration/qa/'+str(p.relative_to(ROOT/'qa')),p)for p in folder.rglob('*')if p.is_file()and p.suffix in {'.json','.log','.png'})
 result.append(('integration/tools/archive-final-integration.py',Path(__file__)))
 assert len({x for x,p in result})==len(result)
 return sorted(result)

def guard(raw):
 t=raw.decode('utf-8')
 if re.search(r'(?m)^[ \t]*-----BEGIN (?:RSA |EC |OPENSSH |DSA )?PRIVATE KEY-----[ \t]*$',t):raise ValueError('Private key marker')
 if re.search(r'(?<![A-Za-z0-9_])(?:github_pat_[A-Za-z0-9_]{40,}|gh[pousr]_[A-Za-z0-9]{30,}|sk-(?:proj-)?[A-Za-z0-9_-]{32,})(?![A-Za-z0-9_])',t):raise ValueError('Credential-like token')
 if re.search(r'(?:X-Amz-Signature|X-Goog-Signature|access_token|refresh_token)=[A-Za-z0-9%_-]{24,}',t,re.I):raise ValueError('Signed URL/token')

def main():
 plan=chosen();manifest=D/'manifest.json';old=json.loads(manifest.read_text());records=list(old['files']);original=[r for r in records if r.get('sourceBoundary')!=BOUNDARY];old_identity=sha(json.dumps(original,sort_keys=True).encode());legacy_boundary=old['sourceBoundary']
 snapshot=(ROOT/'integration/source.json').read_bytes();source=json.loads(snapshot);assert source['sha256']=='d2c1c7b84c9c4a5e3c553458a6406af7300d7c09341d9cc9e26214b0e65d9569'
 now=datetime.datetime.now(datetime.timezone.utc).isoformat();known={(r['logicalPath'],r['rawSha256'])for r in records};seen={r['rawSha256']:r for r in records};states=[];new=0
 for logical,p in plan:
  a=p.stat();raw=p.read_bytes();b=p.stat();assert(a.st_size,a.st_mtime_ns)==(b.st_size,b.st_mtime_ns);states.append((p,b.st_size,b.st_mtime_ns));digest=sha(raw)
  if(logical,digest)in known:continue
  if p.suffix!='.png':guard(raw)
  row={'sourceBoundary':BOUNDARY,'logicalPath':logical,'sourcePath':str(p),'sourceRoot':'task-tmp'if p.is_relative_to(ROOT)else'final-archive-tool','rawBytes':len(raw),'rawSha256':digest,'capturedAt':now}
  if digest in seen:
   other=seen[digest];row.update({k:other[k]for k in ['path','encoding','encodedBytes','encodedSha256']});row['storage']='archive-reference'
  else:
   encoding='identity'if p.suffix=='.png'else'gzip';encoded=raw if encoding=='identity'else gzip.compress(raw,compresslevel=6,mtime=0);target=logical+(''if encoding=='identity'else'.gz')
   if any(r['logicalPath']==logical for r in records):target=logical+'.snapshot-'+digest+(''if encoding=='identity'else'.gz')
   file=D/target;file.parent.mkdir(parents=True,exist_ok=True)
   if file.exists():assert file.read_bytes()==encoded
   else:
    with file.open('xb')as f:f.write(encoded)
   row.update(storage='archive',path=target,encoding=encoding,encodedBytes=len(encoded),encodedSha256=sha(encoded))
  records.append(row);known.add((logical,digest));seen.setdefault(digest,row);new+=1
 for p,size,mtime in states:
  st=p.stat();assert(st.st_size,st.st_mtime_ns)==(size,mtime),'Source changed during read'
 assert[(n,str(p))for n,p in chosen()]==[(n,str(p))for n,p in plan],'Selected inventory changed'
 for r in records:
  data=(D/r['path']).read_bytes();assert sha(data)==r['encodedSha256'];raw=gzip.decompress(data)if r['encoding']=='gzip'else data;assert sha(raw)==r['rawSha256']and len(raw)==r['rawBytes']
 assert sha(json.dumps([r for r in records if r.get('sourceBoundary')!=BOUNDARY],sort_keys=True).encode())==old_identity
 unique={r['path']for r in records};old.update(updatedAt=now,files=records,fileCount=len(records),uniquePayloadFiles=len(unique),rawBytes=sum(r['rawBytes']for r in records),storedPayloadBytes=sum((D/p).stat().st_size for p in unique),archiveIntegrity='PASS',inventoryStableThroughCompletion=True)
 old.setdefault('sourceRoots',{})['final-archive-tool']=str(Path(__file__))
 old['boundaryScopePolicy']='Top sourceBoundary/boundaryMeaning preserve the initial migration snapshot. Read files[*].sourceBoundary and sourceBoundaryIndex for later integration; no old records or payloads were rewritten.'
 old.setdefault('sourceBoundaryIndex',{})[legacy_boundary]={'role':'Initial migration snapshot before latestmain76b76d4; preserved original metadata and records.'}
 old['sourceBoundaryIndex'][BOUNDARY]={'sourceFingerprint':source['sha256'],'sourceManifestPath':'integration/source.json','sourceManifestRawSha256':sha(snapshot),'headBefore':source['headBefore'],'mainIntegrated':'76b76d4991f92011e42cc1eeb813f55c0d0df7e7','oldBoundaryRecordIdentitySha256':old_identity,'oldBoundaryRecordsUnchanged':True,'scope':'Final main48 integration source evidence. Original failed suites remain failed; archive integrity does not infer QA/AT/performance/deployment acceptance.'}
 old.setdefault('appendHistory',[]).append({'capturedAt':now,'sourceBoundary':BOUNDARY,'selectedFiles':len(plan),'newRecords':new})
 fd,tmp=tempfile.mkstemp(prefix='.manifest-',dir=D)
 with os.fdopen(fd,'w')as f:json.dump(old,f,ensure_ascii=False,indent=2);f.write('\n');f.flush();os.fsync(f.fileno())
 os.replace(tmp,manifest)
 print(json.dumps({'archiveIntegrity':'PASS','boundary':BOUNDARY,'selectedFiles':len(plan),'newRecords':new,'totalRecords':len(records),'payloadBytes':old['storedPayloadBytes'],'oldBoundaryRecordsUnchanged':True}),flush=True)
if __name__=='__main__':main()
