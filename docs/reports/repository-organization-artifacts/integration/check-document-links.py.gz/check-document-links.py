#!/usr/bin/env python3
"""Read-only bounded Markdown/CWD review; never runs app commands."""
import hashlib,json,re,sys,unicodedata
from pathlib import Path
from urllib.parse import unquote,urlsplit
from datetime import datetime,timezone
ROOT=Path('/workspace/xk-website')
FILES=[ROOT/'README.md',ROOT/'AGENTS.md',*sorted((ROOT/'docs/03_engineering').glob('*.md')),ROOT/'docs/reports/repository-organization-2026-11-27.md']

def prose_lines(s):
    fence=None
    for n,line in enumerate(s.splitlines(),1):
        m=re.match(r'^\s*(`{3,}|~{3,})',line)
        if m:
            token=m.group(1)
            if fence is None:fence=token[0]
            elif fence==token[0]:fence=None
            yield n,'',True
        else:yield n,('' if fence else line),bool(fence)

def inline_links(line):
    start=0
    while True:
        at=line.find('](',start)
        if at<0:return
        pos=at+2;depth=1;chars=[]
        while pos<len(line) and depth:
            ch=line[pos]
            if ch=='\\' and pos+1<len(line):chars.extend([ch,line[pos+1]]);pos+=2;continue
            if ch=='(':depth+=1
            elif ch==')':
                depth-=1
                if depth==0:break
            chars.append(ch);pos+=1
        if depth==0:
            value=''.join(chars).strip()
            if value.startswith('<') and '>'in value:value=value[1:value.index('>')]
            else:value=re.sub(r'\s+["\'].*$','',value)
            yield value
        start=max(pos+1,at+2)

rows=[];issues=[];count=0;external=0
for f in FILES:
    raw=f.read_bytes();s=raw.decode();links=[];stack=None
    for n,line in enumerate(s.splitlines(),1):
        m=re.match(r'^\s*(`{3,}|~{3,})',line)
        if m:
            if stack is None:stack=(m.group(1)[0],n)
            elif stack[0]==m.group(1)[0]:stack=None
        if line.rstrip()!=line:issues.append({'type':'TRAILING_WHITESPACE','file':str(f.relative_to(ROOT)),'line':n})
    if stack:issues.append({'type':'UNCLOSED_FENCE','file':str(f.relative_to(ROOT)),'line':stack[1]})
    if not s.endswith('\n'):issues.append({'type':'MISSING_FINAL_LF','file':str(f.relative_to(ROOT))})
    for n,line,_ in prose_lines(s):
        for href in inline_links(line):
            if urlsplit(href).scheme or href.startswith('//'):
                external+=1;continue
            targetpart=href.split('#',1)[0].split('?',1)[0]
            if not targetpart:continue
            target=(f.parent/unquote(targetpart)).resolve();exists=target.exists();count+=1
            item={'line':n,'href':href,'resolved':str(target.relative_to(ROOT)) if target.is_relative_to(ROOT) else str(target),'exists':exists}
            links.append(item)
            if not exists:issues.append({'type':'MISSING_RELATIVE_HREF','file':str(f.relative_to(ROOT)),**item})
    rows.append({'file':str(f.relative_to(ROOT)),'sha256':hashlib.sha256(raw).hexdigest(),'lines':len(s.splitlines()),'relativeLinks':links})
manual=[
 {'id':'DOC-ORG-01','severity':'medium','file':'docs/03_engineering/website-smoke.md','line':29,'finding':'Root scripts/run-with-evidence.py is called after the guide declares frontend CWD; root CWD instead makes unprefixed npm miss package.json.','expected':'frontend CWD + ../scripts/run-with-evidence.py OR root runner + npm --prefix frontend.','observedPaths':{'rootRunnerExists':(ROOT/'scripts/run-with-evidence.py').exists(),'frontendRunnerExists':(ROOT/'frontend/scripts/run-with-evidence.py').exists(),'rootPackageExists':(ROOT/'package.json').exists(),'frontendPackageExists':(ROOT/'frontend/package.json').exists()},'stillPresent': 'python3 scripts/run-with-evidence.py' in (ROOT/'docs/03_engineering/website-smoke.md').read_text()},
 {'id':'DOC-ORG-02','severity':'medium','locations':[{'file':'docs/03_engineering/performance-measurement.md','line':7},{'file':'docs/03_engineering/design-collection-maintenance.md','line':147}],'finding':'Unqualified current no-merge/no-deploy statements contradict the latest explicit user authorization in AGENTS/current layout.','expected':'Mark those restrictions as R01 historical scope or defer to current-task authorization, preserving original report facts.','stillPresent': any(x in (ROOT/f).read_text()for f,x in [('docs/03_engineering/performance-measurement.md','不合併部署'),('docs/03_engineering/design-collection-maintenance.md','不合併或部署')])},
 {'id':'DOC-ORG-03','severity':'medium','file':'docs/03_engineering/design-collection-maintenance.md','line':123,'finding':'Current DC007 required summary lists six physical PDFs, omitting the two Modern APP-from supplements required by the active AGENTS/work package.','expected':'Six worst-case PDFs plus two from-price supplements, eight in total, or reference the current work package without a stale count.','stillPresent':'六份真 PDF' in (ROOT/'docs/03_engineering/design-collection-maintenance.md').read_text()},
]
for item in manual:
    if item['id']=='DOC-ORG-01':
        item['stillPresent']='python3 scripts/run-with-evidence.py' in (ROOT/'docs/03_engineering/website-smoke.md').read_text()
        item['status']='OPEN' if item['stillPresent'] else 'RESOLVED_BY_ROOT'
        item['verification']='Actual updated command uses ../scripts/run-with-evidence.py from declared frontend CWD; root runner exists.'
    elif item['id']=='DOC-ORG-02':
        item['stillPresent']=not all('2026-11-27 使用者另已授權' in (ROOT/f).read_text() for f in ['docs/03_engineering/performance-measurement.md','docs/03_engineering/design-collection-maintenance.md'])
        item['status']='OPEN' if item['stillPresent'] else 'RESOLVED_BY_ROOT'
        item['verification']='Both current guides now expressly mark the old restriction as the R01 stage and link the new user authorization.'
    else:
        item['status']='OPEN' if item['stillPresent'] else 'RESOLVED_BY_ROOT'
        item['verification']='Current guide compared against AGENTS requirement: six worst-case plus two Modern APP-from PDFs.'
report={'testId':'ORG-DOCS-READONLY-REVIEW','reviewedAt':datetime.now(timezone.utc).isoformat(),'scope':[str(f.relative_to(ROOT))for f in FILES],'procedure':'Python stdlib read-only inline Markdown href existence, fence balance, final LF, trailing whitespace; manual CWD/current-task consistency. No network or app commands. No historical raw evidence scanned or modified.','command':'python3 /tmp/xk-repo-organization-20261127/integration/check-document-links.py','counts':{'files':len(FILES),'relativeHrefsChecked':count,'externalHrefsNotFetched':external,'formatOrMissingLinkIssues':len(issues)},'status':'PASS_SCOPED_DOCUMENT_REVIEW' if not issues and not any(x['stillPresent'] for x in manual) else 'FINDINGS_REQUIRE_REVIEW','openManualFindings':sum(x['stillPresent'] for x in manual),'automaticFindings':issues,'manualFindings':manual,'reviewHistory':['Read-only review identified runner CWD and two unqualified no-merge guide statements. Root corrected the three locations, and reviewer reread actual updated files.','A further six-versus-eight PDF requirement discrepancy was reported to Root; current status below is based on the latest file bytes.'],'pendingReportPolicy':'PENDING test/deployment values are intentional and excluded from issues. Historical pinned Task/AGENTS sections are not treated as current authorization.','limits':['Inline Markdown relative href existence only; remote destinations and custom renderer anchors were not fetched or certified.','App scripts were read/stat-checked, not executed.','Root may update these owned files after this timestamp; compare the recorded file SHAs.'],'files':rows}
Path('/tmp/xk-repo-organization-20261127/integration/document-review.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'testId':report['testId'],'counts':report['counts'],'automaticFindings':issues,'manualFindings':[{'id':x['id'],'status':x['status']}for x in manual]},ensure_ascii=False))
