from pathlib import Path
import json,hashlib,subprocess,sys
root=Path('/workspace/xk-website');p=Path('/tmp/xk-repo-organization-20261127/integration');checks=[]
def check(k,b,d):checks.append({'testId':k,'status':'PASS' if b else 'FAIL','actual':d})
s=json.loads((p/'source.json').read_text());bad=[]
for r in s['files']:
 b=(root/r['path']).read_bytes()
 if len(b)!=r['bytes'] or hashlib.sha256(b).hexdigest()!=r['sha256']:bad.append(r['path'])
check('FINAL-SOURCE-340',len(s['files'])==340 and not bad,{'count':len(s['files']),'mismatch':bad,'fingerprint':s['sha256']})
for old,new in [('public/images/showcases/kaleidoscope-windows.webp','frontend/public/images/showcases/kaleidoscope-windows.webp'),('src/config/website-showcases.ts','frontend/src/config/website-showcases.ts'),('scripts/test-design-collection-content.mjs','frontend/scripts/test-design-collection-content.mjs')]:
 b=subprocess.check_output(['git','show','76b76d4991f92011e42cc1eeb813f55c0d0df7e7:'+old],cwd=root);check('PRESERVE-MAIN-'+new,b==(root/new).read_bytes(),hashlib.sha256(b).hexdigest())
for name in ['package.json','package-lock.json','next.config.ts','tsconfig.json','eslint.config.mjs','components.json']:
 b=subprocess.check_output(['git','show','075aaa0e4a382fbab442b85931269915c626ac37:'+name],cwd=root);check('FINAL-UNCHANGED-'+name,b==(root/'frontend'/name).read_bytes(),hashlib.sha256(b).hexdigest())
tracked=subprocess.check_output(['git','ls-files'],cwd=root,text=True).splitlines();bad=[n for n in tracked if any(x in n.split('/') for x in ['node_modules','.next','out','__pycache__']) or n.endswith(('.pyc','.pyo','.tsbuildinfo')) or any(x=='.env' or x.startswith('.env.') and x!='.env.example' for x in n.split('/'))]
check('FINAL-NO-GENERATED-OR-ENV-TRACKED',not bad,bad)
for name in ['frontend/node_modules','frontend/.next','frontend/out','frontend/scripts/__pycache__/future.pyc']:
 r=subprocess.run(['git','check-ignore',name],cwd=root,capture_output=True,text=True);check('FINAL-IGNORE-'+name,r.returncode==0,r.stdout.strip())
rawpaths=['docs/reports/dc007-artifacts','docs/screenshots/design-collection/dc007','docs/screenshots/design-collection/dc007-r01']
r=subprocess.check_output(['git','diff','--name-only','075aaa0e4a382fbab442b85931269915c626ac37','--',*rawpaths],cwd=root,text=True).splitlines();check('FINAL-OLD-RAW-IMMUTABLE',not r,r)
check('FINAL-APPROVED-OLD-IMAGE-DELETED',not(root/'frontend/public/images/showcases/qiangang-windows.webp').exists(),'main48 replaces legacy image')
r=subprocess.run(['git','diff','HEAD','--check'],cwd=root,capture_output=True,text=True);check('FINAL-DIFF-WHITESPACE',r.returncode==0,{'exitCode':r.returncode,'stdout':r.stdout})
d={'status':'FAIL' if any(x['status']=='FAIL' for x in checks) else 'PASS','testId':'ORG-FINAL-INTEGRITY','checks':checks};(p/'integrity.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps({'status':d['status'],'checks':len(checks),'failures':[x for x in checks if x['status']=='FAIL']}));sys.exit(d['status']!='PASS')
