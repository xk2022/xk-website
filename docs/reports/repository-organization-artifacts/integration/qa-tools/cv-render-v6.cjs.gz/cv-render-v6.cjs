'use strict';
const assert=require('node:assert/strict'),fonts=require('./font-native-readiness-v5.cjs');
module.exports=async function renderDeferred(page,label='native CV scroll-through'){
 const start=Date.now(),before=await page.evaluate(()=>({x:scrollX,y:scrollY,width:innerWidth,height:innerHeight})),steps=[];
 const targets=await page.locator('section,footer').all();
 try{for(const target of targets){const candidate=await target.evaluate(e=>({auto:getComputedStyle(e).contentVisibility==='auto',hasBox:e.getClientRects().length>0}));if(!candidate.auto||!candidate.hasBox)continue;
  await target.evaluate(e=>e.scrollIntoView({block:'start',inline:'nearest',behavior:'instant'}));
  await page.waitForFunction(e=>{const child=e.querySelector('h2,h3,p,a,button,input,img')||e;return typeof child.checkVisibility==='function'&&child.checkVisibility({contentVisibilityAuto:true});},await target.elementHandle(),{timeout:10000});
  await fonts(page,label);const row=await target.evaluate(e=>{const s=getComputedStyle(e),r=e.getBoundingClientRect(),child=e.querySelector('h2,h3,p,a,button,input,img')||e;return{tag:e.tagName,id:e.id,ariaLabelledby:e.getAttribute('aria-labelledby'),contentVisibility:s.contentVisibility,intrinsic:s.containIntrinsicBlockSize,rect:{x:r.x,y:r.y,width:r.width,height:r.height},nativeRendered:child.checkVisibility({contentVisibilityAuto:true}),textCharacters:e.textContent.length,scrollY};});assert.equal(row.contentVisibility,'auto','QA must preserve actual content-visibility CSS');assert(row.nativeRendered&&row.rect.width>0&&row.rect.height>0,'Actual deferred content did not render after native scrolling');steps.push(row);
 }}finally{await page.evaluate(({x,y})=>scrollTo({left:x,top:y,behavior:'instant'}),before);await fonts(page,label+' restored viewport');}
 return{label,url:page.url(),viewport:before,elapsedMs:Date.now()-start,targets:steps,cssModified:false,scrollMethod:'Native scrollIntoView instant; actual descendant checkVisibility contentVisibilityAuto plus nativefonts.ready; original scroll restored',scope:'Every active screen-auto section/footer was actually visited. Normal offscreen skipping may resume after restoring scroll. Fullpage screenshots remain raw browser captures, never CSS-forced or stitched; actual images still require visual review.'};
};
