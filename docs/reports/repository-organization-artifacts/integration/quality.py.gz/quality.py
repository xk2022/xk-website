from pathlib import Path
import subprocess,json,sys
p=Path('/tmp/xk-repo-organization-20261127/integration/quality');p.mkdir(exist_ok=True);front=Path('/workspace/xk-website/frontend');runner=front.parent/'scripts/run-with-evidence.py';rows=[]
for key,cmd in [('npm-ci',['npm','ci','--cache','/tmp/xk-npm-cache']),('typegen',['npx','next','typegen']),('typescript',['npx','tsc','--noEmit']),('lint',['npm','run','lint']),('unit',['npm','test']),('normal-build',['npm','run','build'])]:
 code=subprocess.run(['python3',str(runner),'--receipt',str(p/(key+'.json')),'--log',str(p/(key+'.log')),'--timeout','600','--',*cmd],cwd=front).returncode;rows.append({'testId':key,'command':cmd,'exitCode':code});(p/'summary.json').write_text(json.dumps({'status':'FAIL'if code else'PASS','checks':rows},indent=2)+'\n');print(json.dumps(rows[-1]),flush=True)
 if code:sys.exit(code)
