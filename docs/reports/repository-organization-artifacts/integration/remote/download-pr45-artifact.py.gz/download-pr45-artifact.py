import hashlib,json,sys,subprocess,urllib.request
from pathlib import Path
root=Path('/tmp/xk-repo-organization-20261127/integration/remote')
try:
 payload=json.loads(sys.stdin.readline());url=payload.pop('downloadUrl');head=subprocess.check_output(['git','rev-parse','HEAD'],cwd='/workspace/xk-website',text=True).strip()
 assert payload['headSha']==payload['expectedHeadSha']==head
 assert payload['pullRequest']==45 and payload['event']=='pull_request'
 with urllib.request.urlopen(url,timeout=60)as response:data=response.read(100_000_001)
 digest=hashlib.sha256(data).hexdigest()
 if len(data)>100_000_000 or len(data)!=payload['expectedBytes']or digest!=payload['digest'].removeprefix('sha256:'):raise ValueError('ZIP size/digest mismatch')
 with(root/'pr45-organized-github-pages.zip').open('xb')as out:out.write(data)
 payload.update(zipSha256=digest,downloadedBytes=len(data))
 with(root/'pr45-organized-artifact-metadata.json').open('x')as out:json.dump(payload,out,indent=2);out.write('\n')
 print(json.dumps({'status':'PASS','artifactId':payload['artifactId'],'runId':payload['runId'],'headSha':head,'zipSha256':digest,'bytes':len(data)}))
except Exception as e:
 print(json.dumps({'status':'FAIL','errorType':type(e).__name__,'httpStatus':getattr(e,'code',None)}));raise SystemExit(1)
