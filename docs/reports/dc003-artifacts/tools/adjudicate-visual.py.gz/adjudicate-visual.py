import pathlib,json,re,hashlib
from html.parser import HTMLParser
p=pathlib.Path('/tmp/xk-dc003');raw=json.loads((p/'visual-comparison-final/result.json').read_text())
class Header(HTMLParser):
 def __init__(self):super().__init__(convert_charrefs=True);self.level=0;self.tokens=[];self.ids=[];self.controls=[]
 def handle_starttag(self,t,a):
  if t=='header':self.level+=1
  if self.level:
   self.tokens.append(['start',t,list(a)])
   d=dict(a)
   if 'id'in d:self.ids.append(d['id'])
   if t=='button' and d.get('aria-label')=='開啟導覽':self.controls.append(d.get('aria-controls'))
 def handle_endtag(self,t):
  if self.level:self.tokens.append(['end',t])
  if t=='header':self.level-=1
 def handle_data(self,d):
  if self.level:self.tokens.append(['text',d])
def load(root,route):
 f=root/('index.html' if route=='/' else route.strip('/')+'/index.html');q=Header();q.feed(f.read_text());assert len(q.controls)==1;identity=q.controls[0];assert re.fullmatch(r'_R_[A-Za-z0-9]+_',identity);assert q.ids.count(identity)==1
 changed=0
 for token in q.tokens:
  if token[0]=='start':
   for a in token[2]:
    if a[0] in ['id','aria-controls'] and a[1]==identity:a[1]='__EXACT_MENU_REFERENCE_PAIR__';changed+=1
 assert changed==2
 return q.tokens,identity
rows=[]
for c in raw['cases']:
 before,oldid=load(p/'baseline-site',c['route']);after,newid=load(pathlib.Path('out'),c['route']);assert c['unresolvedDifferences']==['Header SSR DOM; no generated ID exclusion applied'];assert before==after;assert c['preFooterPixels']['differentPixels']==0;assert c['mainDOM']['equal'];rows.append({'testId':c['testId'],'status':'PASS','allowedNonVisualDelta':{'baselineMenuId':oldid,'finalMenuId':newid,'uniqueTriggerAndPanel':True,'allOtherHeaderTokensEqual':True},'preFooterDifferentPixels':0,'mainDOMEqual':True,'approvedFooterDelta':'Only exact Gallery li; initial full comparison already verified remaining Footer DOM equality','sheets':[s for s in raw['sheets'] if c['testId'].replace('COMPARE-','') in str(s)]})
r={'status':'PASS','method':'Resolve only the two linked React-generated menu identifiers, with exact uniqueness/reference checks and no other token normalization; retain original failed strict comparison. Pixel threshold remains zero. Human visual review is separately required.','originalComparisonSha256':hashlib.sha256((p/'visual-comparison-final/result.json').read_bytes()).hexdigest(),'cases':rows};(p/'visual-adjudication.json').write_text(json.dumps(r,indent=2)+'\n');print('VISUAL_ADJUDICATION_COMPLETE',len(rows),'PASS')
