#!/usr/bin/env python3
"""Remove duplicated CSS/hit-stack payloads without replacing original evidence."""
import argparse
import gzip
import hashlib
import json
from pathlib import Path


def sha(file):return hashlib.sha256(Path(file).read_bytes()).hexdigest()
def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--input',type=Path,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args()
    if a.output.exists():p.error('Use a new output path; do not replace earlier evidence')
    report=json.loads(a.input.read_text());raw={};assets=[];panels=[]
    paintkeys=('tag','id','className','opacity','filter','backdropFilter','maskImage','clipPath','transform','mixBlendMode','backgroundBlendMode','visibility','display')
    panelkeys=(*paintkeys,'rect','backgroundColor','backgroundImage','backgroundClip','boxShadow','borderTopLeftRadius','borderTopRightRadius','borderBottomLeftRadius','borderBottomRightRadius')
    for ref in report['menuEvidence']['records']:
        file=Path(ref['file']);assert sha(file)==ref['sha256'];record=json.loads(gzip.decompress(file.read_bytes()).decode() if file.suffix=='.gz' else file.read_text());raw[record['route']]=record
        assets.append(ref)
        chain=record['after']['menuPanel']['ancestors'];panels.append({'route':record['route'],'rawFileSha256':ref['sha256'],'panel':{k:chain[0][k] for k in panelkeys},'ancestorPaint':[{k:e[k] for k in paintkeys} for e in chain[1:]],'viewport':record['after']['viewport']})
    rows=[];calcs={}
    for row in report['results']:
        out={k:row[k] for k in ('testId','route','width','state','rule','target','status','reason')}
        if 'calculation' in row:
            calc=row['calculation'];key=hashlib.sha256(json.dumps(calc,sort_keys=True).encode()).hexdigest()[:16];calcs[key]=calc;out['calculationRef']=key
        if 'occlusion' in row:
            occ=row['occlusion'];record=raw[row['route']];node=next(n for n in record['after']['targets'] if n['target']==row['target']);covered=set(occ['fullyOpaqueCoveredGlyphs'])
            out['occlusion']={'glyphCount':occ['glyphs'],'fullyOpaqueCoveredCount':len(covered),'remainingCount':len(occ['remainingGlyphs']),'panelRef':row['route'],'method':occ['coverageMethod'],'glyphs':[{'text':g['text'],'rect':g['rect'],'viewportRelation':g['viewportRelation'],'opaqueCovered':i in covered,'pointTopHits':[[pt['x'],pt['y'],pt['stack'][0]['insideMenuPanel'] if pt['stack'] else None,pt['stack'][0]['isTargetOrDescendant'] if pt['stack'] else None] for pt in g['points']]} for i,g in enumerate(node['glyphs'])]}
        rows.append(out)
    summary={k:report[k] for k in ('testId','status','input','inputSha256','inputSuiteStatus','inputEnvironment','inputMode','inputRun','nodeCoverageExact','expectedIncompleteNodes','adjudicatedNodes','counts','paintModel','limitations')}
    summary.update({'derivedFrom':{'path':str(a.input),'sha256':sha(a.input)},'summaryTool':{'path':__file__,'sha256':sha(__file__)},'scope':'Lossless adjudication facts and glyph geometry/9-point top-hit flags retained; repeated style/element stacks are retained in the immutable raw files referenced by SHA. No new browser run or independent PASS is claimed.','rawEvidence':assets,'panels':panels,'calculationsById':calcs,'results':rows,'completionMarker':'DC003_AXE_ADJUDICATION_SUMMARY_COMPLETE'})
    a.output.parent.mkdir(parents=True,exist_ok=True);a.output.write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'status':summary['status'],'output':str(a.output),'sha256':sha(a.output),'bytes':a.output.stat().st_size}))
if __name__=='__main__':main()
