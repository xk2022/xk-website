#!/usr/bin/env python3
"""Offline fresh-input axe adjudication, including native-menu paint evidence."""
import argparse
from collections import Counter
from datetime import datetime, timezone
import importlib.util
import itertools
import gzip
import json
from pathlib import Path
import re
import sys

BASE=Path('/tmp/xk-dc003/adjudicate-axe.py')
spec=importlib.util.spec_from_file_location('dc003_gradient_adjudicator',BASE)
g=importlib.util.module_from_spec(spec);spec.loader.exec_module(g)
COLLECTOR_SHA='b439da5c27d5e0fbfd2cea24844e2faec3fa3c0d3d8ccf4c2c825dc7c524be16'
GZIP_COLLECTOR_SHA='3ded59f2c84e1fa2fa4927dec4a5fdaac6194d6152d904c98b7bcd577f148098'
GZIP_V2_COLLECTOR_SHA='2b6da854a129e72f1b356874a45c288825c63fbc6dae211b8fd1d6c1eac1ea6b'
ROUTES={'/','/services','/portfolio','/contact','/quotation','/design-collection','/__dc003_unknown__'}


def require(condition, reason):
    if not condition:
        raise ValueError(reason)


def same_rect(a,b):
    return all(abs(a[k]-b[k])<0.001 for k in ('x','y','width','height'))


def contained(inner,outer):
    return all((inner['left']>=outer['left'],inner['right']<=outer['right'],inner['top']>=outer['top'],inner['bottom']<=outer['bottom']))


def normal_paint(entry, allow_background=True):
    require(float(entry['opacity'])==1,'Group opacity requires a different paint model')
    for key in ('filter','backdropFilter','maskImage','clipPath'):
        require(entry[key]=='none',key+' is outside the normal paint model')
    require(entry['mixBlendMode']=='normal' and all(x.strip()=='normal' for x in entry['backgroundBlendMode'].split(',')),'Blending requires independent evidence')
    require(entry['visibility']=='visible' and entry['display']!='none','Hidden/collapsed text is outside this model')
    require(entry['textShadow']=='none','Text-shadow is not part of the contrast proof')
    require(not entry.get('pseudo'),'Generated pseudo-element paint requires independent evidence')
    if not allow_background:
        require(entry['backgroundImage']=='none','Unexpected target/ancestor background image')


def threshold(node,entry):
    size=float(entry['fontSize'].removesuffix('px'))
    weight={'normal':400,'bold':700}.get(entry['fontWeight'])
    if weight is None:weight=float(entry['fontWeight'])
    required=3 if size>=24 or (size>=18.6666666667 and weight>=700) else 4.5
    expected=max(float(c['data']['expectedContrastRatio'].split(':')[0]) for c in node['checks'])
    return max(required,expected)


def shadow_layer(panel):
    text=panel['boxShadow']
    matches=list(re.finditer(r'(?:rgba?|color|oklab)\([^()]+\)',text))
    require(matches and 'inset' not in text,'Expected source-reviewed outer menu shadow')
    visible=[]
    for i,match in enumerate(matches):
        rgb,alpha=g.color(match.group())
        geometry=text[match.end():matches[i+1].start() if i+1<len(matches) else len(text)].strip().rstrip(',').strip()
        if alpha>0:visible.append((rgb,alpha,geometry))
    # Tailwind emits transparent ring/shadow placeholders; alpha0 cannot alter paint.
    require(len(visible)==1,'Expected exactly one visible outer menu shadow')
    rgb,alpha,geometry=visible[0]
    require(all(abs(a-b)<0.001 for a,b in zip(rgb,(16,26,51))) and abs(alpha-0.08)<1e-9,'Menu shadow color/alpha differs from the source-reviewed navy8%')
    require(geometry=='0px 4px 16px 0px','Menu shadow geometry differs from the reviewed CSS')
    return rgb,alpha


def verify_panel(record):
    view=record['after']['viewport']
    require(view=={'width':375,'height':1000,'devicePixelRatio':1,'scrollX':0,'scrollY':0},'Menu viewport/scroll/DPR differs from fresh input')
    info=record['after']['menuPanel']
    require(info['resolution']=='FOUND' and info['hidden'] is False,'Expanded panel was not actually visible')
    chain=info['ancestors'];panel=chain[0]
    for entry in chain:
        normal_paint(entry)
        require(entry['transform']=='none','Transformed panel/ancestor requires separate spatial proof')
    require(g.color(panel['backgroundColor'])[1]==1 and panel['backgroundImage']=='none','Panel background is not a solid opaque color')
    require(panel['backgroundClip']=='border-box','Panel opaque fill must extend through its border box')
    require(all(panel[k]=='0px' for k in ('borderTopLeftRadius','borderTopRightRadius','borderBottomLeftRadius','borderBottomRightRadius')),'Rounded panel corners need a shape proof')
    require(len(info['clientRects'])==1,'Fragmented panel is not an opaque rectangle')
    require(same_rect(panel['rect'],info['clientRects'][0]),'Panel border-box geometry disagrees')
    require(panel['rect']['left']==0 and panel['rect']['right']==375 and 0<panel['rect']['top']<panel['rect']['bottom']<1000,'Panel expected to span the mobile viewport inside its bounds')
    return panel,shadow_layer(panel)


def bounds_for_target(before,after,node,shadow):
    require(before['resolution']==after['resolution']=='FOUND','Target must resolve uniquely in both fresh snapshots')
    require(len(before['ancestors'])==len(after['ancestors']),'Target ancestor chain changed while opening menu')
    stable=('tag','id','className','color','backgroundColor','backgroundImage','opacity','fontSize','fontWeight','position','zIndex','visibility','display','mixBlendMode','filter','backdropFilter','maskImage','clipPath','textShadow','webkitTextFillColor','boxShadow')
    for a,b in zip(before['ancestors'],after['ancestors']):
        require(all(a[k]==b[k] for k in stable) and same_rect(a['rect'],b['rect']),'Target paint/geometry changed before vs after menu opening')
        normal_paint(b,False)
    ancestors=after['ancestors'];target=ancestors[0]
    require(target['webkitTextFillColor']==target['color'],'Text fill differs from color')
    bases=[(entry,*g.color(entry['backgroundColor'])) for entry in ancestors if g.color(entry['backgroundColor'])[1]>0]
    require(bases and bases[0][2]==1,'A nearest opaque text background is required')
    base_entry,base,_=bases[0];layers=[]
    require(len(before['decorations'])==len(after['decorations']),'Decoration count changed')
    for old,dec in zip(before['decorations'],after['decorations']):
        chain=dec['ancestors'];require(len(chain)>=2,'Missing decoration parent')
        d,parent=chain[:2]
        require(g.identity(parent)==g.identity(base_entry),'A decoration belongs to a different background context')
        require(old['ancestors'][0]['backgroundImage']==d['backgroundImage'],'Decoration paint changed')
        require(float(d['opacity'])==1 and g.color(d['backgroundColor'])[1]==0,'Decoration has extra opacity/solid paint')
        require(d['filter']=='none' and d['backdropFilter']=='none' and d['mixBlendMode']=='normal' and d['backgroundBlendMode']=='normal','Decoration effect outside reviewed model')
        require(not d.get('pseudo'),'Decorative pseudo-element outside reviewed model')
        name=d['className'];image=d['backgroundImage']
        if name=='pointer-events-none absolute inset-0 brand-pattern-gradient':
            require(image.startswith('radial-gradient('),'Expected radial gradient')
            colors=[g.color(t) for t in re.findall(r'(?:rgba?|color|oklab)\([^()]+\)',image)]
            visible=[v for v in colors if v[1]>0]
            require(len(visible)==1 and abs(visible[0][1]-.12)<1e-9,'Expected single-color12% radial bound')
            require(all(abs(a-b)<0.001 for a,b in zip(visible[0][0],(25,184,213))),'Radial source color changed')
            layers.append(visible[0])
        else:
            raise ValueError('This overlap target has an unreviewed decorative layer: '+name)
    background=[]
    for choices in itertools.product((0,1),repeat=len(layers)):
        value=base
        for (rgb,alpha),enabled in zip(layers,choices):value=g.composite(rgb,value,alpha if enabled else 0)
        background.append(value)
    lo=tuple(min(v[k] for v in background) for k in range(3));hi=tuple(max(v[k] for v in background) for k in range(3))
    foreground,alpha=g.color(target['color'])
    fg=[g.composite(foreground,bg,alpha) for bg in (lo,hi)]
    # Shadow is above the underlying page: it can affect foreground and background.
    # Independent extrema weaken the bound while remaining conservative.
    bg_shadow=[g.composite(shadow[0],v,a) for v in (lo,hi) for a in (0,shadow[1])]
    fg_shadow=[g.composite(shadow[0],v,a) for v in fg for a in (0,shadow[1])]
    bgbox=(tuple(min(v[k] for v in bg_shadow) for k in range(3)),tuple(max(v[k] for v in bg_shadow) for k in range(3)))
    fgbox=(tuple(min(v[k] for v in fg_shadow) for k in range(3)),tuple(max(v[k] for v in fg_shadow) for k in range(3)))
    bl=tuple(g.luminance(v) for v in bgbox);fl=tuple(g.luminance(v) for v in fgbox)
    bound=(bl[0]+.05)/(fl[1]+.05) if fl[1]<bl[0] else (fl[0]+.05)/(bl[1]+.05) if bl[1]<fl[0] else 1
    return {'foreground':foreground,'foregroundAlpha':alpha,'opaqueBase':base,'layers':[{'rgb':v[0],'alphaRange':[0,v[1]]} for v in layers], 'menuShadow':{'rgb':shadow[0],'alphaRange':[0,shadow[1]],'appliesTo':'Both foreground and background, independently bounded'}, 'backgroundRgbBounds':bgbox,'foregroundRgbBounds':fgbox,'backgroundLuminanceBounds':bl,'foregroundLuminanceBounds':fl,'contrastLowerBound':bound,'requiredRatio':threshold(node,target),'method':'Source-audited normal paint, fresh matching before/after computed values, independent gradient alpha extrema and panel-shadow alpha extrema. Opaque panel portions are hidden, and uncovered portions must meet this conservative bound.'}


def gradient_with_menu_shadow(result,record):
    # Even distant gradient text is bounded by the panel shadow source alpha.
    # A partition of the shared shadow alpha retains foreground/background correlation.
    try:
        require('calculation' in result,'Base gradient paint was not established')
        _,shadow=verify_panel(record);calc=result['calculation']
        bg=[calc['backgroundRgbLower'],calc['backgroundRgbUpper']]
        fg=[g.composite(calc['foreground'],v,calc['foregroundAlpha']) for v in bg]
        intervals=[]
        for i in range(32):
            alphas=(shadow[1]*i/32,shadow[1]*(i+1)/32)
            b=[g.composite(shadow[0],v,a) for v in bg for a in alphas]
            f=[g.composite(shadow[0],v,a) for v in fg for a in alphas]
            bl=tuple(g.luminance(tuple((min if end==0 else max)(v[k] for v in b) for k in range(3))) for end in (0,1))
            fl=tuple(g.luminance(tuple((min if end==0 else max)(v[k] for v in f) for k in range(3))) for end in (0,1))
            bound=(bl[0]+.05)/(fl[1]+.05) if fl[1]<bl[0] else (fl[0]+.05)/(bl[1]+.05) if bl[1]<fl[0] else 1
            intervals.append({'alphaRange':alphas,'foregroundLuminanceBounds':fl,'backgroundLuminanceBounds':bl,'contrastLowerBound':bound})
        calc['preShadowContrastLowerBound']=calc['contrastLowerBound']
        calc['contrastLowerBound']=min(v['contrastLowerBound'] for v in intervals)
        calc['menuShadow']={'rgb':shadow[0],'alphaRange':[0,shadow[1]],'appliesTo':'Foreground and background with the same shadow alpha;32 covering alpha intervals keep conservative bounds','intervals':intervals}
        calc['method']+=' In expanded-menu state, the actual8% navy shadow is additionally bounded everywhere, even outside its spatial blur footprint; foreground/background alpha correlation is retained through32 interval bounds.'
        if calc['contrastLowerBound']>=calc['requiredRatio']+.001:
            result.update(status='PASS',reason='Fresh source-pinned gradient and expanded-menu shadow bounds prove the visible text contrast exceeds its required ratio.')
        else:
            result.update(status='NEED_MANUAL',reason='The gradient-plus-menu-shadow bound does not establish compliance; requires spatial/pixel review.')
    except (ValueError,KeyError,TypeError,IndexError) as error:
        result.update(status='NEED_MANUAL',reason=str(error))
    return result


def adjudicate_menu(node,scan,record,source_valid):
    result={'rule':node['rule'],'target':node['target'],'html':node['html'],'checks':node['checks'],'status':'NEED_MANUAL'}
    try:
        require(source_valid,'Fresh source/version integrity or collector coverage failed')
        require(scan['route']==record['route'] and scan['width']==375 and scan['state']=='mobile-menu-expanded','Route/state mismatch')
        panel,shadow=verify_panel(record)
        lookup=lambda stage:next(t for t in record[stage]['targets'] if t['target']==node['target'])
        before,after=lookup('before'),lookup('after')
        require(before['resolution']==after['resolution']=='FOUND','Target did not resolve')
        glyphs=after['glyphs'];require(glyphs,'No actual text glyph geometry')
        require(len(before['glyphs'])==len(glyphs),'Text glyph count changed')
        hidden=[];uncovered=[]
        for i,(old,glyph) in enumerate(zip(before['glyphs'],glyphs)):
            require(glyph['text']==old['text'] and same_rect(glyph['rect'],old['rect']),'Text/glyph position changed')
            require(g.identity(glyph['owner'])==g.identity(after['ancestors'][0]),'Nested text owner needs its own full ancestry/paint proof')
            require(glyph['owner']['color']==after['ancestors'][0]['color'],'Glyph foreground differs from target')
            covered=glyph['viewportRelation']=='FULL' and contained(glyph['rect'],panel['rect']) and len(glyph['points'])==9 and all(p['stack'] and p['stack'][0]['insideMenuPanel'] and not p['stack'][0]['isTargetOrDescendant'] for p in glyph['points'])
            (hidden if covered else uncovered).append(i)
        result['occlusion']={'glyphs':len(glyphs),'fullyOpaqueCoveredGlyphs':hidden,'remainingGlyphs':uncovered,'menuPanel':panel,'coverageMethod':'Entire glyph range border-box is within the actual solid opaque rectangular panel; all9 interior elementsFromPoint top hits are panel descendants, with source/ancestor paint and opacity verified. Partial/outside viewport glyphs are never automatically hidden.'}
        if not uncovered:
            result.update(status='N/A',reason='Every actual glyph is fully covered by the fresh opaque expanded menu panel. No visible underlying text remains to assess in this state.')
        else:
            calc=bounds_for_target(before,after,node,shadow);result['calculation']=calc
            if calc['contrastLowerBound']>=calc['requiredRatio']+.001:
                result.update(status='PASS',reason='Some underlying text remains visible; the fresh before/after source-pinned conservative contrast bound, including menu shadow, exceeds the required ratio.')
            else:
                result['reason']='Visible/partly covered text is not proven compliant by the conservative contrast bound; actual spatial/pixel review is still required. The bound alone is not proof of a failure.'
    except (ValueError,KeyError,TypeError,IndexError,StopIteration) as error:result['reason']=str(error)
    return result


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--input',type=Path,required=True);p.add_argument('--menu-evidence',type=Path,required=True);p.add_argument('--output',type=Path,required=True)
    p.add_argument('--repo',type=Path,default=Path('/workspace/xk-website'));p.add_argument('--paint-model',type=Path,default=Path('/tmp/xk-dc003/menu-paint-model.json'))
    args=p.parse_args();require(not args.output.exists(),'Use a new output path; do not overwrite earlier results')
    raw=json.loads(args.input.read_text());idx=json.loads(args.menu_evidence.read_text());model=json.loads(args.paint_model.read_text());records={};integrity=[]
    require(idx['status']=='COLLECTED' and idx['completionMarker']=='DC003_MENU_PAINT_COLLECTION_COMPLETE','Menu evidence did not finish successfully')
    require(idx['input']['sha256']==g.sha(args.input) and idx['mode']==raw['mode'],'Evidence belongs to a different input/mode')
    require(idx['collector']['sha256'] in (COLLECTOR_SHA,GZIP_COLLECTOR_SHA,GZIP_V2_COLLECTOR_SHA),'Collector version requires renewed review')
    if idx['collector']['sha256'] in (GZIP_COLLECTOR_SHA,GZIP_V2_COLLECTOR_SHA):require(idx['collector'].get('observationLogicSha256')==COLLECTOR_SHA and idx['collector'].get('storageFormat')=='gzip-json-raw-record-v1','Unreviewed compression variant')
    require(idx['environment']['browserVersion']==raw['environment']['browserVersion'],'Chromium versions differ')
    require(idx['counts']=={'records':7,'targets':32,'rawPng':7},'Expected7 page records/32targets/7rawPNGs')
    for row in idx['records']:
        file=Path(row['path']);require(g.sha(file)==row['sha256'],'Page record fileSHA mismatch');record=json.loads(gzip.decompress(file.read_bytes()).decode() if file.suffix=='.gz' else file.read_text())
        # JS JSON.stringify ordering/escaping differs from Python; file SHA is the authoritative payload digest.
        shot=Path(record['screenshot']['path']);require(g.sha(shot)==row['screenshot']['sha256']==record['screenshot']['sha256'],'Raw viewport PNG SHA mismatch')
        require(record['status']=='COLLECTED' and not record['errors'],'Page collection failed')
        if idx['collector']['sha256']==GZIP_V2_COLLECTOR_SHA:
            for request in record['requests']:
                require(request['policyAllowed'] is True,'Request failed the read-only network policy')
                if request['method']!='GET':
                    require(request['method']=='HEAD' and request['resourceType']=='fetch' and request['postDataIsNull'] is True and request['postDataBytes']==0 and request['sameOrigin'] and request['noQueryOrHash'] and request['publishedRoute'] and not request['urlContainsQaPII'] and not request['headersContainQaPII'] and not request['credentialsHeaderPresent'] and request['contentLength'] in (None,'0') and request['transferEncoding'] is None,'Unproven read-only HEAD request')
        require(record['route'] not in records,'Duplicate page record');records[record['route']]=record
        integrity.append({'route':row['route'],'file':str(file),'sha256':row['sha256'],'collectorDataSha256':row['dataSha256'],'png':str(shot),'pngSha256':g.sha(shot),'requestMethods':dict(Counter(q['method'] for q in record['requests'])),'networkPolicy':idx['collector'].get('networkPolicy','Legacy GET-only collection assertion')})
    require(set(records)==ROUTES,'Menu page coverage differs')
    recorded=raw.get('source',{}).get('data',{}).get('files',{})
    validation={path:{'audited':digest,'input':recorded.get(path),'current':g.sha(args.repo/path) if (args.repo/path).is_file() else None,'collector':idx.get('sourceValidation',{}).get(path,{}).get('current')} for path,digest in model['sources'].items()}
    # The collector itself independently validates the ten decorative and two menu source files;
    # the offline review additionally pins the five solid-content/CSS/Button sources.
    model_valid=all(v['audited']==v['input']==v['current'] and (v['collector'] is None or v['collector']==v['current']) for v in validation.values())
    expected=Counter((s['route'],s['width'],s['state'],r['id'],json.dumps(n['target'])) for s in raw['axe'] for r in s['incomplete'] for n in r['nodes'])
    observed=Counter();results=[];menu_targets=Counter()
    for scan in raw['manualStyles']:
        for node in scan['nodes']:
            key=(scan['route'],scan['width'],scan['state'],node['rule'],json.dumps(node['target']));observed[key]+=1
            reasons={c.get('data',{}).get('messageKey') for c in node['checks']}
            if node['rule']=='color-contrast' and reasons=={'bgOverlap'}:
                row=adjudicate_menu(node,scan,records[scan['route']],model_valid);menu_targets[(scan['route'],json.dumps(node['target']))]+=1
            else:
                row=g.adjudicate(node,scan,model_valid)
                if reasons=={'bgGradient'} and scan['state']=='mobile-menu-expanded':row=gradient_with_menu_shadow(row,records[scan['route']])
            row.update(testId=f'DC003-AXE-ADJ-{len(results)+1:03d}',route=scan['route'],width=scan['width'],state=scan['state'],viewport=node.get('viewport'));results.append(row)
    captured=Counter((r['route'],json.dumps(t['target'])) for r in records.values() for t in r['inputTargets'])
    coverage=expected==observed and menu_targets==captured
    counts=Counter(r['status'] for r in results);status='FAIL' if not coverage or counts['FAIL'] else 'NEED_MANUAL' if counts['NEED_MANUAL'] else 'PASS'
    report={'testId':'DC003-AXE-INCOMPLETE-ADJUDICATION-WITH-MENU','status':status,'generatedAt':datetime.now(timezone.utc).isoformat(),'input':str(args.input),'inputSha256':g.sha(args.input),'inputSuiteStatus':raw.get('status'),'inputEnvironment':raw.get('environment'),'inputMode':raw.get('mode'),'inputRun':raw.get('run'),'tools':{'wrapper':{'path':__file__,'sha256':g.sha(__file__)},'gradientAdjudicator':{'path':str(BASE),'sha256':g.sha(BASE)},'collectorSha256':idx['collector']['sha256']},'menuEvidence':{'path':str(args.menu_evidence),'sha256':g.sha(args.menu_evidence),'records':integrity},'paintModel':{'path':str(args.paint_model),'sha256':g.sha(args.paint_model),'valid':model_valid,'sourceValidation':validation,'proof':model['paintProof']},'nodeCoverageExact':coverage,'expectedIncompleteNodes':sum(expected.values()),'adjudicatedNodes':len(results),'counts':dict(counts),'results':results,'limitations':['Scoped fresh-input manual adjudication of axe color-contrast incomplete nodes; not full WCAG/assistive-technology certification.','N/A applies only to text proven fully hidden by the fresh expanded opaque menu, never merely offscreen or partly hidden.','Partial/uncovered glyphs use conservative analytic color bounds, not guessed screenshot pixels; any unmodeled effect remains NEED_MANUAL.','Original suite status and any unrelated failures remain unchanged. No historical Task012 evidence is used.'],'completionMarker':'DC003_AXE_MENU_ADJUDICATION_COMPLETE'}
    args.output.parent.mkdir(parents=True,exist_ok=True);args.output.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'status':status,'coverage':coverage,'counts':dict(counts),'output':str(args.output),'sha256':g.sha(args.output)}));return 1 if status=='FAIL' else 2 if status=='NEED_MANUAL' else 0

if __name__=='__main__':
    try:sys.exit(main())
    except (ValueError,KeyError,TypeError,OSError,IndexError) as e:
        print(json.dumps({'status':'FAIL','fatal':str(e)}));sys.exit(1)
