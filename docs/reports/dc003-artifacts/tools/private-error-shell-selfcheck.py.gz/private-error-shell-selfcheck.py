import ast
import importlib.util
import json
from pathlib import Path

root = Path('/workspace/xk-website')
source = root / 'scripts/smoke-website.py'
ast.parse(source.read_text())
spec = importlib.util.spec_from_file_location('smoke_website', source)
smoke = importlib.util.module_from_spec(spec)
spec.loader.exec_module(smoke)
markers = ['草案，尚未核准生效', *smoke.PRIVATE_DESIGN_SYSTEM_MARKERS]
empty_shell = '<html id="__next_error__"><head></head><body><script>"error recovery"</script></body></html>'
frame = '<html><head></head><body><a href="#main-content">Skip</a><header></header><main id="main-content"><h1>Not found</h1></main><footer></footer></body></html>'
for path, file in [('/privacy', 'privacy-404.html'), ('/dev/design-system', 'dev-design-system-404.html')]:
    observation = smoke.gated_private_404_observation(path, Path('/tmp/xk-dc003', file).read_text(), markers)
    assert observation['errors'] == [], observation
    assert all(count == 0 for count in observation['rawLandmarks'].values())
    assert observation['ssrCompleteFrame'].startswith('N/A')
    assert observation['browserRecoveredFrame'].startswith('REQUIRED')
    assert smoke.gated_private_404_observation(path, empty_shell, markers)['errors'] == []
    for invalid in [frame, empty_shell.replace('id="__next_error__"', ''), empty_shell.replace('</body>', '<header></header></body>'), empty_shell.replace('</body>', '<h1>Private</h1></body>'), empty_shell.replace('</body>', '<a href="#main-content">Skip</a></body>')]:
        assert smoke.gated_private_404_observation(path, invalid, markers)['errors']
    for marker in markers:
        for value in [marker, json.dumps(marker, ensure_ascii=False)[1:-1], json.dumps(marker, ensure_ascii=True)[1:-1]]:
            leaked = empty_shell.replace('</body>', '<script>' + value + '</script></body>')
            assert smoke.gated_private_404_observation(path, leaked, markers)['errors']
for path in ['/unknown-smoke-route', '/design-collection/heritage', '/privacy/child', '/dev/design-system/child', '/about', '/design-collection']:
    assert smoke.gated_private_404_observation(path, empty_shell, markers)['errors']
    assert smoke.modern_frame_errors(smoke.Document(empty_shell).root)
assert smoke.modern_frame_errors(smoke.Document(frame).root) == []
assert smoke.modern_frame_errors(smoke.Document(Path('/tmp/xk-dc003/does-not-exist-404.html').read_text()).root) == []
print('PASS: both observed private raw responses accepted only as zero-landmark error shells, SSR frame N/A/browser REQUIRED; missing-shell, leaked payload, landmarks and non-exact-route exceptions rejected; ordinary unknown frame remains strict. No HTTP requests.')
