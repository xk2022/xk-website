import importlib.util
from pathlib import Path
from types import SimpleNamespace

root = Path('/workspace/xk-website')
spec = importlib.util.spec_from_file_location('smoke_website', root / 'scripts/smoke-website.py')
smoke = importlib.util.module_from_spec(spec)
spec.loader.exec_module(smoke)
frame = '<a href="#main-content">Skip</a><header></header><main id="main-content"><h1>Title</h1><section id="design-styles"></section></main><footer></footer>'
assert smoke.modern_frame_errors(smoke.Document(frame).root) == []
for invalid in [frame + frame, frame.replace('<header></header>', ''), frame.replace('id="main-content"', 'id="other"'), frame.replace('<h1>Title</h1>', '<h1>A</h1><h1>B</h1>'), frame + '<div id="main-content"></div>', frame.replace('href="#main-content"', 'href="#other"')]:
    assert smoke.modern_frame_errors(smoke.Document(invalid).root), invalid

suite = smoke.Smoke(SimpleNamespace(base_url='https://www.xplorekaleidoscope.com/', timeout=1, check_external=False, check_source_assets=False, output='/tmp/xk-dc003/not-used.json'))
assert suite.source_contract()
assert not [check for check in suite.results if check['status'] == 'FAIL']
assert len(suite.public_pages) == 17
assert all('/(modern)/' in path for path in suite.environment['sourceSha256'] if path.endswith('/about/page.tsx'))
suite.documents = {page['path']: smoke.Document(frame).root for page in suite.public_pages}
for reference, expected_valid in [('/design-collection#design-styles', True), ('/about', True), ('/design-collection/heritage', False), ('/design-collection/luxury/contact', False), ('/design-collection/modern', False), ('/design-collection#missing', False), ('/xk-website/about', False), ('/unknown', False)]:
    suite.links_and_resources('/', smoke.Document('<a href="' + reference + '">Link</a>').root)
    check = next(check for check in reversed(suite.results) if check['item'].endswith('all site links and anchors resolve'))
    assert (check['status'] == 'PASS') == expected_valid, check
unavailable = suite.data['showcases']['websiteShowcases'][7]['sourceHref']
assert smoke.normalized_absolute_http_url(unavailable) in suite.unavailable_source_destinations
suite.links_and_resources('/', smoke.Document('<a href="' + unavailable + '">Invalid source CTA</a>').root)
assert next(check for check in reversed(suite.results) if check['item'].endswith('all site links and anchors resolve'))['status'] == 'FAIL'
print('PASS: exact 17-route/source imports, seven frame cases, Gallery/planned/alias/anchor/legacy URL cases and reference-only CTA guard; no HTTP requests')
