from pathlib import Path
import argparse, sys, json, hashlib, re
from datetime import datetime, timezone
from collections import Counter
from importlib.metadata import version
sys.path.insert(0, '/tmp/xk-estimator-tools')
import fitz, zxingcpp
from PIL import Image

parser=argparse.ArgumentParser()
parser.add_argument('pdf')
parser.add_argument('--out',required=True)
parser.add_argument('--mode',required=True,choices=['normal','pages'])
parser.add_argument('--catalog',required=True)
parser.add_argument('--expected-catalog-sha',default=None)
args=parser.parse_args()
source=Path(args.pdf).resolve()
out=Path(args.out).resolve()
out.mkdir(parents=True,exist_ok=False)
catalog_path=Path(args.catalog).resolve()
catalog_sha=hashlib.sha256(catalog_path.read_bytes()).hexdigest()
if args.expected_catalog_sha:
 assert catalog_sha==args.expected_catalog_sha,'Current run catalog digest mismatch.'
catalog=json.loads(catalog_path.read_text())
base=next(b for b in catalog['builds'] if b['id']=='shop')
addons=[a for a in catalog['addons'] if 'shop' in a['applicableBuildIds']]
assert len(addons)==17
expected_urls=['https://www.xplorekaleidoscope.com/','https://www.xplorekaleidoscope.com/portfolio/']
customer='測試客戶'*10
project='測試專案'*15
compact=lambda value:re.sub(r'\s+','',value)
result={'schemaVersion':1,'testId':'DC003-ACTUAL-PDF-PHYSICAL-QR','checkerSha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'mode':args.mode,'startedAt':datetime.now(timezone.utc).isoformat(),'sourcePdf':str(source),'sourceSha256':hashlib.sha256(source.read_bytes()).hexdigest(),'sourceBytes':source.stat().st_size,'catalog':{'path':str(catalog_path),'sha256':catalog_sha},'tools':{'PyMuPDF':version('PyMuPDF'),'Pillow':version('Pillow'),'zxing-cpp':version('zxing-cpp')},'method':'Inspect original app-generated PDF without modifying its content, page count or dimensions. Rasterize full original page at 150/300dpi; no crop, content rescaling or content deletion. Validate extracted PDF text and every text span against frozen independent expectations.','tests':[],'pages':[],'renders':[],'manualVisibility':'PENDING_VIEW_IMAGE'}
def record(id,ok,**details):
 result['tests'].append({'id':id,'result':'PASS' if ok else 'FAIL',**details})

doc=fitz.open(source)
result['pageCount']=len(doc)
record('PDF-ONE-PAGE',len(doc)==1,expected=1,actual=len(doc))
all_text=''
qr_document_urls={150:[],300:[]}
result['qrPageObservations']=[]
for index,page in enumerate(doc):
 rect=page.rect
 width,height=rect.width,rect.height
 mm=[width*25.4/72,height*25.4/72]
 record('PDF-A4-PORTRAIT-'+str(index+1),abs(width-210/25.4*72)<=1 and abs(height-297/25.4*72)<=1 and width<height,actualPt=[width,height],actualMm=mm,tolerancePt=1)
 text=page.get_text('text',sort=True)
 all_text+=page.get_text('text',sort=False)+'\n'
 text_path=out/f'page-{index+1}-text.txt'
 text_path.write_text(text)
 spans=[]
 for block in page.get_text('dict')['blocks']:
  if block['type']!=0:continue
  for line in block['lines']:
   for span in line['spans']:
    bbox=list(span['bbox'])
    spans.append({'text':span['text'],'bbox':bbox,'font':span['font'],'sizePt':span['size'],'flags':span['flags']})
 tol=0.1
 outside=[s for s in spans if s['bbox'][0]<-tol or s['bbox'][1]<-tol or s['bbox'][2]>width+tol or s['bbox'][3]>height+tol]
 span_path=out/f'page-{index+1}-text-spans.json'
 span_path.write_text(json.dumps(spans,ensure_ascii=False,indent=2)+'\n')
 record('PDF-ALL-TEXT-SPANS-IN-PAGE-'+str(index+1),len(outside)==0,totalSpans=len(spans),outsideSpans=outside,tolerancePt=tol,spanEvidence=str(span_path))
 graphics=[]
 for drawing in page.get_drawings():
  r=drawing['rect']
  graphics.append({'kind':'vector','bbox':list(r)})
 for image in page.get_images(full=True):
  for r in page.get_image_rects(image[0]):
   graphics.append({'kind':'raster','xref':image[0],'bbox':list(r)})
 outside_graphics=[g for g in graphics if g['bbox'][0]<-tol or g['bbox'][1]<-tol or g['bbox'][2]>width+tol or g['bbox'][3]>height+tol]
 record('PDF-ALL-GRAPHICS-IN-PAGE-'+str(index+1),len(outside_graphics)==0,totalGraphics=len(graphics),outsideGraphics=outside_graphics,tolerancePt=tol)
 result['pages'].append({'page':index+1,'sizePt':[width,height],'sizeMm':mm,'textCharacters':len(text),'textSpans':len(spans),'text':str(text_path),'spans':str(span_path),'rasterImageCount':len(page.get_images()),'vectorDrawingCount':len(page.get_drawings())})
 for dpi in (150,300):
  pix=page.get_pixmap(dpi=dpi,alpha=False)
  image=Image.frombytes('RGB',[pix.width,pix.height],pix.samples)
  png=out/f'page-{index+1}-{dpi}dpi.png'
  image.save(png)
  decoded=zxingcpp.read_barcodes(image,formats=zxingcpp.BarcodeFormat.QRCode)
  urls=[r.text for r in decoded]
  positions=[]
  for r in decoded:
   positions.append({'text':r.text,'cornersPx':[[getattr(r.position,p).x,getattr(r.position,p).y] for p in ('top_left','top_right','bottom_right','bottom_left')]})
  qr_document_urls[dpi].extend(urls)
  result['qrPageObservations'].append({'page':index+1,'dpi':dpi,'decodedUrls':urls,'decodedPositions':positions})
  result['renders'].append({'page':index+1,'dpi':dpi,'path':str(png),'widthPx':pix.width,'heightPx':pix.height,'sha256':hashlib.sha256(png.read_bytes()).hexdigest(),'decodedUrls':urls})
for dpi,urls in qr_document_urls.items():
 record(f'PDF-QR-DECODE-DOCUMENT-{dpi}',Counter(urls)==Counter(expected_urls),expectedUrls=expected_urls,actualUrls=urls)
normal=compact(all_text)
record('PDF-TEXT-EXTRACTABLE',len(normal)>500 and not any(c in all_text for c in ('\ufffd','\x00')),nonWhitespaceCharacters=len(normal),replacementGlyphs=all_text.count('\ufffd'),nullCharacters=all_text.count('\x00'))
record('PDF-CUSTOMER-40-CJK',compact(customer) in normal,expectedCharacters=len(customer),expected=customer,extractionMethod='Original PDF content order, normalized whitespace; layout-sorted extraction may interleave customer/project columns')
record('PDF-PROJECT-60-CJK',compact(project) in normal,expectedCharacters=len(project),expected=project,extractionMethod='Original PDF content order, normalized whitespace; layout-sorted extraction may interleave customer/project columns')
record('PDF-BASE-NAME',compact(base['name']) in normal,expected=base['name'])
matched=[{'id':a['id'],'name':a['name'],'found':compact(a['name']) in normal} for a in addons]
record('PDF-ALL-17-ADDON-NAMES',all(a['found'] for a in matched),expectedCount=17,matched=matched)
record('PDF-17-SELECTED-ADDON-MARKERS',normal.count('已選·')==17,expected=17,actual=normal.count('已選·'))
record('PDF-BASE-PLUS-17-COUNT',compact('18 項') in normal,expected='18 項')
required=['數位服務方案摘要','V1 參考試算 · 非正式報價單','本次預估費用','年度維護／服務費','第三方服務費','本摘要不是正式報價、訂單或合約','Explore Possibilities. Create Digital Value.','www.xplorekaleidoscope.com','官網','作品集']
required_results=[{'text':t,'found':compact(t) in normal} for t in required]
record('PDF-REQUIRED-BODY-AND-FOOTER',all(a['found'] for a in required_results),expected=required_results)
result['finishedAt']=datetime.now(timezone.utc).isoformat()
failures=[t for t in result['tests'] if t['result']=='FAIL']
result['automatedResult']='FAIL' if failures else 'PASS'
result['status']='FAIL' if failures else 'AUTOMATED_PASS_MANUAL_PENDING'
result['failureCount']=len(failures)
path=out/'verification.json'
path.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'mode':args.mode,'automatedResult':result['automatedResult'],'failureCount':len(failures),'pageCount':len(doc),'sourceSha256':result['sourceSha256'],'result':str(path),'renders':[r['path'] for r in result['renders']],'failedTests':[t['id'] for t in failures]}))
raise SystemExit(1 if failures else 0)
