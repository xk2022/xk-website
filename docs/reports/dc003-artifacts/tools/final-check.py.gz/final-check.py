import pathlib,json,hashlib,subprocess,re,gzip
from urllib.parse import unquote
root=pathlib.Path.cwd();out=root/'docs/reports/dc003-artifacts';checks=[]
def add(id,ok,actual):checks.append({'testId':id,'status':'PASS' if ok else 'FAIL','actual':actual})
s=json.loads((out/'source-final.json').read_text());changed=[f for f,h in s['files'].items() if hashlib.sha256((root/f).read_bytes()).hexdigest()!=h];add('SOURCE-FINAL',not changed,{'files':len(s['files']),'sha256':s['sha256'],'changed':changed})
code=subprocess.run(['git','diff','--check','HEAD'],capture_output=True,text=True);add('GIT-DIFF-WHITESPACE',code.returncode==0,code.stdout+code.stderr)
frozen=['package.json','package-lock.json','next.config.ts','tsconfig.json','.github/workflows/ci.yml'];bad=[f for f in frozen if subprocess.check_output(['git','show','HEAD:'+f])!=(root/f).read_bytes()];add('STACK-AND-DEPLOYMENT-UNCHANGED',not bad,bad)
orig=[f for f in subprocess.check_output(['git','ls-tree','-r','--name-only','794b076','src/app'],text=True).splitlines() if f.endswith('/page.tsx')];bad=[f for f in orig if subprocess.check_output(['git','show','794b076:'+f])!=(root/f.replace('src/app/','src/app/(modern)/',1)).read_bytes()];add('ELEVEN-PAGES-EXACT-MOVE',len(orig)==11 and not bad,bad)
paths=set(subprocess.check_output(['git','diff','HEAD','--name-only'],text=True).splitlines()+subprocess.check_output(['git','ls-files','--others','--exclude-standard'],text=True).splitlines());docs=[root/f for f in sorted(paths) if f.endswith('.md') and (root/f).is_file()];broken=[];fmt=[];nlinks=0
for f in docs:
 text=f.read_text();inside=False;visible=[]
 for i,line in enumerate(text.splitlines(),1):
  if line.startswith(('```','~~~')):inside=not inside;continue
  if not inside:visible.append(line)
  if line.rstrip()!=line:fmt.append([str(f.relative_to(root)),i,'trailing whitespace'])
  if re.match(r'^(<<<<<<<|=======|>>>>>>>)',line):fmt.append([str(f.relative_to(root)),i,'conflict marker'])
 if inside:fmt.append([str(f.relative_to(root)),'unclosed fence'])
 for url in re.findall(r'(?<!!)\[[^\]]+\]\(([^)]+)\)','\n'.join(visible)):
  url=url.strip('<>')
  if re.match(r'^[a-zA-Z][a-zA-Z0-9+.-]*:',url) or url.startswith('/'):continue
  path,_,anchor=url.partition('#');target=(f.parent/unquote(path)).resolve() if path else f;nlinks+=1
  if not target.exists():broken.append([str(f.relative_to(root)),url,'missing path']);continue
  if anchor and target.is_file() and target.suffix=='.md':
   t=target.read_text();ids=re.findall(r'<a\s+id="([^"]+)"',t);heads=[re.sub(r'[^\w\- ]','',x.strip().lower()).replace(' ','-') for x in re.findall(r'^#{1,6}\s+(.+)$',t,re.M)]
   if unquote(anchor) not in ids+heads:broken.append([str(f.relative_to(root)),url,'missing anchor'])
add('MARKDOWN-LINKS',not broken and not fmt,{'documents':len(docs),'links':nlinks,'broken':broken,'formatErrors':fmt})
for directory in [out,root/'docs/screenshots/design-collection/dc003']:
 bad=[]
 for line in (directory/'SHA256SUMS').read_text().splitlines():
  h,name=line.split('  ',1)
  if hashlib.sha256((directory/name).read_bytes()).hexdigest()!=h:bad.append(name)
 add('MANIFEST-'+directory.name,not bad,bad)
errors=[];count=0
for f in out.rglob('*.json'):
 d=json.loads(f.read_text())
 if isinstance(d,dict) and d.get('logSha256'):
  count+=1;name=pathlib.Path(d['logFile']).name;candidates=[f.parent/(name+'.gz'),out/(name+'.gz')];log=next((x for x in candidates if x.exists()),None)
  if not log or hashlib.sha256(gzip.decompress(log.read_bytes())).hexdigest()!=d['logSha256']:errors.append(str(f.relative_to(out)))
add('OS-RECEIPT-LOG-INTEGRITY',not errors,{'receipts':count,'errors':errors})
secrets=[];banned=[];pat=re.compile(rb'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----|github_pat_[A-Za-z0-9_]{20,}|gh[pousr]_[A-Za-z0-9_]{20,}|[?&](?:X-Amz-Signature|sig|access_token)=',re.I)
for name in paths:
 f=root/name
 if not f.is_file():continue
 if any(x in {'.next','out','node_modules','.git'} or x.startswith('.env') for x in pathlib.Path(name).parts):banned.append(name)
 if f.suffix in ['.png','.jpg','.pdf']:continue
 data=gzip.decompress(f.read_bytes()) if f.suffix=='.gz' else f.read_bytes()
 if pat.search(data):secrets.append(name)
add('NO-SECRETS-OR-BUILD-DIRS',not secrets and not banned,{'secrets':secrets,'banned':banned})
r={'status':'PASS' if all(x['status']=='PASS' for x in checks) else 'FAIL','checks':checks};p=pathlib.Path('/tmp/xk-dc003/final-check-result.json');assert not p.exists();p.write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2));raise SystemExit(0 if r['status']=='PASS' else 1)
