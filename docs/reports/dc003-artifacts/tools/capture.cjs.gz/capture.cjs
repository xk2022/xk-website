'use strict';
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto'),assert=require('node:assert/strict');
const {chromium}=require('/tmp/xk-browser-check/node_modules/playwright-core');
const mode=process.argv[2],base=new URL(process.argv[3]),run=process.argv[4]||'final';
assert(['baseline','normal','pages'].includes(mode));assert(['127.0.0.1','localhost'].includes(base.hostname));assert(/^[a-zA-Z0-9_-]+$/.test(run));
const dir=path.join('/tmp/xk-dc003',`${mode}-capture-${run}`);fs.mkdirSync(dir,{recursive:false});
const sourceFile=mode==='baseline'?'/tmp/xk-dc003/baseline-source.json':'/tmp/xk-dc003/source.json';
const sha=file=>crypto.createHash('sha256').update(fs.readFileSync(file)).digest('hex');
const out={testId:'DC003-MODERN-VISUAL-CAPTURE',mode,baseURL:base.href,run,startedAt:new Date().toISOString(),tool:{path:__filename,sha256:sha(__filename)},source:fs.existsSync(sourceFile)?{path:sourceFile,sha256:sha(sourceFile),data:JSON.parse(fs.readFileSync(sourceFile))}:null,environment:{browser:'Chromium',viewportHeight:1000,reducedMotion:'reduce',timezone:'Asia/Taipei',deviceScaleFactor:1},scope:'Five unchanged Modern routes, identical browser/viewport/state; Gallery and added Footer directory link are separately authorized increments. Actual full-page screenshots; capture PASS does not assert manual visual equivalence.',tests:[],screenshots:[],errors:[],status:'PENDING'};
const save=()=>fs.writeFileSync(path.join(dir,'result.json'),JSON.stringify(out,null,2)+'\n');
let browser;
(async()=>{try{
 browser=await chromium.launch({executablePath:'/usr/bin/chromium',headless:true,args:['--no-sandbox','--disable-dev-shm-usage']});out.environment.browserVersion=browser.version();
 for(const route of ['/','/services/','/portfolio/','/contact/','/quotation/'])for(const width of [375,1440]){
  const row={testId:`CAPTURE-${route==='/'?'home':route.split('/')[1]}-${width}`,route,width,expected:{status:200,overflow:false,fullPageScreenshot:true},status:'PENDING'};out.tests.push(row);save();
  const c=await browser.newContext({viewport:{width,height:1000},deviceScaleFactor:1,reducedMotion:'reduce',timezoneId:'Asia/Taipei'}),p=await c.newPage();
  try{
   p.on('console',m=>{if(m.type()==='error')out.errors.push({route,width,type:'console',text:m.text()});});p.on('pageerror',e=>out.errors.push({route,width,type:'runtime',text:e.stack}));
   const response=await p.goto(new URL(route,base).href,{waitUntil:'networkidle',timeout:45000});assert.equal(response.status(),200);await p.waitForFunction(()=>document.fonts.status==='loaded',null,{timeout:30000});
   if(route==='/quotation/')await p.locator('#quotation-estimator[data-quotation-ready="true"]').waitFor();
   const imageRecords=[];for(const img of await p.locator('img[src]').all()){
    if(!await img.isVisible())continue;const src=await img.getAttribute('src');if(new URL(src,base).origin!==base.origin)continue;
    await img.scrollIntoViewIfNeeded();await p.waitForFunction(e=>e.complete&&e.naturalWidth>0,await img.elementHandle(),{timeout:15000});imageRecords.push(await img.evaluate(e=>({src:e.getAttribute('src'),width:e.naturalWidth,height:e.naturalHeight,alt:e.alt})));
   }
   await p.evaluate(()=>scrollTo(0,0));await p.waitForLoadState('networkidle');
   row.actual=await p.evaluate(()=>{
    const rect=e=>{const r=e.getBoundingClientRect(),s=getComputedStyle(e);return{tag:e.tagName,id:e.id,x:r.x,y:r.y+scrollY,width:r.width,height:r.height,font:s.font,fontFamily:s.fontFamily,color:s.color,backgroundColor:s.backgroundColor}};
    const meta=name=>document.head.querySelector(`meta[name="${name}"]`)?.content||null;
    const property=name=>document.head.querySelector(`meta[property="${name}"]`)?.content||null;
    return{url:location.href,title:document.title,metadata:{canonical:document.head.querySelector('link[rel=canonical]')?.href,robots:meta('robots'),description:meta('description'),ogTitle:property('og:title'),ogDescription:property('og:description'),ogURL:property('og:url')},layout:{viewport:innerWidth,scrollWidth:document.documentElement.scrollWidth,height:document.documentElement.scrollHeight,header:[...document.querySelectorAll('header')].map(rect),main:[...document.querySelectorAll('main')].map(rect),footer:[...document.querySelectorAll('footer')].map(rect),h1:[...document.querySelectorAll('h1')].map(e=>({...rect(e),text:e.textContent})),sections:[...document.querySelectorAll('main section[id]')].map(rect)},modernMainHTML:document.querySelector('main')?.innerHTML,disclosures:[...document.querySelectorAll('details')].map(e=>({id:e.id,open:e.open})),webSiteJSONLD:[...document.querySelectorAll('script[type="application/ld+json"]')].map(e=>{try{return JSON.parse(e.textContent)}catch{return e.textContent}})};
   });
   assert(row.actual.layout.scrollWidth<=width,`overflow ${row.actual.layout.scrollWidth}>${width}`);assert.equal(row.actual.layout.h1.length,1);assert.equal(row.actual.layout.main.length,1);assert.equal(row.actual.layout.header.length,1);assert.equal(row.actual.layout.footer.length,1);
   row.actual.images=imageRecords;row.actual.modernMainHTMLSha256=crypto.createHash('sha256').update(row.actual.modernMainHTML||'').digest('hex');
   const name=`${route==='/'?'home':route.split('/')[1]}-${width}.png`,file=path.join(dir,name);await p.screenshot({path:file,fullPage:true,animations:'disabled'});out.screenshots.push({route,width,path:file,sha256:sha(file),bytes:fs.statSync(file).size});row.status='PASS';
  }catch(e){row.status='FAIL';row.error=e.stack;}finally{await c.close();}save();console.log(row.status,row.testId);
 }
 out.counters={expectedTests:10,tests:out.tests.length,expectedScreenshots:10,screenshots:out.screenshots.length,failures:out.tests.filter(t=>t.status==='FAIL').length,consoleRuntimeErrors:out.errors.length};assert.equal(out.tests.length,10);out.status=out.counters.failures||out.errors.length?'FAIL':'PASS';
 }catch(e){out.status='FAIL';out.fatal=e.stack;}finally{out.finishedAt=new Date().toISOString();save();if(browser)await browser.close();console.log('DC003_CAPTURE_COMPLETE',JSON.stringify({status:out.status,counters:out.counters,result:path.join(dir,'result.json')}));process.exitCode=out.status==='PASS'?0:1;}})();
