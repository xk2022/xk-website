from pathlib import Path
import importlib.util,json,hashlib
from PIL import Image
spec=importlib.util.spec_from_file_location('compare','/tmp/xk-dc003/compare-visual.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
checks=[]
a=Image.new('RGB',(4,4),'white');b=a.copy();s,_=m.image_difference(a,b);assert s['differentPixels']==0;checks.append('identical exact pixels')
b.putpixel((2,1),(254,255,255));s,_=m.image_difference(a,b);assert s['differentPixels']==1 and s['bbox']==[2,1,3,2] and s['maxChannelDelta']==1;checks.append('one RGB component delta retained at strict zero threshold')
s,_=m.image_difference(a,Image.new('RGB',(4,5),'white'));assert s['dimensionOnlyPixels']==4;checks.append('extra image-height row recorded')
f=m.fragment('<footer><ul><li><a href="/">Home</a></li><li><a href="/design-collection">設計系列</a></li></ul></footer>')[0];e=m.remove_only_approved_link(f);assert len(f.xpath('.//a'))==1 and e['text']=='設計系列';checks.append('exact authorized single Gallery li only')
try:m.remove_only_approved_link(m.fragment('<footer><li><a href="/design-collection">設計系列</a><span>extra</span></li></footer>')[0]);raise AssertionError('extra Footer change accepted')
except ValueError:checks.append('extra Gallery li content rejected')
assert m.tree(m.fragment('<div id="_R_25b_" aria-controls="_R_25b_"></div>'))!=m.tree(m.fragment('<div id="_R_2b_" aria-controls="_R_2b_"></div>'));checks.append('generated IDs retained, no inferred equivalence')
r={'testId':'DC003-VISUAL-COMPARE-TOOL-PREFLIGHT','status':'PASS','checks':checks,'websiteComparison':'NOT_EXECUTED','toolSha256':hashlib.sha256(Path('/tmp/xk-dc003/compare-visual.py').read_bytes()).hexdigest()};Path('/tmp/xk-dc003/visual-compare-preflight.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r))
