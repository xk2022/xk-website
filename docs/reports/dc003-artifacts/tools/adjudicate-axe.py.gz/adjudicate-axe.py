#!/usr/bin/env python3
"""Offline, per-node adjudication of fresh DC003 axe incomplete evidence."""
import argparse
from collections import Counter
from datetime import datetime, timezone
import hashlib
import itertools
import json
import math
from pathlib import Path
import re
import sys


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def color(value):
    value = value.strip()
    match = re.fullmatch(r"(rgba?|color|oklab)\(([^()]+)\)", value)
    if not match:
        raise ValueError("Unsupported computed color: " + value)
    kind, body = match.groups()
    parts = body.replace(",", " ").replace("/", " ").split()
    if kind == "color":
        if parts.pop(0) != "srgb":
            raise ValueError("Only computed color(srgb ...) is supported")
        rgb = [float(part) * 255 for part in parts[:3]]
    elif kind == "oklab":
        light, a, b = map(float, parts[:3])
        ll = (light + 0.3963377774 * a + 0.2158037573 * b) ** 3
        mm = (light - 0.1055613458 * a - 0.0638541728 * b) ** 3
        ss = (light - 0.0894841775 * a - 1.2914855480 * b) ** 3
        linear = [4.0767416621 * ll - 3.3077115913 * mm + 0.2309699292 * ss,
                  -1.2684380046 * ll + 2.6097574011 * mm - 0.3413193965 * ss,
                  -0.0041960863 * ll - 0.7034186147 * mm + 1.7076147010 * ss]
        rgb = [255 * (12.92 * c if c <= 0.0031308 else 1.055 * c ** (1 / 2.4) - 0.055) for c in linear]
    else:
        rgb = [float(part[:-1]) * 2.55 if part.endswith("%") else float(part) for part in parts[:3]]
    alpha = float(parts[3][:-1]) / 100 if len(parts) == 4 and parts[3].endswith("%") else float(parts[3]) if len(parts) == 4 else 1.0
    if len(rgb) != 3 or not all(math.isfinite(c) for c in [*rgb, alpha]) or not 0 <= alpha <= 1:
        raise ValueError("Invalid computed color")
    return tuple(max(0, min(255, c)) for c in rgb), alpha


def luminance(rgb):
    channels = [c / 255 for c in rgb]
    linear = [c / 12.92 if c <= 0.04045 else ((c + 0.055) / 1.055) ** 2.4 for c in channels]
    return sum(c * weight for c, weight in zip(linear, (0.2126, 0.7152, 0.0722)))


def composite(foreground, background, alpha):
    return tuple(alpha * f + (1 - alpha) * b for f, b in zip(foreground, background))


def identity(entry):
    return entry["tag"], entry["id"], entry["className"], json.dumps(entry["rect"], sort_keys=True)


def adjudicate(node, scan, model_valid):
    result = {"rule": node["rule"], "target": node["target"], "html": node["html"],
              "status": "NEED_MANUAL", "reason": "Unclassified incomplete", "checks": node["checks"]}
    keys = {check.get("data", {}).get("messageKey") for check in node["checks"]}
    if node["rule"] != "color-contrast" or keys != {"bgGradient"}:
        result["reason"] = ("bgOverlap has no recorded occluding element/paint geometry; needs fresh screenshot or menu panel rect, color, opacity and topmost-element evidence. Covered text may be N/A only after coverage is proven."
                            if "bgOverlap" in keys else "Incomplete rule/reason is outside the bounded gradient model.")
        return result
    try:
        if not model_valid or scan["route"] not in ("/", "/services", "/portfolio", "/contact"):
            raise ValueError("The source-pinned decorative paint model does not cover this input version/route")
        inspected = node["computed"]
        if inspected.get("resolution") != "FOUND" or len(node.get("related", [])) != 1:
            raise ValueError("Missing target or a non-single related gradient layer")
        ancestors = inspected["ancestors"]
        related = node["related"][0]["computed"]
        if related.get("resolution") != "FOUND" or len(related["ancestors"]) < 2:
            raise ValueError("Missing related gradient ancestry")
        for entry in [*ancestors, *related["ancestors"]]:
            if float(entry["opacity"]) != 1:
                raise ValueError("Group opacity is not covered by the current paint model")
        if any(entry["backgroundImage"] != "none" for entry in ancestors):
            raise ValueError("Target ancestry has an additional background image")
        bases = []
        for entry in ancestors:
            rgb, alpha = color(entry["backgroundColor"])
            if alpha:
                bases.append((entry, rgb, alpha))
        if not bases or bases[0][2] != 1:
            raise ValueError("No nearest opaque background; translucent ancestor composition requires more evidence")
        base_entry, base, _ = bases[0]
        decoration, parent = related["ancestors"][:2]
        if identity(base_entry) != identity(parent):
            raise ValueError("Related layer's parent is not the target's nearest opaque background")
        if color(decoration["backgroundColor"])[1] != 0:
            raise ValueError("Related layer has an extra solid background")
        image = decoration["backgroundImage"]
        colors = re.findall(r"(?:rgba?|color|oklab)\([^()]+\)", image)
        if len(colors) < 2:
            raise ValueError("Gradient color stops were not fully recorded")
        stops = [color(token) for token in colors]
        visible = [(rgb, alpha) for rgb, alpha in stops if alpha > 0]
        if not visible or any(rgb != visible[0][0] for rgb, _ in visible):
            raise ValueError("Multi-color gradients need an independently bounded color-space model")
        rgb = visible[0][0]
        cap = max(alpha for _, alpha in visible)
        layers = []
        if decoration["className"] == "pointer-events-none absolute inset-0 brand-pattern-gradient":
            if not image.startswith("radial-gradient(") or abs(cap - 0.12) > 1e-9:
                raise ValueError("Unreviewed radial gradient syntax or alpha")
            if tuple(round(c) for c in base) == (16, 26, 51):
                # Source inspection: two perpendicular 9% blue grid layers precede the radial.
                layers.extend([((49, 87, 213), 0.09), ((49, 87, 213), 0.09)])
            layers.append((rgb, cap))
        elif decoration["className"] == "pointer-events-none absolute inset-0 brand-pattern-kaleidoscope":
            if not image.startswith("repeating-conic-gradient(") or abs(cap - 0.07) > 1e-9:
                raise ValueError("Unreviewed conic gradient syntax or alpha")
            layers.append((rgb, cap))
        else:
            raise ValueError("Unreviewed decorative classes")
        backgrounds = []
        for choices in itertools.product((0, 1), repeat=len(layers)):
            sample = base
            for (layer_color, maximum), enabled in zip(layers, choices):
                sample = composite(layer_color, sample, maximum if enabled else 0)
            backgrounds.append(sample)
        lower_bg = tuple(min(c[i] for c in backgrounds) for i in range(3))
        upper_bg = tuple(max(c[i] for c in backgrounds) for i in range(3))
        foreground, foreground_alpha = color(ancestors[0]["color"])
        lower_fg = composite(foreground, lower_bg, foreground_alpha)
        upper_fg = composite(foreground, upper_bg, foreground_alpha)
        bg_luminance = (luminance(lower_bg), luminance(upper_bg))
        fg_luminance = (luminance(lower_fg), luminance(upper_fg))
        if fg_luminance[1] < bg_luminance[0]:
            bound = (bg_luminance[0] + 0.05) / (fg_luminance[1] + 0.05)
        elif bg_luminance[1] < fg_luminance[0]:
            bound = (fg_luminance[0] + 0.05) / (bg_luminance[1] + 0.05)
        else:
            bound = 1.0
        size = float(ancestors[0]["fontSize"].removesuffix("px"))
        weight_text = ancestors[0]["fontWeight"]
        weight = {"normal": 400, "bold": 700}.get(weight_text, float(weight_text) if weight_text.isdigit() else 0)
        minimum = 3 if size >= 24 or (size >= 18.6666666667 and weight >= 700) else 4.5
        expected = max(float(check["data"]["expectedContrastRatio"].split(":")[0]) for check in node["checks"])
        threshold = max(minimum, expected)
        result["calculation"] = {"foreground": foreground, "foregroundAlpha": foreground_alpha,
            "opaqueBase": base, "layers": [{"rgb": c, "alphaRange": [0, a]} for c, a in layers],
            "backgroundRgbLower": lower_bg, "backgroundRgbUpper": upper_bg,
            "foregroundLuminanceBounds": fg_luminance, "backgroundLuminanceBounds": bg_luminance,
            "contrastLowerBound": bound, "requiredRatio": threshold, "fontSizePx": size, "fontWeight": weight,
            "method": "All alpha-extreme combinations produce a conservative RGB box; monotone sRGB luminance and separated foreground/background luminance intervals bound contrast throughout the gradient, including masks. Foreground alpha is composited too."}
        if bound >= threshold + 0.001:
            result["status"] = "PASS"
            result["reason"] = "Source-pinned normal paint and this scan's computed colors prove the full conservative gradient bound exceeds the required contrast."
        else:
            result["reason"] = "The conservative bound does not prove compliance; requires a spatial/actual-pixel check. A failing bound alone does not prove a real violation."
    except (KeyError, TypeError, ValueError, IndexError) as error:
        result["reason"] = str(error)
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--repo", type=Path, default=Path("/workspace/xk-website"))
    parser.add_argument("--paint-model", type=Path, default=Path("/tmp/xk-dc003/axe-paint-model.json"))
    args = parser.parse_args()
    if args.output.exists():
        parser.error("Use a new output path; do not overwrite previous adjudications")
    source = json.loads(args.input.read_text())
    model = json.loads(args.paint_model.read_text())
    recorded_hashes = source.get("source", {}).get("data", {}).get("files", {})
    validation = {path: {"audited": digest, "recorded": recorded_hashes.get(path),
                         "current": sha(args.repo / path) if (args.repo / path).is_file() else None}
                  for path, digest in model["sources"].items()}
    model_valid = all(row["audited"] == row["recorded"] == row["current"] for row in validation.values())
    expected = Counter((scan["route"], scan["width"], scan["state"], rule["id"], json.dumps(node["target"]))
                       for scan in source["axe"] for rule in scan["incomplete"] for node in rule["nodes"])
    observed = Counter()
    rows = []
    for scan in source["manualStyles"]:
        for node in scan["nodes"]:
            observed[(scan["route"], scan["width"], scan["state"], node["rule"], json.dumps(node["target"]))] += 1
            row = adjudicate(node, scan, model_valid)
            row.update({"testId": f"DC003-AXE-ADJ-{len(rows)+1:03d}", "route": scan["route"],
                        "width": scan["width"], "state": scan["state"], "viewport": node.get("viewport")})
            rows.append(row)
    coverage = expected == observed
    counts = Counter(row["status"] for row in rows)
    status = "FAIL" if not coverage or counts["FAIL"] else "NEED_MANUAL" if counts["NEED_MANUAL"] else "PASS"
    report = {"testId": "DC003-AXE-INCOMPLETE-ADJUDICATION", "status": status,
        "input": str(args.input), "inputSha256": sha(args.input), "inputSuiteStatus": source.get("status"),
        "inputEnvironment": source.get("environment"), "inputMode": source.get("mode"), "inputRun": source.get("run"),
        "generatedAt": datetime.now(timezone.utc).isoformat(), "nodeCoverageExact": coverage,
        "expectedIncompleteNodes": sum(expected.values()), "adjudicatedNodes": len(rows), "counts": dict(counts),
        "paintModel": {"path": str(args.paint_model), "sha256": sha(args.paint_model), "valid": model_valid,
                       "sourceValidation": validation, "proof": model["paintProof"]},
        "results": rows,
        "limitations": ["This is fresh-input color-contrast adjudication, not an overall browser suite or WCAG certification.",
                        "bgOverlap without occluder evidence remains NEED_MANUAL; old Task012 is not acceptance evidence.",
                        "Passing ratios are conservative analytic bounds using source-audited normal painting; actual screenshot pixels were not sampled.",
                        "Input suite failures remain failures; adjudication does not relabel its other assertions as passed."],
        "completionMarker": "DC003_AXE_ADJUDICATION_COMPLETE"}
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n")
    print(json.dumps({"status": status, "coverage": coverage, "counts": dict(counts), "output": str(args.output)}))
    return 1 if status == "FAIL" else 2 if status == "NEED_MANUAL" else 0


if __name__ == "__main__":
    sys.exit(main())
