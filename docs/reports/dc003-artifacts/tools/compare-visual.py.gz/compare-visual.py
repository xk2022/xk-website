#!/usr/bin/env python3
"""Read-only DC003 capture comparison. Derived sheets are not new screenshots."""
import argparse, copy, difflib, hashlib, json, math, sys
from datetime import datetime, timezone
from pathlib import Path
import numpy as np
from PIL import Image, ImageChops, ImageDraw, ImageFont
from lxml import html, etree

def digest(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def json_digest(value): return hashlib.sha256(json.dumps(value,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()
def key(route,width): return (route.rstrip('/') or '/',width)
def write_json(path,value): path.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n')
def ranges(values):
 result=[]
 for value in values:
  value=int(value)
  if result and value==result[-1][1]+1:result[-1][1]=value
  else:result.append([value,value])
 return result

def tree(node):
 # Preserve text, comments, every attribute and every child; no IDs/classes excluded.
 if not isinstance(node.tag,str):return {'kind':'comment','text':node.text,'tail':node.tail}
 return {'tag':node.tag,'attrs':dict(sorted(node.attrib.items())),'text':node.text,'children':[tree(c) for c in node],'tail':node.tail}
def fragment(value): return html.fragment_fromstring(value,create_parent='capture-fragment')
def dom_compare(before,after,out_file):
 a,b=tree(before),tree(after)
 aa=json.dumps(a,ensure_ascii=False,indent=2,sort_keys=True).splitlines();bb=json.dumps(b,ensure_ascii=False,indent=2,sort_keys=True).splitlines()
 diff=list(difflib.unified_diff(aa,bb,fromfile='baseline',tofile='final',lineterm=''))
 out_file.write_text('\n'.join(diff)+ ('\n' if diff else ''))
 return {'equal':a==b,'baselineCanonicalSha256':json_digest(a),'finalCanonicalSha256':json_digest(b),'diffLines':len(diff),'diffEvidence':str(out_file),'normalization':'HTML parser only; attributes sorted for semantic comparison. Text/comments/IDs/classes/attributes retained. No generated-ID exclusion or inferred renaming.'}

def ssr_dom(site,route):
 relative=route.strip('/')
 file=Path(site)/relative/'index.html' if relative else Path(site)/'index.html'
 if not file.is_file():raise ValueError('Missing immutable page HTML: '+str(file))
 doc=html.fromstring(file.read_bytes())
 def only(tag):
  nodes=doc.xpath('//'+tag)
  if len(nodes)!=1:raise ValueError(f'{file}: expected one {tag}, got {len(nodes)}')
  return copy.deepcopy(nodes[0])
 return {'path':str(file),'sha256':digest(file),'bytes':file.stat().st_size},only('header'),only('footer')

def remove_only_approved_link(footer):
 links=footer.xpath('.//a[@href="/design-collection" or @href="/design-collection/"]')
 if len(links)!=1:raise ValueError(f'Expected exactly one new Gallery Footer link, got {len(links)}')
 a=links[0];li=a.getparent()
 if li.tag!='li' or len(li)!=1 or li[0] is not a or (li.text or '').strip() or (a.tail or '').strip():raise ValueError('Gallery li contains extra content; authorization is not applicable')
 if ''.join(a.itertext()).strip()!='設計系列':raise ValueError('Unexpected Gallery link label')
 evidence={'href':a.attrib['href'],'text':''.join(a.itertext()),'removedExactLI':etree.tostring(li,encoding='unicode',method='html'),'liParent':li.getparent().tag,'rule':'Only this single exact Gallery li is removed for a secondary semantic Footer comparison. Original DOM and every Footer pixel delta remain recorded.'}
 li.getparent().remove(li)
 return evidence

def image_difference(a,b):
 w=max(a.width,b.width);h=max(a.height,b.height)
 aa=np.zeros((h,w,3),dtype=np.uint8);bb=np.zeros((h,w,3),dtype=np.uint8)
 aa[:a.height,:a.width]=np.asarray(a.convert('RGB'));bb[:b.height,:b.width]=np.asarray(b.convert('RGB'))
 av=np.zeros((h,w),bool);bv=np.zeros((h,w),bool);av[:a.height,:a.width]=True;bv[:b.height,:b.width]=True
 channel=np.abs(aa.astype(np.int16)-bb.astype(np.int16));mask=np.any(channel!=0,axis=2)|(av!=bv)
 ys,xs=np.where(mask)
 bbox=[int(xs.min()),int(ys.min()),int(xs.max())+1,int(ys.max())+1] if len(xs) else None
 tiles=[]
 for y in range(0,h,64):
  for x in range(0,w,64):
   n=int(np.count_nonzero(mask[y:y+64,x:x+64]))
   if n:tiles.append({'box':[x,y,min(x+64,w),min(y+64,h)],'changedPixels':n})
 summary={'strictThreshold':0,'canvasDimensions':[w,h],'differentPixels':int(mask.sum()),'differentRGBComponents':int(np.count_nonzero(channel)),'dimensionOnlyPixels':int(np.count_nonzero(av!=bv)),'maxChannelDelta':int(channel.max()) if channel.size else 0,'bbox':bbox,'changedRowBandsInclusive':ranges(np.where(mask.any(axis=1))[0]),'changedColumnBandsInclusive':ranges(np.where(mask.any(axis=0))[0]),'tiles64px':tiles}
 return summary,mask

def derived_diff(a,b,mask):
 canvas=Image.new('RGB',(mask.shape[1],mask.shape[0]),'#eeeeee');canvas.paste(a.convert('RGB'),(0,0));canvas=Image.blend(canvas,Image.new('RGB',canvas.size,'white'),.70)
 pixels=np.asarray(canvas).copy();pixels[mask]=[238,36,68]
 return Image.fromarray(pixels)

def crop_padded(image,top,bottom,width=None):
 width=width or image.width;top=max(0,int(top));bottom=max(top+1,int(bottom));out=Image.new('RGB',(width,bottom-top),'#ececec');
 if top<image.height:out.paste(image.crop((0,top,min(width,image.width),min(bottom,image.height))),(0,0))
 return out

def sheet(panels,labels,file,title,max_width=600):
 # These are explicitly labelled derived crops, never represented as originals.
 fonts=ImageFont.load_default();scale=min(1,max_width/max(p.width for p in panels));sizes=[(max(1,round(p.width*scale)),max(1,round(p.height*scale))) for p in panels];w=max(s[0] for s in sizes);h=max(s[1] for s in sizes);gap=12;header=56
 canvas=Image.new('RGB',(w*len(panels)+gap*(len(panels)+1),h+header+gap),'white');draw=ImageDraw.Draw(canvas);draw.text((gap,4),title+' [DERIVED EVIDENCE CROPS; originals retained]',fill='black',font=fonts)
 for i,(p,label,size) in enumerate(zip(panels,labels,sizes)):
  x=gap+i*(w+gap);draw.text((x,25),label,fill='black',font=fonts);canvas.paste(p.resize(size,Image.Resampling.LANCZOS),(x,header))
 canvas.save(file)
 return {'path':str(file),'sha256':digest(file),'dimensions':list(canvas.size),'derived':True,'sourceCrops':labels,'scale':scale}

def capture_rows(data):
 if data.get('status')!='PASS':raise ValueError('Capture result must actually be PASS')
 if data.get('counters',{}).get('tests')!=10 or data.get('counters',{}).get('screenshots')!=10:raise ValueError('Incomplete capture counters')
 rows={key(r['route'],r['width']):r for r in data['tests']};shots={key(r['route'],r['width']):r for r in data['screenshots']}
 expected={(route,width) for route in ['/','/services','/portfolio','/contact','/quotation'] for width in [375,1440]}
 if set(rows)!=expected or set(shots)!=expected:raise ValueError('Capture must contain exact five routes x two widths')
 if any(r['status']!='PASS' for r in rows.values()):raise ValueError('Capture has failed tests')
 return rows,shots

def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--baseline',required=True);p.add_argument('--final',required=True);p.add_argument('--baseline-site',required=True);p.add_argument('--final-site',required=True);p.add_argument('--gallery-result');p.add_argument('--out',required=True);args=p.parse_args()
 out=Path(args.out).resolve();out.mkdir(parents=True,exist_ok=False)
 result={'testId':'DC003-MODERN-VISUAL-COMPARISON','startedAt':datetime.now(timezone.utc).isoformat(),'status':'PENDING','tool':{'path':str(Path(__file__).resolve()),'sha256':digest(__file__)},'inputs':{'baseline':{'path':args.baseline,'sha256':digest(args.baseline)},'final':{'path':args.final,'sha256':digest(args.final)},'baselineSite':args.baseline_site,'finalSite':args.final_site},'method':{'actualDOM':'Captured main.innerHTML plus captured Header/Main/H1/section layout and computed font/color data. Header/Footer DOM is SSR HTML from named immutable artifacts, not falsely described as browser-captured markup.','pixel':'Strict decoded RGB pixel comparison, zero tolerance, at original1x dimensions. No crop/resize affects pixel assertions. Full-frame and Footer changes retained; the Header+main pre-Footer region is separately asserted identical.','authorizedDelta':'Only exact new Footer li: /design-collection, label 設計系列. Original Footer pixels all recorded; secondary SSR comparison removes only this li. A Footer DOM match is not a blanket visual approval.','ids':'No generated-ID removal, regex filter or inferred substitution. Any actual ID mismatch is retained and requires exact follow-up proof.','manual':'All derived crops are labelled; originals preserved. Actual viewing of10 pairs and Gallery2 remains PENDING.'},'cases':[],'sheets':[],'gallery':[],'manualReview':'PENDING_ROOT_VIEW_IMAGE'}
 try:
  before=json.loads(Path(args.baseline).read_text());after=json.loads(Path(args.final).read_text());br,bs=capture_rows(before);fr,fs=capture_rows(after)
  environment_keys=['viewportHeight','reducedMotion','timezone','deviceScaleFactor','browserVersion']
  result['environmentComparison']={k:{'baseline':before['environment'].get(k),'final':after['environment'].get(k),'equal':before['environment'].get(k)==after['environment'].get(k)} for k in environment_keys}
  if not all(v['equal'] for v in result['environmentComparison'].values()):raise ValueError('Baseline/final capture environments differ')
  for route,width in br:
   label=('home' if route=='/' else route.strip('/'))+'-'+str(width);case={'testId':'COMPARE-'+label,'route':route,'width':width,'status':'PENDING','expected':{'preFooterPixelsDifferent':0,'headerMainLayoutEqual':True,'mainDOMEquivalent':True,'headerSSRDOMEquivalent':True,'footerSSRDelta':'one exact Gallery li only'}};result['cases'].append(case)
   try:
    ba,fa=br[(route,width)]['actual'],fr[(route,width)]['actual'];bi,fi=Path(bs[(route,width)]['path']),Path(fs[(route,width)]['path'])
    for file,shot in [(bi,bs[(route,width)]),(fi,fs[(route,width)])]:
     if digest(file)!=shot['sha256']:raise ValueError('Screenshot hash differs from captured record: '+str(file))
    a=Image.open(bi).convert('RGB');b=Image.open(fi).convert('RGB');assert a.width==width and b.width==width
    case['images']={'baseline':{'path':str(bi),'sha256':digest(bi),'bytes':bi.stat().st_size,'dimensions':list(a.size)},'final':{'path':str(fi),'sha256':digest(fi),'bytes':fi.stat().st_size,'dimensions':list(b.size)}}
    fields=['viewport','scrollWidth','header','main','h1','sections'];case['layout']={k:{'equal':ba['layout'].get(k)==fa['layout'].get(k),'baseline':ba['layout'].get(k),'final':fa['layout'].get(k)} for k in fields};case['metadataEqual']=ba['metadata']==fa['metadata'] and ba['title']==fa['title'];case['mainDOM']=dom_compare(fragment(ba['modernMainHTML']),fragment(fa['modernMainHTML']),out/(label+'-main-dom.diff'));case['mainDOM']['baselineRawSha256']=hashlib.sha256(ba['modernMainHTML'].encode()).hexdigest();case['mainDOM']['finalRawSha256']=hashlib.sha256(fa['modernMainHTML'].encode()).hexdigest()
    source_a,ha,foa=ssr_dom(args.baseline_site,route);source_b,hb,fob=ssr_dom(args.final_site,route);case['SSRArtifact']={'baseline':source_a,'final':source_b};case['headerSSRDOM']=dom_compare(ha,hb,out/(label+'-header-dom.diff'));case['footerSSRDOMOriginal']=dom_compare(foa,fob,out/(label+'-footer-original-dom.diff'));case['authorizedFooterLI']=remove_only_approved_link(fob);case['footerSSRDOMAfterOnlyApprovedLI']=dom_compare(foa,fob,out/(label+'-footer-minus-gallery-dom.diff'))
    footer_a=ba['layout']['footer'];footer_b=fa['layout']['footer'];assert len(footer_a)==len(footer_b)==1;start_a=footer_a[0]['y'];start_b=footer_b[0]['y'];case['footerLayout']={'baseline':footer_a[0],'final':footer_b[0],'startEqual':start_a==start_b,'heightDelta':footer_b[0]['height']-footer_a[0]['height']}
    split=math.ceil(min(start_a,start_b));pre,pre_mask=image_difference(a.crop((0,0,width,split)),b.crop((0,0,width,split)));case['preFooterPixels']={'rowsComparedExclusiveEnd':split,'fractionalBoundaryRowIncluded':split!=min(start_a,start_b),**pre}
    total,mask=image_difference(a,b);case['allPixelDeltas']=total;case['footerTopAlignedPixels'],_=image_difference(crop_padded(a,start_a,a.height),crop_padded(b,start_b,b.height));difference=derived_diff(a,b,mask);diff_file=out/(label+'-full-delta.png');difference.save(diff_file);case['deltaImage']={'path':str(diff_file),'sha256':digest(diff_file),'dimensions':list(difference.size),'meaning':'Unchanged baseline lightened; every changed or dimension-only pixel red. No threshold or omitted Footer differences.'}
    top_bottom=min(1000,split);center=max(top_bottom,(split-900)//2);parts=[('top',0,top_bottom),('main',center,min(split,center+900)),('footer',min(math.floor(start_a),math.floor(start_b)),max(a.height,b.height))]
    for part,top,bottom in parts:result['sheets'].append(sheet([crop_padded(a,top,bottom),crop_padded(b,top,bottom),crop_padded(difference,top,bottom)],['baseline original crop','final original crop','strict delta (red)'],out/(label+'-'+part+'-sheet.png'),label+' '+part))
    hard=[]
    if not case['metadataEqual']:hard.append('metadata/title')
    if any(not v['equal'] for v in case['layout'].values()):hard.append('captured layout/styles')
    if not case['footerLayout']['startEqual']:hard.append('Footer start shifted')
    if pre['differentPixels']:hard.append('pre-Footer strict pixels')
    if not case['mainDOM']['equal']:hard.append('actual main DOM')
    if not case['headerSSRDOM']['equal']:hard.append('Header SSR DOM; no generated ID exclusion applied')
    if not case['footerSSRDOMAfterOnlyApprovedLI']['equal']:hard.append('Footer SSR changes exceed exact authorized li')
    case['unresolvedDifferences']=hard;case['status']='DIFFERENCES_RECORDED' if hard else 'AUTOMATED_EQUIVALENT_AUTHORIZED_FOOTER_MANUAL_PENDING'
   except Exception as exc:case['status']='FAIL';case['error']=repr(exc)
   write_json(out/'result.json',result)
  if args.gallery_result:
   gallery=json.loads(Path(args.gallery_result).read_text());result['inputs']['galleryResult']={'path':args.gallery_result,'sha256':digest(args.gallery_result)}
   for width in [375,1440]:
    candidates=[s for s in gallery.get('screenshots',[]) if (s.get('route') or '').rstrip('/')=='/design-collection' and s.get('width')==width]
    if len(candidates)!=1:raise ValueError(f'Gallery{width}: expected one actual screenshot')
    s=candidates[0];file=Path(s['path']);assert digest(file)==s['sha256'];im=Image.open(file).convert('RGB');result['gallery'].append({'width':width,'path':str(file),'sha256':digest(file),'dimensions':list(im.size),'comparison':'NEW_AUTHORIZED_GALLERY_INCREMENT_NO_BASELINE','manualReview':'PENDING'})
    result['sheets'].append(sheet([crop_padded(im,0,min(im.height,1200)),crop_padded(im,max(0,im.height-1200),im.height)],['Gallery top actual crop','Gallery bottom actual crop'],out/f'gallery-{width}-sheet.png',f'Gallery{width} new increment'))
  result['counters']={'expectedCases':10,'cases':len(result['cases']),'automatedEquivalent':sum(c['status']=='AUTOMATED_EQUIVALENT_AUTHORIZED_FOOTER_MANUAL_PENDING' for c in result['cases']),'unresolvedDifferenceCases':sum(c['status']=='DIFFERENCES_RECORDED' for c in result['cases']),'executionFailures':sum(c['status']=='FAIL' for c in result['cases']),'expectedGalleryImages':2 if args.gallery_result else 0,'galleryImages':len(result['gallery']),'derivedSheets':len(result['sheets'])}
  assert len(result['cases'])==10
  result['status']='FAIL' if result['counters']['executionFailures'] or result['counters']['unresolvedDifferenceCases'] else 'MANUAL_PENDING'
 except Exception as exc:result['status']='FAIL';result['fatal']=repr(exc)
 result['finishedAt']=datetime.now(timezone.utc).isoformat();write_json(out/'result.json',result)
 links='\n'.join(f'<li><a href="{Path(s["path"]).name}">{Path(s["path"]).name}</a></li>' for s in result['sheets']);(out/'index.html').write_text('<!doctype html><meta charset="utf-8"><title>DC003 derived comparison evidence</title><h1>Derived comparison crops</h1><p>Original screenshots are unchanged. Red marks every strict pixel difference, including Footer. Manual review is pending.</p><ul>'+links+'</ul>')
 print('DC003_VISUAL_COMPARE_COMPLETE',json.dumps({'status':result['status'],'counters':result.get('counters'),'result':str(out/'result.json'),'manualReview':'PENDING_ROOT_VIEW_IMAGE'},ensure_ascii=False))
 return 1 if result['status']=='FAIL' else 2
if __name__=='__main__':sys.exit(main())
