from pathlib import Path
import sys,json,hashlib
from datetime import datetime,timezone
sys.path.insert(0,'/tmp/xk-estimator-tools')
import fitz
pdf=Path(sys.argv[1]);out=Path(sys.argv[2]);out.mkdir(exist_ok=False)
def serial(v):
 if isinstance(v,dict):return{k:serial(x) for k,x in v.items()}
 if isinstance(v,(list,tuple)):return[serial(x) for x in v]
 if isinstance(v,(fitz.Rect,fitz.Point,fitz.Matrix)):return list(v)
 return v

doc=fitz.open(pdf);p=doc[0];drawings=p.get_drawings(extended=True);bboxlog=p.get_bboxlog(layers=True);raw=b'\n'.join(doc.xref_stream(i) for i in p.get_contents());prefix=raw[:raw.index(b'.1451 .3882 .9216 RG')];(out/'content-background-prefix.txt').write_bytes(prefix)
outside=[x for x in drawings if x.get('rect') and(x['rect'].x0<-.1 or x['rect'].y0<-.1 or x['rect'].x1>p.rect.width+.1 or x['rect'].y1>p.rect.height+.1)]
paint_out=[{'seqno':i,'type':t,'bbox':list(r)} for i,(t,r,layer) in enumerate(bboxlog) if t!='ignore-text' and(r[0]<-.1 or r[1]<-.1 or r[2]>p.rect.width+.1 or r[3]>p.rect.height+.1)]
result={'testId':'DC003-PDF-CANVAS-READONLY-DIAGNOSIS','status':'OBSERVED_NOT_ACCEPTANCE_RERUN','observedAt':datetime.now(timezone.utc).isoformat(),'source':{'path':str(pdf),'sha256':hashlib.sha256(pdf.read_bytes()).hexdigest()},'pageCount':len(doc),'mediaBox':list(p.mediabox),'cropBox':list(p.cropbox),'bleedBox':list(p.bleedbox),'pageRect':list(p.rect),'rotation':p.rotation,'pageXref':doc.xref_object(p.xref),'contentXrefs':p.get_contents(),'contentSha256':hashlib.sha256(raw).hexdigest(),'exactContentPrefix':prefix.decode('ascii'),'extendedGraphicsFirst9':serial(drawings[:9]),'originalOutOfBoundsVectors':serial(outside),'allOutOfBoundsActualPaint':paint_out,'bboxLogFirst8':serial(bboxlog[:8]),'opaqueBackgroundState':{'xref':3,'rawObject':doc.xref_object(3),'ca':doc.xref_get_key(3,'ca'),'BM':doc.xref_get_key(3,'BM'),'SMask':doc.xref_get_key(3,'SMask')},'interpretation':'Only the first3 opaque white fill-only axis-aligned origin rectangles exceed MediaBox. They precede every non-white path, text, logo and QR. Prefix confirms printer scale .23999999 times3.125 (~0.75pt per CSSpx) and integer CSS rectangles794x1123/794x1119. CropBox/MediaBox impose page canvas clipping; subsequent two backgrounds additionally have the recorded page-origin clip. This is not content acceptance: original strict failure remains; verifier v2 must classify only this exact observed signature, retain spill properties, and keep all other paint/text/content strict at original0.1pt.'}
(out/'diagnostic.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'status':result['status'],'outOfBoundsVectorCount':len(outside),'outOfBoundsPaintSequenceNumbers':[x['seqno'] for x in paint_out],'diagnostic':str(out/'diagnostic.json')}))
