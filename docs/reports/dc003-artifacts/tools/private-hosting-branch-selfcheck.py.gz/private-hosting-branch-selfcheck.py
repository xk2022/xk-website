import ast
import importlib.util
from pathlib import Path
from types import SimpleNamespace

root = Path('/workspace/xk-website')
source = root / 'scripts/smoke-website.py'
tree = ast.parse(source.read_text())
spec = importlib.util.spec_from_file_location('smoke_website', source)
smoke = importlib.util.module_from_spec(spec)
spec.loader.exec_module(smoke)
run = next(node for node in ast.walk(tree) if isinstance(node, ast.FunctionDef) and node.name == 'run')
negative_loop = next(node for node in run.body if isinstance(node, ast.For) and isinstance(node.iter, ast.Name) and node.iter.id == 'negative')
html_branch = next(node for node in negative_loop.body if isinstance(node, ast.If))
branch = compile(ast.Module(body=[html_branch], type_ignores=[]), str(source), 'exec')
empty_shell = '<html id="__next_error__"><head></head><body></body></html>'
frame = '<html><head></head><body><a href="#main-content">Skip</a><header></header><main id="main-content"><h1>Not found</h1></main><footer></footer></body></html>'

def check(path, html, valid, expected_na):
    suite = smoke.Smoke(SimpleNamespace(base_url='http://127.0.0.1:9/', timeout=1, check_external=False, check_source_assets=False, output='/tmp/xk-dc003/not-used.json'))
    suite.data = {'privacyDraftMarker': '草案，尚未核准生效', 'privacyPolicy': {'sections': [{'paragraphs': ['PRIVATE_POLICY_PARAGRAPH']}]}}
    response = {'status': 404, 'headers': {'content-type': 'text/html'}, 'body': html.encode()}
    exec(branch, smoke.__dict__, {'self': suite, 'path': path, 'response': response})
    failures = [item for item in suite.results if item['status'] == 'FAIL']
    assert (not failures) == valid, (path, failures, html[:120])
    assert len([item for item in suite.results if item['status'] == 'N/A']) == expected_na
    assert len(suite.gated_404_observations) == expected_na
    return suite

for path, file in [('/privacy', 'privacy-404.html'), ('/dev/design-system', 'dev-design-system-404.html')]:
    check(path, Path('/tmp/xk-dc003', file).read_text(), True, 1)
    check(path, empty_shell, True, 1)
    check(path, frame, True, 0)
    check(path, (root / 'out/404.html').read_text(), True, 0)
    check(path, '<html><head></head><body></body></html>', False, 0)
    check(path, frame.replace('<header></header>', ''), False, 0)
    check(path, frame.replace('</body>', '<header></header></body>'), False, 0)
    check(path, empty_shell.replace('</body>', '<header></header></body>'), False, 1)
    for payload in ['PRIVATE_POLICY_PARAGRAPH', '草案，尚未核准生效', *smoke.PRIVATE_DESIGN_SYSTEM_MARKERS]:
        check(path, frame.replace('</body>', '<script>' + payload + '</script></body>'), False, 0)
        check(path, empty_shell.replace('</body>', '<script>' + payload + '</script></body>'), False, 1)
for path in ['/unknown-smoke-route', '/privacy/child', '/dev/design-system/child', '/design-collection/modern', '/design-collection/heritage']:
    check(path, empty_shell, False, 0)
    check(path, frame, True, 0)
print('PASS: actual smoke branch accepts normal private Next shells (0 landmarks/N/A) and Pages private custom 404s (1 complete SSR frame/no N/A); missing/duplicate frames, serialized private payload and unknown-route shell exceptions fail. Both saved normal responses and actual Pages out/404.html tested read-only; no HTTP.')
