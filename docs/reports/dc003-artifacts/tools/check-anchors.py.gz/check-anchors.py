import argparse,json,subprocess,pathlib,urllib.request,collections
from html.parser import HTMLParser
p=argparse.ArgumentParser();p.add_argument('--base',required=True);p.add_argument('--output',required=True);a=p.parse_args()
code="import {designCollectionRegistry as registry} from './src/config/design-collection.ts';import {getPublishedDesignRoutes} from './src/lib/design-collection/routes.ts';process.stdout.write(JSON.stringify({registry,routes:getPublishedDesignRoutes()}))"
d=json.loads(subprocess.check_output(['node','--import','./scripts/register-test-aliases.mjs','--input-type=module','-e',code],text=True));f=json.loads(pathlib.Path('scripts/fixtures/design-collection-contract.json').read_text());assert sorted(r['presentationPath'] for r in d['routes'])==sorted(f['publishedPaths']) and len(d['routes'])==17
class IDs(HTMLParser):
 def __init__(self):super().__init__();self.ids=collections.Counter()
 def handle_starttag(self,t,attrs):
  for n,v in attrs:
   if n=='id':self.ids[v]+=1
rows=[]
for r in d['routes']:
 path=r['presentationPath'];url=a.base.rstrip('/')+path+('/' if path!='/' else '');anchors=d['registry']['collectionAnchors'] if r['pageKey']=='collection' else d['registry']['anchors'][r['styleId']][r['pageKey']]
 with urllib.request.urlopen(url,timeout=30) as response:status=response.status;html=response.read().decode()
 q=IDs();q.feed(html);bad={k:q.ids[k] for k in anchors if q.ids[k]!=1};rows.append({'testId':'ANCHOR-'+path,'url':url,'status':'PASS' if status==200 and not bad else 'FAIL','expected':{'httpStatus':200,'declaredIDsExactlyOnce':anchors},'actual':{'httpStatus':status,'counts':{k:q.ids[k] for k in anchors},'bad':bad}})
r={'status':'PASS' if len(rows)==17 and all(x['status']=='PASS' for x in rows) else 'FAIL','routes':17,'declaredAnchors':sum(len(x['expected']['declaredIDsExactlyOnce']) for x in rows),'results':rows};o=pathlib.Path(a.output);assert not o.exists();o.write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({k:v for k,v in r.items() if k!='results'}));raise SystemExit(0 if r['status']=='PASS' else 1)
