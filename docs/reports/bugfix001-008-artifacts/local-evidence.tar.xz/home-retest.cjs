'use strict';
// LOCAL production/static acceptance only. Root owns all builds, servers, and outer receipts.
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const { spawnSync } = require('node:child_process');
const { chromium, request } = require('/tmp/xk-browser-check/node_modules/playwright-core');
const { AxeBuilder } = require('/tmp/xk-browser-check/node_modules/@axe-core/playwright');
const { NetworkMonitor } = require('./network.cjs');
const { assertChanges } = require('./changed-content.cjs');
const { inspectLayout, inspectFocused, inspectSemantics, inspectContrastStyles } = require('./a11y-observations.cjs');
const ROOT = '/workspace/xk-website', TASK = '/tmp/xk-bugfix001-008';
const options = Object.fromEntries(process.argv.slice(2).map(arg => {
  const index = arg.indexOf('=');
  assert.ok(arg.startsWith('--') && index > 2, 'Use --name=value');
  return [arg.slice(2, index), arg.slice(index + 1)];
}));
assert.ok(['normal', 'pages'].includes(options.mode), 'Required --mode=normal|pages');
assert.match(options['expected-fingerprint'] || '', /^[a-f0-9]{64}$/, 'Required --expected-fingerprint=<frozen source fingerprint>');
const mode = options.mode;
const base = new URL(mode === 'normal' ? 'http://127.0.0.1:3110/' : 'http://127.0.0.1:3111/xk-website/');
const runName = options.run || 'local-' + new Date().toISOString().replace(/[:.]/g, '-');
assert.match(runName, /^[a-zA-Z0-9][a-zA-Z0-9._-]*$/);
const runDir = path.join(TASK, mode, runName);
fs.mkdirSync(path.dirname(runDir), { recursive: true });
fs.mkdirSync(runDir); // Never overwrite a failed run or raw network receipt.
const sha = value => crypto.createHash('sha256').update(value).digest('hex');
const saveJson = (name, data) => { const file = path.join(runDir, name); fs.mkdirSync(path.dirname(file), { recursive: true }); fs.writeFileSync(file, JSON.stringify(data, null, 2) + '\n'); return file; };
const result = {
  task: 'Bugfix001–008 role-only focused Home retest; unchanged-route baseline retained by explicit diff bridge', mode, base: base.href, runDir,
  status: 'PENDING', automatedStatus: 'PENDING', manualReviewStatus: 'PENDING', actualProcessExitCode: null,
  startedAt: new Date().toISOString(), tests: [], responsive: [], axe: [], metadata: [], http: [], storage: [], links: [], screenshots: [], manualReview: [],
  expectedCounts: { publicRoutes: 9, responsive: mode === 'normal' ? 2 : 5, axe: mode === 'pages' ? 3 : 0, keyboardJourneys: 2, mobileJourneys: 1, reducedMotion: 1, screenshots: mode === 'pages' ? 5 : 0, storageContexts: mode === 'normal' ? 2 : 5, changeAssertions: mode === 'normal' ? 2 : 5 },
  notes: ['All URLs and screenshots are LOCAL, not Vercel Preview/Production.', 'Each assertion belongs to this shared process; actual process exit is supplied by the root outer runner, never inferred from collector completion.', 'Layout candidates, axe incomplete, headings/names/contrast and screenshot inspection require explicit human decisions. Automated completion never marks those manual items PASS.', 'No full WCAG55, real AT, real browser zoom, performance or field CWV claim. No deployment/hosting logging absence claim.'],
};
let browser, api, monitor, specs, expectations, contract;
result.changeAssertions = [];
const linkInventory = new Map(), idInventory = new Map(), htmlCache = new Map();
const contexts = new Set();
function save() { saveJson('results.json', result); }
for (const file of ['home-retest.cjs', 'network.cjs', 'a11y-observations.cjs', 'export-metadata.mjs', 'acceptance-plan.json', 'changed-content.cjs']) {
  const bytes = fs.readFileSync(path.join(TASK, file));
  fs.writeFileSync(path.join(runDir, file), bytes);
  (result.toolSources ||= []).push({ source: path.join(TASK, file), snapshot: path.join(runDir, file), sha256: sha(bytes) });
}
async function test(id, procedure, fn) {
  assert.ok(!result.tests.some(row => row.testId === id), 'Unique subtest ID');
  const row = { testId: id, procedure, status: 'PENDING', exitCode: null, startedAt: new Date().toISOString() };
  result.tests.push(row); result.activeTest = id; save();
  try { row.actual = await fn(); row.status = 'PASS'; }
  catch (error) { row.status = 'FAIL'; row.error = { message: error.message, stack: error.stack }; }
  row.finishedAt = new Date().toISOString(); result.activeTest = null; save();
  console.log(row.status + ' ' + id);
  return row;
}
function checkSource(phase) {
  const file = options.source || path.join(TASK, 'source.json');
  const bytes = fs.readFileSync(file), source = JSON.parse(bytes);
  assert.equal(source.fingerprint, options['expected-fingerprint'], 'Explicit frozen fingerprint');
  const ordered = Object.fromEntries(Object.entries(source.files).sort(([a], [b]) => a < b ? -1 : a > b ? 1 : 0));
  assert.equal(sha(Buffer.from(JSON.stringify(ordered))), source.fingerprint, 'Canonical sorted source map fingerprint');
  const checks = Object.entries(source.files).map(([relative, expected]) => {
    const absolute = path.resolve(ROOT, relative); assert.ok(absolute.startsWith(ROOT + path.sep), 'Source stays inside root');
    const actual = fs.existsSync(absolute) ? sha(fs.readFileSync(absolute)) : null;
    return { file: relative, expected, actual, equal: expected === actual };
  });
  saveJson('source-' + phase + '.json', { manifest: file, manifestSha256: sha(bytes), fingerprint: source.fingerprint, checks });
  assert.ok(checks.length > 0 && checks.every(row => row.equal), 'Every frozen source file byte hash: ' + phase);
  result.sourceFingerprint = source.fingerprint;
  if (phase === 'before') fs.writeFileSync(path.join(runDir, 'source.json'), bytes);
  else { assert.equal(sha(bytes), sha(fs.readFileSync(path.join(runDir, 'source.json'))), 'Manifest itself unchanged'); const contractFile = options.contract || path.join(TASK, 'contract.json'); if (fs.existsSync(path.join(runDir, 'contract.json'))) assert.equal(sha(fs.readFileSync(contractFile)), sha(fs.readFileSync(path.join(runDir, 'contract.json'))), 'Root-reviewed contract bytes unchanged'); }
  return { fingerprint: source.fingerprint, filesChecked: checks.length };
}
function urlFor(route) {
  const suffix = route === '/' ? '' : route.slice(1) + (mode === 'pages' && !path.posix.extname(route) ? '/' : '');
  return new URL(suffix, base).href;
}
function routeKey(value) {
  const url = new URL(value, base);
  assert.equal(url.origin, base.origin, 'Same local origin');
  if (mode === 'pages') {
    assert.ok(url.pathname === '/xk-website' || url.pathname.startsWith(base.pathname), 'Exact Pages base path: ' + url.href);
    const suffix = url.pathname.slice('/xk-website'.length).replace(/\/$/, '');
    return suffix || '/';
  }
  assert.ok(!url.pathname.startsWith('/xk-website'), 'Normal mode must not carry Pages prefix');
  return url.pathname.replace(/\/$/, '') || '/';
}
async function http(url, expectedStatus, name) {
  const response = await api.get(url, { timeout: 20000, maxRedirects: 5 });
  const body = await response.body();
  const stem = name || sha(Buffer.from(url)).slice(0, 16);
  const bodyFile = path.join(runDir, 'http', stem + '.body'); fs.mkdirSync(path.dirname(bodyFile), { recursive: true }); fs.writeFileSync(bodyFile, body);
  const row = { url, finalUrl: response.url(), status: response.status(), headers: response.headers(), body: bodyFile, bytes: body.length, sha256: sha(body) };
  saveJson('http/' + stem + '.json', row); result.http.push(row);
  assert.equal(response.status(), expectedStatus, url);
  return { ...row, text: body.toString('utf8') };
}
async function go(page, spec) {
  if (page.url().startsWith(base.origin)) await monitor.drain(page);
  const response = await page.goto(urlFor(spec.path), { waitUntil: 'networkidle' });
  assert.equal(response.status(), 200, 'Browser route200 ' + spec.path);
  assert.equal(routeKey(page.url()), spec.path);
  await monitor.drain(page);
  return response;
}
async function installStorage(page, record) {
  await page.exposeBinding('__xk13Before', (_, row) => record.documentsBefore.push(row));
  await page.exposeBinding('__xk13StorageEvent', (_, row) => record.events.push(row));
  await page.addInitScript(() => {
    if (!/^https?:$/.test(location.protocol)) return;
    const before = { documentId: crypto.randomUUID(), url: location.href, phase: 'Document initialization before application scripts', localStorageKeys: Object.keys(localStorage), sessionStorageKeys: Object.keys(sessionStorage), cookiePresent: document.cookie.length > 0 };
    Object.defineProperty(window, '__xk13BeforeSnapshot', { value: before });
    void window.__xk13Before(before).catch(() => {});
    const report = row => { void window.__xk13StorageEvent({ ...row, at: Date.now(), url: location.href }).catch(() => {}); };
    for (const name of ['setItem', 'removeItem', 'clear']) {
      const original = Storage.prototype[name];
      Storage.prototype[name] = function (...args) { report({ operation: name, store: this === localStorage ? 'localStorage' : 'sessionStorage', keyLength: String(args[0] || '').length }); return original.apply(this, args); };
    }
    const descriptor = Object.getOwnPropertyDescriptor(Document.prototype, 'cookie');
    if (descriptor?.get && descriptor?.set) Object.defineProperty(Document.prototype, 'cookie', { configurable: descriptor.configurable, enumerable: descriptor.enumerable, get: descriptor.get, set(value) { report({ operation: 'cookie.set', length: String(value).length }); return descriptor.set.call(this, value); } });
    if (window.indexedDB) { const original = indexedDB.open; indexedDB.open = function (...args) { report({ operation: 'indexedDB.open', nameLength: String(args[0] || '').length }); return original.apply(this, args); }; }
  });
}
async function storageAfter(page, context) {
  const browserState = await context.storageState({ indexedDB: true });
  const documentState = await page.evaluate(async () => ({ url: location.href, localStorageKeys: Object.keys(localStorage), sessionStorageKeys: Object.keys(sessionStorage), indexedDB: typeof indexedDB.databases === 'function' ? await indexedDB.databases() : null }));
  return { ...documentState, cookies: browserState.cookies.map(c => ({ name: c.name, domain: c.domain, path: c.path, valueLength: c.value.length })), origins: browserState.origins.map(o => ({ origin: o.origin, localStorageKeys: o.localStorage.map(item => item.name), indexedDbNames: (o.indexedDB || []).map(item => item.name) })) };
}
async function withPage(width, spec, fn) {
  const context = await browser.newContext({ viewport: { width, height: 1000 } }); contexts.add(context);
  const record = { route: spec.path, width, before: await context.storageState({ indexedDB: true }), documentsBefore: [], events: [], after: null, status: 'PENDING' };
  result.storage.push(record);
  let page, actionError, cleanupError, answer;
  try {
    assert.deepEqual(record.before, { cookies: [], origins: [] }, 'Actual fresh context before first navigation');
    page = await context.newPage(); page.setDefaultTimeout(12000); page.setDefaultNavigationTimeout(20000);
    await installStorage(page, record); await monitor.watch(page);
    answer = await fn(page);
  } catch (error) { actionError = error; }
  finally {
    try {
      if (page && !page.isClosed() && page.url().startsWith(base.origin)) {
        await monitor.drain(page);
        const actualBefore = await page.evaluate(() => window.__xk13BeforeSnapshot);
        assert.ok(actualBefore, 'Actual initialized document-before snapshot exists');
        if (!record.documentsBefore.some(row => row.documentId === actualBefore.documentId)) record.documentsBefore.push(actualBefore);
        record.after = await storageAfter(page, context);
        assert.ok(record.documentsBefore.length > 0);
        for (const before of record.documentsBefore) { assert.deepEqual(before.localStorageKeys, []); assert.deepEqual(before.sessionStorageKeys, []); assert.equal(before.cookiePresent, false); }
        assert.deepEqual(record.after.cookies, []); assert.deepEqual(record.after.localStorageKeys, []); assert.deepEqual(record.after.sessionStorageKeys, []);
        assert.ok(Array.isArray(record.after.indexedDB), 'Browser indexedDB.databases required for actual inventory'); assert.deepEqual(record.after.indexedDB, []);
        for (const origin of record.after.origins) { assert.deepEqual(origin.localStorageKeys, []); assert.deepEqual(origin.indexedDbNames, []); }
        assert.deepEqual(record.events, []); record.status = 'PASS';
      } else throw new Error('Context did not finish on an observable application document');
    } catch (error) { cleanupError = error; record.status = 'FAIL'; record.error = error.message; }
    try { await context.close(); } catch (error) { cleanupError ||= error; }
    contexts.delete(context); save();
  }
  if (actionError) throw actionError;
  if (cleanupError) throw cleanupError;
  return answer;
}
async function inventory(page, spec) {
  const data = await page.evaluate(() => ({ links: [...document.querySelectorAll('a[href]')].map(a => ({ source: location.href, href: a.getAttribute('href'), resolved: a.href, text: a.textContent.trim() })), ids: [...document.querySelectorAll('[id]')].map(node => node.id) }));
  assert.equal(new Set(data.ids).size, data.ids.length, 'Unique DOM IDs');
  idInventory.set(spec.path, new Set(data.ids));
  for (const row of data.links) linkInventory.set(spec.path + '\n' + row.href, row);
  return data.links.length;
}
async function metadata(page, spec) {
  const observed = await page.evaluate(() => {
    const one = selector => { const nodes = [...document.querySelectorAll(selector)]; return { count: nodes.length, value: nodes[0]?.getAttribute('content') || nodes[0]?.getAttribute('href') || null }; };
    return { title: document.title, titleCount: document.querySelectorAll('head > title').length, description: one('meta[name="description"]'), canonical: one('link[rel="canonical"]'), robots: one('meta[name="robots"]'), ogTitle: one('meta[property="og:title"]'), ogDescription: one('meta[property="og:description"]'), ogUrl: one('meta[property="og:url"]'), ogLocale: one('meta[property="og:locale"]'), ogType: one('meta[property="og:type"]'), ogSiteName: one('meta[property="og:site_name"]'), twitterTitle: one('meta[name="twitter:title"]'), twitterDescription: one('meta[name="twitter:description"]'), twitterCard: one('meta[name="twitter:card"]'), language: document.documentElement.lang, schemas: [...document.querySelectorAll('script[type="application/ld+json"]')].map(node => node.textContent), unapprovedMeta: [...document.querySelectorAll('meta[property^="og:image"],meta[name^="twitter:image"],meta[name="twitter:site"],meta[name="twitter:creator"],meta[name="google-site-verification"]')].map(node => node.outerHTML) };
  });
  assert.equal(observed.title, spec.title); assert.equal(observed.titleCount, 1);
  for (const key of ['description', 'canonical', 'robots', 'ogTitle', 'ogDescription', 'ogUrl', 'ogLocale', 'ogType', 'ogSiteName', 'twitterTitle', 'twitterDescription', 'twitterCard']) assert.equal(observed[key].count, 1, key + ' unique');
  for (const key of ['description', 'ogDescription', 'twitterDescription']) assert.equal(observed[key].value, spec.description);
  for (const key of ['ogTitle', 'twitterTitle']) assert.equal(observed[key].value, spec.title);
  const brandPath = mode === 'pages' && spec.path !== '/' ? spec.path + '/' : spec.path;
  const brandUrl = spec.path === "/" && mode === "normal" ? new URL(expectations.siteConfig.url).origin : new URL(brandPath, expectations.siteConfig.url).href;
  assert.equal(observed.canonical.value, brandUrl); assert.equal(observed.ogUrl.value, brandUrl);
  assert.equal(observed.ogLocale.value, 'zh_TW'); assert.equal(observed.ogType.value, 'website'); assert.equal(observed.ogSiteName.value, expectations.siteConfig.name); assert.equal(observed.language, 'zh-TW'); assert.equal(observed.twitterCard.value, 'summary');
  assert.deepEqual(observed.robots.value.split(',').map(s => s.trim()).sort(), ['nofollow', 'noindex']);
  assert.deepEqual(observed.unapprovedMeta, []); assert.equal(observed.schemas.length, 1); assert.ok(!observed.schemas[0].includes('<'));
  assert.deepEqual(JSON.parse(observed.schemas[0]), { '@context': 'https://schema.org', '@type': 'WebSite', name: expectations.siteConfig.name, url: new URL('/', expectations.siteConfig.url).href, inLanguage: 'zh-TW' });
  const headFile = path.join(runDir, 'metadata', keyFor(spec.path) + '.head.html'); fs.mkdirSync(path.dirname(headFile), { recursive: true }); fs.writeFileSync(headFile, await page.locator('head').innerHTML());
  result.metadata.push({ route: spec.path, expected: spec, observed, headFile });
  return observed;
}
function keyFor(route) { return route === '/' ? 'home' : route.slice(1).replaceAll('/', '--'); }
async function axe(page, spec, width, state) {
  const raw = await new AxeBuilder({ page }).withTags(['wcag2a', 'wcag2aa', 'wcag21a', 'wcag21aa']).analyze();
  const rawFile = saveJson('axe/' + keyFor(spec.path) + '-' + width + '-' + state + '.json', raw);
  const row = { route: spec.path, width, state, violations: raw.violations.length, incomplete: raw.incomplete.map(rule => ({ id: rule.id, nodes: rule.nodes.length })), rawFile };
  result.axe.push(row);
  if (row.incomplete.length) result.manualReview.push({ kind: 'axe-incomplete', ...row, status: 'PENDING', reason: 'Each raw incomplete rule/node needs an explicit decision, not an automatic PASS.' });
  assert.deepEqual(raw.violations, [], 'Actual axe violations must be zero'); return row;
}
async function keyboard(page, spec, width) {
  await page.keyboard.press('Tab');
  const skip = await inspectFocused(page); saveJson('focus/' + keyFor(spec.path) + '-' + width + '-skip.json', skip);
  assert.equal(await page.locator(':focus').getAttribute('href'), '#main-content'); assert.ok(skip.rendered && !skip.outsideViewport); assert.notEqual(skip.fullyObscured, true);
  await page.keyboard.press('Enter'); assert.equal(await page.evaluate(() => document.activeElement.id), 'main-content');
  const firstMain = page.locator('main a[href]').first(); await firstMain.focus(); await page.keyboard.press('Tab'); await page.keyboard.press('Shift+Tab');
  const focus = await inspectFocused(page); assert.ok(focus.rendered && !focus.outsideViewport); assert.notEqual(focus.fullyObscured, true); assert.ok(focus.focusVisible);
  saveJson('focus/' + keyFor(spec.path) + '-' + width + '-main.json', focus);
  const footer = page.locator('footer a').first(); await footer.focus();
  const footerFocus = await inspectFocused(page); assert.ok(footerFocus.rendered && !footerFocus.outsideViewport); assert.notEqual(footerFocus.fullyObscured, true);
  saveJson('focus/' + keyFor(spec.path) + '-' + width + '-footer.json', footerFocus);
  result.manualReview.push({ kind: 'focus-visible-rendered-review', route: spec.path, width, status: 'PENDING', evidence: ['focus/' + keyFor(spec.path) + '-' + width + '-skip.json', 'focus/' + keyFor(spec.path) + '-' + width + '-main.json'], reason: 'Inspect actual focus styling/contrast; geometry and focus-visible state alone do not certify appearance.' });
  (result.keyboard ||= []).push({ route: spec.path, width, skipToMain: true, realTabShiftTab: true, footerReachable: true });
}
async function mobile(page, spec) {
  const trigger = page.locator('header button[aria-controls][aria-expanded]');
  await trigger.focus(); await page.keyboard.press('Space'); await monitor.drain(page);
  const menu = page.getByRole('navigation', { name: '手機導覽', exact: true }); assert.ok(await menu.isVisible());
  if (mode === 'pages') await test('BF-L07-axe-' + keyFor(spec.path) + '-375-expanded', 'axe actual expanded mobile disclosure', () => axe(page, spec, 375, 'expanded'));
  await page.keyboard.press('Escape'); assert.equal(await trigger.getAttribute('aria-expanded'), 'false'); assert.ok(await trigger.evaluate(node => node === document.activeElement));
  await page.keyboard.press('Space'); await page.keyboard.press('Tab'); assert.equal(await trigger.getAttribute('aria-expanded'), 'true');
  await page.keyboard.press('Shift+Tab'); assert.ok(await trigger.evaluate(node => node === document.activeElement)); assert.equal(await trigger.getAttribute('aria-expanded'), 'true');
  const linkCount = await menu.locator('a').count(), sequence = [];
  for (let index = 0; index < linkCount; index++) { await page.keyboard.press('Tab'); sequence.push(await inspectFocused(page)); assert.equal(await trigger.getAttribute('aria-expanded'), 'true'); }
  await page.keyboard.press('Tab'); await monitor.drain(page);
  const after = await inspectFocused(page); assert.equal(await trigger.getAttribute('aria-expanded'), 'false');
  assert.ok(await page.evaluate(() => !!document.activeElement.closest('main')), 'Native focus remains in main on leave, not forced to trigger'); assert.notEqual(after.fullyObscured, true); assert.ok(!after.outsideViewport);
  await trigger.focus(); await page.keyboard.press('Space');
  const outsidePointer = await trigger.evaluate(button => {
    const panel = document.getElementById(button.getAttribute('aria-controls'));
    const r = panel.getBoundingClientRect(), wrapper = button.parentElement;
    const ys = [r.bottom + 12, innerHeight - 2, Math.max(2, r.top - 12)];
    const xs = [2, 16, innerWidth - 2, innerWidth / 2];
    for (const y of ys) for (const x of xs) {
      if (x < 0 || y < 0 || x >= innerWidth || y >= innerHeight) continue;
      if (!(x < r.left || x > r.right || y < r.top || y > r.bottom)) continue;
      const hit = document.elementFromPoint(x, y);
      if (hit && !wrapper.contains(hit) && !hit.closest('a,button,input,textarea,select,[role=button]')) return { x, y, panel: { left: r.left, top: r.top, right: r.right, bottom: r.bottom }, hit: { tag: hit.tagName, id: hit.id, className: hit.getAttribute('class') }, viewport: { width: innerWidth, height: innerHeight } };
    }
    return null;
  });
  assert.ok(outsidePointer, 'Observed safe viewport point outside actual panel and disclosure wrapper');
  await page.mouse.click(outsidePointer.x, outsidePointer.y);
  assert.equal(await trigger.getAttribute('aria-expanded'), 'false');
  await trigger.focus(); await page.keyboard.press('Space');
  const destination = spec.path === '/' ? '/about' : '/';
  const routeLink = menu.locator('a').filter({ hasText: destination === '/' ? /^首頁$/ : /^關於 XK$/ }); assert.equal(await routeLink.count(), 1);
  await routeLink.click(); await page.waitForURL(url => routeKey(url.href) === destination); await monitor.drain(page); assert.equal(await trigger.getAttribute('aria-expanded'), 'false');
  await go(page, spec);
  saveJson('focus/' + keyFor(spec.path) + '-mobile-journey.json', { route: spec.path, linkCount, sequence, after, outsidePointer, destination, escapeReturnsTrigger: true, internalTabKeepsOpen: true, focusLeaveClosesWithoutReturn: true, outsidePointerCloses: true, routeClickCloses: true });
  (result.mobile ||= []).push({ route: spec.path, destination, escape: true, focusLeave: true, outsidePointer: true, routeClick: true });
  if (spec.path === '/') {
    const before = await page.evaluate(() => ({ url: location.href, scrollY, targetTop: document.getElementById('services').getBoundingClientRect().top }));
    const serviceLink = page.getByRole('link', { name: '探索我們的服務', exact: true });
    assert.equal(await serviceLink.count(), 1);
    await serviceLink.click();
    await page.waitForFunction(() => {
      const target = document.getElementById('services'), r = target?.getBoundingClientRect();
      return location.hash === '#services' && scrollY > 0 && r && r.top >= -1 && r.top < innerHeight && r.bottom > 0;
    }, undefined, { timeout: 8000 });
    const after = await page.evaluate(() => { const r = document.getElementById('services').getBoundingClientRect(); return { url: location.href, scrollY, target: { top: r.top, bottom: r.bottom, height: r.height }, viewport: { width: innerWidth, height: innerHeight } }; });
    assert.equal(routeKey(after.url), '/');
    result.serviceAnchor = { procedure: 'Real homepage service link click; bounded8s hash/scroll/viewport condition', before, after, status: 'PASS' };
    saveJson('home-service-anchor.json', result.serviceAnchor);
    await go(page, spec);
  }
}
async function reduced(page, spec) {
  await page.emulateMedia({ reducedMotion: 'reduce' }); await go(page, spec);
  const data = await page.evaluate(() => ({ matches: matchMedia('(prefers-reduced-motion: reduce)').matches, scroll: getComputedStyle(document.documentElement).scrollBehavior, offenders: [...document.querySelectorAll('*')].filter(node => { const style = getComputedStyle(node); return style.transitionDuration.split(',').some(v => parseFloat(v) > 0.01) || style.animationDuration.split(',').some(v => parseFloat(v) > 0.01); }).map(node => ({ tag: node.tagName, className: node.getAttribute('class') })) }));
  saveJson('motion/' + keyFor(spec.path) + '.json', data); assert.ok(data.matches); assert.equal(data.scroll, 'auto'); assert.deepEqual(data.offenders, []);
  (result.reducedMotion ||= []).push({ route: spec.path, ...data });
}
async function screenshot(page, spec, width) {
  const file = path.join(runDir, 'screenshots', 'LOCAL-' + mode + '-' + keyFor(spec.path) + '-' + width + '.png'); fs.mkdirSync(path.dirname(file), { recursive: true });
  await page.screenshot({ path: file, fullPage: true, animations: 'disabled' }); const bytes = fs.readFileSync(file);
  const row = { file, environment: 'LOCAL ' + mode + ', not Vercel', url: page.url(), sourceFingerprint: result.sourceFingerprint, viewport: page.viewportSize(), pngWidth: bytes.readUInt32BE(16), pngHeight: bytes.readUInt32BE(20), sha256: sha(bytes), manualInspection: 'PENDING' };
  result.screenshots.push(row); result.manualReview.push({ kind: 'screenshot', ...row, status: 'PENDING' });
}
async function changedContent(page, spec, width) {
  const row = await assertChanges({ page, route: spec.path, width, contract, urlFor, routeKey, go: () => go(page, spec), monitor });
  result.changeAssertions.push(row); return row;
}
async function browserCase(spec, width) {
  return withPage(width, spec, async page => {
    await go(page, spec); const layout = await inspectLayout(page);
    const layoutFile = saveJson('layout/' + keyFor(spec.path) + '-' + width + '.json', layout);
    const row = { route: spec.path, width, url: page.url(), layoutFile, candidateCount: layout.candidates.length, manualCandidateStatus: layout.candidates.length ? 'PENDING' : 'No candidates collected; not a visual certification' };
    result.responsive.push(row);
    if (layout.candidates.length) result.manualReview.push({ kind: 'layout-candidates', route: spec.path, width, status: 'PENDING', count: layout.candidates.length, evidence: layoutFile, reason: 'Review every candidate for actual clipping/intentional decoration/scrolling; collector success is not PASS.' });
    assert.ok(layout.documentScrollWidth <= width && layout.bodyScrollWidth <= width, 'Actual document/body horizontal overflow');
    for (const c of contract.home.services.cards) { const article=page.getByRole('article',{name:c.title,exact:true}); assert.equal(await article.count(),1,'Five semantic named Home Service articles'); assert.equal(await article.getAttribute('id'),c.selector.slice(1)); }
    assert.equal(await page.locator('main').count(), 1); assert.equal(await page.locator('h1').count(), 1);
    assert.equal(await page.locator('form,input,textarea,select,button[type="submit"]').count(), 0, 'No new collection form');
    assert.ok((await page.locator('footer').innerText()).includes('隱私權政策（待確認）')); assert.equal(await page.locator('footer a[href$="privacy"],footer a[href$="privacy/"]').count(), 0);
    await inventory(page, spec);
    if (width === 1440) { await metadata(page, spec); const semantics = saveJson('semantics/' + keyFor(spec.path) + '.json', await inspectSemantics(page)); const contrast = saveJson('contrast/' + keyFor(spec.path) + '.json', await inspectContrastStyles(page)); result.manualReview.push({ kind: 'names-headings-contrast', route: spec.path, status: 'PENDING', evidence: [semantics, contrast], reason: 'Manual heading/order/names/gradient contrast check, independent from axe.' }); }
    if (mode === 'pages' && [375, 1440].includes(width)) await test('BF-L07-axe-' + keyFor(spec.path) + '-' + width, 'axe WCAG2/2.1 A/AA actual page', () => axe(page, spec, width, 'closed'));
    if (mode === 'pages' && (spec.path === '/' || (spec.path === '/solutions' && [375, 1440].includes(width)))) await screenshot(page, spec, width);
    if (['/', '/solutions'].includes(spec.path)) await test('BF-changes-' + keyFor(spec.path) + '-' + width, 'Frozen new copy/CTA/registry contracts in rendered DOM', () => changedContent(page, spec, width));
    if ([375, 1440].includes(width)) await test('BF-L06-keyboard-' + keyFor(spec.path) + '-' + width, 'Skip link, keyboard/focus and footer', () => keyboard(page, spec, width));
    if (width === 375) {
      await test('BF-L06-mobile-' + keyFor(spec.path), 'Mobile Escape/internal Tab/focus leave/outside pointer/route navigation', () => mobile(page, spec));
      await test('BF-L06-motion-' + keyFor(spec.path), 'Actual reduced-motion rendering', () => reduced(page, spec));
    }
    return row;
  });
}
async function verifyLinks() {
  const statuses = new Map();
  for (const entry of linkInventory.values()) {
    const url = new URL(entry.resolved); assert.ok(['http:', 'https:'].includes(url.protocol), 'No fake collection/script channel ' + entry.href);
    if (url.origin !== base.origin) { assert.equal(url.protocol, 'https:'); result.links.push({ ...entry, kind: 'external-only', activation: 'Not activated' }); continue; }
    const key = routeKey(url.href); assert.ok(specs.some(spec => spec.path === key), 'No unpublished route link ' + url.href); assert.equal(url.search, '', 'No invented query endpoint');
    if (!statuses.has(url.pathname)) { const response = await http(url.origin + url.pathname, 200); statuses.set(url.pathname, response.status); }
    if (url.hash) assert.ok(idInventory.get(key)?.has(decodeURIComponent(url.hash.slice(1))), 'Real target anchor ' + url.href);
    result.links.push({ ...entry, kind: 'internal', route: key, http: 200, anchorVerified: !!url.hash });
  }
  assert.equal(new Set([...linkInventory.values()].map(row => routeKey(row.source))).size, 9);
  saveJson('links.json', result.links); return { occurrences: result.links.length, anchors: result.links.filter(row => row.anchorVerified).length, uniquePathsProbed: statuses.size };
}
async function protections() {
  const rows = [];
  for (const route of ['/privacy', '/dev/design-system', '/unknown-bugfix001-008-route', '/portfolio/unknown-bugfix001-008-project', '/sitemap.xml']) {
    const response = await http(urlFor(route), 404, '404-' + keyFor(route)); assert.ok(!response.text.includes('草案，尚未核准生效')); rows.push({ route, url: response.url, status: 404, draftMarkerAbsent: true });
  }
  const robotsUrl = new URL('robots.txt', base).href, response = await http(robotsUrl, 200, 'robots');
  const lines = response.text.split(/\r?\n/).map(line => line.trim()).filter(Boolean);
  assert.ok(lines.includes('User-Agent: *') || lines.includes('User-agent: *')); assert.ok(lines.includes('Allow: ' + base.pathname));
  assert.ok(lines.includes('Disallow: ' + base.pathname + 'dev/')); assert.ok(lines.includes('Disallow: ' + base.pathname + 'privacy')); assert.ok(!/^Sitemap:/im.test(response.text)); assert.ok(!lines.includes('Disallow: /'));
  if (mode === 'pages') {
    await http(new URL('.nojekyll', base).href, 200, 'nojekyll'); await http(new URL('404.html', base).href, 200, '404-document');
    const out = path.join(ROOT, 'out'), files = [];
    const walk = directory => { for (const entry of fs.readdirSync(directory, { withFileTypes: true })) { const file = path.join(directory, entry.name); if (entry.isDirectory()) walk(file); else files.push(file); } }; walk(out);
    assert.ok(!files.some(file => /(^|\/)(privacy|dev)(\/|\.)/.test(path.relative(out, file)))); assert.ok(!fs.existsSync(path.join(out, 'sitemap.xml')));
    for (const file of files.filter(file => /\.(html|txt|json|js)$/.test(file))) { const text = fs.readFileSync(file, 'utf8'); for (const sentinel of ['草案，尚未核准生效', 'policy-scope', 'cookies-tracking', 'privacy-contact']) assert.ok(!text.includes(sentinel), 'No draft payload marker: ' + file); }
    for (const spec of specs) assert.ok(fs.existsSync(path.join(out, spec.path.slice(1), 'index.html')), 'Actual exported page ' + spec.path);
    saveJson('export-protection.json', { filesScanned: files.length, publicRoutes: 9, draftDevPayloadAbsent: true, sitemapAbsent: true, nojekyll: true, notFoundDocument: true });
  }
  return rows;
}
(async () => {
  try {
    const sourceTest = await test('BF-source-before', 'Every source.json actual file hash before browser work', () => checkSource('before')); assert.equal(sourceTest.status, 'PASS');
    const contractFile = options.contract || path.join(TASK, 'contract.json'); contract = JSON.parse(fs.readFileSync(contractFile));
    assert.equal(contract.ready, true, 'Root must complete and review final exact-copy contract'); assert.equal(contract.sourceFingerprint, result.sourceFingerprint, 'Contract matches frozen source'); fs.copyFileSync(contractFile, path.join(runDir, 'contract.json'));
    const exportFile = path.join(runDir, 'expected-metadata.json');
    const exported = spawnSync(process.execPath, [path.join(TASK, 'export-metadata.mjs'), exportFile], { encoding: 'utf8' });
    saveJson('metadata-export-process.json', { command: [process.execPath, path.join(TASK, 'export-metadata.mjs'), exportFile], status: exported.status, signal: exported.signal, error: exported.error?.message, stdout: exported.stdout, stderr: exported.stderr });
    assert.equal(exported.status, 0, 'Separate source-to-JSON metadata export completed'); expectations = JSON.parse(fs.readFileSync(exportFile));
    for (const [file, hash] of Object.entries(expectations.sourceFiles)) assert.equal(sha(fs.readFileSync(path.join(ROOT, file))), hash);
    assert.deepEqual(expectations.seoProtectionPolicy, { mode: 'protected', publishSitemap: false }); specs = expectations.seoPages.filter(spec => spec.availability === 'public'); assert.equal(specs.length, 9); assert.deepEqual(specs.map(spec => spec.path).sort(), JSON.parse(fs.readFileSync(path.join(TASK, 'acceptance-plan.json'))).routes.slice().sort(), 'Exact nine public routes unchanged');
    api = await request.newContext({ timeout: 20000 });
    browser = await chromium.launch({ executablePath: '/usr/bin/chromium', headless: true, args: ['--no-sandbox'] }); result.browser = browser.version(); result.node = process.version;
    monitor = new NetworkMonitor({ base: base.href, mode: mode === 'normal' ? 'general' : 'pages', root: ROOT, runDir, api, routeUrls: specs.map(spec => urlFor(spec.path)) });
    await test('BF-L04-http-nine', 'Save actual 9 public HTTP headers/body before responsive browser matrix', async () => { for (const spec of specs) { const row = await http(urlFor(spec.path), 200, keyFor(spec.path)); htmlCache.set(spec.path, row.text); assert.equal(routeKey(row.finalUrl), spec.path); assert.ok(row.text.includes('noindex') && row.text.includes('nofollow')); } return { routes: 9 }; });
    const widths = mode === 'pages' ? [320, 375, 768, 1440, 1920] : [375, 1440];
    for (const width of widths) for (const spec of specs.filter(s => s.path === '/')) await test('BF-' + (mode === 'normal' ? 'L06' : 'L05') + '-case-' + keyFor(spec.path) + '-' + width, 'Actual LOCAL route/viewport and contained interaction checks', () => browserCase(spec, width));
    await test('BF-protection-' + mode, 'Expected404, robots and Pages .nojekyll/export exclusion', protections);
    await test('BF-network-' + mode, 'Task012 strict all-method network/console/runtime classification and independent full resource GET', async () => { const data = await monitor.verify(); result.network = data; assert.equal(data.unexpectedErrors, 0); return data; });
    await test('BF-storage-' + mode, 'Actual fresh-context and every actual before/after cookie/storage/IDB inventory', () => { assert.equal(result.storage.length, result.expectedCounts.storageContexts); assert.ok(result.storage.every(row => row.status === 'PASS' && row.after && row.documentsBefore.length)); return { contexts: result.storage.length, actualPairs: result.storage.length }; });
    await test('BF-counts-' + mode, 'Coverage counts and independent source-to-JSON metadata completeness', () => {
      for (const [key, expected] of Object.entries({ responsive: result.expectedCounts.responsive, axe: result.expectedCounts.axe, metadata: 1, screenshots: result.expectedCounts.screenshots, changeAssertions: result.expectedCounts.changeAssertions, keyboard: 2, mobile: 1, reducedMotion: 1 })) assert.equal((result[key] || []).length, expected, 'Coverage ' + key);
      assert.equal(new Set(result.metadata.map(row => row.observed.title)).size, 1); assert.equal(new Set(result.metadata.map(row => row.observed.description.value)).size, 1);
      return { ...result.expectedCounts, metadata: 1 };
    });
  } catch (error) { result.fatal = { message: error.message, stack: error.stack }; }
  finally {
    try { await test('BF-source-after', 'Every frozen source file and manifest byte hash after all work', () => checkSource('after')); } catch (error) { result.sourceAfterError = error.message; }
    monitor?.finish();
    for (const context of contexts) await context.close().catch(() => {});
    await browser?.close().catch(error => { result.cleanupError = error.message; }); await api?.dispose().catch(error => { result.cleanupError = error.message; });
    result.automatedStatus = result.fatal || result.cleanupError || result.sourceAfterError || result.tests.some(row => row.status === 'FAIL') ? 'FAIL' : 'PASS';
    result.manualReviewStatus = 'PENDING'; result.status = result.automatedStatus === 'FAIL' ? 'FAIL' : 'PENDING';
    result.coverage = { responsive: result.responsive.length, axe: result.axe.length, metadata: result.metadata.length, keyboard: (result.keyboard || []).length, mobile: (result.mobile || []).length, reducedMotion: (result.reducedMotion || []).length, storageContexts: result.storage.length, actualStoragePairs: result.storage.filter(row => row.after).length, screenshots: result.screenshots.length, changeAssertions: result.changeAssertions.length, subtests: result.tests.length, expectedSubtests: mode === 'normal' ? 15 : 24 };
    result.complete = result.automatedStatus === 'PASS' && result.coverage.subtests === result.coverage.expectedSubtests && result.coverage.responsive === result.expectedCounts.responsive && result.coverage.axe === result.expectedCounts.axe && result.coverage.metadata === 1 && result.coverage.actualStoragePairs === result.expectedCounts.storageContexts && result.coverage.changeAssertions === result.expectedCounts.changeAssertions && result.coverage.screenshots === result.expectedCounts.screenshots;
    result.finishedAt = new Date().toISOString(); result.counts = { automatedPass: result.tests.filter(row => row.status === 'PASS').length, automatedFail: result.tests.filter(row => row.status === 'FAIL').length, manualPending: result.manualReview.length };
    saveJson('manual-review.json', { status: 'PENDING', note: 'Root must make explicit decisions and inspect actual screenshot bytes. This file is not an automatic PASS.', items: result.manualReview }); save();
    console.log(JSON.stringify({ automatedStatus: result.automatedStatus, overallStatus: result.status, complete: result.complete, coverage: result.coverage, manualReviewStatus: result.manualReviewStatus, counts: result.counts, result: path.join(runDir, 'results.json') }));
    process.exitCode = result.automatedStatus === 'PASS' && result.complete ? 0 : 1;
  }
})();
