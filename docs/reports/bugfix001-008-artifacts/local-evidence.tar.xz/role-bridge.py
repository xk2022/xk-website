from pathlib import Path
import json,hashlib,shutil,datetime
P=Path('/tmp/xk-bugfix001-008');old=P/'initial-out';new=Path('/workspace/xk-website/out')
def build_id(root):
 p=list((root/'_next/static').glob('*/_buildManifest.js'));assert len(p)==1,p;return p[0].parent.name
ids=[build_id(old),build_id(new)];rows=[]
for f in old.rglob('*'):
 if not f.is_file():continue
 rel=f.relative_to(old).as_posix()
 if rel=='index.html'or not rel.endswith(('.html','.css','.js','.woff2')):continue
 other=new/rel
 if not other.exists()and rel.startswith('_next/static/'+ids[0]+'/'):other=new/rel.replace('_next/static/'+ids[0]+'/', '_next/static/'+ids[1]+'/',1)
 assert other.exists(),rel
 a=f.read_bytes();b=other.read_bytes();same=a==b
 if not same and rel.endswith('.html'):same=a.replace(ids[0].encode(),b'ACTUAL_BUILD_ID')==b.replace(ids[1].encode(),b'ACTUAL_BUILD_ID')
 assert same,rel;rows.append({'file':rel,'comparison':'raw'if a==b else'only actual Next BuildID','sha256Final':hashlib.sha256(b).hexdigest()})
html={r['file']for r in rows if r['file'].endswith('.html')};expected={str(p.relative_to(old))for p in old.rglob('*.html')} - {'index.html'}
assert html==expected and len(html)==11;assert {'404.html','404/index.html','_not-found/index.html'}<=html;assert len([r for r in rows if r['file'].endswith('.css')])==3
(P/'role-artifact-bridge.json').write_text(json.dumps({'status':'PASS','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'oldBuildId':ids[0],'newBuildId':ids[1],'htmlCount':len(html),'scope':'Eight unchanged public pages and three actual exported 404 representations, CSS/JS/fonts compared; only actual BuildID replacement in HTML, no RSC normalization','rows':rows},indent=2)+'\n')
root=P/'pages-final-root';assert not root.exists();root.mkdir();shutil.copytree(new,root/'xk-website');assert (root/'xk-website/index.html').is_file();print('Artifact bridge',len(rows),'files;11 actual non-Home HTML;3 CSS; prepared 204-file static root')
