'use strict';
// Root reviews contract.json against frozen source; no browser-derived expectations.
const assert = require('node:assert/strict');
const clean = value => value.replace(/\s+/g, ' ').trim();
async function unique(scope, selector) { const node = scope.locator(selector); assert.equal(await node.count(), 1, 'Unique ' + selector); return node; }
async function includes(node, values) { assert.ok(Array.isArray(values) && values.length > 0, 'Nonempty exact-copy expectations'); const text = clean(await node.innerText()); for (const value of values) { assert.ok(typeof value === 'string' && value.length > 0); assert.ok(text.includes(clean(value)), 'Expected rendered copy ' + value); } }
async function link(scope, expected, urlFor) {
  assert.ok(expected.label && expected.href && expected.href.startsWith('/'));
  const node = scope.getByRole('link', { name: expected.label, exact: true }); assert.equal(await node.count(), 1, 'Unique link ' + expected.label);
  const expectedUrl = new URL(expected.href, urlFor('/')); const route = expectedUrl.pathname;
  const modeUrl = new URL(urlFor(route)); modeUrl.hash = expectedUrl.hash;
  assert.equal(await node.evaluate(a => a.href), modeUrl.href, 'Actual resolved path/anchor ' + expected.href); return node;
}
async function assertChanges({ page, route, width, contract, urlFor, routeKey, go, monitor }) {
  const counts = {};
  if (route === '/') {
    const home = contract.home;
    const hero = await unique(page, home.hero.selector); await includes(hero, home.hero.text);
    assert.equal(home.hero.primary.label, '探索我們的服務'); assert.equal(home.hero.primary.href, '/#services'); assert.equal(home.hero.secondary.href, '/portfolio');
    await link(hero, home.hero.primary, urlFor); const secondary = await link(hero, home.hero.secondary, urlFor);
    const services = await unique(page, home.services.selector); assert.equal(home.services.cards.length, 5); assert.equal(await services.locator('[id^="service-"]').count(), 5, 'Actual five original Home service anchors');
    for (const card of home.services.cards) { const node = await unique(services, card.selector); await includes(node, [card.title, card.need, card.delivery]); await link(node, card.cta, urlFor); }
    counts.serviceCards = 5;
    const technologies = await unique(page, home.technologies.selector); const articles = technologies.locator('article'); assert.equal(await articles.count(), 5); assert.equal(home.technologies.cards.length, 5); await includes(technologies, home.technologies.text);
    for (let index = 0; index < 5; index++) { const card = home.technologies.cards[index], article = articles.nth(index); await includes(article, [card.title, card.description]); assert.deepEqual((await article.locator('li').allTextContents()).map(clean), card.items.map(clean)); }
    counts.technologyArticles = 5;
    const why = await unique(page, home.why.selector); assert.equal(await why.locator('ol > li').count(), 4); await includes(why, home.why.text); counts.whyItems = 4;
    const solutions = await unique(page, home.solutions.selector); assert.equal(home.solutions.links.length, 3);
    for (const entry of home.solutions.links) { assert.ok(entry.href.startsWith('/solutions#solution-'), 'Published registry anchor'); const node = solutions.locator('a').filter({ has: page.getByRole('heading', { name: entry.title, exact: true }) }); assert.equal(await node.count(), 1); const expected = new URL(urlFor('/solutions')); expected.hash = entry.href.split('#')[1]; assert.equal(await node.evaluate(a => a.href), expected.href); }
    counts.solutionLinks = 3;
    // Exercise the new secondary CTA once in each mode, with real navigation and strict monitoring.
    if (width === 375) { await secondary.click(); await page.waitForURL(url => routeKey(url.href) === '/portfolio'); await monitor.drain(page); await go(); counts.secondaryCtaClick = true; }
  } else if (route === '/solutions') {
    assert.equal(contract.solutions.articles.length, 4); assert.equal(await page.locator('#solution-details article').count(), 4);
    for (const article of contract.solutions.articles) {
      const node = await unique(page, article.selector); await includes(node, [article.title, '相關展示規劃', '可規劃的交付', article.scopeNote]); assert.equal(article.deliverables.length, 3); await includes(node, article.deliverables);
      assert.ok(article.projects.length > 0); for (const project of article.projects) { assert.equal(project.status, 'PLANNED'); assert.ok(project.href.startsWith('/portfolio/')); await includes(node, [project.statusText, project.note]); await link(node, project, urlFor); }
    }
    counts.solutionArticles = 4; counts.plannedDeliverables = 12; counts.relatedPlannedProjects = contract.solutions.articles.reduce((n, a) => n + a.projects.length, 0);
  } else throw new Error('Unexpected changed route ' + route);
  return { route, width, status: 'PASS', counts, expectationSource: 'root-reviewed frozen contract.json' };
}
module.exports = { assertChanges };
