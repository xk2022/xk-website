'use strict';

/**
 * Read-only DOM/computed-style observations, not WCAG verdicts or an AX-tree API.
 * Each helper makes one page.evaluate() call and never focuses, clicks, scrolls,
 * navigates, changes styles, or sends requests. Main harness owns interpretation.
 *
 * const { inspectFocused, inspectTargets } = require('./a11y-observations.cjs');
 * const focused = await inspectFocused(page); // after the harness's real Tab
 * const targets = await inspectTargets(page); // review candidates + exceptions
 * const styles = await inspectContrastStyles(page, ['main p', 'footer a']);
 *
 * 24px/44px results concern measured CSS bounding boxes only. Inline, spacing,
 * equivalent-target and other exceptions require human judgment. 44px is an
 * existing UI-contract observation here; it does not establish AAA conformance.
 * Hit tests sample nine points, not every painted pixel. Contrast observations
 * contain computed styles and ancestry, never a source-color contrast PASS.
 */

async function observe(page, kind, selectors) {
  return page.evaluate(({ kind, selectors }) => {
    const rect = r => ({ x: r.x, y: r.y, left: r.left, top: r.top, right: r.right, bottom: r.bottom, width: r.width, height: r.height });
    const text = (node, limit = 400) => (node?.textContent || '').replace(/\s+/g, ' ').trim().slice(0, limit);
    const describe = node => node instanceof Element ? {
      tag: node.tagName.toLowerCase(), id: node.id || null,
      className: node.getAttribute('class'), role: node.getAttribute('role'),
      ariaLabel: node.getAttribute('aria-label'), text: text(node, 180),
    } : null;
    const rendered = node => {
      const s = getComputedStyle(node), r = node.getBoundingClientRect();
      return s.display !== 'none' && s.visibility !== 'hidden' && s.visibility !== 'collapse'
        && node.getClientRects().length > 0 && r.width > 0 && r.height > 0;
    };
    const references = value => (value || '').split(/\s+/).filter(Boolean).map(id => {
      const node = document.getElementById(id);
      return { id, exists: !!node, text: text(node) };
    });
    const labels = node => ({
      ariaLabel: node.getAttribute('aria-label'),
      labelledBy: references(node.getAttribute('aria-labelledby')),
      describedBy: references(node.getAttribute('aria-describedby')),
      associatedLabels: [...(node.labels || [])].map(label => ({ ...describe(label), htmlFor: label.htmlFor })),
      title: node.getAttribute('title'), alt: node.getAttribute('alt'),
      placeholder: node.getAttribute('placeholder'),
      note: 'Name sources only; this is not the browser accessibility-tree computed name.',
    });
    const unique = selector => [...new Set(document.querySelectorAll(selector))];
    const focusSelector = 'a[href],area[href],button,input:not([type="hidden"]),select,textarea,summary,iframe,[contenteditable]:not([contenteditable="false"]),[tabindex]';
    const clippingAncestors = node => {
      const r = node.getBoundingClientRect(), found = [];
      for (let parent = node.parentElement; parent; parent = parent.parentElement) {
        const s = getComputedStyle(parent), p = parent.getBoundingClientRect();
        const clipX = /^(hidden|clip|scroll|auto)$/.test(s.overflowX);
        const clipY = /^(hidden|clip|scroll|auto)$/.test(s.overflowY);
        if ((clipX && (r.left < p.left - 1 || r.right > p.right + 1)) || (clipY && (r.top < p.top - 1 || r.bottom > p.bottom + 1))) {
          found.push({ element: describe(parent), rect: rect(p), overflowX: s.overflowX, overflowY: s.overflowY, scrollLeft: parent.scrollLeft, scrollTop: parent.scrollTop, scrollable: parent.scrollWidth > parent.clientWidth || parent.scrollHeight > parent.clientHeight });
        }
      }
      return found;
    };
    const common = {
      url: location.href, observedAt: new Date().toISOString(), observationsOnly: true,
      viewport: { width: innerWidth, height: innerHeight, devicePixelRatio, scrollX, scrollY },
    };

    if (kind === 'semantics') {
      return {
        ...common, documentLanguage: document.documentElement.lang,
        headings: unique('h1,h2,h3,h4,h5,h6,[role="heading"]').map(node => ({
          ...describe(node), text: text(node), nativeLevel: /^H[1-6]$/.test(node.tagName) ? Number(node.tagName[1]) : null,
          ariaLevel: node.getAttribute('aria-level'), language: node.closest('[lang]')?.getAttribute('lang') || null,
          rendered: rendered(node), ariaHiddenAncestor: !!node.closest('[aria-hidden="true"]'), rect: rect(node.getBoundingClientRect()),
        })),
        navigation: unique('nav,[role="navigation"]').map(node => ({
          ...describe(node), rendered: rendered(node), labels: labels(node),
          links: [...node.querySelectorAll('a[href]')].map(link => ({ ...describe(link), href: link.getAttribute('href'), current: link.getAttribute('aria-current'), rendered: rendered(link) })),
        })),
        landmarks: unique('main,header,footer,nav,aside,section[aria-label],section[aria-labelledby],form[aria-label],form[aria-labelledby],[role="main"],[role="banner"],[role="contentinfo"],[role="navigation"],[role="complementary"],[role="region"],[role="search"],[role="form"]')
          .map(node => ({ ...describe(node), labels: labels(node), rendered: rendered(node), nestedInSectioningContent: !!node.parentElement?.closest('article,aside,main,nav,section') })),
        labelElements: unique('label').map(node => ({ ...describe(node), htmlFor: node.htmlFor, control: describe(node.control), rendered: rendered(node) })),
        controls: unique('input,textarea,select,button,[role="button"],[role="checkbox"],[role="radio"],[role="switch"]')
          .map(node => ({ ...describe(node), type: node.getAttribute('type'), labels: labels(node), rendered: rendered(node), disabled: node.matches(':disabled'), ariaDisabled: node.getAttribute('aria-disabled') })),
        svgAndImages: unique('svg,img').map(node => ({
          ...describe(node), tag: node.tagName.toLowerCase(), rendered: rendered(node), labels: labels(node),
          src: node.getAttribute('src'), viewBox: node.getAttribute('viewBox'),
          svgTitles: [...node.querySelectorAll('title')].map(n => ({ id: n.id || null, text: text(n) })),
          svgDescriptions: [...node.querySelectorAll('desc')].map(n => ({ id: n.id || null, text: text(n) })),
          ariaHidden: node.getAttribute('aria-hidden'), focusableAttribute: node.getAttribute('focusable'),
          rect: rect(node.getBoundingClientRect()),
        })),
        focusables: unique(focusSelector).map(node => ({
          ...describe(node), labels: labels(node), href: node.getAttribute('href'), tabIndex: node.tabIndex,
          rendered: rendered(node), disabled: node.matches(':disabled'), inertAncestor: !!node.closest('[inert]'),
          ariaHiddenAncestor: !!node.closest('[aria-hidden="true"]'), rect: rect(node.getBoundingClientRect()),
        })),
        interpretation: 'Native/explicit semantic candidates and authored name sources. Main harness must confirm actual AX roles/names and meaningful order.',
      };
    }

    if (kind === 'targets') {
      const nodes = unique('a[href],button,input:not([type="hidden"]),select,textarea,summary,[role="button"],[role="link"],[role="checkbox"],[role="radio"],[role="switch"]');
      const targets = nodes.filter(rendered).map((node, index) => {
        const r = node.getBoundingClientRect(), s = getComputedStyle(node);
        const trigger = node.matches('button[aria-controls][aria-expanded],[role="button"][aria-controls][aria-expanded]');
        const cta = node.matches('a[data-slot="button"],button[data-slot="button"],[data-cta]');
        return {
          index, element: describe(node), labels: labels(node), rect: rect(r),
          clientRects: [...node.getClientRects()].map(rect), display: s.display, opacity: s.opacity,
          pointerEvents: s.pointerEvents, disabled: node.matches(':disabled'),
          center: { x: r.left + r.width / 2, y: r.top + r.height / 2 },
          boxAtLeast24: r.width >= 24 && r.height >= 24, boxAtLeast44: r.width >= 44 && r.height >= 44,
          existing44ContractCandidate: trigger || cta, kind: trigger ? 'disclosure-trigger' : cta ? 'cta-or-ui-button' : 'other-target',
          possibleInlineException: s.display === 'inline' && !!node.parentElement?.closest('p,li,dd,dt,figcaption,blockquote'),
          spacingReview: null,
        };
      });
      for (const target of targets.filter(row => !row.boxAtLeast24)) {
        const neighbors = targets.filter(row => row.index !== target.index).map(other => {
          const dx = Math.max(other.rect.left - target.center.x, 0, target.center.x - other.rect.right);
          const dy = Math.max(other.rect.top - target.center.y, 0, target.center.y - other.rect.bottom);
          const centerDistance = Math.hypot(other.center.x - target.center.x, other.center.y - target.center.y);
          return { targetIndex: other.index, centerDistance, centerToOtherBoxDistance: Math.hypot(dx, dy), intersects24DiameterCircleCandidate: other.boxAtLeast24 ? Math.hypot(dx, dy) < 12 : centerDistance < 24 };
        }).sort((a, b) => a.centerToOtherBoxDistance - b.centerToOtherBoxDistance);
        target.spacingReview = { nearest: neighbors[0] || null, intersectingCandidates: neighbors.filter(row => row.intersects24DiameterCircleCandidate), note: 'Geometric evidence only. Inline, equivalent target, spacing, essential and other applicable exceptions require review; no automatic failure.' };
      }
      return {
        ...common, units: 'CSS px', targets,
        below24Candidates: targets.filter(row => !row.boxAtLeast24).map(row => row.index),
        belowExisting44Candidates: targets.filter(row => row.existing44ContractCandidate && !row.boxAtLeast44).map(row => row.index),
        interpretation: '24px box candidates are not automatic WCAG failures. 44px checks existing trigger/CTA design expectations only; no AAA conclusion.',
      };
    }

    if (kind === 'focused') {
      const active = document.activeElement;
      if (!(active instanceof Element)) return { ...common, activeElement: null, fullyObscured: null, partial: null, hitTests: [] };
      const r = active.getBoundingClientRect(), s = getComputedStyle(active);
      const area = { left: Math.max(0, r.left), top: Math.max(0, r.top), right: Math.min(innerWidth, r.right), bottom: Math.min(innerHeight, r.bottom) };
      const hasViewportArea = area.right > area.left && area.bottom > area.top;
      const hitTests = [];
      if (hasViewportArea) for (const fy of [1 / 6, 1 / 2, 5 / 6]) for (const fx of [1 / 6, 1 / 2, 5 / 6]) {
        const x = area.left + (area.right - area.left) * fx, y = area.top + (area.bottom - area.top) * fy;
        const hit = document.elementFromPoint(x, y);
        const owned = !!hit && (hit === active || active.contains(hit));
        const ancestor = !!hit && hit !== active && hit.contains(active);
        const hitStyle = hit ? getComputedStyle(hit) : null;
        const uncertain = !hit || ancestor || s.pointerEvents === 'none' || hitStyle?.opacity === '0';
        hitTests.push({
          x, y, hit: describe(hit), owned, ancestor, uncertain,
          obstructionCandidate: !owned && !uncertain,
          hitStyles: hitStyle ? { position: hitStyle.position, zIndex: hitStyle.zIndex, opacity: hitStyle.opacity, pointerEvents: hitStyle.pointerEvents, backgroundColor: hitStyle.backgroundColor, backgroundImage: hitStyle.backgroundImage } : null,
        });
      }
      const blocked = hitTests.filter(row => row.obstructionCandidate).length;
      const fullyObscured = hitTests.length ? blocked === hitTests.length : null;
      return {
        ...common, activeElement: describe(active), labels: labels(active), rect: rect(r), rendered: rendered(active),
        focusVisible: active.matches(':focus-visible'), tabIndex: active.tabIndex,
        styles: { outlineStyle: s.outlineStyle, outlineWidth: s.outlineWidth, outlineColor: s.outlineColor, outlineOffset: s.outlineOffset, boxShadow: s.boxShadow, color: s.color, backgroundColor: s.backgroundColor, backgroundImage: s.backgroundImage, opacity: s.opacity, pointerEvents: s.pointerEvents },
        viewportIntersection: { ...area, width: Math.max(0, area.right - area.left), height: Math.max(0, area.bottom - area.top) },
        fullyWithinViewport: r.width > 0 && r.height > 0 && r.left >= 0 && r.top >= 0 && r.right <= innerWidth && r.bottom <= innerHeight,
        outsideViewport: !hasViewportArea, clippingAncestors: clippingAncestors(active),
        hitTests, fullyObscured, partial: hitTests.length ? blocked > 0 && !fullyObscured : null,
        obscurers: hitTests.filter(row => row.obstructionCandidate).map(row => ({ element: row.hit, point: { x: row.x, y: row.y }, styles: row.hitStyles })),
        uncertainHitTests: hitTests.filter(row => row.uncertain).length,
        interpretation: 'fullyObscured/partial describe sampled hit-test obstruction candidates inside the viewport, not pixel-proof visibility or a WCAG/AAA verdict. Transparent layers, pointer-events and ancestor hits can be indeterminate.',
      };
    }

    if (kind === 'layout') {
      const nodes = unique('header,main,footer,nav,main section,main article,main h1,main h2,main h3,main h4,main h5,main h6,main p,main li,main a,main button,main table,main pre,main code,main input,main textarea,main select');
      const candidates = [];
      for (const node of nodes.filter(rendered)) {
        const r = node.getBoundingClientRect(), s = getComputedStyle(node), ancestors = clippingAncestors(node);
        const horizontalViewportOverflow = r.left < -1 || r.right > innerWidth + 1;
        const ownContentOverflow = node.clientWidth > 0 && node.scrollWidth > node.clientWidth + 1;
        const truncationStyle = s.textOverflow === 'ellipsis' || (s.webkitLineClamp && s.webkitLineClamp !== 'none' && s.webkitLineClamp !== '0');
        if (horizontalViewportOverflow || ownContentOverflow || truncationStyle || ancestors.length) candidates.push({
          element: describe(node), rect: rect(r), horizontalViewportOverflow, ownContentOverflow,
          clientWidth: node.clientWidth, scrollWidth: node.scrollWidth, clientHeight: node.clientHeight, scrollHeight: node.scrollHeight,
          overflowX: s.overflowX, overflowY: s.overflowY, whiteSpace: s.whiteSpace, textOverflow: s.textOverflow,
          lineClamp: s.webkitLineClamp || null, truncationStyle: !!truncationStyle, clippingAncestors: ancestors,
        });
      }
      return { ...common, documentScrollWidth: document.documentElement.scrollWidth, bodyScrollWidth: document.body?.scrollWidth ?? null, documentClientWidth: document.documentElement.clientWidth, candidates, interpretation: 'Candidates require manual review; intentional scrolling, clipping/decorations, inline fragmentation and scrollable regions are not automatically failures. Offscreen vertical page content is normal.' };
    }

    if (kind === 'contrast') {
      return {
        ...common, selectors,
        elements: unique(selectors.join(',')).map(node => {
          const s = getComputedStyle(node), ancestry = [];
          let cumulativeOpacity = 1;
          for (let ancestor = node; ancestor; ancestor = ancestor.parentElement) {
            const a = getComputedStyle(ancestor);
            cumulativeOpacity *= Number(a.opacity);
            ancestry.push({ element: describe(ancestor), backgroundColor: a.backgroundColor, backgroundImage: a.backgroundImage, opacity: a.opacity, filter: a.filter, backdropFilter: a.backdropFilter, mixBlendMode: a.mixBlendMode });
          }
          return {
            element: describe(node), text: text(node), rendered: rendered(node), rect: rect(node.getBoundingClientRect()),
            color: s.color, backgroundColor: s.backgroundColor, backgroundImage: s.backgroundImage,
            opacity: s.opacity, cumulativeAncestorOpacity: cumulativeOpacity, fontSize: s.fontSize,
            fontWeight: s.fontWeight, fontFamily: s.fontFamily, lineHeight: s.lineHeight,
            textShadow: s.textShadow, textFillColor: s.webkitTextFillColor || null,
            ancestry, contrastRatio: null, contrastResult: null,
          };
        }),
        interpretation: 'Actual computed styles at observation time for axe-incomplete/manual review. Gradients, images, sibling overlays, opacity and compositing need rendered-pixel assessment. No source-token comparison, ratio, contrast PASS or WCAG verdict is produced.',
      };
    }
    throw new Error('Unknown observation kind');
  }, { kind, selectors });
}

async function inspectSemantics(page) { return observe(page, 'semantics'); }
async function inspectTargets(page) { return observe(page, 'targets'); }
async function inspectFocused(page) { return observe(page, 'focused'); }
async function inspectLayout(page) { return observe(page, 'layout'); }
async function inspectContrastStyles(page, selectors = ['main h1', 'main h2', 'main h3', 'main p', 'main li', 'main a', 'button', 'footer a']) {
  const list = typeof selectors === 'string' ? [selectors] : selectors;
  if (!Array.isArray(list) || !list.length || !list.every(value => typeof value === 'string' && value.trim())) throw new TypeError('selectors must be a nonempty CSS selector string or string array');
  return observe(page, 'contrast', list);
}

module.exports = { inspectSemantics, inspectTargets, inspectFocused, inspectLayout, inspectContrastStyles };
