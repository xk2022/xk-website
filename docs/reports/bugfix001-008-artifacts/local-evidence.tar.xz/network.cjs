'use strict';

const assert = require('node:assert/strict');
const crypto = require('node:crypto');
const fs = require('node:fs');
const path = require('node:path');

const REQUEST_WINDOW_MS = 250;
const EVENT_WINDOW_MS = 1000;
const TREE_WINDOW_MS = 3000;
const CLOCK_TOLERANCE_MS = 50;
const BINDING = '__xkTask009NetworkObservation';
const DOCUMENT_KEY = '__xkTask009NetworkDocument';

function installFetchObserver({ binding, documentKey }) {
  if (window[documentKey]) return;
  const state = { documentId: typeof crypto.randomUUID === 'function' ? crypto.randomUUID() : `${Date.now()}:${Math.random()}`, serial: 0 };
  Object.defineProperty(window, documentKey, { value: state });
  const nativeFetch = window.fetch;
  window.fetch = function (...args) {
    const input = args[0];
    const method = String(args[1]?.method || (input instanceof Request ? input.method : 'GET')).toUpperCase();
    let url;
    try { url = new URL(input instanceof Request ? input.url : String(input), location.href).href; }
    catch { return nativeFetch.apply(this, args); }
    const observed = method === 'HEAD' || (method === 'GET' && new URL(url).pathname.endsWith('/__next._tree.txt'));
    if (!observed) return nativeFetch.apply(this, args);
    const row = {
      observationId: `${state.documentId}:${++state.serial}`, documentId: state.documentId,
      url, method, startedAt: Date.now(),
      initiatorLocation: { origin: location.origin, pathname: location.pathname, search: location.search },
    };
    const report = extra => {
      try { void window[binding]({ ...row, ...extra }).catch(() => {}); } catch {}
    };
    report({ phase: 'start' });
    let pending;
    try { pending = nativeFetch.apply(this, args); }
    catch (error) { report({ phase: 'end', state: 'rejected', finishedAt: Date.now(), name: error.name, message: error.message }); throw error; }
    pending.then(
      response => report({ phase: 'end', state: 'fulfilled', finishedAt: Date.now(), status: response.status, responseUrl: response.url }),
      error => report({ phase: 'end', state: 'rejected', finishedAt: Date.now(), name: error.name, message: error.message }),
    );
    return pending;
  };
}

function nearest(rows, predicate, distance) {
  return rows.filter(predicate).sort((a, b) => distance(a) - distance(b))[0];
}

function isTreeTarget(value, expected) {
  try {
    const actual = new URL(value), target = new URL(expected);
    return actual.origin === target.origin && actual.pathname === target.pathname && !actual.hash
      && [...actual.searchParams.keys()].every(key => key === '_rsc');
  } catch { return false; }
}

/** Modes: general, pages, preview. Only pages permits the strict HEAD exception. */
class NetworkMonitor {
  constructor({ base, mode, root, runDir, api, routeUrls }) {
    this.base = new URL(base);
    assert.ok(this.base.pathname.endsWith('/'), 'NetworkMonitor base must end in /');
    assert.ok(['general', 'pages', 'preview'].includes(mode));
    assert.ok(api && typeof api.get === 'function' && typeof api.head === 'function');
    this.mode = mode;
    this.root = path.resolve(root);
    this.runDir = path.resolve(runDir);
    this.api = api;
    this.routeUrls = new Set(Array.from(routeUrls || [], value => new URL(value, this.base).href));
    assert.ok(this.routeUrls.size, 'Explicit actual routeUrls required');
    fs.mkdirSync(this.runDir, { recursive: true });
    this.rawFile = path.join(this.runDir, 'network-raw.ndjson');
    this.classificationFile = path.join(this.runDir, 'network-classification.json');
    this.fd = fs.openSync(this.rawFile, 'wx');
    this.serial = 0;
    this.watchSerial = 0;
    this.pages = new Map();
    this.cdpRequests = [];
    this.cdpFailures = [];
    this.fetchObservations = new Map();
    this.browserErrors = [];
    this.assets = new Map();
    this.bundleCache = new Map();
    this.verifyStarted = false;
    this.finished = false;
  }

  _raw(kind, data) {
    assert.ok(!this.finished, 'NetworkMonitor is finished');
    const row = { id: `n${++this.serial}`, at: Date.now(), kind, ...data };
    fs.writeSync(this.fd, JSON.stringify(row) + '\n');
    return row;
  }

  _error(kind, data) {
    const row = this._raw(kind, data);
    this.browserErrors.push(row);
    return row;
  }

  async watch(page) {
    assert.ok(!this.finished && !this.verifyStarted, 'Watch must precede verify/finish');
    if (this.pages.has(page)) return this.pages.get(page).watchId;
    const state = { watchId: ++this.watchSerial, pending: new Set(), lastEventAt: Date.now(), requests: new WeakMap(), iconProofs: new Set(), listeners: [] };
    this.pages.set(page, state);
    const watchId = state.watchId;
    const on = (target, event, callback) => {
      const guarded = (...values) => { if (!this.finished) callback(...values); };
      target.on(event, guarded);
      state.listeners.push([target, event, guarded]);
    };
    await page.exposeBinding(BINDING, ({ frame }, value) => {
      if (this.finished) return;
      const row = this._raw('fetch-observation', { watchId, frameUrl: frame.url(), ...value });
      const key = `${watchId}:${value.observationId}`;
      const observation = this.fetchObservations.get(key) || { watchId, ...value };
      if (value.phase === 'start') observation.startEventId = row.id;
      else Object.assign(observation, value, { endEventId: row.id });
      this.fetchObservations.set(key, observation);
      state.lastEventAt = Date.now();
    });
    await page.addInitScript(installFetchObserver, { binding: BINDING, documentKey: DOCUMENT_KEY });
    // Also support a just-created about:blank page or an explicitly watched loaded page.
    await page.evaluate(installFetchObserver, { binding: BINDING, documentKey: DOCUMENT_KEY });

    on(page, 'request', request => {
      const row = this._raw('browser-request', {
        watchId, url: request.url(), method: request.method(), resourceType: request.resourceType(),
        navigation: request.isNavigationRequest(), pageUrl: page.url(),
      });
      state.requests.set(request, row);
      state.pending.add(request);
      state.lastEventAt = Date.now();
    });
    on(page, 'response', response => {
      const request = response.request();
      const row = this._raw('browser-response', {
        watchId, requestEventId: state.requests.get(request)?.id, url: response.url(),
        method: request.method(), resourceType: request.resourceType(), status: response.status(),
      });
      if (response.status() >= 400) this.browserErrors.push(row);
      const assetType = ['stylesheet', 'script', 'font', 'image', 'media', 'manifest'].includes(request.resourceType());
      if (request.method() === 'GET' && (assetType || /\.(?:css|m?js|woff2?|ttf|otf|svg|ico|png|jpe?g|gif|webp|avif|txt|json|webmanifest)(?:\?|$)/i.test(response.url()))) {
        const asset = this.assets.get(response.url()) || { url: response.url(), resourceType: request.resourceType(), responseEventIds: [], statuses: new Set() };
        asset.responseEventIds.push(row.id);
        asset.statuses.add(response.status());
        this.assets.set(response.url(), asset);
      }
      state.lastEventAt = Date.now();
    });
    on(page, 'requestfinished', request => {
      this._raw('browser-requestfinished', { watchId, requestEventId: state.requests.get(request)?.id, url: request.url(), method: request.method() });
      state.pending.delete(request);
      state.lastEventAt = Date.now();
    });
    on(page, 'requestfailed', request => {
      this._error('browser-requestfailed', {
        watchId, requestEventId: state.requests.get(request)?.id, url: request.url(),
        method: request.method(), resourceType: request.resourceType(), message: request.failure()?.errorText || '',
      });
      state.pending.delete(request);
      state.lastEventAt = Date.now();
    });
    on(page, 'console', message => {
      if (message.type() === 'error') this._error('browser-console-error', { watchId, pageUrl: page.url(), message: message.text(), location: message.location() });
    });
    on(page, 'pageerror', error => this._error('browser-runtime-error', { watchId, pageUrl: page.url(), message: error.message, stack: error.stack }));
    const cdp = await page.context().newCDPSession(page);
    state.cdp = cdp;
    const requests = new Map();
    on(cdp, 'Network.requestWillBeSent', event => {
      const row = this._raw('cdp-request', {
        watchId, requestId: event.requestId, loaderId: event.loaderId, frameId: event.frameId,
        wallTime: event.wallTime, timestamp: event.timestamp, documentUrl: event.documentURL,
        url: event.request.url, method: event.request.method, type: event.type,
        referer: event.request.headers.Referer || event.request.headers.referer || null,
        nextUrl: event.request.headers['Next-Url'] || event.request.headers['next-url'] || null,
        initiator: event.initiator,
      });
      requests.set(event.requestId, row);
      this.cdpRequests.push(row);
      state.lastEventAt = Date.now();
    });
    on(cdp, 'Network.responseReceived', event => {
      const request = requests.get(event.requestId);
      const row = this._raw('cdp-response', { watchId, requestId: event.requestId, requestEventId: request?.id, loaderId: event.loaderId, url: event.response.url, status: event.response.status, type: event.type });
      if (request) Object.assign(request, { responseEventId: row.id, status: event.response.status });
      state.lastEventAt = Date.now();
    });
    on(cdp, 'Network.loadingFinished', event => {
      const request = requests.get(event.requestId);
      const row = this._raw('cdp-loadingFinished', { watchId, requestId: event.requestId, requestEventId: request?.id, timestamp: event.timestamp });
      if (request) request.finishedEventId = row.id;
      state.lastEventAt = Date.now();
    });
    on(cdp, 'Network.loadingFailed', event => {
      const request = requests.get(event.requestId);
      const row = this._raw('cdp-loadingFailed', { watchId, requestId: event.requestId, requestEventId: request?.id, errorText: event.errorText, canceled: event.canceled === true, type: event.type, timestamp: event.timestamp });
      if (request) request.failureEventId = row.id;
      this.cdpFailures.push({ ...row, request });
      state.lastEventAt = Date.now();
    });
    await cdp.send('Network.enable');
    this._raw('watch-ready', { watchId, pageUrl: page.url() });
    return watchId;
  }

  async drain(page) {
    const state = this.pages.get(page);
    assert.ok(state, 'Call watch(page) before drain(page)');
    assert.ok(!this.finished, 'NetworkMonitor is finished');
    const deadline = Date.now() + 30000;
    let timer;
    const work = async () => {
      await page.waitForLoadState('domcontentloaded', { timeout: Math.max(1, deadline - Date.now()) });
      await page.evaluate(() => document.fonts.ready);
      const declaration = await page.evaluate(key => ({
        documentId: window[key]?.documentId,
        icons: [...new Set([...document.querySelectorAll('link[rel~=icon]')].map(node => node.href))],
      }), DOCUMENT_KEY);
      for (const url of declaration.icons) {
        const key = `${declaration.documentId}:${url}`;
        if (state.iconProofs.has(key)) continue;
        const proof = await page.evaluate(async ({ url, remaining }) => {
          const controller = new AbortController();
          const timeout = setTimeout(() => controller.abort(), remaining);
          try {
            const response = await fetch(url, { cache: 'force-cache', signal: controller.signal });
            const body = await response.arrayBuffer();
            const digest = await crypto.subtle.digest('SHA-256', body);
            return { url, status: response.status, bytes: body.byteLength, sha256: [...new Uint8Array(digest)].map(value => value.toString(16).padStart(2, '0')).join('') };
          } finally { clearTimeout(timeout); }
        }, { url, remaining: Math.max(1, deadline - Date.now()) });
        const event = this._raw('declared-icon-body', { watchId: state.watchId, documentId: declaration.documentId, ...proof });
        assert.equal(proof.status, 200, `Declared icon HTTP200: ${url} (${event.id})`);
        assert.ok(proof.bytes > 0, `Declared icon nonempty full body: ${url}`);
        state.iconProofs.add(key);
      }
      while (state.pending.size || Date.now() - state.lastEventAt < 100) {
        assert.ok(Date.now() < deadline, 'Network drain exceeded 30 seconds');
        await new Promise(resolve => setTimeout(resolve, 25));
      }
      return { pending: 0, quietMs: 100, declaredIcons: declaration.icons.length };
    };
    try {
      return await Promise.race([
        work(),
        new Promise((_, reject) => { timer = setTimeout(() => reject(new Error('Network drain exceeded 30 seconds (fonts/icon body/pending requests)')), 30000); }),
      ]);
    } finally { clearTimeout(timer); }
  }

  _observations() { return [...this.fetchObservations.values()]; }

  async _callsite(request) {
    const frames = request?.initiator?.stack?.callFrames || [];
    for (const frame of frames) {
      let url;
      try { url = new URL(frame.url); } catch { continue; }
      if (url.origin !== this.base.origin || !url.pathname.startsWith(this.base.pathname + '_next/static/chunks/')) continue;
      if (!this.bundleCache.has(url.href)) {
        const response = await this.api.get(url.href, { timeout: 30000 });
        assert.equal(response.status(), 200, 'Independent actual prefetch bundle HTTP200');
        const body = await response.body();
        const relative = url.pathname.slice((this.base.pathname + '_next/static/chunks/').length);
        const local = path.resolve(this.root, 'out/_next/static/chunks', relative);
        const localBase = path.resolve(this.root, 'out/_next/static/chunks') + path.sep;
        assert.ok(local.startsWith(localBase), 'Chunk stays within final build output');
        const sha256 = crypto.createHash('sha256').update(body).digest('hex');
        assert.ok(fs.existsSync(local), 'Prefetch bundle exists in final Pages output');
        assert.equal(crypto.createHash('sha256').update(fs.readFileSync(local)).digest('hex'), sha256, 'Served prefetch bundle equals final build');
        const row = this._raw('prefetch-bundle-proof', { url: url.href, localFile: local, bytes: body.length, sha256, status: response.status() });
        this.bundleCache.set(url.href, { body, eventId: row.id });
      }
      const bundle = this.bundleCache.get(url.href);
      const line = bundle.body.toString('utf8').split('\n')[frame.lineNumber] || '';
      const snippet = line.slice(Math.max(0, frame.columnNumber - 500), frame.columnNumber + 300);
      if (snippet.includes('NEXT_ROUTER_PREFETCH_HEADER') && snippet.includes('method:"HEAD"')) {
        return this._raw('prefetch-callsite-proof', { bundleEventId: bundle.eventId, url: url.href, lineNumber: frame.lineNumber, columnNumber: frame.columnNumber, snippet }).id;
      }
    }
    return null;
  }

  async verify() {
    assert.ok(!this.finished && !this.verifyStarted, 'verify() is called exactly once before finish()');
    this.verifyStarted = true;
    const assetProofs = [], expectedHeads = [], unexpected = [];
    const usedEvents = new Set(), usedHeads = new Set(), usedTrees = new Set(), usedTreeObservations = new Set();
    const observations = this._observations();
    const failureSnapshot = [...this.browserErrors];
    const failures = failureSnapshot.filter(row => row.kind === 'browser-requestfailed');
    for (const asset of this.assets.values()) {
      try {
        assert.ok([...asset.statuses].every(status => status === 200 || status === 304), 'All observed asset responses are HTTP200/304');
        const response = await this.api.get(asset.url, { timeout: 30000 });
        const body = await response.body();
        const row = this._raw('independent-asset-body', { url: asset.url, status: response.status(), bytes: body.length, sha256: crypto.createHash('sha256').update(body).digest('hex') });
        assetProofs.push({ url: asset.url, eventId: row.id, responseEventIds: asset.responseEventIds });
        assert.equal(response.status(), 200, 'Independent asset GET HTTP200');
        assert.ok(body.length, 'Independent asset full body is nonempty');
      } catch (error) {
        const row = this._raw('asset-verification-error', { url: asset.url, message: error.message });
        unexpected.push({ eventId: row.id, kind: row.kind, url: asset.url, message: row.message });
      }
    }
    const routeProbes = new Map();
    for (const failure of failureSnapshot) {
      let match = null;
      if (this.mode === 'pages' && failure.kind === 'browser-requestfailed' && failure.method === 'HEAD' && failure.resourceType === 'fetch' && failure.message === 'net::ERR_ABORTED' && this.routeUrls.has(failure.url)) {
        const event = nearest(this.cdpFailures, candidate => !usedEvents.has(candidate.id) && candidate.watchId === failure.watchId && candidate.type === 'Fetch' && candidate.canceled && candidate.errorText === 'net::ERR_ABORTED' && candidate.request?.method === 'HEAD' && candidate.request.url === failure.url && candidate.request.loaderId && candidate.request.status === 200 && Math.abs(candidate.at - failure.at) < EVENT_WINDOW_MS, candidate => Math.abs(candidate.at - failure.at));
        const request = event?.request;
        const head = request && nearest(observations, candidate => !usedHeads.has(candidate.observationId) && candidate.watchId === failure.watchId && candidate.method === 'HEAD' && candidate.url === failure.url && candidate.state === 'fulfilled' && candidate.status === 200 && candidate.startEventId && candidate.endEventId && Math.abs(candidate.startedAt - request.wallTime * 1000) < REQUEST_WINDOW_MS && Math.abs(candidate.finishedAt - failure.at) < EVENT_WINDOW_MS, candidate => Math.abs(candidate.startedAt - request.wallTime * 1000));
        if (head) {
          const treeUrl = new URL('__next._tree.txt', failure.url).href;
          const source = JSON.stringify(head.initiatorLocation);
          const tree = nearest(this.cdpRequests, candidate => !usedTrees.has(candidate.id) && candidate.watchId === failure.watchId && candidate.method === 'GET' && isTreeTarget(candidate.url, treeUrl) && candidate.loaderId === request.loaderId && candidate.status === 200 && !candidate.failureEventId && candidate.finishedEventId && candidate.wallTime * 1000 >= head.finishedAt - CLOCK_TOLERANCE_MS && candidate.wallTime * 1000 <= head.finishedAt + TREE_WINDOW_MS, candidate => Math.abs(candidate.wallTime * 1000 - head.finishedAt));
          const treeObservation = tree && nearest(observations, candidate => !usedTreeObservations.has(candidate.observationId) && candidate.watchId === failure.watchId && candidate.method === 'GET' && candidate.url === tree.url && candidate.documentId === head.documentId && JSON.stringify(candidate.initiatorLocation) === source && candidate.state === 'fulfilled' && candidate.status === 200 && candidate.startEventId && candidate.endEventId && candidate.startedAt >= head.finishedAt - CLOCK_TOLERANCE_MS && candidate.startedAt <= head.finishedAt + TREE_WINDOW_MS && Math.abs(candidate.startedAt - tree.wallTime * 1000) < REQUEST_WINDOW_MS, candidate => Math.abs(candidate.startedAt - tree.wallTime * 1000));
          // A failed browser GET is never excused by an independent successful GET.
          const failedTree = tree && failures.some(candidate => candidate.method === 'GET' && candidate.watchId === failure.watchId && candidate.url === tree.url && Math.abs(candidate.at - tree.at) < TREE_WINDOW_MS);
          if (tree && treeObservation && !failedTree) {
            try {
              const callsiteEventId = await this._callsite(request);
              if (callsiteEventId) {
                if (!routeProbes.has(failure.url)) {
                  const headResponse = await this.api.head(failure.url, { timeout: 30000 });
                  const getResponse = await this.api.get(failure.url, { timeout: 30000 });
                  const row = this._raw('independent-route-probe', { url: failure.url, headStatus: headResponse.status(), getStatus: getResponse.status() });
                  routeProbes.set(failure.url, row);
                }
                const probe = routeProbes.get(failure.url);
                if (probe.headStatus === 200 && probe.getStatus === 200) {
                  match = { failureEventId: failure.id, cdpFailureEventId: event.id, headRequestEventId: request.id, headResponseEventId: request.responseEventId, headStartEventId: head.startEventId, headEndEventId: head.endEventId, treeRequestEventId: tree.id, treeResponseEventId: tree.responseEventId, treeFinishedEventId: tree.finishedEventId, treeStartEventId: treeObservation.startEventId, treeEndEventId: treeObservation.endEventId, callsiteEventId, independentProbeEventId: probe.id };
                  usedEvents.add(event.id); usedHeads.add(head.observationId); usedTrees.add(tree.id); usedTreeObservations.add(treeObservation.observationId);
                }
              }
            } catch (error) {
              const row = this._raw('head-classification-proof-error', { failureEventId: failure.id, message: error.message });
              unexpected.push({ eventId: row.id, kind: row.kind, message: row.message });
            }
          }
        }
      }
      if (match) expectedHeads.push(match);
      else unexpected.push({ eventId: failure.id, kind: failure.kind, url: failure.url || failure.pageUrl, method: failure.method, status: failure.status, message: failure.message });
    }
    for (const event of this.cdpFailures) {
      if (usedEvents.has(event.id)) continue;
      const represented = this.browserErrors.some(row => row.kind === 'browser-requestfailed' && row.watchId === event.watchId && row.url === event.request?.url && row.method === event.request?.method && Math.abs(row.at - event.at) < EVENT_WINDOW_MS);
      if (!represented) unexpected.push({ eventId: event.id, kind: event.kind, url: event.request?.url, method: event.request?.method, message: event.errorText });
    }
    // Include late events rather than silently dropping errors that arrive during API verification.
    for (const row of this.browserErrors.slice(failureSnapshot.length)) unexpected.push({ eventId: row.id, kind: row.kind, url: row.url || row.pageUrl, method: row.method, status: row.status, message: row.message });
    const evidenceFiles = { rawNetwork: this.rawFile, classification: this.classificationFile };
    const summary = { assets: this.assets.size, rawRequestFailures: this.browserErrors.filter(row => row.kind === 'browser-requestfailed').length, expectedHeadCount: expectedHeads.length, unexpectedErrors: unexpected.length, evidenceFiles };
    fs.writeFileSync(this.classificationFile, JSON.stringify({
      ...summary,
      policy: 'Only actual known-route Pages HEAD ERR_ABORTED with matching CDP loaderId, fulfilled200 fetch, same-document synchronous initiatorLocation, causal completed tree GET200, actual final Next prefetch callsite and independent HEAD/GET200 is expected. All raw events occur once in NDJSON; records below reference event IDs. No GET/asset/console/runtime exemption.',
      tolerancesMs: { requestStart: REQUEST_WINDOW_MS, failureEvent: EVENT_WINDOW_MS, causalTree: TREE_WINDOW_MS, eventClock: CLOCK_TOLERANCE_MS },
      assetsVerified: assetProofs, expectedHeads, unexpected,
    }, null, 2) + '\n');
    fs.fsyncSync(this.fd);
    return summary;
  }

  finish() {
    if (this.finished) return;
    for (const state of this.pages.values()) for (const [target, event, callback] of state.listeners) target.off(event, callback);
    fs.fsyncSync(this.fd);
    fs.closeSync(this.fd);
    this.finished = true;
  }
}

module.exports = { NetworkMonitor };
