import collections,datetime,hashlib,itertools,json,re
from pathlib import Path
from urllib.parse import urlsplit
from html.parser import HTMLParser
P=Path('/tmp/xk-bugfix001-008')
def composite(f, a, b):
    return [x * a + y * (1 - a) for x, y in zip(f, b)]

def lum(c):
    return sum((k * (x / 255 / 12.92 if x / 255 <= 0.04045 else ((x / 255 + 0.055) / 1.055) ** 2.4) for k, x in zip([0.2126, 0.7152, 0.0722], c)))

def ratio(a, b):
    x, y = sorted([lum(a), lum(b)])
    return (y + 0.05) / (x + 0.05)

def color(s):
    if s.startswith('rgb'):
        v = [float(x) for x in re.findall('[\\d.]+', s)]
        return (v[:3], v[3] if len(v) > 3 else 1)
    m = re.fullmatch('oklab\\(([-.\\deE]+) ([-.\\deE]+) ([-.\\deE]+) / ([-.\\deE]+)\\)', s)
    assert m, s
    L, a, b, alpha = map(float, m.groups())
    l = (L + 0.3963377774 * a + 0.2158037573 * b) ** 3
    m0 = (L - 0.1055613458 * a - 0.0638541728 * b) ** 3
    s0 = (L - 0.0894841775 * a - 1.291485548 * b) ** 3
    linear = [4.0767416621 * l - 3.3077115913 * m0 + 0.2309699292 * s0, -1.2684380046 * l + 2.6097574011 * m0 - 0.3413193965 * s0, -0.0041960863 * l - 0.7034186147 * m0 + 1.707614701 * s0]
    return ([255 * max(0, min(1, 12.92 * v if v <= 0.0031308 else else1(v))) for v in linear], alpha)

def else1(v):
    return 1.055 * v ** (1 / 2.4) - 0.055

def normalized_html(s):

    def href(m):
        p = urlsplit(m.group(2))
        path = p.path.removeprefix('/xk-website')
        path = path.rstrip('/') or '/'
        return 'href=' + m.group(1) + path + ('?' + p.query if p.query else '') + ('#' + p.fragment if p.fragment else '') + m.group(1)
    return re.sub('href=([\\"\\x27])([^\\"\\x27]*)\\1', href, s)

class Opening(HTMLParser):

    def handle_starttag(self, t, a):
        if not hasattr(self, 'tag'):
            self.tag = t
            self.attrs = dict(a)

def opening_agrees(raw, actual):
    a = Opening()
    a.feed(raw)
    b = Opening()
    b.feed(actual)
    if a.tag != b.tag:
        return False
    for k, v in a.attrs.items():
        w = b.attrs.get(k)
        if k == 'href':

            def norm(z):
                u = urlsplit(z)
                return (u.path.removeprefix('/xk-website').rstrip('/') or '/') + ('?' + u.query if u.query else '') + ('#' + u.fragment if u.fragment else '')
            if norm(v) != norm(w):
                return False
        elif v and v.endswith('...'):
            if k != 'class' or not w.startswith(v[:-3]):
                return False
        elif v != w:
            return False
    return True

initial=json.loads((P/'fresh-contrast-nodes-pages.json').read_text());final=json.loads((P/'fresh-contrast-home-final.json').read_text());assert initial['collectionComplete']and final['collectionComplete']and final['counts']['cases']==3 and final['counts']['ambiguousOrMissing']==[]
r={'files':[c for c in initial['files']if not c['raw'].startswith('home-')]+final['files'],'sourceBefore':final['sourceBefore']};assert len(r['files'])==27
r['counts']={'selectors':sum(len(c['rows'])for c in r['files'])}
light=[min(a,b)for a,b in zip(composite([25,184,213],.12,[245,247,251]),composite([49,87,213],.07,[255]*3))]
darks=[]
for layers in set(itertools.permutations([(49,87,213,.09),(49,87,213,.09),(25,184,213,.12)])):
 c=[16,26,51]
 for *fg,a in layers:c=composite(fg,a,c)
 darks.append(c)
dark=[max(c[i]for c in darks)for i in range(3)];rows=[];counts=collections.Counter()
for case in r['files']:
 for row in case['rows']:
  assert row['rule']=='color-contrast' and row['matchCount']==1
  n=row['nodes'][0];c=n['current'];assert opening_agrees(row['rawHtml'],n['actualHtml']),(case['raw'],row['target']);assert all(a['opacity']=='1'and a['filter']=='none'and a['mixBlendMode']=='normal'for a in n['ancestry'])
  bg=next(a['backgroundColor']for a in n['ancestry']if a['backgroundColor']not in['rgba(0, 0, 0, 0)','transparent']);assert bg in ['rgb(16, 26, 51)','rgb(245, 247, 251)','rgb(255, 255, 255)']
  fg,alpha=color(c['color']);bound=dark if bg=='rgb(16, 26, 51)'else light
  if bg!='rgb(16, 26, 51)':assert alpha==1 and fg in [[16,26,51],[23,32,51],[49,87,213]]
  contrast=ratio(composite(fg,alpha,bound),bound);assert contrast>=4.5,(case['raw'],row['target'],contrast)
  keys=[x.get('data',{}).get('messageKey')for x in row['checks']];assert set(keys)<= {'bgGradient','bgOverlap'}
  overlap='bgOverlap'in keys;fully=overlap and n['panelGeometryContainsEntireNode']and n['sampledCoveredByDisclosureCount']==9
  if overlap:assert n['expandedDisclosurePanel']['backgroundColor']=='rgb(255, 255, 255)'and n['expandedDisclosurePanel']['opacity']=='1'
  kind='fully-covered'if fully else'partly-covered'if overlap else'gradient';counts[kind]+=1
  rows.append({'raw':case['raw'],'rawSha256':case['rawSha256'],'target':row['target'],'foreground':c['color'],'nearestOpaqueBackground':bg,'conservativeRatio':contrast,'requiredConservativeRatio':4.5,'kind':kind,'status':'N/A'if fully else'PASS','decision':'Opaque panel fully covers this entire node; visible counterpart also satisfies calculated bound'if fully else'Actual foreground and maximum gradient-alpha bound pass, including any exposed text'})
assert len(rows)==r['counts']['selectors']
normal=json.loads((P/'normal/initial/results.json').read_text());pages=json.loads((P/'pages/initial/results.json').read_text())
assert normal['complete']and pages['complete'];assert all(x['candidateCount']==0 for t in [normal,pages]for x in t['responsive'])
review={'status':'PASS','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'sourceFingerprint':r['sourceBefore']['fingerprint'],'scope':'Current basic LOCAL regression, not full WCAG certification/AT/performance','contrast':{'cases':27,'selectors':len(rows),'minimumConservativeRatio':min(x['conservativeRatio']for x in rows),'counts':dict(counts),'lightMinimumRgb':light,'darkMaximumRgb':dark,'method':'Fresh current Pages actual foreground/opacity/opaque ancestor and same-source CSS maximum alpha. Light lower bound; per-channel dark upper bound across every layer order. Mask only reduces overlay. Actual Oklab converted to sRGB. All raw opening attrs checked; axe-truncated class checked by exact prefix. Opaque panel full-node geometry plus nine hit tests supplements covered-state decision; no blanket incomplete waiver or glyph pixel-certification claim.','nodes':rows},'rootVisualReview':{'screenshots':'Seven current full-page PNG actually viewed; Home320/375/768/1440/1920 and Solutions375/1440. Three current real focus screenshots reviewed separately.','findings':'No clipping/overlap; headings, Services need/delivery/actions and technology card hierarchy readable; Portfolio planning status and AI future note retained.','keyboard':'36 journeys actual Tab/ShiftTab/skip/main/footer/Escape/focus-leave/outside pointer/route navigation. Blue focus outline/ring visible in actual captured states.','semantics':'Current rendered nine-page heading/name inventories plus new typed content contract reviewed; no fake contact form or unpublished link.'},'collectorBoundary':'Original manual/overall PENDING remains unchanged; this separate Root judgment completes the reviewed local scope.'}
review['versionBridge']={'initialSource':initial['sourceBefore']['fingerprint'],'finalSource':final['sourceBefore']['fingerprint'],'reusedCases':24,'freshHomeCases':3,'proof':'impact-retest.json, role-artifact-bridge.json; only Home card role attribute changed, 11 non-Home/error HTML and three stylesheets unchanged after only actual BuildID replacement. Old observations are not relabelled as fresh.'}
(P/'manual-adjudication-final.json').write_text(json.dumps(review,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'status':'PASS','nodes':len(rows),'counts':dict(counts),'minimumConservativeRatio':review['contrast']['minimumConservativeRatio']}))
