import assert from "node:assert/strict";
import { writeFileSync } from "node:fs";
import { getInquiryAction, inquiryAction } from "/workspace/xk-website/src/config/inquiry.ts";
import { verifiedContactChannels } from "/workspace/xk-website/src/config/contact.ts";

const cases = [];
const empty = getInquiryAction([]);
assert.equal(empty.state, "preparation");
assert.equal(empty.label, "詢價前準備");
assert.equal(empty.href, "/contact#contact-preparation");
assert.match(empty.description, /尚未開放詢價收件/);
cases.push({ id: "EMPTY_IS_PREPARATION_ONLY", actual: empty });

// Synthetic destinations are never written to application configuration or requested.
const email = { label: "Fixture email", href: "mailto:fixture@example.invalid" };
const web = { label: "Fixture web", href: "https://contact.example.invalid/" };
const singleEmail = getInquiryAction([email]);
assert.equal(singleEmail.state, "direct");
assert.equal(singleEmail.label, "立即詢價");
assert.equal(singleEmail.href, email.href);
assert.match(singleEmail.description, /開啟電子郵件程式/);
cases.push({ id: "ONE_EMAIL_OPENS_COMPOSER", actual: singleEmail });
const singleWeb = getInquiryAction([web]);
assert.equal(singleWeb.state, "direct");
assert.equal(singleWeb.href, web.href);
cases.push({ id: "ONE_WEB_USES_VERIFIED_DESTINATION", actual: singleWeb });
const multiple = getInquiryAction([email, web]);
assert.equal(multiple.state, "choose-channel");
assert.equal(multiple.href, "/contact#contact-channels");
assert.equal(multiple.label, "立即詢價");
cases.push({ id: "MULTIPLE_CHANNELS_ALLOW_CHOICE", actual: multiple });
assert.deepEqual(verifiedContactChannels, []);
assert.deepEqual(inquiryAction, empty);
cases.push({ id: "PUBLIC_REGISTRY_STILL_EMPTY", actual: verifiedContactChannels });

const result = { status: "PASS", cases: cases.length, syntheticDestinationsRequested: false, rows: cases };
writeFileSync("/tmp/xk-inquiry-cta/inquiry-contract.json", JSON.stringify(result, null, 2) + "\n");
console.log({ status: result.status, cases: result.cases });
