import argparse,datetime,gzip,hashlib,json,pathlib,re,subprocess,sys
ap=argparse.ArgumentParser();ap.add_argument('--seal',action='store_true');args=ap.parse_args()
root=pathlib.Path('/workspace/xk-website');temp=pathlib.Path('/tmp/xk-inquiry-cta');artifacts=root/'docs/reports/homepage-inquiry-artifacts';shots=root/'docs/screenshots/homepage-inquiry'
read=lambda p:json.loads(p.read_text());sha=lambda b:hashlib.sha256(b).hexdigest();now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
def verify(row):
 data=(root/row['archivePath']).read_bytes();assert sha(data)==row['archiveSha256'];raw=gzip.decompress(data) if row['compression']=='gzip' else data;assert len(raw)==row['rawBytes'] and sha(raw)==row['rawSha256']
def totals(d):
 f=d['files'];t={'files':len(f),'commandReceipts':sum(x['category']=='command-receipt' for x in f),'gzipFiles':sum(x['compression']=='gzip' for x in f),'rawBytes':sum(x['rawBytes'] for x in f),'archiveBytes':sum(x['archiveBytes'] for x in f)};t['savedBytes']=t['rawBytes']-t['archiveBytes'];t['reductionPercent']=round(t['savedBytes']/t['rawBytes']*100,2);d['totals']=t
if args.seal:
 mp=artifacts/'manifest.json';d=read(mp)
 for name,compress in [('package-evidence.receipt.json',False),('package-evidence.log',True)]:
  p=temp/name;raw=p.read_bytes();receipt=read(p) if not compress else None
  if receipt:assert receipt['exitCode']==0 and receipt['finishedAt']
  dest=artifacts/(('commands/' if receipt else '')+name+('.gz' if compress else ''));assert not dest.exists();data=gzip.compress(raw,compresslevel=9,mtime=0) if compress else raw;dest.write_bytes(data);row={'sourcePath':str(p),'logicalPath':name,'archivePath':dest.relative_to(root).as_posix(),'category':'command-receipt' if receipt else 'evidence','compression':'gzip' if compress else 'identity','rawBytes':len(raw),'rawSha256':sha(raw),'archiveBytes':len(data),'archiveSha256':sha(data)}
  if receipt:row.update(exitCode=receipt['exitCode'],receiptStatus=receipt['status'],observationMethod=receipt['observationMethod'])
  d['files'].append(row)
 for row in d['files']:verify(row)
 c=read(artifacts/'changed-files.json');assert all((sha((root/f['path']).read_bytes()) if (root/f['path']).is_file() else None)==f['sha256'] for f in c['files'])
 actual={p.relative_to(root).as_posix() for p in artifacts.rglob('*') if p.is_file()};accounted={f['archivePath'] for f in d['files']};assert actual-accounted=={(artifacts/'manifest.json').relative_to(root).as_posix(),(artifacts/'changed-files.json').relative_to(root).as_posix()}
 assert len(accounted)==len(d['files']);assert len(list(shots.glob('*.png')))==2
 totals(d);d['verification'].update(rawAndArchiveSha256RoundTrips=len(d['files']),changedFilesHashMismatches=[],sealedAt=now());d['packaging']='Packaging runner observed OS exit 0, then --seal verified archived bytes and added that completed receipt. No website reruns.';mp.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'status':'SEALED','manifest':str(mp),'manifestSha256':sha(mp.read_bytes()),'totals':d['totals']}));sys.exit(0)
assert not artifacts.exists() and not shots.exists(),'Refuse to overwrite existing evidence'
source=read(temp/'source.json');normal=read(temp/'normal-final/result.json');first=read(temp/'pages-final/result.json');corrected=read(temp/'pages-corrected/result.json');bridge=read(temp/'screenshot-bridge.json');visual=read(temp/'visual-review.json');correction=read(temp/'browser-tool-correction.json');contract=read(temp/'inquiry-contract.json')
assert normal['status']=='PASS' and len(normal['tests'])==28
assert first['status']=='FAIL' and sum(t['status']=='FAIL' for t in first['tests'])==1
assert corrected['status']=='PASS' and len(corrected['tests'])==29
assert corrected['counters']['actualLayouts']==15 and corrected['counters']['violations']==0 and corrected['counters']['incompleteScans']==0
assert contract['status']=='PASS' and contract['cases']==5
for name,exitcode in [('browser-normal.json',0),('browser-pages.json',1),('browser-pages-retest.json',0),('inquiry-contract-receipt.json',0)]:
 r=read(temp/name);assert r['exitCode']==exitcode and r['finishedAt']
assert visual['status'].startswith('PASS') and len(bridge)==2
assert sha((temp/'browser-before-trailing-slash.cjs').read_bytes())==correction['originalSha256'];assert sha((temp/'browser.cjs').read_bytes())==correction['correctedSha256']
for b in bridge:
 a=pathlib.Path(b['reviewedPath']).read_bytes();z=pathlib.Path(b['finalPath']).read_bytes();assert a==z and sha(z)==b['sha256'] and b['byteIdentical']
mismatches=[p for p,h in source['files'].items() if not (root/p).is_file() or sha((root/p).read_bytes())!=h];assert not mismatches,mismatches;assert len(source['files'])==129
inputs=[]
for p in sorted(temp.iterdir()):
 if p.is_file() and p.suffix in ['.json','.log','.cjs','.mjs'] and not p.name.startswith('package-evidence'):inputs.append((p,p.name))
inputs.extend([(temp/'normal-final/result.json','browser-normal-result.json'),(temp/'pages-final/result.json','browser-pages-original-result.json'),(temp/'pages-corrected/result.json','browser-pages-corrected-result.json'),(pathlib.Path('/tmp/xk-homepage-inquiry-sources-2026-11-24/evidence.json'),'sources/evidence.json'),(temp/'package-evidence.py','tools/package-evidence.py')])
secret=re.compile(rb'https?://[^\s"<>]+[?&](?:x-amz-signature|x-goog-signature|access_token|token|signature|sig)=|gh[pousr]_[A-Za-z0-9]{20,}',re.I)
for p,_ in inputs:assert not secret.search(p.read_bytes()),'Potential sensitive URL/token in '+str(p)
artifacts.mkdir(parents=True);shots.mkdir(parents=True);files=[]
for p,name in inputs:
 raw=p.read_bytes();value=read(p) if p.suffix=='.json' else None;receipt=isinstance(value,dict) and 'command' in value and 'exitCode' in value
 if receipt:assert value['exitCode'] is not None and value.get('finishedAt'),str(p)
 logical=('commands/'+name) if receipt else name;compress=p.suffix!='.json' or len(raw)>24576 or name.endswith('-result.json');dest=artifacts/(logical+('.gz' if compress else ''));dest.parent.mkdir(parents=True,exist_ok=True);assert not dest.exists();data=gzip.compress(raw,compresslevel=9,mtime=0) if compress else raw;dest.write_bytes(data)
 row={'sourcePath':str(p),'logicalPath':name,'archivePath':dest.relative_to(root).as_posix(),'category':'command-receipt' if receipt else 'tool' if p.suffix in ['.cjs','.mjs','.py'] else 'evidence','compression':'gzip' if compress else 'identity','rawBytes':len(raw),'rawSha256':sha(raw),'archiveBytes':len(data),'archiveSha256':sha(data)}
 if receipt:row.update(exitCode=value['exitCode'],receiptStatus=value['status'],observationMethod=value.get('observationMethod'))
 files.append(row)
for b in bridge:
 p=pathlib.Path(b['finalPath']);raw=p.read_bytes();dest=shots/p.name;dest.write_bytes(raw);files.append({'sourcePath':str(p),'logicalPath':'screenshots/'+p.name,'archivePath':dest.relative_to(root).as_posix(),'category':'screenshot','compression':'identity','rawBytes':len(raw),'rawSha256':sha(raw),'archiveBytes':len(raw),'archiveSha256':sha(raw),'reviewedOriginal':b['reviewedPath'],'byteIdentityBridge':'screenshot-bridge.json'})
changed=[];entries=[]
for l in subprocess.check_output(['git','diff','--name-status',source['base']],cwd=root,text=True).splitlines():p=l.split('\t');entries.append((p[-1],p[0],'git diff --name-status '+source['base']))
for p in subprocess.check_output(['git','ls-files','--others','--exclude-standard'],cwd=root,text=True).splitlines():entries.append((p,'UNTRACKED','git ls-files --others --exclude-standard'))
for p,status,method in entries:
 if p.startswith(('docs/reports/homepage-inquiry-artifacts/','docs/screenshots/homepage-inquiry/')):continue
 raw=(root/p).read_bytes() if (root/p).is_file() else None;changed.append({'path':p,'status':status,'method':method,'bytes':len(raw) if raw is not None else None,'sha256':sha(raw) if raw is not None else None})
c={'capturedAt':now(),'base':source['base'],'headAtCapture':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'scope':'Current batch diff plus untracked files excluding generated evidence. No Git mutation by packager.','files':changed};cp=artifacts/'changed-files.json';cp.write_text(json.dumps(c,ensure_ascii=False,indent=2)+'\n')
for row in files:verify(row)
d={'schemaVersion':1,'task':'Homepage inquiry CTA focused UI','createdAt':now(),'timezone':'Asia/Taipei','source':{'base':source['base'],'fingerprint':source['fingerprint'],'snapshot':'source.json','fingerprintFiles':len(source['files']),'currentMismatches':[]},'changedFiles':{'path':'changed-files.json','count':len(changed),'rawSha256':sha(cp.read_bytes()),'archiveSha256':sha(cp.read_bytes())},'outcomes':{'normal':{'status':normal['status'],'tests':28,'exitCode':0},'originalPages':{'status':first['status'],'passed':28,'failed':1,'exitCode':1,'cause':'Mode-specific trailing slash expectation in QA tool; retained unchanged.'},'correctedPages':{'status':corrected['status'],'tests':29,'exitCode':0},'contractCases':5,'visual':visual['status'],'sourceFilesMatched':129},'scopeLimits':['Verified contact registry is still empty. CTA is inquiry preparation only; no receiving, submission, successful enquiry delivery or response-time claim is established.','The user has not provided point 2. It remains PENDING and is outside this implementation.','This branch is for draft PR review. No merge/deployment/public update is authorized or claimed by this evidence package.','Only Home/About/Contact at five widths and targeted inquiry-control axe were run. No full 15-route browser/136-asset suite, full-page axe, real AT or complete WCAG certification is claimed. Separate smoke covers the 15-route regression.','Visual review originally examined pages-final screenshots; screenshot-bridge.json proves the two corrected screenshots are byte-identical. It is a bridge, not a newly claimed manual view.','Read-only source review evidence is supplied without an outer run-with-evidence.py receipt. Its recorded source commit/blob and findings are preserved; no missing process result is invented.'],'mappingNotes':['logicalPath maps report names to archivePath, including browser-pages-original-result.json.gz and browser-pages-corrected-result.json.gz.','Command receipts remain verbatim under commands/. Original Pages exit 1 is retained beside retest exit 0.','Raw bytes can be recovered by gzip -dc; both raw and archive SHA256 are recorded.','Only current /tmp/xk-inquiry-cta and the one explicit read-only source evidence file are included. Old batches and duplicate screenshots are excluded.','Only pages-corrected PNGs are copied, once, to docs/screenshots/homepage-inquiry/.','Before/after QA tools and their exact SHA boundary are preserved; no application/build change was used to bypass the failed assertion.','Manifest omits its own SHA to avoid a circular hash; changed-files snapshot is separately hashed.'],'securityReview':{'textInputsScanned':len(inputs),'potentialSecretMatches':0,'selection':'Current batch only; no unrelated temp/source PNG bulk, credentials or signed URLs.'},'verification':{'rawAndArchiveSha256RoundTrips':len(files),'sourceFingerprintFilesMatch':129,'screenshotCount':2,'uncompressedExecutableTools':0},'files':files};totals(d);(artifacts/'manifest.json').write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'status':'PACKAGED','manifest':str(artifacts/'manifest.json'),'totals':d['totals'],'changedFiles':len(changed),'sourceFingerprint':source['fingerprint']}))
